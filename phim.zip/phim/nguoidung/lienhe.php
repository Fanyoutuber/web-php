<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Untitled Document</title>
</head>

<body>
<center><h1 class="lienhe"><font color="#000000">GỬI LIÊN HỆ CHO CHÚNG TÔI</font></h1>
    <table>
        <tr>
            <td>

                <span class="lienhe"><font color="#000000">Họ tên (*) :</font></span>

            </td>
            <td>
                <label>
                    <input name="" type="text" size="50px"/>
                </label>
            </td>
        </tr>
        <tr>
            <td>

                <span class="lienhe"><font color="#000000">Email (*) :</font></span>

            </td>
            <td>
                <label>
                    <input name="" type="text" size="50px"/>
                </label>
            </td>
        </tr>
        <tr>
            <td>

                <span class="lienhe"><font color="#000000">Tiêu đề :</font></span>

            </td>
            <td>
                <label>
                    <input name="" type="text" size="50px"/>
                </label>
            </td>
        </tr>
        <tr>
            <td>

                <span class="lienhe"><font color="#000000">Nội dung liên hệ :</font></span>

            </td>
            <td>
                <label>
                    <textarea name="" cols="" rows="" style="height:110px;width:330px;"> </textarea>
                </label>
            </td>
        </tr>

        <tr>
            <td>
                <input name="lienhe" type="button" value="Gửi liên hệ"/>
            </td>
        </tr>
    </table>
</center>

</body>
</html>
