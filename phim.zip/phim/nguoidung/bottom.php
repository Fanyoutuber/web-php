<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table border="0" cellpadding="0" cellspacing="0" align="center">
<tr height="90" align="center"><td colspan="4" width="1000">
 <object width="1000" height="90">
<param value="http://xemphimso.com/img/topbanner.swf" name="movie"/>
<param name="wmode" value="opaque" vmode="transparent"/>
<embed width="1000" height="90" src="quang cao/bannerqc.swf" wmode="opaque" vmode="transparent"/>
</object>
</td></tr>
<tr>
	<td width="200" align="center">
   
    <font color="#CCFFCC" size="+3">Xemphimla.vn</font>    </td>
    <td width="200" align="center">
    Hỗ trợ khách hàng:<br />
    Số điện thoại: 0987678567<br />
    Email:tuongvu@gmail.com<br />
    </td>
</tr>
</table>
</body>
</html>
