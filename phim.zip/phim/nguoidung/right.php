<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Untitled Document</title>
</head>

<body>
<table width="300" border="0" align="left" cellpadding="0" cellspacing="0">
    <tr height="10" align="center">
        <td colspan="2"><span style="color: #FFFFFF; ">
				 <script>
				var mydate = new Date();
                var year = mydate.getYear();
                if (year >= 1000) {
                } else {
                    year += 1900;
                }
                var day = mydate.getDay();
                var month = mydate.getMonth();
                var daym = mydate.getDate();
                if (daym >= 10) {
                } else {
                    daym = "0" + daym;
                }
                var dayarray = new Array("Chủ nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy");
                var montharray = new Array("/1", "/2", "/3", "/4", "/5", "/6", "/7", "/8", "/9", "/10", "/11", "/12");
                document.write("Hôm nay " + dayarray[day] + " Ngày " + daym + "" + montharray[month] + "/" + year + "");
				</script>
                </span>
        </td>
    </tr>
    <tr height="30" align="center">
        <td align="left">
            <img src="images/online.gif"/>
        </td>
        <td><span style="color: #CCCCCC; "><img src="images/luottruycap.gif"/>&nbsp; 150 online</span></td>
    </tr>
    <tr height="40" align="center">
        <td colspan="3">
            <img src="images/RapPhimVN.com__+1.png"/>

        </td>
    </tr>
    <tr height="30" align="center">
        <td colspan="3">
            <label>
                <select name="ctl00$ucMenuLinkWebsite1$ddlMenuLinkWebsite"
                        onchange="if(this.selectedIndex > 0)window.open(this.value); return false;setTimeout(&#39;__doPostBack(\&#39;ctl00$ucMenuLinkWebsite1$ddlMenuLinkWebsite\&#39;,\&#39;\&#39;)&#39;, 0)"
                        style="color:#1C1C1C;font-family:Tahoma;font-size:13px;height:20px;width:150px;padding-top:0px">

                    <option selected="selected" value="---Chọn liên kết---">---Chọn li&#234;n kết---</option>

                    <option value="http://google.com.vn">Google.com.vn</option>

                    <option value="http://www.24h.com">24h.com</option>

                    <option value="http://www.mp3.zing.vn">mp3.zing.vn</option>

                    <option value="http://www.vatgia.com/">vatgia.com</option>


                </select>
            </label>
        </td>
    </tr>

    <tr height="250" align="center">
        <td colspan="2">
            <a href="http://4menshop.com/ao-so-mi-nam.html" title="Áo sơ mi nam" target="_blank">
                <img src="quang cao/4men.gif" height="250" width="300"/>
            </a>
        </td>
    </tr>

    <tr height="250" align="center">
        <td colspan="2" width="300">
            <object width="300" height="250">
                <param value="http://xemphimso.com/img/wingame.swf" name="movie"/>
                <param name="wmode" value="opaque" vmode="transparent"/>
                <embed width="300" height="250" src="quang cao/wingame.jpg" wmode="opaque" vmode="transparent"/>
            </object>
        </td>
    </tr>
    <tr height="10">
        <td colspan="2"></td>
    </tr>
    <tr height="15" align="center">
        <td valign="middle" align="center" colspan="2"><span
                    style="color: #99FFFF; font-size: larger; ">Phim xem nhiều:</span>
        </td>
    </tr>
    <tr height="10">
        <td colspan="2"></td>
    </tr>
    <tr height="100" align="center">
        <td>
            <a href="phimxemnhieu.php?idxemnhieu=11"><img src="upload/2012/nguoi nhen 3.jpg" height="100"
                                                          width="70"/></a>
        </td>
        <td align="left">
            <a href="phimxemnhieu.php?idphimxemnhieu=11"><span style="color: #FFCCCC; ">Người nhện 3</span></a><br/>
            Lượt xem: 560.000
        </td>
    </tr>

    <tr height="100" align="center">
        <td>
            <a href="phimxemnhieu.php?idxemnhieu=11"><img src="upload/2012/nhiem vu cuoi.jpg" height="100" width="70"/></a>
        </td>
        <td align="left">
            <a href="phimxemnhieu.php?idphimxemnhieu=11"><span style="color: #FFCCCC; ">Nhiệm vụ cuối</span></a><br/>
            Lượt xem: 330 000
        </td>
    </tr>
    <tr height="100" align="center">
        <td>
            <a href="phimxemnhieu.php?idxemnhieu=11"><img src="upload/2012/phep thuat 3.jpg" height="100"
                                                          width="70"/></a>
        </td>
        <td align="left">
            <a href="phimxemnhieu.php?idphimxemnhieu=11"><span style="color: #FFCCCC; ">Phép thuật 3</span></a><br/>
            Lượt xem: 250.000
        </td>
    </tr>
    <tr height="100" align="center">
        <td>
            <a href="phimxemnhieu.php?idxemnhieu=11"><img src="upload/2012/phong than.jpeg" height="100"
                                                          width="70"/></a>
        </td>
        <td align="left">
            <a href="phimxemnhieu.php?idphimxemnhieu=11"><span style="color: #FFCCCC; ">Phong thần</span></a><br/>
            Lượt xem: 199.000
        </td>
    </tr>

    <tr height="100" align="center">
        <td>
            <a href="phimxemnhieu.php?idxemnhieu=11"><img src="upload/2012/quai thu vo hinh.jpg" height="100"
                                                          width="70"/></a>
        </td>
        <td align="left">
            <a href="phimxemnhieu.php?idphimxemnhieu=11"><span style="color: #FFCCCC; ">Quái thú vô hình</span></a><br/>
            Lượt xem: 90.000
        </td>
    </tr>
    <tr height="50">
        <td></td>
    </tr>
</table>
</body>
</html>
