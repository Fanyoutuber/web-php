<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link href="css.css" type="text/css" rel="stylesheet"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Web xem phim cực nhanh</title>
</head>

<body>
<table align="center" border="0" width="1000" cellpadding="0" cellspacing="0">
<tr>
<td colspan="2">
<?php
include("top.php");
?>
</td>
</tr>
<tr > 
<td width="700" bgcolor="#333333" valign="top" align="center">
<?php include("id.php")?>
</td>
<td width="300" bgcolor="#333366" align="center" valign="top">
<?php
include("right.php")
?>
</td>
</tr>
<tr height="60">
<td colspan="3" bgcolor="#996600">
<?php
include("bottom.php")
?>
</td>
</tr>
</table>
</body>
</html>
