<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table width="1000" cellpadding="0" cellspacing="0" border="0">
<tr height="100" bgcolor="#9933CC">
<td colspan="3">
<img src="banner/banner%201.jpg" height="296" width="1000" />
</td>
</tr>
<tr height="20" bgcolor="#FFCC99" align="center">
<td>
<marquee behavior="scroll" align="absmiddle" width="750px;">
<font color="#FF0000" size="+3">Quản trị website xemphimpro.vn</font>
</marquee>
</td>
</tr>
</table>
</body>
</html>
