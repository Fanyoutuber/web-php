<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<h1>Chào mừng đến với trang quản lý!</h1>
Hiện tại bạn chưa đăng nhập.<br>
Nếu đăng nhập bạn mới có thể chỉnh sửa website.<br>
<a href="index.php?id=dangnhap">Nhấn vào đây</a> để đăng nhập.
</body>
</html>
