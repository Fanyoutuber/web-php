-- NUKEVIET 4.0
-- Module: Database
-- http://www.nukeviet.vn
--
-- Host: 127.0.0.1
-- Generation Time: April 16, 2024, 07:42 AM GMT
-- Server version: 5.7.28-log
-- PHP Version: 7.0.33

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET SESSION `character_set_client`='utf8mb4';
SET SESSION `character_set_results`='utf8mb4';
SET SESSION `character_set_connection`='utf8mb4';
SET SESSION `collation_connection`='utf8mb4_unicode_ci';
SET NAMES 'utf8mb4';
ALTER DATABASE DEFAULT CHARACTER SET `utf8mb4` COLLATE `utf8mb4_unicode_ci`;

--
-- Database: `vgemmjtp_tancuong`
--


-- ---------------------------------------


--
-- Table structure for table `nv4_authors`
--

DROP TABLE IF EXISTS `nv4_authors`;
CREATE TABLE `nv4_authors` (
  `admin_id` int(10) unsigned NOT NULL,
  `editor` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `lev` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `files_level` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `position` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `main_module` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'siteinfo',
  `admin_theme` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `addtime` int(11) NOT NULL DEFAULT '0',
  `edittime` int(11) NOT NULL DEFAULT '0',
  `is_suspend` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `susp_reason` text  COLLATE utf8mb4_unicode_ci,
  `pre_check_num` varchar(40)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `pre_last_login` int(10) unsigned NOT NULL DEFAULT '0',
  `pre_last_ip` varchar(45)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `pre_last_agent` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `check_num` varchar(40)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `last_login` int(10) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_agent` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_authors`
--

INSERT INTO `nv4_authors` VALUES
(1, 'ckeditor', 1, 'adobe,archives,audio,documents,flash,images,real,video|1|1|1', 'Administrator', 'siteinfo', '', 0, 0, 0, '', '', 0, '', '', 'c25e092f820e19fd6649430b53a617bc', 1713186949, '171.236.126.15', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36');


-- ---------------------------------------


--
-- Table structure for table `nv4_authors_api_credential`
--

DROP TABLE IF EXISTS `nv4_authors_api_credential`;
CREATE TABLE `nv4_authors_api_credential` (
  `admin_id` int(10) unsigned NOT NULL,
  `credential_title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `credential_ident` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `credential_secret` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `credential_ips` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `auth_method` enum('none','password_verify')  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'password_verify' COMMENT 'Phương thức xác thực',
  `api_roles` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `addtime` int(11) NOT NULL DEFAULT '0',
  `edittime` int(11) NOT NULL DEFAULT '0',
  `last_access` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `credential_ident` (`credential_ident`),
  UNIQUE KEY `credential_secret` (`credential_secret`),
  KEY `admin_id` (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci COMMENT='Bảng lưu key API của quản trị';


-- ---------------------------------------


--
-- Table structure for table `nv4_authors_api_role`
--

DROP TABLE IF EXISTS `nv4_authors_api_role`;
CREATE TABLE `nv4_authors_api_role` (
  `role_id` smallint(6) NOT NULL AUTO_INCREMENT,
  `role_title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `role_description` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_data` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `edittime` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`role_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci COMMENT='Bảng lưu quyền truy cập API';


-- ---------------------------------------


--
-- Table structure for table `nv4_authors_config`
--

DROP TABLE IF EXISTS `nv4_authors_config`;
CREATE TABLE `nv4_authors_config` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `keyname` varchar(39)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `begintime` int(10) unsigned NOT NULL DEFAULT '0',
  `endtime` int(10) unsigned NOT NULL DEFAULT '0',
  `notice` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `keyname` (`keyname`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_authors_module`
--

DROP TABLE IF EXISTS `nv4_authors_module`;
CREATE TABLE `nv4_authors_module` (
  `mid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `module` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `lang_key` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` mediumint(9) NOT NULL DEFAULT '0',
  `act_1` tinyint(4) NOT NULL DEFAULT '0',
  `act_2` tinyint(4) NOT NULL DEFAULT '1',
  `act_3` tinyint(4) NOT NULL DEFAULT '1',
  `checksum` varchar(32)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`mid`),
  UNIQUE KEY `module` (`module`)
) ENGINE=MyISAM  AUTO_INCREMENT=13  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_authors_module`
--

INSERT INTO `nv4_authors_module` VALUES
(1, 'siteinfo', 'mod_siteinfo', 1, 1, 1, 1, '9a266e2583662600f6e2f4c5b496c1bf'), 
(2, 'authors', 'mod_authors', 2, 1, 1, 1, '28fe34e7ee6dcb56de4181021b18acca'), 
(3, 'settings', 'mod_settings', 3, 1, 1, 0, '9db1495b7a5a1c9ef0d45b730d8eca95'), 
(4, 'database', 'mod_database', 4, 1, 0, 0, '9ef3b3b242921d92d69955a3cfda0ace'), 
(5, 'webtools', 'mod_webtools', 5, 1, 1, 0, '04cbdec6f26f219e03c1705bcb561338'), 
(6, 'seotools', 'mod_seotools', 6, 1, 1, 0, '1cb412b1505fee3c06466553c5ee2fdd'), 
(7, 'language', 'mod_language', 7, 1, 1, 0, '1cf90d369f7a098a8ebfe3c07938cd5a'), 
(8, 'modules', 'mod_modules', 8, 1, 1, 0, '68a19638a31293b55b5b98cab749d98a'), 
(9, 'themes', 'mod_themes', 9, 1, 1, 0, '518d9a379babd0f6fb9339e4289cab58'), 
(10, 'extensions', 'mod_extensions', 10, 1, 0, 0, '81ef80c5d7b478749198a5a82ae1e890'), 
(11, 'upload', 'mod_upload', 11, 1, 1, 1, '187507fb253a86e6edf1cd19665e6acd'), 
(12, 'zalo', 'mod_zalo', 12, 1, 0, 0, 'd03434befbc7b9d79980c36614fb960c');


-- ---------------------------------------


--
-- Table structure for table `nv4_authors_oauth`
--

DROP TABLE IF EXISTS `nv4_authors_oauth`;
CREATE TABLE `nv4_authors_oauth` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int(10) unsigned NOT NULL COMMENT 'ID của quản trị',
  `oauth_server` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Eg: facebook, google...',
  `oauth_uid` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ID duy nhất ứng với server',
  `oauth_email` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Email',
  `oauth_id` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_id` (`admin_id`,`oauth_server`,`oauth_uid`),
  KEY `oauth_email` (`oauth_email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci COMMENT='Bảng lưu xác thực 2 bước từ oauth của admin';


-- ---------------------------------------


--
-- Table structure for table `nv4_banners_click`
--

DROP TABLE IF EXISTS `nv4_banners_click`;
CREATE TABLE `nv4_banners_click` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bid` mediumint(9) NOT NULL DEFAULT '0',
  `click_time` int(10) unsigned NOT NULL DEFAULT '0',
  `click_day` int(11) NOT NULL,
  `click_ip` varchar(46)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_country` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_browse_key` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_browse_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_os_key` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_os_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_ref` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bid` (`bid`),
  KEY `click_day` (`click_day`),
  KEY `click_ip` (`click_ip`),
  KEY `click_country` (`click_country`),
  KEY `click_browse_key` (`click_browse_key`),
  KEY `click_os_key` (`click_os_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_banners_plans`
--

DROP TABLE IF EXISTS `nv4_banners_plans`;
CREATE TABLE `nv4_banners_plans` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `blang` char(2)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text  COLLATE utf8mb4_unicode_ci,
  `form` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `width` smallint(5) unsigned NOT NULL DEFAULT '0',
  `height` smallint(5) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `require_image` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `uploadtype` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `uploadgroup` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `exp_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_banners_plans`
--

INSERT INTO `nv4_banners_plans` VALUES
(1, '', 'Mid-page ad block', '', 'sequential', 575, 72, 1, 1, 'images', '', 0), 
(2, '', 'Left-column ad block', '', 'sequential', 212, 800, 1, 1, 'images', '', 0), 
(3, '', 'Right-column ad block', '', 'random', 250, 500, 1, 1, 'images', '', 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_banners_rows`
--

DROP TABLE IF EXISTS `nv4_banners_rows`;
CREATE TABLE `nv4_banners_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `clid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `file_name` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_ext` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_mime` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `width` int(10) unsigned NOT NULL DEFAULT '0',
  `height` int(10) unsigned NOT NULL DEFAULT '0',
  `file_alt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imageforswf` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `click_url` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `target` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '_blank',
  `bannerhtml` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `publ_time` int(10) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(10) unsigned NOT NULL DEFAULT '0',
  `hits_total` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `clid` (`clid`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_banners_rows`
--

INSERT INTO `nv4_banners_rows` VALUES
(1, 'Mid-page advertisement', 1, 1, 'webnhanh.jpg', 'png', 'image/jpeg', 575, 72, '', '', 'http://webnhanh.vn', '_blank', '', 1712405092, 1712405092, 0, 0, 1, 1), 
(2, 'Left-column advertisement', 2, 1, 'vinades.jpg', 'jpg', 'image/jpeg', 212, 400, '', '', 'http://vinades.vn', '_blank', '', 1712405092, 1712405092, 0, 0, 1, 2);


-- ---------------------------------------


--
-- Table structure for table `nv4_config`
--

DROP TABLE IF EXISTS `nv4_config`;
CREATE TABLE `nv4_config` (
  `lang` varchar(3)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sys',
  `module` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'global',
  `config_name` varchar(30)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `config_value` text  COLLATE utf8mb4_unicode_ci,
  UNIQUE KEY `lang` (`lang`,`module`,`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_config`
--

INSERT INTO `nv4_config` VALUES
('sys', 'site', 'admin_theme', 'admin_default'), 
('sys', 'site', 'date_pattern', 'l, d/m/Y'), 
('sys', 'site', 'time_pattern', 'H:i'), 
('sys', 'site', 'online_upd', '1'), 
('sys', 'site', 'statistic', '1'), 
('sys', 'site', 'site_phone', ''), 
('sys', 'site', 'mailer_mode', 'mail'), 
('sys', 'site', 'smtp_host', 'smtp.gmail.com'), 
('sys', 'site', 'smtp_ssl', '1'), 
('sys', 'site', 'smtp_port', '465'), 
('sys', 'site', 'verify_peer_ssl', '1'), 
('sys', 'site', 'verify_peer_name_ssl', '1'), 
('sys', 'site', 'smtp_username', 'user@gmail.com'), 
('sys', 'site', 'smtp_password', ''), 
('sys', 'site', 'sender_name', ''), 
('sys', 'site', 'sender_email', ''), 
('sys', 'site', 'reply_name', ''), 
('sys', 'site', 'reply_email', ''), 
('sys', 'site', 'force_sender', '0'), 
('sys', 'site', 'force_reply', '0'), 
('sys', 'site', 'notify_email_error', '0'), 
('sys', 'site', 'googleAnalyticsID', ''), 
('sys', 'site', 'googleAnalyticsSetDomainName', '0'), 
('sys', 'site', 'googleAnalyticsMethod', 'classic'), 
('sys', 'site', 'googleAnalytics4ID', ''), 
('sys', 'site', 'searchEngineUniqueID', ''), 
('sys', 'site', 'zaloOfficialAccountID', ''), 
('sys', 'site', 'zaloAppID', ''), 
('sys', 'site', 'zaloAppSecretKey', ''), 
('sys', 'site', 'zaloOAAccessToken', ''), 
('sys', 'site', 'zaloOARefreshToken', ''), 
('sys', 'site', 'zaloOAAccessTokenTime', '0'), 
('sys', 'site', 'metaTagsOgp', '1'), 
('sys', 'site', 'pageTitleMode', 'pagetitle'), 
('sys', 'site', 'description_length', '170'), 
('sys', 'site', 'nv_unickmin', '4'), 
('sys', 'site', 'nv_unickmax', '20'), 
('sys', 'site', 'nv_upassmin', '8'), 
('sys', 'site', 'nv_upassmax', '32'), 
('sys', 'site', 'dir_forum', ''), 
('sys', 'site', 'nv_unick_type', '4'), 
('sys', 'site', 'nv_upass_type', '3'), 
('sys', 'site', 'allowmailchange', '1'), 
('sys', 'site', 'allowuserpublic', '1'), 
('sys', 'site', 'allowquestion', '0'), 
('sys', 'site', 'allowloginchange', '0'), 
('sys', 'site', 'allowuserlogin', '1'), 
('sys', 'site', 'allowuserloginmulti', '0'), 
('sys', 'site', 'allowuserreg', '2'), 
('sys', 'site', 'is_user_forum', '0'), 
('sys', 'site', 'openid_servers', ''), 
('sys', 'site', 'openid_processing', 'connect,create,auto'), 
('sys', 'site', 'user_check_pass_time', '1800'), 
('sys', 'site', 'auto_login_after_reg', '1'), 
('sys', 'site', 'whoviewuser', '2'), 
('sys', 'site', 'ssl_https', '0'), 
('sys', 'site', 'facebook_client_id', ''), 
('sys', 'site', 'facebook_client_secret', ''), 
('sys', 'site', 'google_client_id', ''), 
('sys', 'site', 'google_client_secret', ''), 
('sys', 'site', 'referer_blocker', '1'), 
('sys', 'site', 'private_site', '0'), 
('sys', 'site', 'max_user_admin', '0'), 
('sys', 'site', 'max_user_number', '0'), 
('sys', 'site', 'captcha_area', 'r,m,p'), 
('sys', 'site', 'captcha_type', 'captcha'), 
('sys', 'site', 'dkim_included', 'sendmail,mail'), 
('sys', 'site', 'smime_included', 'sendmail,mail'), 
('sys', 'site', 'nv_csp', 'script-src &#039;self&#039; *.google.com *.google-analytics.com *.googletagmanager.com *.gstatic.com *.facebook.com *.facebook.net *.twitter.com *.zalo.me *.zaloapp.com *.tawk.to *.cloudflareinsights.com &#039;unsafe-inline&#039; &#039;unsafe-hashes&#039; &#039;unsafe-eval&#039;;object-src &#039;self&#039;;style-src &#039;self&#039; *.google.com *.googleapis.com *.tawk.to &#039;unsafe-inline&#039;;img-src &#039;self&#039; data: *.twitter.com *.google.com *.googleapis.com *.gstatic.com *.facebook.com tawk.link *.tawk.to static.nukeviet.vn;media-src &#039;self&#039; *.tawk.to;frame-src &#039;self&#039; *.google.com *.youtube.com *.facebook.com *.facebook.net *.twitter.com *.zalo.me;font-src &#039;self&#039; *.googleapis.com *.gstatic.com *.tawk.to;connect-src &#039;self&#039; *.zalo.me *.tawk.to wss://*.tawk.to;form-action &#039;self&#039; *.google.com;base-uri &#039;self&#039;;'), 
('sys', 'site', 'nv_csp_act', '0'), 
('sys', 'site', 'nv_rp', 'no-referrer-when-downgrade, strict-origin-when-cross-origin'), 
('sys', 'site', 'nv_rp_act', '1'), 
('sys', 'site', 'ogp_image', ''), 
('sys', 'site', 'over_capacity', '0'), 
('sys', 'site', 'show_folder_size', '0'), 
('sys', 'define', 'nv_gfx_num', '6'), 
('sys', 'global', 'closed_site', '0'), 
('sys', 'global', 'site_reopening_time', '0'), 
('sys', 'global', 'notification_active', '1'), 
('sys', 'global', 'notification_autodel', '15'), 
('sys', 'global', 'site_keywords', 'NukeViet, portal, mysql, php'), 
('sys', 'global', 'block_admin_ip', '0'), 
('sys', 'global', 'admfirewall', '0'), 
('sys', 'global', 'dump_autobackup', '1'), 
('sys', 'global', 'dump_backup_ext', 'gz'), 
('sys', 'global', 'dump_backup_day', '30'), 
('sys', 'global', 'file_allowed_ext', 'adobe,archives,audio,documents,flash,images,real,video'), 
('sys', 'global', 'forbid_extensions', 'htm,html,htmls,js,php,php3,php4,php5,phtml,inc'), 
('sys', 'global', 'forbid_mimes', 'application/ecmascript,application/javascript,application/x-javascript,text/ecmascript,text/html,text/javascript,application/x-httpd-php,application/x-httpd-php-source,application/php,application/x-php,text/php,text/x-php'), 
('sys', 'global', 'nv_max_size', '52428800'), 
('sys', 'global', 'nv_overflow_size', '0'), 
('sys', 'global', 'upload_checking_mode', 'strong'), 
('sys', 'global', 'upload_alt_require', '1'), 
('sys', 'global', 'upload_auto_alt', '1'), 
('sys', 'global', 'upload_chunk_size', '0'), 
('sys', 'global', 'useactivate', '2'), 
('sys', 'global', 'allow_sitelangs', 'vi'), 
('sys', 'global', 'read_type', '0'), 
('sys', 'global', 'rewrite_enable', '1'), 
('sys', 'global', 'rewrite_optional', '1'), 
('sys', 'global', 'rewrite_endurl', '/'), 
('sys', 'global', 'rewrite_exturl', '.html'), 
('sys', 'global', 'rewrite_op_mod', 'news'), 
('sys', 'global', 'autocheckupdate', '1'), 
('sys', 'global', 'autoupdatetime', '24'), 
('sys', 'global', 'gzip_method', '1'), 
('sys', 'global', 'authors_detail_main', '0'), 
('sys', 'global', 'spadmin_add_admin', '1'), 
('sys', 'global', 'timestamp', '1713189588'), 
('sys', 'global', 'version', '4.5.04'), 
('sys', 'global', 'cookie_httponly', '1'), 
('sys', 'global', 'admin_check_pass_time', '1800'), 
('sys', 'global', 'cookie_secure', '0'), 
('sys', 'global', 'cookie_SameSite', 'Lax'), 
('sys', 'global', 'cookie_share', '0'), 
('sys', 'global', 'is_flood_blocker', '1'), 
('sys', 'global', 'max_requests_60', '40'), 
('sys', 'global', 'max_requests_300', '150'), 
('sys', 'global', 'is_login_blocker', '1'), 
('sys', 'global', 'login_number_tracking', '5'), 
('sys', 'global', 'login_time_tracking', '5'), 
('sys', 'global', 'login_time_ban', '30'), 
('sys', 'global', 'nv_display_errors_list', '1'), 
('sys', 'global', 'display_errors_list', '1'), 
('sys', 'global', 'nv_auto_resize', '1'), 
('sys', 'global', 'dump_interval', '1'), 
('sys', 'global', 'nv_static_url', ''), 
('sys', 'global', 'cdn_url', ''), 
('sys', 'global', 'two_step_verification', '0'), 
('sys', 'global', 'admin_2step_opt', 'code'), 
('sys', 'global', 'admin_2step_default', 'code'), 
('sys', 'global', 'recaptcha_sitekey', ''), 
('sys', 'global', 'recaptcha_secretkey', ''), 
('sys', 'global', 'recaptcha_type', 'image'), 
('sys', 'global', 'recaptcha_ver', '2'), 
('sys', 'global', 'users_special', '0'), 
('sys', 'global', 'crosssite_restrict', '1'), 
('sys', 'global', 'crosssite_valid_domains', ''), 
('sys', 'global', 'crosssite_valid_ips', ''), 
('sys', 'global', 'crossadmin_restrict', '1'), 
('sys', 'global', 'crossadmin_valid_domains', ''), 
('sys', 'global', 'crossadmin_valid_ips', ''), 
('sys', 'global', 'domains_whitelist', '[\"youtube.com\",\"www.youtube.com\",\"google.com\",\"www.google.com\",\"drive.google.com\",\"docs.google.com\"]'), 
('sys', 'global', 'domains_restrict', '1'), 
('sys', 'global', 'remote_api_access', '0'), 
('sys', 'global', 'remote_api_log', '1'), 
('sys', 'global', 'allow_null_origin', '0'), 
('sys', 'global', 'ip_allow_null_origin', ''), 
('sys', 'global', 'cookie_notice_popup', '0'), 
('sys', 'global', 'XSSsanitize', '1'), 
('sys', 'global', 'admin_XSSsanitize', '1'), 
('sys', 'define', 'nv_gfx_width', '150'), 
('sys', 'define', 'nv_gfx_height', '40'), 
('sys', 'define', 'nv_max_width', '1500'), 
('sys', 'define', 'nv_max_height', '1500'), 
('sys', 'define', 'nv_mobile_mode_img', '480'), 
('sys', 'define', 'nv_live_cookie_time', '31104000'), 
('sys', 'define', 'nv_live_session_time', '0'), 
('sys', 'define', 'nv_anti_iframe', '1'), 
('sys', 'define', 'nv_anti_agent', '0'), 
('sys', 'define', 'nv_allowed_html_tags', 'embed, object, param, a, b, blockquote, br, caption, col, colgroup, div, em, h1, h2, h3, h4, h5, h6, hr, i, img, li, p, span, strong, s, sub, sup, table, tbody, td, th, tr, u, ul, ol, iframe, figure, figcaption, video, audio, source, track, code, pre'), 
('sys', 'define', 'nv_debug', '0'), 
('vi', 'global', 'site_domain', ''), 
('vi', 'global', 'site_name', 'An Thái Tân Cương Trà - Chè Thượng Hạng từ Thái Nguyên'), 
('vi', 'global', 'site_logo', 'uploads/logo-an-thai-tan-cuong-tra_1.png'), 
('vi', 'global', 'site_banner', ''), 
('vi', 'global', 'site_favicon', 'uploads/favicon_2.png'), 
('vi', 'global', 'site_description', 'Công ty TNHH Trà Tân Cương Hoàng Đạt - Chè Thượng Hạng Thái Nguyên'), 
('vi', 'global', 'site_keywords', 'chè thái nguyên, trà thái nguyên, che tan cuong thai nguyen, trà tân cương thái nguyên'), 
('vi', 'global', 'theme_type', 'r,d'), 
('vi', 'global', 'site_theme', 'default'), 
('vi', 'global', 'preview_theme', ''), 
('vi', 'global', 'user_allowed_theme', ''), 
('vi', 'global', 'mobile_theme', ''), 
('vi', 'global', 'site_home_module', 'san-pham'), 
('vi', 'global', 'switch_mobi_des', '0'), 
('vi', 'global', 'upload_logo', ''), 
('vi', 'global', 'upload_logo_pos', 'bottomRight'), 
('vi', 'global', 'autologosize1', '50'), 
('vi', 'global', 'autologosize2', '40'), 
('vi', 'global', 'autologosize3', '30'), 
('vi', 'global', 'autologomod', ''), 
('vi', 'global', 'name_show', '0'), 
('vi', 'global', 'cronjobs_next_time', '1713253637'), 
('vi', 'global', 'disable_site_content', 'Vì lý do kỹ thuật website tạm ngưng hoạt động. Thành thật xin lỗi các bạn vì sự bất tiện này!'), 
('vi', 'seotools', 'prcservice', ''), 
('vi', 'about', 'auto_postcomm', '1'), 
('vi', 'about', 'allowed_comm', '-1'), 
('vi', 'about', 'view_comm', '6'), 
('vi', 'about', 'setcomm', '4'), 
('vi', 'about', 'activecomm', '0'), 
('vi', 'about', 'emailcomm', '0'), 
('vi', 'about', 'adminscomm', ''), 
('vi', 'about', 'sortcomm', '0'), 
('vi', 'about', 'captcha_area_comm', '1'), 
('vi', 'about', 'perpagecomm', '5'), 
('vi', 'about', 'timeoutcomm', '360'), 
('vi', 'about', 'allowattachcomm', '0'), 
('vi', 'about', 'alloweditorcomm', '0'), 
('vi', 'news', 'indexfile', 'viewcat_main_right'), 
('vi', 'news', 'mobile_indexfile', 'viewcat_page_new'), 
('vi', 'news', 'per_page', '20'), 
('vi', 'news', 'st_links', '10'), 
('vi', 'news', 'homewidth', '100'), 
('vi', 'news', 'homeheight', '150'), 
('vi', 'news', 'blockwidth', '70'), 
('vi', 'news', 'blockheight', '75'), 
('vi', 'news', 'imagefull', '460'), 
('vi', 'news', 'copyright', 'Chú ý: Việc đăng lại bài viết trên ở website hoặc các phương tiện truyền thông khác mà không ghi rõ nguồn http://nukeviet.vn là vi phạm bản quyền'), 
('vi', 'news', 'showtooltip', '1'), 
('vi', 'news', 'tooltip_position', 'bottom'), 
('vi', 'news', 'tooltip_length', '150'), 
('vi', 'news', 'showhometext', '1'), 
('vi', 'news', 'timecheckstatus', '0'), 
('vi', 'news', 'config_source', '0'), 
('vi', 'news', 'show_no_image', ''), 
('vi', 'news', 'allowed_rating', '1'), 
('vi', 'news', 'allowed_rating_point', '1'), 
('vi', 'news', 'facebookappid', ''), 
('vi', 'news', 'socialbutton', 'facebook,twitter'), 
('vi', 'news', 'alias_lower', '1'), 
('vi', 'news', 'tags_alias', '0'), 
('vi', 'news', 'auto_tags', '0'), 
('vi', 'news', 'tags_remind', '1'), 
('vi', 'news', 'keywords_tag', '1'), 
('vi', 'news', 'copy_news', '0'), 
('vi', 'news', 'structure_upload', 'Ym'), 
('vi', 'news', 'imgposition', '2'), 
('vi', 'news', 'htmlhometext', '0'), 
('vi', 'news', 'order_articles', '0'), 
('vi', 'news', 'identify_cat_change', '0'), 
('vi', 'news', 'active_history', '0'), 
('vi', 'news', 'hide_author', '0'), 
('vi', 'news', 'hide_inauthor', '0'), 
('vi', 'news', 'elas_use', '0'), 
('vi', 'news', 'elas_host', ''), 
('vi', 'news', 'elas_port', '9200'), 
('vi', 'news', 'elas_index', ''), 
('vi', 'news', 'instant_articles_active', '0'), 
('vi', 'news', 'instant_articles_template', 'default'), 
('vi', 'news', 'instant_articles_httpauth', '0'), 
('vi', 'news', 'instant_articles_username', ''), 
('vi', 'news', 'instant_articles_password', ''), 
('vi', 'news', 'instant_articles_livetime', '60'), 
('vi', 'news', 'instant_articles_gettime', '120'), 
('vi', 'news', 'instant_articles_auto', '1'), 
('vi', 'news', 'auto_postcomm', '1'), 
('vi', 'news', 'allowed_comm', '-1'), 
('vi', 'news', 'view_comm', '6'), 
('vi', 'news', 'setcomm', '4'), 
('vi', 'news', 'activecomm', '1'), 
('vi', 'news', 'emailcomm', '0'), 
('vi', 'news', 'adminscomm', ''), 
('vi', 'news', 'sortcomm', '0'), 
('vi', 'news', 'captcha_area_comm', '1'), 
('vi', 'news', 'perpagecomm', '5'), 
('vi', 'news', 'timeoutcomm', '360'), 
('vi', 'news', 'allowattachcomm', '0'), 
('vi', 'news', 'alloweditorcomm', '0'), 
('vi', 'news', 'frontend_edit_alias', '0'), 
('vi', 'news', 'frontend_edit_layout', '1'), 
('vi', 'news', 'captcha_type', 'captcha'), 
('vi', 'contact', 'bodytext', 'Để không ngừng nâng cao chất lượng dịch vụ và đáp ứng tốt hơn nữa các yêu cầu của Quý khách, chúng tôi mong muốn nhận được các thông tin phản hồi. Nếu Quý khách có bất kỳ thắc mắc hoặc đóng góp nào, xin vui lòng liên hệ với chúng tôi theo thông tin dưới đây. Chúng tôi sẽ phản hồi lại Quý khách trong thời gian sớm nhất.'), 
('vi', 'contact', 'sendcopymode', '0'), 
('vi', 'contact', 'captcha_type', 'captcha'), 
('vi', 'voting', 'difftimeout', '3600'), 
('vi', 'voting', 'captcha_type', 'captcha'), 
('sys', 'banners', 'captcha_type', 'captcha'), 
('vi', 'page', 'auto_postcomm', '1'), 
('vi', 'page', 'allowed_comm', '-1'), 
('vi', 'page', 'view_comm', '6'), 
('vi', 'page', 'setcomm', '4'), 
('vi', 'page', 'activecomm', '0'), 
('vi', 'page', 'emailcomm', '0'), 
('vi', 'page', 'adminscomm', ''), 
('vi', 'page', 'sortcomm', '0'), 
('vi', 'page', 'captcha_area_comm', '1'), 
('vi', 'page', 'perpagecomm', '5'), 
('vi', 'page', 'timeoutcomm', '360'), 
('vi', 'page', 'allowattachcomm', '0'), 
('vi', 'page', 'alloweditorcomm', '0'), 
('vi', 'comment', 'captcha_type', 'captcha'), 
('vi', 'siteterms', 'auto_postcomm', '1'), 
('vi', 'siteterms', 'allowed_comm', '-1'), 
('vi', 'siteterms', 'view_comm', '6'), 
('vi', 'siteterms', 'setcomm', '4'), 
('vi', 'siteterms', 'activecomm', '0'), 
('vi', 'siteterms', 'emailcomm', '0'), 
('vi', 'siteterms', 'adminscomm', ''), 
('vi', 'siteterms', 'sortcomm', '0'), 
('vi', 'siteterms', 'captcha_area_comm', '1'), 
('vi', 'siteterms', 'perpagecomm', '5'), 
('vi', 'siteterms', 'timeoutcomm', '360'), 
('vi', 'siteterms', 'allowattachcomm', '0'), 
('vi', 'siteterms', 'alloweditorcomm', '0'), 
('vi', 'freecontent', 'next_execute', '0'), 
('sys', 'site', 'statistics_timezone', 'Asia/Bangkok'), 
('sys', 'site', 'site_email', 'webmaster@anthaitra.vn'), 
('sys', 'global', 'error_set_logs', '1'), 
('sys', 'global', 'error_send_email', 'webmaster@anthaitra.vn'), 
('sys', 'global', 'site_lang', 'vi'), 
('sys', 'global', 'my_domains', 'anthaitra.vn'), 
('sys', 'global', 'cookie_prefix', 'nv4'), 
('sys', 'global', 'session_prefix', 'nv4s_q19Q0C'), 
('sys', 'global', 'site_timezone', 'byCountry'), 
('sys', 'global', 'proxy_blocker', '0'), 
('sys', 'global', 'str_referer_blocker', '0'), 
('sys', 'global', 'lang_multi', '0'), 
('sys', 'global', 'lang_geo', '0'), 
('sys', 'global', 'ftp_server', 'localhost'), 
('sys', 'global', 'ftp_port', '21'), 
('sys', 'global', 'ftp_user_name', ''), 
('sys', 'global', 'ftp_user_pass', 'V0YUvh9bm1FtGbbHcSKcwQ,,'), 
('sys', 'global', 'ftp_path', '/'), 
('sys', 'global', 'ftp_check_login', '0'), 
('vi', 'san-pham', 'groups_notify', '3'), 
('vi', 'san-pham', 'template_active', '1'), 
('vi', 'san-pham', 'group_price', ''), 
('vi', 'san-pham', 'review_captcha', '1'), 
('vi', 'san-pham', 'image_size', '300x300'), 
('vi', 'san-pham', 'home_data', 'cat'), 
('vi', 'san-pham', 'home_view', 'viewgrid'), 
('vi', 'san-pham', 'per_page', '30'), 
('vi', 'san-pham', 'per_row', '4'), 
('vi', 'san-pham', 'money_unit', 'VND'), 
('vi', 'san-pham', 'weight_unit', 'g'), 
('vi', 'san-pham', 'post_auto_member', '0'), 
('vi', 'san-pham', 'auto_check_order', '1'), 
('vi', 'san-pham', 'format_order_id', 'S%06s'), 
('vi', 'san-pham', 'format_code_id', 'S%06s'), 
('vi', 'san-pham', 'facebookappid', ''), 
('vi', 'san-pham', 'active_guest_order', '1'), 
('vi', 'san-pham', 'active_showhomtext', '1'), 
('vi', 'san-pham', 'active_order', '1'), 
('vi', 'san-pham', 'active_order_popup', '1'), 
('vi', 'san-pham', 'active_order_non_detail', '1'), 
('vi', 'san-pham', 'active_price', '1'), 
('vi', 'san-pham', 'active_order_number', '1'), 
('vi', 'san-pham', 'order_day', '0'), 
('vi', 'san-pham', 'order_nexttime', '0'), 
('vi', 'san-pham', 'active_payment', '1'), 
('vi', 'san-pham', 'groups_price', '3'), 
('vi', 'san-pham', 'active_tooltip', '0'), 
('vi', 'san-pham', 'timecheckstatus', '0'), 
('vi', 'san-pham', 'show_product_code', '0'), 
('vi', 'san-pham', 'show_compare', '0'), 
('vi', 'san-pham', 'show_displays', '0'), 
('vi', 'san-pham', 'use_shipping', '1'), 
('vi', 'san-pham', 'use_coupons', '0'), 
('vi', 'san-pham', 'active_wishlist', '0'), 
('vi', 'san-pham', 'active_gift', '0'), 
('vi', 'san-pham', 'active_warehouse', '0'), 
('vi', 'san-pham', 'tags_alias', '0'), 
('vi', 'san-pham', 'auto_tags', '1'), 
('vi', 'san-pham', 'tags_remind', '0'), 
('vi', 'san-pham', 'point_active', '0'), 
('vi', 'san-pham', 'point_conversion', '0'), 
('vi', 'san-pham', 'point_new_order', '0'), 
('vi', 'san-pham', 'money_to_point', '0'), 
('vi', 'san-pham', 'review_active', '1'), 
('vi', 'san-pham', 'review_check', '1'), 
('vi', 'gioi-thieu', 'auto_postcomm', '1'), 
('vi', 'gioi-thieu', 'allowed_comm', '-1'), 
('vi', 'gioi-thieu', 'view_comm', '6'), 
('vi', 'gioi-thieu', 'setcomm', '4'), 
('vi', 'gioi-thieu', 'activecomm', '1'), 
('vi', 'gioi-thieu', 'emailcomm', '0'), 
('vi', 'gioi-thieu', 'adminscomm', ''), 
('vi', 'gioi-thieu', 'sortcomm', '0'), 
('vi', 'gioi-thieu', 'captcha_area_comm', '1'), 
('vi', 'gioi-thieu', 'perpagecomm', '5'), 
('vi', 'gioi-thieu', 'timeoutcomm', '360'), 
('vi', 'gioi-thieu', 'allowattachcomm', '0'), 
('vi', 'gioi-thieu', 'alloweditorcomm', '0'), 
('vi', 'lien-he', 'bodytext', ''), 
('vi', 'lien-he', 'sendcopymode', '0'), 
('vi', 'lien-he', 'captcha_type', 'captcha'), 
('vi', 'tin-tuc', 'instant_articles_template', 'default'), 
('vi', 'tin-tuc', 'instant_articles_active', '0'), 
('vi', 'tin-tuc', 'active_history', '0'), 
('vi', 'tin-tuc', 'hide_author', '0'), 
('vi', 'tin-tuc', 'hide_inauthor', '0'), 
('vi', 'tin-tuc', 'elas_use', '0'), 
('vi', 'tin-tuc', 'elas_host', ''), 
('vi', 'tin-tuc', 'per_page', '20'), 
('vi', 'tin-tuc', 'st_links', '10'), 
('vi', 'tin-tuc', 'homewidth', '300'), 
('vi', 'tin-tuc', 'homeheight', '200'), 
('vi', 'tin-tuc', 'blockwidth', '70'), 
('vi', 'tin-tuc', 'blockheight', '75'), 
('vi', 'tin-tuc', 'imagefull', '460'), 
('vi', 'tin-tuc', 'copyright', ''), 
('vi', 'tin-tuc', 'showtooltip', '0'), 
('vi', 'tin-tuc', 'tooltip_position', 'bottom'), 
('vi', 'tin-tuc', 'tooltip_length', '150'), 
('vi', 'tin-tuc', 'showhometext', '1'), 
('vi', 'tin-tuc', 'timecheckstatus', '0'), 
('vi', 'tin-tuc', 'config_source', '0'), 
('vi', 'tin-tuc', 'show_no_image', ''), 
('vi', 'tin-tuc', 'allowed_rating', '1'), 
('vi', 'tin-tuc', 'allowed_rating_point', '1'), 
('vi', 'tin-tuc', 'facebookappid', ''), 
('vi', 'tin-tuc', 'socialbutton', ''), 
('vi', 'tin-tuc', 'alias_lower', '1'), 
('vi', 'tin-tuc', 'tags_alias', '0'), 
('vi', 'tin-tuc', 'auto_tags', '0'), 
('vi', 'tin-tuc', 'tags_remind', '1'), 
('vi', 'tin-tuc', 'keywords_tag', '1'), 
('vi', 'tin-tuc', 'copy_news', '0'), 
('vi', 'tin-tuc', 'structure_upload', 'Ym'), 
('vi', 'tin-tuc', 'imgposition', '2'), 
('vi', 'tin-tuc', 'htmlhometext', '0'), 
('vi', 'tin-tuc', 'order_articles', '0'), 
('vi', 'tin-tuc', 'indexfile', 'viewcat_page_new'), 
('vi', 'tin-tuc', 'mobile_indexfile', 'viewcat_page_new'), 
('vi', 'tin-tuc', 'elas_port', '9200'), 
('vi', 'tin-tuc', 'elas_index', ''), 
('vi', 'tin-tuc', 'identify_cat_change', '0'), 
('vi', 'tin-tuc', 'instant_articles_gettime', '120'), 
('vi', 'tin-tuc', 'instant_articles_httpauth', '0'), 
('vi', 'tin-tuc', 'instant_articles_username', ''), 
('vi', 'tin-tuc', 'instant_articles_password', ''), 
('vi', 'tin-tuc', 'instant_articles_livetime', '60'), 
('vi', 'tin-tuc', 'instant_articles_auto', '1'), 
('vi', 'tin-tuc', 'auto_postcomm', '1'), 
('vi', 'tin-tuc', 'allowed_comm', '-1'), 
('vi', 'tin-tuc', 'view_comm', '6'), 
('vi', 'tin-tuc', 'setcomm', '4'), 
('vi', 'tin-tuc', 'activecomm', '1'), 
('vi', 'tin-tuc', 'emailcomm', '0'), 
('vi', 'tin-tuc', 'adminscomm', ''), 
('vi', 'tin-tuc', 'sortcomm', '0'), 
('vi', 'tin-tuc', 'captcha_area_comm', '1'), 
('vi', 'tin-tuc', 'perpagecomm', '5'), 
('vi', 'tin-tuc', 'timeoutcomm', '360'), 
('vi', 'tin-tuc', 'allowattachcomm', '0'), 
('vi', 'tin-tuc', 'alloweditorcomm', '0'), 
('vi', 'tin-tuc', 'frontend_edit_alias', '0'), 
('vi', 'tin-tuc', 'frontend_edit_layout', '1'), 
('vi', 'tin-tuc', 'captcha_type', 'captcha'), 
('vi', 'thong-tin', 'auto_postcomm', '1'), 
('vi', 'thong-tin', 'allowed_comm', '-1'), 
('vi', 'thong-tin', 'view_comm', '6'), 
('vi', 'thong-tin', 'setcomm', '4'), 
('vi', 'thong-tin', 'activecomm', '1'), 
('vi', 'thong-tin', 'emailcomm', '0'), 
('vi', 'thong-tin', 'adminscomm', ''), 
('vi', 'thong-tin', 'sortcomm', '0'), 
('vi', 'thong-tin', 'captcha_area_comm', '1'), 
('vi', 'thong-tin', 'perpagecomm', '5'), 
('vi', 'thong-tin', 'timeoutcomm', '360'), 
('vi', 'thong-tin', 'allowattachcomm', '0'), 
('vi', 'thong-tin', 'alloweditorcomm', '0'), 
('vi', 'san-pham', 'download_active', '0'), 
('vi', 'san-pham', 'download_groups', '6'), 
('vi', 'san-pham', 'saleprice_active', '0'), 
('vi', 'san-pham', 'sortdefault', '1'), 
('vi', 'san-pham', 'alias_lower', '1'), 
('vi', 'san-pham', 'auto_postcomm', '1'), 
('vi', 'san-pham', 'allowed_comm', '-1'), 
('vi', 'san-pham', 'view_comm', '6'), 
('vi', 'san-pham', 'setcomm', '4'), 
('vi', 'san-pham', 'activecomm', '1'), 
('vi', 'san-pham', 'emailcomm', '0'), 
('vi', 'san-pham', 'adminscomm', ''), 
('vi', 'san-pham', 'sortcomm', '0'), 
('vi', 'san-pham', 'captcha', '1'), 
('vi', 'san-pham', 'allowattachcomm', '0'), 
('vi', 'san-pham', 'alloweditorcomm', '0'), 
('vi', 'san-pham', 'captcha_area_comm', '1'), 
('vi', 'san-pham', 'captcha_type_comm', 'captcha'), 
('vi', 'san-pham', 'captcha_type', 'captcha');


-- ---------------------------------------


--
-- Table structure for table `nv4_cookies`
--

DROP TABLE IF EXISTS `nv4_cookies`;
CREATE TABLE `nv4_cookies` (
  `name` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `value` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `domain` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `expires` int(11) NOT NULL DEFAULT '0',
  `secure` tinyint(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `cookiename` (`name`,`domain`,`path`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_cookies`
--

INSERT INTO `nv4_cookies` VALUES
('nv4c_b1Sp_u_lang', 'YpTSHDtzEZZlnKC1-4-mDQ,,', '.api.nukeviet.vn', '/', 1743509642, 0), 
('nv4c_b1Sp_statistic_vi', 'QbjnvblSnFiCwxgH1KvA_Q,,', '.api.nukeviet.vn', '/', 1712407442, 0), 
('nv4c_b1Sp_nvvithemever', 'y6z0B4S1YKW4aqQyD0bnVQ,,', '.api.nukeviet.vn', '/', 1743509675, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_counter`
--

DROP TABLE IF EXISTS `nv4_counter`;
CREATE TABLE `nv4_counter` (
  `c_type` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `c_val` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_update` int(11) NOT NULL DEFAULT '0',
  `c_count` int(10) unsigned NOT NULL DEFAULT '0',
  `vi_count` int(10) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `c_type` (`c_type`,`c_val`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_counter`
--

INSERT INTO `nv4_counter` VALUES
('c_time', 'start', 0, 0, 0), 
('c_time', 'last', 0, 1713251892, 0), 
('total', 'hits', 1713251892, 252, 252), 
('year', '2024', 1713251892, 252, 252), 
('year', '2025', 0, 0, 0), 
('year', '2026', 0, 0, 0), 
('year', '2027', 0, 0, 0), 
('year', '2028', 0, 0, 0), 
('year', '2029', 0, 0, 0), 
('year', '2030', 0, 0, 0), 
('year', '2031', 0, 0, 0), 
('year', '2032', 0, 0, 0), 
('month', 'Jan', 0, 0, 0), 
('month', 'Feb', 0, 0, 0), 
('month', 'Mar', 0, 0, 0), 
('month', 'Apr', 1713251892, 252, 252), 
('month', 'May', 0, 0, 0), 
('month', 'Jun', 0, 0, 0), 
('month', 'Jul', 0, 0, 0), 
('month', 'Aug', 0, 0, 0), 
('month', 'Sep', 0, 0, 0), 
('month', 'Oct', 0, 0, 0), 
('month', 'Nov', 0, 0, 0), 
('month', 'Dec', 0, 0, 0), 
('day', '01', 0, 0, 0), 
('day', '02', 0, 0, 0), 
('day', '03', 0, 0, 0), 
('day', '04', 0, 0, 0), 
('day', '05', 0, 0, 0), 
('day', '06', 1712406961, 2, 2), 
('day', '07', 0, 0, 0), 
('day', '08', 1712567842, 16, 16), 
('day', '09', 1712670783, 16, 16), 
('day', '10', 1712743038, 19, 19), 
('day', '11', 1712854441, 70, 70), 
('day', '12', 1712940162, 57, 57), 
('day', '13', 1713026079, 33, 33), 
('day', '14', 1713104426, 11, 11), 
('day', '15', 1713196554, 24, 24), 
('day', '16', 1713251892, 4, 4), 
('day', '17', 0, 0, 0), 
('day', '18', 0, 0, 0), 
('day', '19', 0, 0, 0), 
('day', '20', 0, 0, 0), 
('day', '21', 0, 0, 0), 
('day', '22', 0, 0, 0), 
('day', '23', 0, 0, 0), 
('day', '24', 0, 0, 0), 
('day', '25', 0, 0, 0), 
('day', '26', 0, 0, 0), 
('day', '27', 0, 0, 0), 
('day', '28', 0, 0, 0), 
('day', '29', 0, 0, 0), 
('day', '30', 0, 0, 0), 
('day', '31', 0, 0, 0), 
('dayofweek', 'Sunday', 1713104426, 11, 11), 
('dayofweek', 'Monday', 1713196554, 40, 40), 
('dayofweek', 'Tuesday', 1713251892, 20, 20), 
('dayofweek', 'Wednesday', 1712743038, 19, 19), 
('dayofweek', 'Thursday', 1712854441, 70, 70), 
('dayofweek', 'Friday', 1712940162, 57, 57), 
('dayofweek', 'Saturday', 1713026079, 35, 35), 
('hour', '00', 1712856943, 0, 0), 
('hour', '01', 1712860570, 0, 0), 
('hour', '02', 1713122410, 0, 0), 
('hour', '03', 1713125029, 0, 0), 
('hour', '04', 1712956041, 0, 0), 
('hour', '05', 1712873265, 0, 0), 
('hour', '06', 1712879260, 0, 0), 
('hour', '07', 1713226359, 1, 1), 
('hour', '08', 1713058657, 0, 0), 
('hour', '09', 1713235935, 1, 1), 
('hour', '10', 1713237796, 1, 1), 
('hour', '11', 1713155726, 0, 0), 
('hour', '12', 1712985356, 0, 0), 
('hour', '13', 1713162236, 0, 0), 
('hour', '14', 1713251892, 1, 1), 
('hour', '15', 1713171414, 0, 0), 
('hour', '16', 1713173430, 0, 0), 
('hour', '17', 1713175418, 0, 0), 
('hour', '18', 1713181788, 0, 0), 
('hour', '19', 1713185733, 0, 0), 
('hour', '20', 1713189217, 0, 0), 
('hour', '21', 1713192464, 0, 0), 
('hour', '22', 1713196554, 0, 0), 
('hour', '23', 1713026079, 0, 0), 
('bot', 'googlebot', 0, 0, 0), 
('bot', 'msnbot', 0, 0, 0), 
('bot', 'bingbot', 0, 0, 0), 
('bot', 'yahooslurp', 0, 0, 0), 
('bot', 'w3cvalidator', 0, 0, 0), 
('browser', 'opera', 0, 0, 0), 
('browser', 'operamini', 0, 0, 0), 
('browser', 'webtv', 0, 0, 0), 
('browser', 'explorer', 1712850326, 2, 2), 
('browser', 'edge', 1713021501, 3, 3), 
('browser', 'pocket', 0, 0, 0), 
('browser', 'konqueror', 0, 0, 0), 
('browser', 'icab', 0, 0, 0), 
('browser', 'omniweb', 0, 0, 0), 
('browser', 'firebird', 0, 0, 0), 
('browser', 'firefox', 1713185630, 18, 18), 
('browser', 'iceweasel', 0, 0, 0), 
('browser', 'shiretoko', 0, 0, 0), 
('browser', 'mozilla', 1713196554, 5, 5), 
('browser', 'amaya', 0, 0, 0), 
('browser', 'lynx', 0, 0, 0), 
('browser', 'safari', 1712836190, 1, 1), 
('browser', 'iphone', 1713026079, 9, 9), 
('browser', 'ipod', 0, 0, 0), 
('browser', 'ipad', 0, 0, 0), 
('browser', 'chrome', 1713251892, 209, 209), 
('browser', 'cococ', 0, 0, 0), 
('browser', 'android', 1713140925, 1, 1), 
('browser', 'googlebot', 0, 0, 0), 
('browser', 'yahooslurp', 0, 0, 0), 
('browser', 'w3cvalidator', 0, 0, 0), 
('browser', 'blackberry', 0, 0, 0), 
('browser', 'icecat', 0, 0, 0), 
('browser', 'nokias60', 0, 0, 0), 
('browser', 'nokia', 0, 0, 0), 
('browser', 'msn', 0, 0, 0), 
('browser', 'msnbot', 0, 0, 0), 
('browser', 'bingbot', 0, 0, 0), 
('browser', 'netscape', 0, 0, 0), 
('browser', 'galeon', 0, 0, 0), 
('browser', 'netpositive', 0, 0, 0), 
('browser', 'phoenix', 0, 0, 0), 
('browser', 'Mobile', 0, 0, 0), 
('browser', 'bots', 1712984474, 3, 3), 
('browser', 'Unknown', 1712835378, 1, 1), 
('os', 'unknown', 1713196554, 9, 9), 
('os', 'win', 0, 0, 0), 
('os', 'win10', 1713237796, 157, 157), 
('os', 'win8', 0, 0, 0), 
('os', 'win7', 1712850326, 2, 2), 
('os', 'win2003', 0, 0, 0), 
('os', 'winvista', 0, 0, 0), 
('os', 'wince', 0, 0, 0), 
('os', 'winxp', 0, 0, 0), 
('os', 'win2000', 0, 0, 0), 
('os', 'apple', 1713122410, 11, 11), 
('os', 'linux', 1713185630, 12, 12), 
('os', 'os2', 0, 0, 0), 
('os', 'beos', 0, 0, 0), 
('os', 'iphone', 1713251892, 50, 50), 
('os', 'ipod', 0, 0, 0), 
('os', 'ipad', 0, 0, 0), 
('os', 'blackberry', 0, 0, 0), 
('os', 'nokia', 0, 0, 0), 
('os', 'freebsd', 0, 0, 0), 
('os', 'openbsd', 0, 0, 0), 
('os', 'netbsd', 0, 0, 0), 
('os', 'sunos', 0, 0, 0), 
('os', 'opensolaris', 0, 0, 0), 
('os', 'android', 1713140925, 11, 11), 
('os', 'irix', 0, 0, 0), 
('os', 'palm', 0, 0, 0), 
('country', 'AD', 0, 0, 0), 
('country', 'AE', 0, 0, 0), 
('country', 'AF', 0, 0, 0), 
('country', 'AG', 0, 0, 0), 
('country', 'AI', 0, 0, 0), 
('country', 'AL', 0, 0, 0), 
('country', 'AM', 0, 0, 0), 
('country', 'AN', 0, 0, 0), 
('country', 'AO', 0, 0, 0), 
('country', 'AQ', 0, 0, 0), 
('country', 'AR', 0, 0, 0), 
('country', 'AS', 0, 0, 0), 
('country', 'AT', 0, 0, 0), 
('country', 'AU', 1712854441, 2, 2), 
('country', 'AW', 0, 0, 0), 
('country', 'AZ', 0, 0, 0), 
('country', 'BA', 0, 0, 0), 
('country', 'BB', 0, 0, 0), 
('country', 'BD', 0, 0, 0), 
('country', 'BE', 1712975309, 2, 2), 
('country', 'BF', 0, 0, 0), 
('country', 'BG', 0, 0, 0), 
('country', 'BH', 0, 0, 0), 
('country', 'BI', 0, 0, 0), 
('country', 'BJ', 0, 0, 0), 
('country', 'BM', 0, 0, 0), 
('country', 'BN', 0, 0, 0), 
('country', 'BO', 0, 0, 0), 
('country', 'BR', 0, 0, 0), 
('country', 'BS', 0, 0, 0), 
('country', 'BT', 0, 0, 0), 
('country', 'BW', 0, 0, 0), 
('country', 'BY', 0, 0, 0), 
('country', 'BZ', 0, 0, 0), 
('country', 'CA', 1712835035, 8, 8), 
('country', 'CD', 0, 0, 0), 
('country', 'CF', 0, 0, 0), 
('country', 'CG', 0, 0, 0), 
('country', 'CH', 0, 0, 0), 
('country', 'CI', 0, 0, 0), 
('country', 'CK', 0, 0, 0), 
('country', 'CL', 0, 0, 0), 
('country', 'CM', 0, 0, 0), 
('country', 'CN', 0, 0, 0), 
('country', 'CO', 0, 0, 0), 
('country', 'CR', 0, 0, 0), 
('country', 'CS', 0, 0, 0), 
('country', 'CU', 0, 0, 0), 
('country', 'CV', 0, 0, 0), 
('country', 'CY', 0, 0, 0), 
('country', 'CZ', 0, 0, 0), 
('country', 'DE', 1712850201, 2, 2), 
('country', 'DJ', 0, 0, 0), 
('country', 'DK', 1712851346, 1, 1), 
('country', 'DM', 0, 0, 0), 
('country', 'DO', 0, 0, 0), 
('country', 'DZ', 0, 0, 0), 
('country', 'EC', 0, 0, 0), 
('country', 'EE', 0, 0, 0), 
('country', 'EG', 1713021501, 1, 1), 
('country', 'ER', 0, 0, 0), 
('country', 'ES', 0, 0, 0), 
('country', 'ET', 0, 0, 0), 
('country', 'EU', 0, 0, 0), 
('country', 'FI', 0, 0, 0), 
('country', 'FJ', 0, 0, 0), 
('country', 'FK', 0, 0, 0), 
('country', 'FM', 0, 0, 0), 
('country', 'FO', 0, 0, 0), 
('country', 'FR', 1713021500, 2, 2), 
('country', 'GA', 0, 0, 0), 
('country', 'GB', 1712892993, 1, 1), 
('country', 'GD', 0, 0, 0), 
('country', 'GE', 0, 0, 0), 
('country', 'GF', 0, 0, 0), 
('country', 'GH', 0, 0, 0), 
('country', 'GI', 0, 0, 0), 
('country', 'GL', 0, 0, 0), 
('country', 'GM', 0, 0, 0), 
('country', 'GN', 0, 0, 0), 
('country', 'GP', 0, 0, 0), 
('country', 'GQ', 0, 0, 0), 
('country', 'GR', 0, 0, 0), 
('country', 'GS', 0, 0, 0), 
('country', 'GT', 0, 0, 0), 
('country', 'GU', 0, 0, 0), 
('country', 'GW', 0, 0, 0), 
('country', 'GY', 0, 0, 0), 
('country', 'HK', 0, 0, 0), 
('country', 'HN', 0, 0, 0), 
('country', 'HR', 0, 0, 0), 
('country', 'HT', 0, 0, 0), 
('country', 'HU', 0, 0, 0), 
('country', 'ID', 0, 0, 0), 
('country', 'IE', 1712838265, 1, 1), 
('country', 'IL', 0, 0, 0), 
('country', 'IN', 0, 0, 0), 
('country', 'IO', 0, 0, 0), 
('country', 'IQ', 0, 0, 0), 
('country', 'IR', 0, 0, 0), 
('country', 'IS', 0, 0, 0), 
('country', 'IT', 0, 0, 0), 
('country', 'JM', 0, 0, 0), 
('country', 'JO', 0, 0, 0), 
('country', 'JP', 1712890768, 9, 9), 
('country', 'KE', 0, 0, 0), 
('country', 'KG', 0, 0, 0), 
('country', 'KH', 0, 0, 0), 
('country', 'KI', 0, 0, 0), 
('country', 'KM', 0, 0, 0), 
('country', 'KN', 0, 0, 0), 
('country', 'KR', 0, 0, 0), 
('country', 'KW', 0, 0, 0), 
('country', 'KY', 0, 0, 0), 
('country', 'KZ', 0, 0, 0), 
('country', 'LA', 0, 0, 0), 
('country', 'LB', 0, 0, 0), 
('country', 'LC', 0, 0, 0), 
('country', 'LI', 0, 0, 0), 
('country', 'LK', 0, 0, 0), 
('country', 'LR', 0, 0, 0), 
('country', 'LS', 0, 0, 0), 
('country', 'LT', 0, 0, 0), 
('country', 'LU', 0, 0, 0), 
('country', 'LV', 0, 0, 0), 
('country', 'LY', 0, 0, 0), 
('country', 'MA', 0, 0, 0), 
('country', 'MC', 0, 0, 0), 
('country', 'MD', 0, 0, 0), 
('country', 'MG', 0, 0, 0), 
('country', 'MH', 0, 0, 0), 
('country', 'MK', 0, 0, 0), 
('country', 'ML', 0, 0, 0), 
('country', 'MM', 0, 0, 0), 
('country', 'MN', 0, 0, 0), 
('country', 'MO', 0, 0, 0), 
('country', 'MP', 0, 0, 0), 
('country', 'MQ', 0, 0, 0), 
('country', 'MR', 0, 0, 0), 
('country', 'MT', 0, 0, 0), 
('country', 'MU', 0, 0, 0), 
('country', 'MV', 0, 0, 0), 
('country', 'MW', 0, 0, 0), 
('country', 'MX', 0, 0, 0), 
('country', 'MY', 0, 0, 0), 
('country', 'MZ', 0, 0, 0), 
('country', 'NA', 0, 0, 0), 
('country', 'NC', 0, 0, 0), 
('country', 'NE', 0, 0, 0), 
('country', 'NF', 0, 0, 0), 
('country', 'NG', 0, 0, 0), 
('country', 'NI', 0, 0, 0), 
('country', 'NL', 0, 0, 0), 
('country', 'NO', 0, 0, 0), 
('country', 'NP', 0, 0, 0), 
('country', 'NR', 0, 0, 0), 
('country', 'NU', 0, 0, 0), 
('country', 'NZ', 0, 0, 0), 
('country', 'OM', 0, 0, 0), 
('country', 'PA', 0, 0, 0), 
('country', 'PE', 0, 0, 0), 
('country', 'PF', 0, 0, 0), 
('country', 'PG', 0, 0, 0), 
('country', 'PH', 0, 0, 0), 
('country', 'PK', 0, 0, 0), 
('country', 'PL', 0, 0, 0), 
('country', 'PR', 0, 0, 0), 
('country', 'PS', 0, 0, 0), 
('country', 'PT', 0, 0, 0), 
('country', 'PW', 0, 0, 0), 
('country', 'PY', 0, 0, 0), 
('country', 'QA', 0, 0, 0), 
('country', 'RE', 0, 0, 0), 
('country', 'RO', 1712834232, 1, 1), 
('country', 'RU', 1713125029, 6, 6), 
('country', 'RW', 0, 0, 0), 
('country', 'SA', 0, 0, 0), 
('country', 'SB', 0, 0, 0), 
('country', 'SC', 0, 0, 0), 
('country', 'SD', 0, 0, 0), 
('country', 'SE', 0, 0, 0), 
('country', 'SG', 0, 0, 0), 
('country', 'SI', 0, 0, 0), 
('country', 'SK', 0, 0, 0), 
('country', 'SL', 0, 0, 0), 
('country', 'SM', 0, 0, 0), 
('country', 'SN', 0, 0, 0), 
('country', 'SO', 0, 0, 0), 
('country', 'SR', 0, 0, 0), 
('country', 'ST', 0, 0, 0), 
('country', 'SV', 0, 0, 0), 
('country', 'SY', 0, 0, 0), 
('country', 'SZ', 0, 0, 0), 
('country', 'TD', 0, 0, 0), 
('country', 'TF', 0, 0, 0), 
('country', 'TG', 0, 0, 0), 
('country', 'TH', 0, 0, 0), 
('country', 'TJ', 0, 0, 0), 
('country', 'TK', 0, 0, 0), 
('country', 'TL', 0, 0, 0), 
('country', 'TM', 0, 0, 0), 
('country', 'TN', 0, 0, 0), 
('country', 'TO', 0, 0, 0), 
('country', 'TR', 0, 0, 0), 
('country', 'TT', 0, 0, 0), 
('country', 'TV', 0, 0, 0), 
('country', 'TW', 0, 0, 0), 
('country', 'TZ', 0, 0, 0), 
('country', 'UA', 0, 0, 0), 
('country', 'UG', 0, 0, 0), 
('country', 'US', 1713237796, 44, 44), 
('country', 'UY', 0, 0, 0), 
('country', 'UZ', 0, 0, 0), 
('country', 'VA', 0, 0, 0), 
('country', 'VC', 0, 0, 0), 
('country', 'VE', 0, 0, 0), 
('country', 'VG', 0, 0, 0), 
('country', 'VI', 0, 0, 0), 
('country', 'VN', 1713251892, 89, 89), 
('country', 'VU', 0, 0, 0), 
('country', 'WS', 0, 0, 0), 
('country', 'YE', 0, 0, 0), 
('country', 'YT', 0, 0, 0), 
('country', 'YU', 0, 0, 0), 
('country', 'ZA', 1712851353, 1, 1), 
('country', 'ZM', 0, 0, 0), 
('country', 'ZW', 0, 0, 0), 
('country', 'ZZ', 1712992596, 82, 82), 
('country', 'unkown', 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_cronjobs`
--

DROP TABLE IF EXISTS `nv4_cronjobs`;
CREATE TABLE `nv4_cronjobs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `start_time` int(10) unsigned NOT NULL DEFAULT '0',
  `inter_val` int(10) unsigned NOT NULL DEFAULT '0',
  `inter_val_type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0: Lặp lại sau thời điểm bắt đầu thực tế, 1:lặp lại sau thời điểm bắt đầu trong CSDL',
  `run_file` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `run_func` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `params` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `del` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `is_sys` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `last_time` int(10) unsigned NOT NULL DEFAULT '0',
  `last_result` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `vi_cron_name` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `is_sys` (`is_sys`)
) ENGINE=MyISAM  AUTO_INCREMENT=10  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_cronjobs`
--

INSERT INTO `nv4_cronjobs` VALUES
(1, 1712405092, 5, 0, 'online_expired_del.php', 'cron_online_expired_del', '', 0, 1, 1, 1713253337, 1, 'Xóa các dòng ghi trạng thái online đã cũ trong CSDL'), 
(2, 1712405092, 1440, 0, 'dump_autobackup.php', 'cron_dump_autobackup', '', 0, 1, 1, 1713166172, 1, 'Tự động lưu CSDL'), 
(3, 1712405092, 60, 0, 'temp_download_destroy.php', 'cron_auto_del_temp_download', '', 0, 1, 1, 1713251893, 1, 'Xóa các file tạm trong thư mục tmp'), 
(4, 1712405092, 30, 0, 'ip_logs_destroy.php', 'cron_del_ip_logs', '', 0, 1, 1, 1713251893, 1, 'Xóa IP log files, Xóa các file nhật ký truy cập'), 
(5, 1712405092, 1440, 0, 'error_log_destroy.php', 'cron_auto_del_error_log', '', 0, 1, 1, 1713166172, 1, 'Xóa các file error_log quá hạn'), 
(6, 1712405092, 360, 0, 'error_log_sendmail.php', 'cron_auto_sendmail_error_log', '', 0, 1, 0, 0, 0, 'Gửi email các thông báo lỗi cho admin'), 
(7, 1712405092, 60, 0, 'ref_expired_del.php', 'cron_ref_expired_del', '', 0, 1, 1, 1713251893, 1, 'Xóa các referer quá hạn'), 
(8, 1712405092, 60, 0, 'check_version.php', 'cron_auto_check_version', '', 0, 1, 1, 1713251893, 1, 'Kiểm tra phiên bản NukeViet'), 
(9, 1712405092, 1440, 0, 'notification_autodel.php', 'cron_notification_autodel', '', 0, 1, 1, 1713166172, 1, 'Xóa thông báo cũ');


-- ---------------------------------------


--
-- Table structure for table `nv4_extension_files`
--

DROP TABLE IF EXISTS `nv4_extension_files`;
CREATE TABLE `nv4_extension_files` (
  `idfile` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'other',
  `title` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lastmodified` int(10) unsigned NOT NULL DEFAULT '0',
  `duplicate` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`idfile`)
) ENGINE=MyISAM  AUTO_INCREMENT=285  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_extension_files`
--

INSERT INTO `nv4_extension_files` VALUES
(1, 'module', 'shops', 'modules/shops/action_mysql.php', 1712405953, 0), 
(2, 'module', 'shops', 'modules/shops/admin/active_pay.php', 1712405953, 0), 
(3, 'module', 'shops', 'modules/shops/admin/alias.php', 1712405953, 0), 
(4, 'module', 'shops', 'modules/shops/admin/block.php', 1712405953, 0), 
(5, 'module', 'shops', 'modules/shops/admin/blockcat.php', 1712405953, 0), 
(6, 'module', 'shops', 'modules/shops/admin/carrier.php', 1712405953, 0), 
(7, 'module', 'shops', 'modules/shops/admin/carrier_config.php', 1712405953, 0), 
(8, 'module', 'shops', 'modules/shops/admin/carrier_config_items.php', 1712405953, 0), 
(9, 'module', 'shops', 'modules/shops/admin/cat.php', 1712405953, 0), 
(10, 'module', 'shops', 'modules/shops/admin/change_block.php', 1712405953, 0), 
(11, 'module', 'shops', 'modules/shops/admin/change_cat.php', 1712405953, 0), 
(12, 'module', 'shops', 'modules/shops/admin/change_group.php', 1712405953, 0), 
(13, 'module', 'shops', 'modules/shops/admin/change_location.php', 1712405953, 0), 
(14, 'module', 'shops', 'modules/shops/admin/change_source.php', 1712405953, 0), 
(15, 'module', 'shops', 'modules/shops/admin/chang_block_cat.php', 1712405953, 0), 
(16, 'module', 'shops', 'modules/shops/admin/content.php', 1712405953, 0), 
(17, 'module', 'shops', 'modules/shops/admin/coupons.php', 1712405953, 0), 
(18, 'module', 'shops', 'modules/shops/admin/coupons_view.php', 1712405953, 0), 
(19, 'module', 'shops', 'modules/shops/admin/custom_form.php', 1712405953, 0), 
(20, 'module', 'shops', 'modules/shops/admin/delmoney.php', 1712405953, 0), 
(21, 'module', 'shops', 'modules/shops/admin/delunit.php', 1712405953, 0), 
(22, 'module', 'shops', 'modules/shops/admin/delweight.php', 1712405953, 0), 
(23, 'module', 'shops', 'modules/shops/admin/del_block_cat.php', 1712405953, 0), 
(24, 'module', 'shops', 'modules/shops/admin/del_cat.php', 1712405953, 0), 
(25, 'module', 'shops', 'modules/shops/admin/del_content.php', 1712405953, 0), 
(26, 'module', 'shops', 'modules/shops/admin/del_group.php', 1712405953, 0), 
(27, 'module', 'shops', 'modules/shops/admin/del_location.php', 1712405953, 0), 
(28, 'module', 'shops', 'modules/shops/admin/del_source.php', 1712405953, 0), 
(29, 'module', 'shops', 'modules/shops/admin/detemplate.php', 1712405953, 0), 
(30, 'module', 'shops', 'modules/shops/admin/discounts.php', 1712405953, 0), 
(31, 'module', 'shops', 'modules/shops/admin/docpay.php', 1712405953, 0), 
(32, 'module', 'shops', 'modules/shops/admin/download.php', 1712405953, 0), 
(33, 'module', 'shops', 'modules/shops/admin/exptime.php', 1712405953, 0), 
(34, 'module', 'shops', 'modules/shops/admin/fields.php', 1712405953, 0), 
(35, 'module', 'shops', 'modules/shops/admin/field_tab.php', 1712405953, 0), 
(36, 'module', 'shops', 'modules/shops/admin/getcatalog.php', 1712405953, 0), 
(37, 'module', 'shops', 'modules/shops/admin/getgroup.php', 1712405953, 0), 
(38, 'module', 'shops', 'modules/shops/admin/getprice.php', 1712405953, 0), 
(39, 'module', 'shops', 'modules/shops/admin/group.php', 1712405953, 0), 
(40, 'module', 'shops', 'modules/shops/admin/index.html', 1712405953, 0), 
(41, 'module', 'shops', 'modules/shops/admin/items.php', 1712405953, 0), 
(42, 'module', 'shops', 'modules/shops/admin/keywords.php', 1712405953, 0), 
(43, 'module', 'shops', 'modules/shops/admin/list_block.php', 1712405953, 0), 
(44, 'module', 'shops', 'modules/shops/admin/list_block_cat.php', 1712405953, 0), 
(45, 'module', 'shops', 'modules/shops/admin/list_cat.php', 1712405953, 0), 
(46, 'module', 'shops', 'modules/shops/admin/list_group.php', 1712405953, 0), 
(47, 'module', 'shops', 'modules/shops/admin/list_location.php', 1712405953, 0), 
(48, 'module', 'shops', 'modules/shops/admin/location.php', 1712405953, 0), 
(49, 'module', 'shops', 'modules/shops/admin/main.php', 1712405953, 0), 
(50, 'module', 'shops', 'modules/shops/admin/money.php', 1712405953, 0), 
(51, 'module', 'shops', 'modules/shops/admin/order.php', 1712405953, 0), 
(52, 'module', 'shops', 'modules/shops/admin/order_seller.php', 1712405953, 0), 
(53, 'module', 'shops', 'modules/shops/admin/or_del.php', 1712405953, 0), 
(54, 'module', 'shops', 'modules/shops/admin/or_view.php', 1712405953, 0), 
(55, 'module', 'shops', 'modules/shops/admin/point.php', 1712405953, 0), 
(56, 'module', 'shops', 'modules/shops/admin/print.php', 1712405953, 0), 
(57, 'module', 'shops', 'modules/shops/admin/prounit.php', 1712405953, 0), 
(58, 'module', 'shops', 'modules/shops/admin/publtime.php', 1712405953, 0), 
(59, 'module', 'shops', 'modules/shops/admin/review.php', 1712405953, 0), 
(60, 'module', 'shops', 'modules/shops/admin/seller.php', 1712405953, 0), 
(61, 'module', 'shops', 'modules/shops/admin/setting.php', 1712405953, 0), 
(62, 'module', 'shops', 'modules/shops/admin/shipping.php', 1712405953, 0), 
(63, 'module', 'shops', 'modules/shops/admin/shops.php', 1712405953, 0), 
(64, 'module', 'shops', 'modules/shops/admin/tabs.php', 1712405953, 0), 
(65, 'module', 'shops', 'modules/shops/admin/tags.php', 1712405953, 0), 
(66, 'module', 'shops', 'modules/shops/admin/tagsajax.php', 1712405953, 0), 
(67, 'module', 'shops', 'modules/shops/admin/template.php', 1712405953, 0), 
(68, 'module', 'shops', 'modules/shops/admin/updateprice.php', 1712405953, 0), 
(69, 'module', 'shops', 'modules/shops/admin/view.php', 1712405953, 0), 
(70, 'module', 'shops', 'modules/shops/admin/warehouse.php', 1712405953, 0), 
(71, 'module', 'shops', 'modules/shops/admin/warehouse_logs.php', 1712405953, 0), 
(72, 'module', 'shops', 'modules/shops/admin/weight.php', 1712405953, 0), 
(73, 'module', 'shops', 'modules/shops/admin.functions.php', 1712405953, 0), 
(74, 'module', 'shops', 'modules/shops/admin.menu.php', 1712405953, 0), 
(75, 'module', 'shops', 'modules/shops/blocks/global.block_bxproduct_center.ini', 1712405953, 0), 
(76, 'module', 'shops', 'modules/shops/blocks/global.block_bxproduct_center.php', 1712405953, 0), 
(77, 'module', 'shops', 'modules/shops/blocks/global.block_cart.php', 1712405953, 0), 
(78, 'module', 'shops', 'modules/shops/blocks/global.block_catalogs.ini', 1712405953, 0), 
(79, 'module', 'shops', 'modules/shops/blocks/global.block_catalogs.php', 1712405953, 0), 
(80, 'module', 'shops', 'modules/shops/blocks/global.block_price_view.ini', 1712405953, 0), 
(81, 'module', 'shops', 'modules/shops/blocks/global.block_price_view.php', 1712405953, 0), 
(82, 'module', 'shops', 'modules/shops/blocks/global.block_product_center.ini', 1712405953, 0), 
(83, 'module', 'shops', 'modules/shops/blocks/global.block_product_center.php', 1712405953, 0), 
(84, 'module', 'shops', 'modules/shops/blocks/global.block_relates_product.ini', 1712405953, 0), 
(85, 'module', 'shops', 'modules/shops/blocks/global.block_relates_product.php', 1712405953, 0), 
(86, 'module', 'shops', 'modules/shops/blocks/global.block_search.php', 1712405953, 0), 
(87, 'module', 'shops', 'modules/shops/blocks/index.html', 1712405953, 0), 
(88, 'module', 'shops', 'modules/shops/blocks/module.block_filter_product.ini', 1712405953, 0), 
(89, 'module', 'shops', 'modules/shops/blocks/module.block_filter_product.php', 1712405953, 0), 
(90, 'module', 'shops', 'modules/shops/blocks/module.block_filter_product_cat.ini', 1712405953, 0), 
(91, 'module', 'shops', 'modules/shops/blocks/module.block_filter_product_cat.php', 1712405953, 0), 
(92, 'module', 'shops', 'modules/shops/blocks/module.block_others_product.php', 1712405953, 0), 
(93, 'module', 'shops', 'modules/shops/blocks/module.block_product_center.php', 1712405953, 0), 
(94, 'module', 'shops', 'modules/shops/comment.php', 1712405953, 0), 
(95, 'module', 'shops', 'modules/shops/fields.check.php', 1712405953, 0), 
(96, 'module', 'shops', 'modules/shops/funcs/ajax.php', 1712405953, 0), 
(97, 'module', 'shops', 'modules/shops/funcs/blockcat.php', 1712405953, 0), 
(98, 'module', 'shops', 'modules/shops/funcs/cart.php', 1712405953, 0), 
(99, 'module', 'shops', 'modules/shops/funcs/checkorder.php', 1712405953, 0), 
(100, 'module', 'shops', 'modules/shops/funcs/compare.php', 1712405953, 0), 
(101, 'module', 'shops', 'modules/shops/funcs/delhis.php', 1712405953, 0), 
(102, 'module', 'shops', 'modules/shops/funcs/detail.php', 1712405953, 0), 
(103, 'module', 'shops', 'modules/shops/funcs/download.php', 1712405953, 0), 
(104, 'module', 'shops', 'modules/shops/funcs/group.php', 1712405953, 0), 
(105, 'module', 'shops', 'modules/shops/funcs/history.php', 1712405953, 0), 
(106, 'module', 'shops', 'modules/shops/funcs/index.html', 1712405953, 0), 
(107, 'module', 'shops', 'modules/shops/funcs/loadcart.php', 1712405953, 0), 
(108, 'module', 'shops', 'modules/shops/funcs/main.php', 1712405953, 0), 
(109, 'module', 'shops', 'modules/shops/funcs/order.php', 1712405953, 0), 
(110, 'module', 'shops', 'modules/shops/funcs/payment.php', 1712405953, 0), 
(111, 'module', 'shops', 'modules/shops/funcs/point.php', 1712405953, 0), 
(112, 'module', 'shops', 'modules/shops/funcs/print.php', 1712405953, 0), 
(113, 'module', 'shops', 'modules/shops/funcs/print_pro.php', 1712405953, 0), 
(114, 'module', 'shops', 'modules/shops/funcs/remove.php', 1712405953, 0), 
(115, 'module', 'shops', 'modules/shops/funcs/review.php', 1712405953, 0), 
(116, 'module', 'shops', 'modules/shops/funcs/rss.php', 1712405953, 0), 
(117, 'module', 'shops', 'modules/shops/funcs/search.php', 1712405953, 0), 
(118, 'module', 'shops', 'modules/shops/funcs/sendmail.php', 1712405953, 0), 
(119, 'module', 'shops', 'modules/shops/funcs/setcart.php', 1712405953, 0), 
(120, 'module', 'shops', 'modules/shops/funcs/shippingajax.php', 1712405953, 0), 
(121, 'module', 'shops', 'modules/shops/funcs/sitemap.php', 1712405953, 0), 
(122, 'module', 'shops', 'modules/shops/funcs/tag.php', 1712405953, 0), 
(123, 'module', 'shops', 'modules/shops/funcs/viewcat.php', 1712405953, 0), 
(124, 'module', 'shops', 'modules/shops/funcs/wishlist.php', 1712405953, 0), 
(125, 'module', 'shops', 'modules/shops/funcs/wishlist_update.php', 1712405953, 0), 
(126, 'module', 'shops', 'modules/shops/functions.php', 1712405953, 0), 
(127, 'module', 'shops', 'modules/shops/global.functions.php', 1712405953, 0), 
(128, 'module', 'shops', 'modules/shops/index.html', 1712405953, 0), 
(129, 'module', 'shops', 'modules/shops/language/admin_en.php', 1712405953, 0), 
(130, 'module', 'shops', 'modules/shops/language/admin_vi.php', 1712405953, 0), 
(131, 'module', 'shops', 'modules/shops/language/data_vi.php', 1712405953, 0), 
(132, 'module', 'shops', 'modules/shops/language/en.php', 1712405953, 0), 
(133, 'module', 'shops', 'modules/shops/language/index.html', 1712405953, 0), 
(134, 'module', 'shops', 'modules/shops/language/vi.php', 1712405953, 0), 
(135, 'module', 'shops', 'modules/shops/menu.php', 1712405953, 0), 
(136, 'module', 'shops', 'modules/shops/notification.php', 1712405953, 0), 
(137, 'module', 'shops', 'modules/shops/rssdata.php', 1712405953, 0), 
(138, 'module', 'shops', 'modules/shops/search.php', 1712405953, 0), 
(139, 'module', 'shops', 'modules/shops/site.functions.php', 1712405953, 0), 
(140, 'module', 'shops', 'modules/shops/siteinfo.php', 1712405953, 0), 
(141, 'module', 'shops', 'modules/shops/theme.php', 1712405953, 0), 
(142, 'module', 'shops', 'modules/shops/version.php', 1712405953, 0), 
(143, 'module', 'shops', 'modules/shops/wallet.admin.php', 1712405953, 0), 
(144, 'module', 'shops', 'themes/admin_default/css/shops.css', 1712405953, 0), 
(145, 'module', 'shops', 'themes/admin_default/js/content.js', 1712405953, 0), 
(146, 'module', 'shops', 'themes/admin_default/js/shops.js', 1712405953, 0), 
(147, 'module', 'shops', 'themes/admin_default/modules/shops/block.tpl', 1712405953, 0), 
(148, 'module', 'shops', 'themes/admin_default/modules/shops/blockcat.tpl', 1712405953, 0), 
(149, 'module', 'shops', 'themes/admin_default/modules/shops/block_cat_list.tpl', 1712405953, 0), 
(150, 'module', 'shops', 'themes/admin_default/modules/shops/block_list.tpl', 1712405953, 0), 
(151, 'module', 'shops', 'themes/admin_default/modules/shops/carrier.tpl', 1712405953, 0), 
(152, 'module', 'shops', 'themes/admin_default/modules/shops/carrier_config.tpl', 1712405953, 0), 
(153, 'module', 'shops', 'themes/admin_default/modules/shops/carrier_config_items.tpl', 1712405953, 0), 
(154, 'module', 'shops', 'themes/admin_default/modules/shops/cat_add.tpl', 1712405953, 0), 
(155, 'module', 'shops', 'themes/admin_default/modules/shops/cat_delete.tpl', 1712405953, 0), 
(156, 'module', 'shops', 'themes/admin_default/modules/shops/cat_lists.tpl', 1712405953, 0), 
(157, 'module', 'shops', 'themes/admin_default/modules/shops/content.tpl', 1712405953, 0), 
(158, 'module', 'shops', 'themes/admin_default/modules/shops/coupons.tpl', 1712405953, 0), 
(159, 'module', 'shops', 'themes/admin_default/modules/shops/coupons_view.tpl', 1712405953, 0), 
(160, 'module', 'shops', 'themes/admin_default/modules/shops/discounts.tpl', 1712405953, 0), 
(161, 'module', 'shops', 'themes/admin_default/modules/shops/docpay.tpl', 1712405953, 0), 
(162, 'module', 'shops', 'themes/admin_default/modules/shops/download.tpl', 1712405953, 0), 
(163, 'module', 'shops', 'themes/admin_default/modules/shops/email_new_order_payment.tpl', 1712405953, 0), 
(164, 'module', 'shops', 'themes/admin_default/modules/shops/fields.tpl', 1712405953, 0), 
(165, 'module', 'shops', 'themes/admin_default/modules/shops/field_tab.tpl', 1712405953, 0), 
(166, 'module', 'shops', 'themes/admin_default/modules/shops/getprice.tpl', 1712405953, 0), 
(167, 'module', 'shops', 'themes/admin_default/modules/shops/group_add.tpl', 1712405953, 0), 
(168, 'module', 'shops', 'themes/admin_default/modules/shops/group_delete.tpl', 1712405953, 0), 
(169, 'module', 'shops', 'themes/admin_default/modules/shops/group_lists.tpl', 1712405953, 0), 
(170, 'module', 'shops', 'themes/admin_default/modules/shops/index.html', 1712405953, 0), 
(171, 'module', 'shops', 'themes/admin_default/modules/shops/items.tpl', 1712405953, 0), 
(172, 'module', 'shops', 'themes/admin_default/modules/shops/location.tpl', 1712405953, 0), 
(173, 'module', 'shops', 'themes/admin_default/modules/shops/location_lists.tpl', 1712405953, 0), 
(174, 'module', 'shops', 'themes/admin_default/modules/shops/main.tpl', 1712405953, 0), 
(175, 'module', 'shops', 'themes/admin_default/modules/shops/money.tpl', 1712405953, 0), 
(176, 'module', 'shops', 'themes/admin_default/modules/shops/order.tpl', 1712405953, 0), 
(177, 'module', 'shops', 'themes/admin_default/modules/shops/order_seller.tpl', 1712405953, 0), 
(178, 'module', 'shops', 'themes/admin_default/modules/shops/or_view.tpl', 1712405953, 0), 
(179, 'module', 'shops', 'themes/admin_default/modules/shops/point.tpl', 1712405953, 0), 
(180, 'module', 'shops', 'themes/admin_default/modules/shops/print.tpl', 1712405953, 0), 
(181, 'module', 'shops', 'themes/admin_default/modules/shops/prounit.tpl', 1712405953, 0), 
(182, 'module', 'shops', 'themes/admin_default/modules/shops/review.tpl', 1712405953, 0), 
(183, 'module', 'shops', 'themes/admin_default/modules/shops/seller.tpl', 1712405953, 0), 
(184, 'module', 'shops', 'themes/admin_default/modules/shops/setting.tpl', 1712405953, 0), 
(185, 'module', 'shops', 'themes/admin_default/modules/shops/shipping.tpl', 1712405953, 0), 
(186, 'module', 'shops', 'themes/admin_default/modules/shops/shipping_menu.tpl', 1712405953, 0), 
(187, 'module', 'shops', 'themes/admin_default/modules/shops/shops.tpl', 1712405953, 0), 
(188, 'module', 'shops', 'themes/admin_default/modules/shops/tabs.tpl', 1712405953, 0), 
(189, 'module', 'shops', 'themes/admin_default/modules/shops/tags.tpl', 1712405953, 0), 
(190, 'module', 'shops', 'themes/admin_default/modules/shops/tags_lists.tpl', 1712405953, 0), 
(191, 'module', 'shops', 'themes/admin_default/modules/shops/template.tpl', 1712405953, 0), 
(192, 'module', 'shops', 'themes/admin_default/modules/shops/topics.tpl', 1712405953, 0), 
(193, 'module', 'shops', 'themes/admin_default/modules/shops/updateprice.tpl', 1712405953, 0), 
(194, 'module', 'shops', 'themes/admin_default/modules/shops/warehouse.tpl', 1712405953, 0), 
(195, 'module', 'shops', 'themes/admin_default/modules/shops/warehouse_logs.tpl', 1712405953, 0), 
(196, 'module', 'shops', 'themes/admin_default/modules/shops/weight.tpl', 1712405953, 0), 
(197, 'module', 'shops', 'themes/default/css/jquery.bxslider.css', 1712405953, 0), 
(198, 'module', 'shops', 'themes/default/css/shops.css', 1712405953, 0), 
(199, 'module', 'shops', 'themes/default/images/shops/24x24-no.png', 1712405953, 0), 
(200, 'module', 'shops', 'themes/default/images/shops/access_head_bg.png', 1712405953, 0), 
(201, 'module', 'shops', 'themes/default/images/shops/ajax-loader.gif', 1712405953, 0), 
(202, 'module', 'shops', 'themes/default/images/shops/bgbt.png', 1712405953, 0), 
(203, 'module', 'shops', 'themes/default/images/shops/bg_divtab.png', 1712405953, 0), 
(204, 'module', 'shops', 'themes/default/images/shops/buzz.png', 1712405953, 0), 
(205, 'module', 'shops', 'themes/default/images/shops/controls.png', 1712405953, 0), 
(206, 'module', 'shops', 'themes/default/images/shops/flickr.png', 1712405953, 0), 
(207, 'module', 'shops', 'themes/default/images/shops/google.png', 1712405953, 0), 
(208, 'module', 'shops', 'themes/default/images/shops/icon_files/doc.png', 1712405953, 0), 
(209, 'module', 'shops', 'themes/default/images/shops/icon_files/document.png', 1712405953, 0), 
(210, 'module', 'shops', 'themes/default/images/shops/icon_files/docx.png', 1712405953, 0), 
(211, 'module', 'shops', 'themes/default/images/shops/icon_files/odt.png', 1712405953, 0), 
(212, 'module', 'shops', 'themes/default/images/shops/icon_files/pdf.png', 1712405953, 0), 
(213, 'module', 'shops', 'themes/default/images/shops/icon_files/ppt.png', 1712405953, 0), 
(214, 'module', 'shops', 'themes/default/images/shops/icon_files/pptx.png', 1712405953, 0), 
(215, 'module', 'shops', 'themes/default/images/shops/icon_files/rar.png', 1712405953, 0), 
(216, 'module', 'shops', 'themes/default/images/shops/icon_files/xsl.png', 1712405953, 0), 
(217, 'module', 'shops', 'themes/default/images/shops/icon_files/xslx.png', 1712405953, 0), 
(218, 'module', 'shops', 'themes/default/images/shops/icon_files/zip.png', 1712405953, 0), 
(219, 'module', 'shops', 'themes/default/images/shops/index.html', 1712405953, 0), 
(220, 'module', 'shops', 'themes/default/images/shops/jquery.ez-plus.js', 1712405953, 0), 
(221, 'module', 'shops', 'themes/default/images/shops/no-image.jpg', 1712405953, 0), 
(222, 'module', 'shops', 'themes/default/images/shops/OwlCarousel2/assets/owl.carousel.min.css', 1712405953, 0), 
(223, 'module', 'shops', 'themes/default/images/shops/OwlCarousel2/assets/owl.video.play.png', 1712405953, 0), 
(224, 'module', 'shops', 'themes/default/images/shops/OwlCarousel2/LICENSE', 1712405953, 0), 
(225, 'module', 'shops', 'themes/default/images/shops/OwlCarousel2/owl.carousel.min.js', 1712405953, 0), 
(226, 'module', 'shops', 'themes/default/images/shops/previous-next.png', 1712405953, 0), 
(227, 'module', 'shops', 'themes/default/images/shops/print.png', 1712405953, 0), 
(228, 'module', 'shops', 'themes/default/images/shops/pro_tab.png', 1712405953, 0), 
(229, 'module', 'shops', 'themes/default/images/shops/rate/rate-btn2-hover.png', 1712405953, 0), 
(230, 'module', 'shops', 'themes/default/images/shops/rate/rate-btn2.png', 1712405953, 0), 
(231, 'module', 'shops', 'themes/default/images/shops/rate/rate-btn3-hover.png', 1712405953, 0), 
(232, 'module', 'shops', 'themes/default/images/shops/rate/rate-stars.png', 1712405953, 0), 
(233, 'module', 'shops', 'themes/default/images/shops/square.jpg', 1712405953, 0), 
(234, 'module', 'shops', 'themes/default/images/shops/star-png.png', 1712405953, 0), 
(235, 'module', 'shops', 'themes/default/images/shops/star.png', 1712405953, 0), 
(236, 'module', 'shops', 'themes/default/images/shops/tiny-slider/index.html', 1712405953, 0), 
(237, 'module', 'shops', 'themes/default/images/shops/tiny-slider/min/index.html', 1712405953, 0), 
(238, 'module', 'shops', 'themes/default/images/shops/tiny-slider/min/tiny-slider.helper.ie8.js', 1712405953, 0), 
(239, 'module', 'shops', 'themes/default/images/shops/tiny-slider/min/tiny-slider.js', 1712405953, 0), 
(240, 'module', 'shops', 'themes/default/images/shops/tiny-slider/sourcemaps/index.html', 1712405953, 0), 
(241, 'module', 'shops', 'themes/default/images/shops/tiny-slider/sourcemaps/tiny-slider.css.map', 1712405953, 0), 
(242, 'module', 'shops', 'themes/default/images/shops/tiny-slider/sourcemaps/tiny-slider.helper.ie8.js.map', 1712405953, 0), 
(243, 'module', 'shops', 'themes/default/images/shops/tiny-slider/sourcemaps/tiny-slider.js.map', 1712405953, 0), 
(244, 'module', 'shops', 'themes/default/images/shops/tiny-slider/tiny-slider.css', 1712405953, 0), 
(245, 'module', 'shops', 'themes/default/images/shops/twitter.png', 1712405953, 0), 
(246, 'module', 'shops', 'themes/default/images/shops/zoom-img.png', 1712405953, 0), 
(247, 'module', 'shops', 'themes/default/js/jquery.bxslider.min.js', 1712405953, 0), 
(248, 'module', 'shops', 'themes/default/js/shops.js', 1712405953, 0), 
(249, 'module', 'shops', 'themes/default/modules/shops/block.bxproduct_center.tpl', 1712405953, 0), 
(250, 'module', 'shops', 'themes/default/modules/shops/block.cart.tpl', 1712405953, 0), 
(251, 'module', 'shops', 'themes/default/modules/shops/block.catalogsv.tpl', 1712405953, 0), 
(252, 'module', 'shops', 'themes/default/modules/shops/block.filter_product.tpl', 1712405953, 0), 
(253, 'module', 'shops', 'themes/default/modules/shops/block.filter_product_cat.tpl', 1712405953, 0), 
(254, 'module', 'shops', 'themes/default/modules/shops/block.others_product.tpl', 1712405953, 0), 
(255, 'module', 'shops', 'themes/default/modules/shops/block.price_view.tpl', 1712405953, 0), 
(256, 'module', 'shops', 'themes/default/modules/shops/block.product_center.tpl', 1712405953, 0), 
(257, 'module', 'shops', 'themes/default/modules/shops/block.search.tpl', 1712405953, 0), 
(258, 'module', 'shops', 'themes/default/modules/shops/blockcat.tpl', 1712405953, 0), 
(259, 'module', 'shops', 'themes/default/modules/shops/cart.tpl', 1712405953, 0), 
(260, 'module', 'shops', 'themes/default/modules/shops/compare.tpl', 1712405953, 0), 
(261, 'module', 'shops', 'themes/default/modules/shops/coupons_info.tpl', 1712405953, 0), 
(262, 'module', 'shops', 'themes/default/modules/shops/custom_tab_fields.tpl', 1712405953, 0), 
(263, 'module', 'shops', 'themes/default/modules/shops/detail.tpl', 1712405953, 0), 
(264, 'module', 'shops', 'themes/default/modules/shops/download_content.tpl', 1712405953, 0), 
(265, 'module', 'shops', 'themes/default/modules/shops/email_new_order.tpl', 1712405953, 0), 
(266, 'module', 'shops', 'themes/default/modules/shops/history_order.tpl', 1712405953, 0), 
(267, 'module', 'shops', 'themes/default/modules/shops/index.html', 1712405953, 0), 
(268, 'module', 'shops', 'themes/default/modules/shops/main.tpl', 1712405953, 0), 
(269, 'module', 'shops', 'themes/default/modules/shops/main_cat.tpl', 1712405953, 0), 
(270, 'module', 'shops', 'themes/default/modules/shops/order.tpl', 1712405953, 0), 
(271, 'module', 'shops', 'themes/default/modules/shops/payment.tpl', 1712405953, 0), 
(272, 'module', 'shops', 'themes/default/modules/shops/point.tpl', 1712405953, 0), 
(273, 'module', 'shops', 'themes/default/modules/shops/print.tpl', 1712405953, 0), 
(274, 'module', 'shops', 'themes/default/modules/shops/print_pro.tpl', 1712405953, 0), 
(275, 'module', 'shops', 'themes/default/modules/shops/review_content.tpl', 1712405953, 0), 
(276, 'module', 'shops', 'themes/default/modules/shops/review_list.tpl', 1712405953, 0), 
(277, 'module', 'shops', 'themes/default/modules/shops/search.tpl', 1712405953, 0), 
(278, 'module', 'shops', 'themes/default/modules/shops/tag.tpl', 1712405953, 0), 
(279, 'module', 'shops', 'themes/default/modules/shops/viewcat.tpl', 1712405953, 0), 
(280, 'module', 'shops', 'themes/default/modules/shops/viewgird.tpl', 1712405953, 0), 
(281, 'module', 'shops', 'themes/default/modules/shops/viewlist.tpl', 1712405953, 0), 
(282, 'module', 'shops', 'themes/default/modules/shops/wishlist.tpl', 1712405953, 0), 
(283, 'module', 'shops', 'uploads/shops/2015_05/giay-bup-be-ngoi-sao-nhap-khau.jpg', 1712405953, 0), 
(284, 'module', 'shops', 'assets/shops/2015_05/giay-bup-be-ngoi-sao-nhap-khau.jpg', 1712405953, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_ips`
--

DROP TABLE IF EXISTS `nv4_ips`;
CREATE TABLE `nv4_ips` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(32)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mask` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `area` tinyint(4) NOT NULL,
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`,`type`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_ips`
--

INSERT INTO `nv4_ips` VALUES
(1, 1, '127.0.0.2', 0, 1, 1712405148, 0, '');


-- ---------------------------------------


--
-- Table structure for table `nv4_language`
--

DROP TABLE IF EXISTS `nv4_language`;
CREATE TABLE `nv4_language` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `idfile` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `langtype` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'lang_module',
  `lang_key` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filelang` (`idfile`,`lang_key`,`langtype`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_language_file`
--

DROP TABLE IF EXISTS `nv4_language_file`;
CREATE TABLE `nv4_language_file` (
  `idfile` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_file` varchar(200)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `langtype` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'lang_module',
  PRIMARY KEY (`idfile`),
  UNIQUE KEY `module` (`module`,`admin_file`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_logs`
--

DROP TABLE IF EXISTS `nv4_logs`;
CREATE TABLE `nv4_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `module_name` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_key` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `note_action` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_acess` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL,
  `log_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=333  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_logs`
--

INSERT INTO `nv4_logs` VALUES
(1, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1712405155), 
(2, 'vi', 'modules', 'Kích hoạt module \"contact\"', 'Không', '', 1, 1712405920), 
(3, 'vi', 'modules', 'Kích hoạt module \"about\"', 'Không', '', 1, 1712405925), 
(4, 'vi', 'extensions', 'Cài đặt ứng dụng', 'module-shops-4-5-04.zip', '', 1, 1712405950), 
(5, 'vi', 'modules', 'Thêm module ảo san_pham', '', '', 1, 1712405967), 
(6, 'vi', 'modules', 'Thêm module ảo gioi_thieu', '', '', 1, 1712405988), 
(7, 'vi', 'modules', 'Thêm module ảo lien_he', '', '', 1, 1712405997), 
(8, 'vi', 'modules', 'Thêm module ảo tin_tuc', '', '', 1, 1712406004), 
(9, 'vi', 'modules', 'Thêm module ảo thong_tin', '', '', 1, 1712406018), 
(10, 'vi', 'modules', 'Thiết lập module mới san-pham', '', '', 1, 1712406028), 
(11, 'vi', 'modules', 'Sửa module &ldquo;san-pham&rdquo;', '', '', 1, 1712406035), 
(12, 'vi', 'modules', 'Thiết lập module mới gioi-thieu', '', '', 1, 1712406043), 
(13, 'vi', 'modules', 'Sửa module &ldquo;gioi-thieu&rdquo;', '', '', 1, 1712406047), 
(14, 'vi', 'modules', 'Thiết lập module mới lien-he', '', '', 1, 1712406054), 
(15, 'vi', 'modules', 'Sửa module &ldquo;lien-he&rdquo;', '', '', 1, 1712406057), 
(16, 'vi', 'modules', 'Thiết lập module mới tin-tuc', '', '', 1, 1712406063), 
(17, 'vi', 'modules', 'Cài lại module \"tin-tuc\"', '', '', 1, 1712406078), 
(18, 'vi', 'modules', 'Thiết lập module mới thong-tin', '', '', 1, 1712406088), 
(19, 'vi', 'modules', 'Sửa module &ldquo;thong-tin&rdquo;', '', '', 1, 1712406092), 
(20, 'vi', 'modules', 'Kích hoạt module \"news\"', 'Không', '', 1, 1712406464), 
(21, 'vi', 'modules', 'Thứ tự module: gioi-thieu', '20 -> 1', '', 1, 1712406468), 
(22, 'vi', 'modules', 'Thứ tự module: san-pham', '20 -> 2', '', 1, 1712406470), 
(23, 'vi', 'modules', 'Thứ tự module: tin-tuc', '20 -> 3', '', 1, 1712406472), 
(24, 'vi', 'modules', 'Thứ tự module: lien-he', '20 -> 4', '', 1, 1712406475), 
(25, 'vi', 'modules', 'Thứ tự module: thong-tin', '20 -> 5', '', 1, 1712406477), 
(26, 'vi', 'modules', 'Sửa module &ldquo;tin-tuc&rdquo;', '', '', 1, 1712406484), 
(27, 'vi', 'themes', 'Sửa block', 'Name : top bar-tencty', '', 1, 1712406719), 
(28, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1712536183), 
(29, 'vi', 'san-pham', 'log_edit_catalog', 'id 2', '', 1, 1712536397), 
(30, 'vi', 'san-pham', 'log_edit_catalog', 'id 3', '', 1, 1712536436), 
(31, 'vi', 'san-pham', 'log_edit_catalog', 'id 4', '', 1, 1712536463), 
(32, 'vi', 'san-pham', 'log_edit_catalog', 'id 5', '', 1, 1712536481), 
(33, 'vi', 'san-pham', 'log_add_catalog', 'id 23', '', 1, 1712536513), 
(34, 'vi', 'san-pham', 'log_add_catalog', 'id 24', '', 1, 1712536570), 
(35, 'vi', 'modules', 'Thêm module ảo trang_chu', '', '', 1, 1712537201), 
(36, 'vi', 'modules', 'Thiết lập module mới trang-chu', '', '', 1, 1712537205), 
(37, 'vi', 'modules', 'Sửa module &ldquo;trang-chu&rdquo;', '', '', 1, 1712537209), 
(38, 'vi', 'modules', 'Thứ tự module: trang-chu', '21 -> 1', '', 1, 1712537215), 
(39, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1712537252), 
(40, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1712537355), 
(41, 'vi', 'menu', 'Edit row menu', 'Row menu id: 1', '', 1, 1712537378), 
(42, 'vi', 'menu', 'Edit row menu', 'Row menu id: 2', '', 1, 1712537385), 
(43, 'vi', 'menu', 'Del row menu', 'Row menu id: 3 of Menu id: 1', '', 1, 1712537395), 
(44, 'vi', 'menu', 'Del row menu', 'Row menu id: 4 of Menu id: 1', '', 1, 1712537396), 
(45, 'vi', 'menu', 'Del row menu', 'Row menu id: 5 of Menu id: 1', '', 1, 1712537399), 
(46, 'vi', 'menu', 'Del row menu', 'Row menu id: 6 of Menu id: 1', '', 1, 1712537400), 
(47, 'vi', 'menu', 'Del row menu', 'Row menu id: 7 of Menu id: 1', '', 1, 1712537402), 
(48, 'vi', 'menu', 'Add row menu', 'Row menu id: 23 of Menu id: 1', '', 1, 1712537407), 
(49, 'vi', 'menu', 'Add row menu', 'Row menu id: 24 of Menu id: 1', '', 1, 1712537414), 
(50, 'vi', 'thong-tin', 'Add', ' ', '', 1, 1712537433), 
(51, 'vi', 'menu', 'Add row menu', 'Row menu id: 25 of Menu id: 1', '', 1, 1712537442), 
(52, 'vi', 'menu', 'Del row menu', 'Row menu id: 8,9,10,11,12,13,14,15', '', 1, 1712539948), 
(53, 'vi', 'menu', 'Del row menu', 'Row menu id: 16,17,18,19,20,21,22', '', 1, 1712539955), 
(54, 'vi', 'menu', 'Del row menu', 'Row menu id: 16,17,18,19,20,21,22', '', 1, 1712539969), 
(55, 'vi', 'tin-tuc', 'Thêm chuyên mục', 'Tin nội bộ', '', 1, 1712540004), 
(56, 'vi', 'tin-tuc', 'Thêm chuyên mục', 'Tin hoạt động', '', 1, 1712540008), 
(57, 'vi', 'tin-tuc', 'Thêm chuyên mục', 'Ngành chè', '', 1, 1712540022), 
(58, 'vi', 'tin-tuc', 'Thêm chuyên mục', 'Tuyển dụng', '', 1, 1712540028), 
(59, 'vi', 'tin-tuc', 'Thêm chuyên mục', 'Kiến thức', '', 1, 1712540269), 
(60, 'vi', 'menu', 'Add row menu', 'Row menu id: 26 of Menu id: 1', '', 1, 1712540307), 
(61, 'vi', 'menu', 'Add row menu', 'Row menu id: 27 of Menu id: 1', '', 1, 1712540322), 
(62, 'vi', 'menu', 'Change weight row menu', 'Row menu id: 24, new weight: 7', '', 1, 1712540325), 
(63, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1712542907), 
(64, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1712544679), 
(65, 'vi', 'themes', 'Thêm block', 'Name : global block catalogs', '', 1, 1712544722), 
(66, 'vi', 'themes', 'Sửa block', 'Name : global block catalogs', '', 1, 1712544804), 
(67, 'vi', 'themes', 'Sửa block', 'Name : Danh mục sản phẩm', '', 1, 1712544813), 
(68, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1712545361), 
(69, 'vi', 'san-pham', 'log_edit_catalog', 'id 2', '', 1, 1712545379), 
(70, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1712553063), 
(71, 'vi', 'themes', 'Thêm block', 'Name : header-cty', '', 1, 1712553220), 
(72, 'vi', 'themes', 'Sửa block', 'Name : header-cty', '', 1, 1712553229), 
(73, 'vi', 'themes', 'Sửa block', 'Name : header-cty', '', 1, 1712553255), 
(74, 'vi', 'themes', 'Sửa block', 'Name : header-cty', '', 1, 1712553281), 
(75, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1712559047), 
(76, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1712559070), 
(77, 'vi', 'menu', 'Inactive row menu', 'Row menu id: 26', '', 1, 1712560679), 
(78, 'vi', 'modules', 'Cài lại module \"san-pham\"', '', '', 1, 1712561755), 
(79, 'vi', 'san-pham', 'log_add_catalog', 'id 1', '', 1, 1712561789), 
(80, 'vi', 'san-pham', 'log_add_catalog', 'id 2', '', 1, 1712561803), 
(81, 'vi', 'san-pham', 'log_add_catalog', 'id 3', '', 1, 1712561812), 
(82, 'vi', 'san-pham', 'log_add_catalog', 'id 4', '', 1, 1712561823), 
(83, 'vi', 'themes', 'Thêm block', 'Name : Sản phẩm mới', '', 1, 1712562032), 
(84, 'vi', 'san-pham', 'Add A Product', 'ID: 1', '', 1, 1712562161), 
(85, 'vi', 'san-pham', 'Add A Product', 'ID: 2', '', 1, 1712562192), 
(86, 'vi', 'san-pham', 'Add A Product', 'ID: 3', '', 1, 1712562233), 
(87, 'vi', 'san-pham', 'Add A Product', 'ID: 4', '', 1, 1712562260), 
(88, 'vi', 'themes', 'Sửa block', 'Name : Sản phẩm mới', '', 1, 1712562291), 
(89, 'vi', 'themes', 'Sửa block', 'Name : Sản phẩm mới', '', 1, 1712562309), 
(90, 'vi', 'themes', 'Sửa block', 'Name : Sản phẩm mới', '', 1, 1712562321), 
(91, 'vi', 'themes', 'Thêm block', 'Name : Sản phẩm bán chạy', '', 1, 1712562348), 
(92, 'vi', 'themes', 'Sửa block', 'Name : Sản phẩm mới', '', 1, 1712563066), 
(93, 'vi', 'themes', 'Sửa block', 'Name : Copyright', '', 1, 1712563140), 
(94, 'vi', 'themes', 'Sửa block', 'Name : Công ty chủ quản', '', 1, 1712563310), 
(95, 'vi', 'themes', 'Sửa block', 'Name : Công ty chủ quản', '', 1, 1712563320), 
(96, 'vi', 'themes', 'Sửa block', 'Name : Thông tin công ty', '', 1, 1712563356), 
(97, 'vi', 'san-pham', 'log_edit_catalog', 'id 3', '', 1, 1712563402), 
(98, 'vi', 'san-pham', 'log_edit_catalog', 'id 2', '', 1, 1712563407), 
(99, 'vi', 'san-pham', 'log_edit_catalog', 'id 1', '', 1, 1712563415), 
(100, 'vi', 'upload', 'Upload file', 'uploads/logo-huong-van-tra-1.png.webp', '', 1, 1712563449), 
(101, 'vi', 'san-pham', 'log_add_catalog', 'id 5', '', 1, 1712566161), 
(102, 'vi', 'san-pham', 'log_add_catalog', 'id 6', '', 1, 1712566168), 
(103, 'vi', 'san-pham', 'log_edit_catalog', 'id 6', '', 1, 1712566180), 
(104, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1712566767), 
(105, 'vi', 'themes', 'Thêm block', 'Name : Giỏ hàng', '', 1, 1712566785), 
(106, 'vi', 'themes', 'Sửa block', 'Name : Sản phẩm mới', '', 1, 1712567021), 
(107, 'vi', 'san-pham', 'Add A Product', 'ID: 5', '', 1, 1712567063), 
(108, 'vi', 'san-pham', 'Cấu hình module', 'Setting', '', 1, 1712567259), 
(109, 'vi', 'san-pham', 'Cấu hình module', 'Setting', '', 1, 1712567276), 
(110, 'vi', 'san-pham', 'Cấu hình module', 'Setting', '', 1, 1712567285), 
(111, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1712568553), 
(112, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1712568628), 
(113, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1712630700), 
(114, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1712630726), 
(115, 'vi', 'themes', 'Sửa block', 'Name : Danh mục sản phẩm', '', 1, 1712630747), 
(116, 'vi', 'san-pham', 'Edit A Product', 'ID: 5', '', 1, 1712630844), 
(117, 'vi', 'san-pham', 'Edit A Product', 'ID: 4', '', 1, 1712630847), 
(118, 'vi', 'san-pham', 'Edit A Product', 'ID: 3', '', 1, 1712630851), 
(119, 'vi', 'san-pham', 'Edit A Product', 'ID: 1', '', 1, 1712630853), 
(120, 'vi', 'themes', 'Thêm block', 'Name : Sản phẩm mới', '', 1, 1712630903), 
(121, 'vi', 'themes', 'Thêm block', 'Name : Sản phẩm mới', '', 1, 1712631075), 
(122, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1712639266), 
(123, 'vi', 'san-pham', 'log_add_group', 'id 1', '', 1, 1712639316), 
(124, 'vi', 'san-pham', 'log_add_group', 'id 2', '', 1, 1712639320), 
(125, 'vi', 'san-pham', 'log_add_group', 'id 3', '', 1, 1712639326), 
(126, 'vi', 'san-pham', 'log_add_group', 'id 4', '', 1, 1712639331), 
(127, 'vi', 'san-pham', 'Add A Product', 'ID: 6', '', 1, 1712639363), 
(128, 'vi', 'san-pham', 'Cấu hình module', 'Setting', '', 1, 1712640586), 
(129, 'vi', 'themes', 'Sửa block', 'Name : Sản phẩm mới', '', 1, 1712640627), 
(130, 'vi', 'san-pham', 'Cấu hình module', 'Setting', '', 1, 1712641028), 
(131, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1712661312), 
(132, 'vi', 'san-pham', 'Cấu hình module', 'Setting', '', 1, 1712661340), 
(133, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1712665987), 
(134, 'vi', 'san-pham', 'Cấu hình module', 'Setting', '', 1, 1712668374), 
(135, 'vi', 'tin-tuc', 'log_add_blockcat', ' ', '', 1, 1712669576), 
(136, 'vi', 'tin-tuc', 'log_add_blockcat', ' ', '', 1, 1712669584), 
(137, 'vi', 'themes', 'Thêm block', 'Name : Tin tức - Bài viết', '', 1, 1712669655), 
(138, 'vi', 'tin-tuc', 'Thêm bài viết', 'Ý tưởng để kết hợp trà với bánh trung thu của bạn', '', 1, 1712669713), 
(139, 'vi', 'tin-tuc', 'Thêm bài viết', 'Thưởng thức Trà Sen Sớm để cảm nhận hương vị sớm của Sen', '', 1, 1712669747), 
(140, 'vi', 'tin-tuc', 'Thêm bài viết', 'Hướng dẫn cách pha trà thơm – ngon – giữ nguyên vị trà', '', 1, 1712669970), 
(141, 'vi', 'tin-tuc', 'Thêm bài viết', 'Tuyệt chiêu pha trà ngon cực kỳ đơn giản', '', 1, 1712670024), 
(142, 'vi', 'tin-tuc', 'Thêm bài viết', 'Hai cách ướp trà sen thông dụng nhất', '', 1, 1712670077), 
(143, 'vi', 'san-pham', 'Edit A Product', 'ID: 5', '', 1, 1712670303), 
(144, 'vi', 'san-pham', 'Edit A Product', 'ID: 6', '', 1, 1712670353), 
(145, 'vi', 'san-pham', 'log_edit_catalog', 'id 1', '', 1, 1712670461), 
(146, 'vi', 'san-pham', 'Add A Product', 'ID: 7', '', 1, 1712670558), 
(147, 'vi', 'san-pham', 'Cấu hình module', 'Setting', '', 1, 1712670689), 
(148, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1712712877), 
(149, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1712712882), 
(150, 'vi', 'themes', 'Sửa block', 'Name : Tin tức - Bài viết', '', 1, 1712714964), 
(151, 'vi', 'themes', 'Sửa block', 'Name : Tin tức - Bài viết', '', 1, 1712717647), 
(152, 'vi', 'themes', 'Sửa block', 'Name : Tin tức - Bài viết', '', 1, 1712717704), 
(153, 'vi', 'themes', 'Sửa block', 'Name : Tin tức - Bài viết', '', 1, 1712717713), 
(154, 'vi', 'tin-tuc', 'Sửa bài viết', 'Thưởng thức Trà Sen Sớm để cảm nhận hương vị sớm của Sen', '', 1, 1712717793), 
(155, 'vi', 'tin-tuc', 'Sửa bài viết', 'Ý tưởng để kết hợp trà với bánh trung thu của bạn', '', 1, 1712717807), 
(156, 'vi', 'themes', 'Thêm block', 'Name : Phản hồi khách hàng', '', 1, 1712738387), 
(157, 'vi', 'themes', 'Sửa block', 'Name : Phản hồi khách hàng', '', 1, 1712738674), 
(158, 'vi', 'themes', 'Sửa block', 'Name : Tin tức - Bài viết', '', 1, 1712739944), 
(159, 'vi', 'themes', 'Sửa block', 'Name : Tin tức - Bài viết', '', 1, 1712739949), 
(160, 'vi', 'themes', 'Sửa block', 'Name : Tin tức - Bài viết', '', 1, 1712741108), 
(161, 'vi', 'themes', 'Sửa block', 'Name : Sản phẩm bán chạy', '', 1, 1712741140), 
(162, 'vi', 'themes', 'Sửa block', 'Name : Tin tức - Bài viết', '', 1, 1712741173), 
(163, 'vi', 'themes', 'Sửa block', 'Name : Tin tức - Bài viết', '', 1, 1712741182), 
(164, 'vi', 'themes', 'Sửa block', 'Name : Sản phẩm bán chạy', '', 1, 1712741203), 
(165, 'vi', 'themes', 'Sửa block', 'Name : Thăm dò ý kiến', '', 1, 1712741218), 
(166, 'vi', 'themes', 'Sửa block', 'Name : Thống kê', '', 1, 1712741231), 
(167, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1712743404), 
(168, 'vi', 'san-pham', 'Cấu hình module', 'Setting', '', 1, 1712743495), 
(169, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1712743535), 
(170, 'vi', 'san-pham', 'log_add_catalog', 'id 7', '', 1, 1712743543), 
(171, 'vi', 'san-pham', 'log_edit_catalog', 'id 7', '', 1, 1712743571), 
(172, 'vi', 'san-pham', 'Sửa nhóm sản phẩm', 'Khối lượng', '', 1, 1712743615), 
(173, 'vi', 'san-pham', 'Cấu hình module', 'Setting', '', 1, 1712743726), 
(174, 'vi', 'san-pham', 'log_edit_catalog', 'id 1', '', 1, 1712744342), 
(175, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1712744366), 
(176, 'vi', 'modules', 'Xóa module \"trang-chu\"', '', '', 1, 1712744453), 
(177, 'vi', 'themes', 'Sửa block', 'Name : Phản hồi khách hàng', '', 1, 1712744473), 
(178, 'vi', 'themes', 'Sửa block', 'Name : Phản hồi khách hàng', '', 1, 1712744483), 
(179, 'vi', 'themes', 'Sửa block', 'Name : Phản hồi khách hàng', '', 1, 1712744650), 
(180, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1712795796), 
(181, 'vi', 'san-pham', 'Edit A Product', 'ID: 7', '', 1, 1712795827), 
(182, 'vi', 'san-pham', 'Cấu hình module', 'Setting', '', 1, 1712796239), 
(183, 'vi', 'san-pham', 'Edit A Product', 'ID: 3', '', 1, 1712798240), 
(184, 'vi', 'san-pham', 'Edit A Product', 'ID: 7', '', 1, 1712798252), 
(185, 'vi', 'san-pham', 'Edit A Product', 'ID: 7', '', 1, 1712798265), 
(186, 'vi', 'themes', 'Sửa block', 'Name : Tin tức - Bài viết', '', 1, 1712801117), 
(187, 'vi', 'themes', 'Sửa block', 'Name : Sản phẩm bán chạy', '', 1, 1712801327), 
(188, 'vi', 'san-pham', 'Edit A Product', 'ID: 3', '', 1, 1712801891), 
(189, 'vi', 'themes', 'Sửa block', 'Name : Thống kê', '', 1, 1712802014), 
(190, 'vi', 'themes', 'Thêm block', 'Name : Danh mục sản phẩm', '', 1, 1712802050), 
(191, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1712811695), 
(192, 'vi', 'themes', 'Thêm block', 'Name : Giỏ hàng', '', 1, 1712811733), 
(193, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1712819244), 
(194, 'vi', 'themes', 'Sửa block', 'Name : Danh mục sản phẩm', '', 1, 1712819916), 
(195, 'vi', 'themes', 'Sửa block', 'Name : Sản phẩm bán chạy', '', 1, 1712820292), 
(196, 'vi', 'san-pham', 'Edit A Product', 'ID: 3', '', 1, 1712820311), 
(197, 'vi', 'themes', 'Sửa block', 'Name : Giỏ hàng', '', 1, 1712825721), 
(198, 'vi', 'san-pham', 'log_del_catalog', 'id 7', '', 1, 1712826006), 
(199, 'vi', 'san-pham', 'log_add_catalog', 'id 8', '', 1, 1712826018), 
(200, 'vi', 'san-pham', 'log_del_catalog', 'id 5', '', 1, 1712826027), 
(201, 'vi', 'san-pham', 'log_del_catalog', 'id 6', '', 1, 1712826028), 
(202, 'vi', 'san-pham', 'log_add_catalog', 'id 9', '', 1, 1712826035), 
(203, 'vi', 'upload', 'Upload file', 'uploads/logo-che-tan-cuong-hoang-dat.png', '', 1, 1712826331), 
(204, 'vi', 'login', '[admin] Đăng nhập Thất bại', ' Client IP:171.236.126.15', '', 0, 1712834264), 
(205, 'vi', 'login', '[admin] Đăng nhập Thất bại', ' Client IP:171.236.126.15', '', 0, 1712834267), 
(206, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:171.236.126.15', '', 0, 1712834283), 
(207, 'vi', 'san-pham', 'log_del_product', 'id 7,6,5,4,3,2,1,', '', 1, 1712834360), 
(208, 'vi', 'upload', 'Upload file', 'uploads/san-pham/2024_04/che-bup-trung-du-tan-cuong-thai-nguyen.jpg', '', 1, 1712834417), 
(209, 'vi', 'san-pham', 'Add A Product', 'ID: 8', '', 1, 1712834551), 
(210, 'vi', 'san-pham', 'log_edit_catalog', 'id 1', '', 1, 1712834574), 
(211, 'vi', 'san-pham', 'log_edit_catalog', 'id 2', '', 1, 1712834583), 
(212, 'vi', 'san-pham', 'Cấu hình module', 'Setting', '', 1, 1712834611), 
(213, 'vi', 'san-pham', 'Sửa nhóm sản phẩm', 'Loại chè', '', 1, 1712834641), 
(214, 'vi', 'san-pham', 'log_edit_catalog', 'id 1', '', 1, 1712834659), 
(215, 'vi', 'san-pham', 'Edit A Product', 'ID: 8', '', 1, 1712834672), 
(216, 'vi', 'upload', 'Upload file', 'uploads/san-pham/2024_04/che-bup-trung-du-tan-cuong-thai-nguyen_1.jpg', '', 1, 1712834704), 
(217, 'vi', 'san-pham', 'Edit A Product', 'ID: 8', '', 1, 1712834708), 
(218, 'vi', 'san-pham', 'Edit A Product', 'ID: 8', '', 1, 1712834741), 
(219, 'vi', 'upload', 'Upload file', 'uploads/san-pham/2024_04/che-bup-trung-du-tan-cuong-thai-nguyen-goi-500gram.jpg', '', 1, 1712834796), 
(220, 'vi', 'san-pham', 'Add A Product', 'ID: 9', '', 1, 1712834817), 
(221, 'vi', 'san-pham', 'Add A Product', 'ID: 10', '', 1, 1712834954), 
(222, 'vi', 'san-pham', 'log_edit_catalog', 'id 2', '', 1, 1712835094), 
(223, 'vi', 'san-pham', 'log_edit_catalog', 'id 3', '', 1, 1712835108), 
(224, 'vi', 'san-pham', 'log_edit_catalog', 'id 4', '', 1, 1712835114), 
(225, 'vi', 'upload', 'Upload file', 'uploads/san-pham/2024_04/tra-moc-cau-tan-cuong-thai-nguyen.jpg', '', 1, 1712835167), 
(226, 'vi', 'san-pham', 'Add A Product', 'ID: 11', '', 1, 1712835242), 
(227, 'vi', 'san-pham', 'Add A Product', 'ID: 12', '', 1, 1712835351), 
(228, 'vi', 'san-pham', 'Cấu hình module', 'Setting', '', 1, 1712835428), 
(229, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:171.236.126.15', '', 0, 1712837560), 
(230, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:171.236.126.15', '', 0, 1712839200), 
(231, 'vi', 'san-pham', 'log_edit_catalog', 'id 1', '', 1, 1712840202), 
(232, 'vi', 'san-pham', 'log_edit_catalog', 'id 2', '', 1, 1712840208), 
(233, 'vi', 'san-pham', 'log_edit_catalog', 'id 3', '', 1, 1712840212), 
(234, 'vi', 'san-pham', 'log_edit_catalog', 'id 4', '', 1, 1712840218), 
(235, 'vi', 'san-pham', 'log_edit_catalog', 'id 9', '', 1, 1712840224), 
(236, 'vi', 'san-pham', 'Edit A Product', 'ID: 8', '', 1, 1712840280), 
(237, 'vi', 'san-pham', 'Edit A Product', 'ID: 9', '', 1, 1712840304), 
(238, 'vi', 'san-pham', 'log_edit_catalog', 'id 1', '', 1, 1712840599), 
(239, 'vi', 'san-pham', 'Edit A Product', 'ID: 10', '', 1, 1712840613), 
(240, 'vi', 'san-pham', 'Edit A Product', 'ID: 9', '', 1, 1712840618), 
(241, 'vi', 'san-pham', 'Edit A Product', 'ID: 8', '', 1, 1712840626), 
(242, 'vi', 'san-pham', 'Cấu hình module', 'Setting', '', 1, 1712840806), 
(243, 'vi', 'san-pham', 'Edit A Product', 'ID: 9', '', 1, 1712840813), 
(244, 'vi', 'san-pham', 'Cấu hình module', 'Setting', '', 1, 1712840879), 
(245, 'vi', 'san-pham', 'log_add_location', 'id 1', '', 1, 1712841038), 
(246, 'vi', 'themes', 'Cập nhật lại vị trí các block', 'reset position all block', '', 1, 1712841182), 
(247, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1712842167), 
(248, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1712843766), 
(249, 'vi', 'themes', 'Sửa block', 'Name : Social icon', '', 1, 1712845052), 
(250, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:171.236.126.15', '', 0, 1712850280), 
(251, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1712850293), 
(252, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:171.236.126.15', '', 0, 1712889259), 
(253, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.168.179.153', '', 0, 1712897767), 
(254, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:113.168.179.153', '', 0, 1712899583), 
(255, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.168.179.153', '', 0, 1712904059), 
(256, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.168.179.153', '', 0, 1712909671), 
(257, 'vi', 'themes', 'Sửa block', 'Name : Phản hồi khách hàng', '', 1, 1712909700), 
(258, 'vi', 'themes', 'Sửa block', 'Name : Phản hồi khách hàng', '', 1, 1712909721), 
(259, 'vi', 'san-pham', 'Add A Product', 'ID: 13', '', 1, 1712910888), 
(260, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1712910912), 
(261, 'vi', 'menu', 'Add row menu', 'Row menu id: 28 of Menu id: 1', '', 1, 1712912039), 
(262, 'vi', 'menu', 'Add row menu', 'Row menu id: 29 of Menu id: 1', '', 1, 1712912044), 
(263, 'vi', 'menu', 'Add row menu', 'Row menu id: 30 of Menu id: 1', '', 1, 1712912048), 
(264, 'vi', 'menu', 'Edit row menu', 'Row menu id: 25', '', 1, 1712912062), 
(265, 'vi', 'menu', 'Del row menu', 'Row menu id: 27 of Menu id: 1', '', 1, 1712912068), 
(266, 'vi', 'menu', 'Del row menu', 'Row menu id: 24 of Menu id: 1', '', 1, 1712912070), 
(267, 'vi', 'thong-tin', 'Edit', 'ID: 1', '', 1, 1712912091), 
(268, 'vi', 'thong-tin', 'Add', ' ', '', 1, 1712912111), 
(269, 'vi', 'menu', 'Add row menu', 'Row menu id: 31 of Menu id: 1', '', 1, 1712912121), 
(270, 'vi', 'users', 'log_edit_user', 'userid 1', '', 1, 1712916152), 
(271, 'vi', 'login', '[admin] Đăng nhập Thất bại', ' Client IP:113.168.179.153', '', 0, 1712927324), 
(272, 'vi', 'login', '[admin] Đăng nhập Thất bại', ' Client IP:113.168.179.153', '', 0, 1712927327), 
(273, 'vi', 'login', '[admin] Đăng nhập Thất bại', ' Client IP:113.168.179.153', '', 0, 1712927331), 
(274, 'vi', 'login', '[admin] Đăng nhập Thất bại', ' Client IP:113.168.179.153', '', 0, 1712927336), 
(275, 'vi', 'login', '[admin] Đăng nhập Thất bại', ' Client IP:113.168.179.153', '', 0, 1712927341), 
(276, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.168.179.153', '', 0, 1712929174), 
(277, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1712929179), 
(278, 'vi', 'login', '[admin] Đăng nhập Thất bại', ' Client IP:113.168.179.153', '', 0, 1712939899), 
(279, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.168.179.153', '', 0, 1712939908), 
(280, 'vi', 'themes', 'Thêm block', 'Name : Lọc theo giá', '', 1, 1712939961), 
(281, 'vi', 'themes', 'Sửa block', 'Name : Lọc theo giá', '', 1, 1712939972), 
(282, 'vi', 'themes', 'Sửa block', 'Name : Lọc theo giá', '', 1, 1712939982), 
(283, 'vi', 'themes', 'Sửa block', 'Name : Tìm kiếm sản phẩm', '', 1, 1712940000), 
(284, 'vi', 'themes', 'Sửa block', 'Name : Bán chạy', '', 1, 1712940044), 
(285, 'vi', 'themes', 'Thêm block', 'Name : Sản phẩm mới', '', 1, 1712940091), 
(286, 'vi', 'themes', 'Sửa block', 'Name : Sản phẩm mới', '', 1, 1712940100), 
(287, 'vi', 'themes', 'Cập nhật lại vị trí các block', 'reset position all block', '', 1, 1712940127), 
(288, 'vi', 'themes', 'Sửa block', 'Name : Thống kê', '', 1, 1712940157), 
(289, 'vi', 'upload', 'Upload file', 'uploads/san-pham/2024_04/z4881061494672-bef18896541894c93568d5b21d06817d.jpg', '', 1, 1712940233), 
(290, 'vi', 'san-pham', 'Add A Product', 'ID: 14', '', 1, 1712940254), 
(291, 'vi', 'upload', 'Upload file', 'uploads/san-pham/2024_04/che-bup-trung-du-tan-cuong-thai-nguyen-goi-500gram_1.jpg', '', 1, 1712940333), 
(292, 'vi', 'san-pham', 'Add A Product', 'ID: 15', '', 1, 1712940345), 
(293, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1712940741), 
(294, 'vi', 'login', '[admin] Đăng nhập Thất bại', ' Client IP:171.236.126.15', '', 0, 1712984451), 
(295, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:171.236.126.15', '', 0, 1712984456), 
(296, 'vi', 'upload', 'Upload file', 'uploads/logo-che-tan-cuong-hoang-dat-thai-nguyen.png', '', 1, 1712984495), 
(297, 'vi', 'upload', 'Upload file', 'uploads/che-tan-cuong-hoang-dat-thai-nguyen.png', '', 1, 1712984871), 
(298, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:171.236.126.15', '', 0, 1712998696), 
(299, 'vi', 'san-pham', 'Edit A Product', 'ID: 8', '', 1, 1712998787), 
(300, 'vi', 'san-pham', 'Edit A Product', 'ID: 9', '', 1, 1712998804), 
(301, 'vi', 'san-pham', 'Edit A Product', 'ID: 10', '', 1, 1712998819), 
(302, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1713000482), 
(303, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1713001269), 
(304, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1713001330), 
(305, 'vi', 'themes', 'Sửa block', 'Name : Thông tin công ty', '', 1, 1713001423), 
(306, 'vi', 'themes', 'Sửa block', 'Name : header-cty', '', 1, 1713001443), 
(307, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:171.236.126.15', '', 0, 1713098572), 
(308, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:171.236.126.15', '', 0, 1713098632), 
(309, 'vi', 'login', '[admin] Đăng nhập Thất bại', ' Client IP:171.236.126.15', '', 0, 1713099061), 
(310, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:171.236.126.15', '', 0, 1713099066), 
(311, 'vi', 'upload', 'Upload file', 'uploads/favicon.png', '', 1, 1713099139), 
(312, 'vi', 'san-pham', 'log_del_product', 'id 10,9,8,', '', 1, 1713100060), 
(313, 'vi', 'san-pham', 'log_del_catalog', 'id 1', '', 1, 1713100074), 
(314, 'vi', 'san-pham', 'log_edit_catalog', 'id 8', '', 1, 1713100098), 
(315, 'vi', 'san-pham', 'log_add_catalog', 'id 10', '', 1, 1713100469), 
(316, 'vi', 'san-pham', 'log_add_catalog', 'id 11', '', 1, 1713100607), 
(317, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.168.179.153', '', 0, 1713148055), 
(318, 'vi', 'upload', 'Upload file', 'uploads/logo-an-thai-tan-cuong-tra.png', '', 1, 1713148070), 
(319, 'vi', 'upload', 'Upload file', 'uploads/favicon_1.png', '', 1, 1713148142), 
(320, 'vi', 'upload', 'Upload file', 'uploads/logo-an-thai-tan-cuong-tra_1.png', '', 1, 1713149174), 
(321, 'vi', 'san-pham', 'log_add_catalog', 'id 12', '', 1, 1713149307), 
(322, 'vi', 'upload', 'Upload file', 'uploads/favicon_2.png', '', 1, 1713150023), 
(323, 'vi', 'login', '[admin] Đăng nhập Thất bại', ' Client IP:113.168.179.153', '', 0, 1713170534), 
(324, 'vi', 'login', '[admin] Đăng nhập Thất bại', ' Client IP:113.168.179.153', '', 0, 1713170541), 
(325, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.168.179.153', '', 0, 1713170551), 
(326, 'vi', 'menu', 'Add row menu', 'Row menu id: 32 of Menu id: 1', '', 1, 1713170580), 
(327, 'vi', 'menu', 'Add row menu', 'Row menu id: 33 of Menu id: 1', '', 1, 1713170586), 
(328, 'vi', 'menu', 'Add row menu', 'Row menu id: 34 of Menu id: 1', '', 1, 1713170591), 
(329, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:171.236.126.15', '', 0, 1713186949), 
(330, 'vi', 'menu', 'Active row menu', 'Row menu id: 26', '', 1, 1713187028), 
(331, 'vi', 'menu', 'Change weight row menu', 'Row menu id: 31, new weight: 5', '', 1, 1713187039), 
(332, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1713189588);


-- ---------------------------------------


--
-- Table structure for table `nv4_notification`
--

DROP TABLE IF EXISTS `nv4_notification`;
CREATE TABLE `nv4_notification` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_view_allowed` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Cấp quản trị được xem: 0,1,2',
  `logic_mode` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0: Cấp trên xem được cấp dưới, 1: chỉ cấp hoặc người được chỉ định',
  `send_to` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Danh sách id người nhận, phân cách bởi dấu phảy',
  `send_from` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `area` tinyint(3) unsigned NOT NULL,
  `language` char(3)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `obid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `view` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `send_to` (`send_to`),
  KEY `admin_view_allowed` (`admin_view_allowed`),
  KEY `logic_mode` (`logic_mode`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_plugin`
--

DROP TABLE IF EXISTS `nv4_plugin`;
CREATE TABLE `nv4_plugin` (
  `pid` tinyint(4) NOT NULL AUTO_INCREMENT,
  `plugin_file` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `plugin_area` tinyint(4) NOT NULL,
  `weight` tinyint(4) NOT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `plugin_file` (`plugin_file`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_plugin`
--

INSERT INTO `nv4_plugin` VALUES
(1, 'qrcode.php', 1, 1), 
(2, 'cdn_js_css_image.php', 3, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_block`
--

DROP TABLE IF EXISTS `nv4_san_pham_block`;
CREATE TABLE `nv4_san_pham_block` (
  `bid` int(10) unsigned NOT NULL,
  `id` int(10) unsigned NOT NULL,
  `weight` int(10) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_block`
--

INSERT INTO `nv4_san_pham_block` VALUES
(1, 11, 5), 
(1, 12, 4), 
(1, 13, 3), 
(2, 13, 3), 
(1, 14, 2), 
(2, 14, 2), 
(1, 15, 1), 
(2, 15, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_block_cat`
--

DROP TABLE IF EXISTS `nv4_san_pham_block_cat`;
CREATE TABLE `nv4_san_pham_block_cat` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(1) NOT NULL DEFAULT '0',
  `image` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` smallint(6) NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `vi_title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_description` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_bodytext` text  COLLATE utf8mb4_unicode_ci,
  `vi_keywords` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `vi_tag_title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_tag_description` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`bid`),
  UNIQUE KEY `vi_alias` (`vi_alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_block_cat`
--

INSERT INTO `nv4_san_pham_block_cat` VALUES
(1, 1, '', 1, 1712561925, 1712561925, 'Sản phẩm mới', 'San-pham-moi', 'Sản phẩm mới', 'Sản phẩm mới', '', '', ''), 
(2, 0, '', 2, 1712561935, 1712561935, 'Sản phẩm bán chạy', 'San-pham-ban-chay', 'Sản phẩm bán chạy', 'Sản phẩm bán chạy', '', '', '');


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_carrier`
--

DROP TABLE IF EXISTS `nv4_san_pham_carrier`;
CREATE TABLE `nv4_san_pham_carrier` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(15)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` tinyint(3) unsigned NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_carrier`
--

INSERT INTO `nv4_san_pham_carrier` VALUES
(1, 'Vận chuyển mặc định', '', '', '', '', 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_carrier_config`
--

DROP TABLE IF EXISTS `nv4_san_pham_carrier_config`;
CREATE TABLE `nv4_san_pham_carrier_config` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` tinyint(3) unsigned NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_carrier_config`
--

INSERT INTO `nv4_san_pham_carrier_config` VALUES
(1, 'Vận chuyển mặc định', '', 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_carrier_config_items`
--

DROP TABLE IF EXISTS `nv4_san_pham_carrier_config_items`;
CREATE TABLE `nv4_san_pham_carrier_config_items` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `cid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` smallint(5) unsigned NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_carrier_config_items`
--

INSERT INTO `nv4_san_pham_carrier_config_items` VALUES
(1, 1, 'Giá vận chuyển', '', 1, 1712840998);


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_carrier_config_location`
--

DROP TABLE IF EXISTS `nv4_san_pham_carrier_config_location`;
CREATE TABLE `nv4_san_pham_carrier_config_location` (
  `cid` tinyint(3) unsigned NOT NULL,
  `iid` smallint(5) unsigned NOT NULL,
  `lid` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `cid` (`cid`,`lid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_carrier_config_weight`
--

DROP TABLE IF EXISTS `nv4_san_pham_carrier_config_weight`;
CREATE TABLE `nv4_san_pham_carrier_config_weight` (
  `iid` smallint(5) unsigned NOT NULL,
  `weight` double unsigned NOT NULL,
  `weight_unit` varchar(20)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `carrier_price` double NOT NULL,
  `carrier_price_unit` char(3)  COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_carrier_config_weight`
--

INSERT INTO `nv4_san_pham_carrier_config_weight` VALUES
(1, '3', 'kg', '35000', 'VND'), 
(1, '5', 'kg', '45000', 'VND'), 
(1, '10', 'kg', '100000', 'VND'), 
(1, '15', 'kg', '150000', 'VND'), 
(1, '20', 'kg', '200000', 'VND');


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_catalogs`
--

DROP TABLE IF EXISTS `nv4_san_pham_catalogs`;
CREATE TABLE `nv4_san_pham_catalogs` (
  `catid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `image` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sort` mediumint(9) NOT NULL DEFAULT '0',
  `lev` smallint(6) NOT NULL DEFAULT '0',
  `viewcat` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` int(11) NOT NULL DEFAULT '0',
  `subcatid` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `inhome` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(3) unsigned NOT NULL DEFAULT '3',
  `newday` tinyint(4) NOT NULL DEFAULT '3',
  `typeprice` tinyint(4) NOT NULL DEFAULT '2',
  `form` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `group_price` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `viewdescriptionhtml` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `admins` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(10) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `cat_allow_point` tinyint(1) NOT NULL DEFAULT '0',
  `cat_number_point` tinyint(4) NOT NULL DEFAULT '0',
  `cat_number_product` tinyint(4) NOT NULL DEFAULT '0',
  `vi_title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_title_custom` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_description` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_descriptionhtml` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `vi_keywords` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `vi_tag_description` mediumtext  COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`catid`),
  UNIQUE KEY `vi_alias` (`vi_alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=13  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_catalogs`
--

INSERT INTO `nv4_san_pham_catalogs` VALUES
(11, 0, '', 5, 5, 0, 'viewlist', 0, '', 1, 4, 7, 1, '', '', 1, '', 1713100607, 1713100607, '6', 0, 0, 0, 'Trà ướp hoa', '', 'tra-uop-hoa', '', 'Trà ướp hoa là sản phẩm được sử dụng chè Thái Nguyên đặc sản ướp cùng 1 số loại hoa giúp sản phẩm thêm hấp dẫn, hương vị thơm ngon như: Trà ướp hoa nhài, Trà ướp sen, Trà ướp hoa sói,...', '', ''), 
(2, 0, '', 2, 2, 0, 'viewgrid', 0, '', 1, 4, 7, 1, 'thong_tin_khac', '', 0, '', 1712561803, 1712840208, '6', 0, 0, 0, 'Chè Móc câu', '', 'che-moc-cau', 'Chè móc câu Thái Nguyên', 'Chè móc câu Thái Nguyên', 'Chè móc câu Thái Nguyên', ''), 
(3, 0, '', 3, 3, 0, 'viewgrid', 0, '', 1, 4, 7, 1, 'thong_tin_khac', '', 1, '', 1712561812, 1712840212, '6', 0, 0, 0, 'Chè Tôm nõn', '', 'che-tom-non', 'Chè tôm nõn', 'Chè tôm nõn', 'Chè tôm nõn', ''), 
(4, 0, '', 4, 4, 0, 'viewgrid', 0, '', 1, 4, 7, 1, 'thong_tin_khac', '', 1, '', 1712561823, 1712840218, '6', 0, 0, 0, 'Chè Đinh Cao Cấp', '', 'Che-Dinh-Cao-Cap', '', '', '', ''), 
(9, 0, '', 8, 8, 0, 'viewlist', 0, '', 1, 4, 7, 1, 'thong_tin_khac', '', 0, '', 1712826035, 1712840224, '6', 0, 0, 0, 'Trà cụ', '', 'Tra-cu', '', '', '', ''), 
(8, 0, '', 6, 6, 0, 'viewlist', 0, '', 1, 4, 7, 1, '', '', 0, '', 1712826018, 1713100098, '6', 0, 0, 0, 'Hộp trà - Quà tặng', '', 'Hop-tra-qua-tang', '', '', '', ''), 
(10, 0, '', 1, 1, 0, 'viewlist', 0, '', 1, 4, 7, 1, '', '', 0, '', 1713100469, 1713100469, '6', 0, 0, 0, 'Chè dùng thử', '', 'che-dung-thu', '', 'Chè dùng thử là sản phẩm dùng thử, được đóng gói nhỏ giá thành thấp cho khách hàng mua thưởng thức thử trà Thái Nguyên tại Công ty Trà Tân Cương Hoàng Đạt', '', ''), 
(12, 0, '', 7, 7, 0, 'viewlist', 0, '', 1, 4, 7, 1, '', '', 0, '', 1713149307, 1713149307, '6', 0, 0, 0, 'Ấm trà', '', 'Am-tra', '', '', '', '');


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_coupons`
--

DROP TABLE IF EXISTS `nv4_san_pham_coupons`;
CREATE TABLE `nv4_san_pham_coupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `code` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `type` varchar(1)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'p',
  `discount` double NOT NULL DEFAULT '0',
  `total_amount` double NOT NULL DEFAULT '0',
  `date_start` int(10) unsigned NOT NULL DEFAULT '0',
  `date_end` int(10) unsigned NOT NULL DEFAULT '0',
  `uses_per_coupon` int(10) unsigned NOT NULL DEFAULT '0',
  `uses_per_coupon_count` int(11) NOT NULL DEFAULT '0',
  `date_added` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_coupons_history`
--

DROP TABLE IF EXISTS `nv4_san_pham_coupons_history`;
CREATE TABLE `nv4_san_pham_coupons_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `date_added` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_coupons_product`
--

DROP TABLE IF EXISTS `nv4_san_pham_coupons_product`;
CREATE TABLE `nv4_san_pham_coupons_product` (
  `cid` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL,
  UNIQUE KEY `cid` (`cid`,`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_discounts`
--

DROP TABLE IF EXISTS `nv4_san_pham_discounts`;
CREATE TABLE `nv4_san_pham_discounts` (
  `did` smallint(6) NOT NULL AUTO_INCREMENT,
  `title` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` smallint(6) NOT NULL DEFAULT '0',
  `add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(10) unsigned NOT NULL DEFAULT '0',
  `begin_time` int(10) unsigned NOT NULL DEFAULT '0',
  `end_time` int(10) unsigned NOT NULL DEFAULT '0',
  `config` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `detail` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`did`),
  KEY `begin_time` (`begin_time`,`end_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_field`
--

DROP TABLE IF EXISTS `nv4_san_pham_field`;
CREATE TABLE `nv4_san_pham_field` (
  `fid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `field` varchar(25)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `listtemplate` varchar(25)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `tab` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` int(10) unsigned NOT NULL DEFAULT '1',
  `field_type` enum('number','date','textbox','textarea','editor','select','radio','checkbox','multiselect')  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'textbox',
  `field_choices` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `sql_choices` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `match_type` enum('none','alphanumeric','email','url','regex','callback')  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `match_regex` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `func_callback` varchar(75)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `min_length` int(11) NOT NULL DEFAULT '0',
  `max_length` bigint(20) unsigned NOT NULL DEFAULT '0',
  `class` varchar(25)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `language` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `default_value` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`fid`),
  UNIQUE KEY `field` (`field`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_field`
--

INSERT INTO `nv4_san_pham_field` VALUES
(2, 'thongtinkhac', '2', '', 1, 'editor', '', '', 'none', '', '', 0, 500, '100%@100px', 'a:1:{s:2:\"vi\";a:2:{i:0;s:16:\"Thông tin khác\";i:1;s:100:\"Nhập vào thông tin khác của sản phẩm như:
- Khối lượng
- Kích thước
- Loại\";}}', '');


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_field_value_vi`
--

DROP TABLE IF EXISTS `nv4_san_pham_field_value_vi`;
CREATE TABLE `nv4_san_pham_field_value_vi` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `rows_id` int(10) unsigned NOT NULL,
  `field_id` mediumint(9) NOT NULL,
  `field_value` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rows_id` (`rows_id`,`field_id`)
) ENGINE=MyISAM  AUTO_INCREMENT=9  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_field_value_vi`
--

INSERT INTO `nv4_san_pham_field_value_vi` VALUES
(6, 13, 2, '- Khối lượng: 500gram<br />- Kiểu đóng gói: Túi chân không 500gram'), 
(7, 14, 2, 'Nõn tôm'), 
(8, 15, 2, 'Đinh cao cấp');


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_files`
--

DROP TABLE IF EXISTS `nv4_san_pham_files`;
CREATE TABLE `nv4_san_pham_files` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `path` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `filesize` int(10) unsigned NOT NULL DEFAULT '0',
  `extension` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `download_groups` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '-1',
  `status` tinyint(3) unsigned DEFAULT '1',
  `vi_title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_description` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_files_rows`
--

DROP TABLE IF EXISTS `nv4_san_pham_files_rows`;
CREATE TABLE `nv4_san_pham_files_rows` (
  `id_rows` int(10) unsigned NOT NULL,
  `id_files` mediumint(8) unsigned NOT NULL,
  `download_hits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `id_files` (`id_files`,`id_rows`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_group`
--

DROP TABLE IF EXISTS `nv4_san_pham_group`;
CREATE TABLE `nv4_san_pham_group` (
  `groupid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `image` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sort` mediumint(9) NOT NULL DEFAULT '0',
  `lev` smallint(6) NOT NULL DEFAULT '0',
  `viewgroup` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'viewgrid',
  `numsubgroup` int(11) NOT NULL DEFAULT '0',
  `subgroupid` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `inhome` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `indetail` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(10) unsigned NOT NULL DEFAULT '0',
  `numpro` int(10) unsigned NOT NULL DEFAULT '0',
  `in_order` tinyint(4) NOT NULL DEFAULT '0',
  `is_require` tinyint(1) NOT NULL DEFAULT '0',
  `vi_title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_description` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_keywords` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`groupid`),
  UNIQUE KEY `vi_alias` (`vi_alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_group`
--

INSERT INTO `nv4_san_pham_group` VALUES
(1, 0, '', 1, 1, 0, 'viewgrid', 3, '2,3,4', 1, 0, 1712639316, 1712834641, 0, 1, 0, 'Loại chè', 'khoi-luong', '', ''), 
(2, 1, '', 1, 2, 1, 'viewgrid', 0, '', 1, 0, 1712639320, 1712639320, 0, 1, 0, '1kg', '1kg', '', ''), 
(3, 1, '', 2, 3, 1, 'viewgrid', 0, '', 1, 0, 1712639326, 1712639326, 0, 1, 0, '500 gram', '500-gram', '', ''), 
(4, 1, '', 3, 4, 1, 'viewgrid', 0, '', 1, 0, 1712639331, 1712639331, 0, 1, 0, '200 gram', '200-gram', '', '');


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_group_cateid`
--

DROP TABLE IF EXISTS `nv4_san_pham_group_cateid`;
CREATE TABLE `nv4_san_pham_group_cateid` (
  `groupid` mediumint(8) unsigned NOT NULL,
  `cateid` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `groupid` (`groupid`,`cateid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_group_cateid`
--

INSERT INTO `nv4_san_pham_group_cateid` VALUES
(1, 1), 
(1, 2), 
(1, 3), 
(1, 4);


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_group_items`
--

DROP TABLE IF EXISTS `nv4_san_pham_group_items`;
CREATE TABLE `nv4_san_pham_group_items` (
  `pro_id` int(10) unsigned NOT NULL DEFAULT '0',
  `group_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`pro_id`,`group_id`),
  KEY `pro_id` (`pro_id`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_group_quantity`
--

DROP TABLE IF EXISTS `nv4_san_pham_group_quantity`;
CREATE TABLE `nv4_san_pham_group_quantity` (
  `pro_id` int(10) unsigned NOT NULL DEFAULT '0',
  `listgroup` varchar(247)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(10) unsigned NOT NULL,
  UNIQUE KEY `pro_id` (`pro_id`,`listgroup`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_location`
--

DROP TABLE IF EXISTS `nv4_san_pham_location`;
CREATE TABLE `nv4_san_pham_location` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sort` mediumint(9) NOT NULL DEFAULT '0',
  `lev` smallint(6) NOT NULL DEFAULT '0',
  `numsub` int(11) NOT NULL DEFAULT '0',
  `subid` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_location`
--

INSERT INTO `nv4_san_pham_location` VALUES
(1, 0, 'Việt Nam', 1, 1, 0, 0, '');


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_money_vi`
--

DROP TABLE IF EXISTS `nv4_san_pham_money_vi`;
CREATE TABLE `nv4_san_pham_money_vi` (
  `id` mediumint(9) NOT NULL,
  `code` char(3)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `symbol` varchar(3)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `exchange` double NOT NULL DEFAULT '0',
  `round` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_format` varchar(5)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ',||.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_money_vi`
--

INSERT INTO `nv4_san_pham_money_vi` VALUES
(840, 'USD', 'US Dollar', '$', '21000', '0.01', ',||.'), 
(704, 'VND', 'Vietnam Dong', 'đ', '1', '100', ',||.');


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_orders`
--

DROP TABLE IF EXISTS `nv4_san_pham_orders`;
CREATE TABLE `nv4_san_pham_orders` (
  `order_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_code` varchar(30)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lang` char(2)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `order_name` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_email` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_phone` varchar(20)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_address` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_note` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `admin_id` int(10) unsigned NOT NULL DEFAULT '0',
  `shop_id` int(10) unsigned NOT NULL DEFAULT '0',
  `who_is` int(10) unsigned NOT NULL DEFAULT '0',
  `unit_total` char(3)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_total` double unsigned NOT NULL DEFAULT '0',
  `order_time` int(10) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(10) unsigned NOT NULL DEFAULT '0',
  `postip` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_view` tinyint(4) NOT NULL DEFAULT '0',
  `transaction_status` tinyint(4) NOT NULL,
  `transaction_id` int(11) NOT NULL DEFAULT '0',
  `transaction_count` int(11) NOT NULL,
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `order_code` (`order_code`),
  KEY `user_id` (`user_id`),
  KEY `order_time` (`order_time`),
  KEY `shop_id` (`shop_id`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_orders`
--

INSERT INTO `nv4_san_pham_orders` VALUES
(1, 'S000001', 'vi', 'admin', 'vucongtinh@gmail.com', '098877852', '', '', 1, 0, 0, 0, 'VND', '150000', 1712840843, 0, '171.236.126.15', 1, 0, 0, 0), 
(2, 'S000002', 'vi', 'admin', 'vucongtinh@gmail.com', '0964888550', '', '', 1, 0, 0, 0, 'VND', '300000', 1712841122, 0, '171.236.126.15', 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_orders_id`
--

DROP TABLE IF EXISTS `nv4_san_pham_orders_id`;
CREATE TABLE `nv4_san_pham_orders_id` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `listgroupid` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `proid` mediumint(9) NOT NULL,
  `num` mediumint(9) NOT NULL,
  `price` double NOT NULL DEFAULT '0',
  `discount_id` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `orderid` (`order_id`,`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_orders_id`
--

INSERT INTO `nv4_san_pham_orders_id` VALUES
(1, 1, '', 9, 1, '150000', 0), 
(2, 2, '', 10, 1, '300000', 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_orders_id_group`
--

DROP TABLE IF EXISTS `nv4_san_pham_orders_id_group`;
CREATE TABLE `nv4_san_pham_orders_id_group` (
  `order_i` int(11) NOT NULL,
  `group_id` mediumint(9) NOT NULL,
  UNIQUE KEY `orderid` (`order_i`,`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_orders_shipping`
--

DROP TABLE IF EXISTS `nv4_san_pham_orders_shipping`;
CREATE TABLE `nv4_san_pham_orders_shipping` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `ship_name` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `ship_phone` varchar(25)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `ship_location_id` mediumint(8) unsigned NOT NULL,
  `ship_address_extend` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `ship_shops_id` tinyint(3) unsigned NOT NULL,
  `ship_carrier_id` tinyint(3) unsigned NOT NULL,
  `weight` double NOT NULL DEFAULT '0',
  `weight_unit` char(20)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `ship_price` double NOT NULL DEFAULT '0',
  `ship_price_unit` char(3)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `add_time` int(10) unsigned NOT NULL,
  `edit_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `add_time` (`add_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_point`
--

DROP TABLE IF EXISTS `nv4_san_pham_point`;
CREATE TABLE `nv4_san_pham_point` (
  `userid` int(11) NOT NULL DEFAULT '0',
  `point_total` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_point_history`
--

DROP TABLE IF EXISTS `nv4_san_pham_point_history`;
CREATE TABLE `nv4_san_pham_point_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL DEFAULT '0',
  `order_id` int(11) NOT NULL,
  `point` int(11) NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_point_queue`
--

DROP TABLE IF EXISTS `nv4_san_pham_point_queue`;
CREATE TABLE `nv4_san_pham_point_queue` (
  `order_id` int(11) NOT NULL,
  `point` mediumint(9) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_review`
--

DROP TABLE IF EXISTS `nv4_san_pham_review`;
CREATE TABLE `nv4_san_pham_review` (
  `review_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `sender` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` int(11) NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`review_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_rows`
--

DROP TABLE IF EXISTS `nv4_san_pham_rows`;
CREATE TABLE `nv4_san_pham_rows` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `listcatid` int(11) NOT NULL DEFAULT '0',
  `user_id` mediumint(9) NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(10) unsigned NOT NULL DEFAULT '0',
  `exptime` int(10) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `product_code` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `product_number` int(11) NOT NULL DEFAULT '0',
  `product_price` double NOT NULL DEFAULT '0',
  `price_config` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `saleprice` double NOT NULL DEFAULT '0',
  `money_unit` char(3)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_unit` smallint(6) NOT NULL,
  `product_weight` double NOT NULL DEFAULT '0',
  `weight_unit` char(20)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `discount_id` smallint(6) NOT NULL DEFAULT '0',
  `homeimgfile` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `homeimgalt` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `otherimage` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `gift_from` int(10) unsigned NOT NULL DEFAULT '0',
  `gift_to` int(10) unsigned NOT NULL DEFAULT '0',
  `inhome` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ratingdetail` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `allowed_send` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowed_print` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowed_save` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitslm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `num_sell` mediumint(9) NOT NULL DEFAULT '0',
  `showprice` tinyint(4) NOT NULL DEFAULT '0',
  `vi_title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `vi_bodytext` mediumtext  COLLATE utf8mb4_unicode_ci,
  `vi_gift_content` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `vi_address` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `vi_tag_title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_tag_description` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vi_alias` (`vi_alias`),
  KEY `listcatid` (`listcatid`),
  KEY `user_id` (`user_id`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`)
) ENGINE=MyISAM  AUTO_INCREMENT=16  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_rows`
--

INSERT INTO `nv4_san_pham_rows` VALUES
(11, 2, 1, 1712835242, 1712835242, 1, 1712835242, 0, 2, 'S000011', 1, '35000', '', '0', 'VND', 1, '100', 'g', 0, '2024_04/tra-moc-cau-tan-cuong-thai-nguyen.jpg', 1, 'trà móc câu tân cương thái nguyên', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 3, 0, 0, 0, 1, 'Chè Móc Câu Tân Cương 100gram', 'che-moc-cau-tan-cuong-100gram', 'Là loại chè Tân Cương Thái Nguyên được hái 1 tôm 2 lá, búp chè sau khi chế biến có hình dáng như 1 chiếc móc câu, hương thơm nhẹ, màu xanh nhạt, ngọt hậu', 'Là loại chè Tân Cương Thái Nguyên được hái 1 tôm 2 lá, búp chè sau khi chế biến có hình dáng như 1 chiếc móc câu, hương thơm nhẹ, màu xanh nhạt, ngọt hậu<br />Đóng gói 100gram khách hàng có thể mua dùng thử', '', '', '', ''), 
(12, 2, 1, 1712835242, 1712835242, 1, 1712835351, 0, 2, 'S000012', 1, '70000', '', '0', 'VND', 1, '200', 'g', 0, '2024_04/tra-moc-cau-tan-cuong-thai-nguyen.jpg', 1, 'trà móc câu tân cương thái nguyên', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 5, 0, 0, 0, 1, 'Chè Móc Câu Tân Cương 200gram', 'che-moc-cau-tan-cuong-200gram', 'Là loại chè Tân Cương Thái Nguyên được hái 1 tôm 2 lá, búp chè sau khi chế biến có hình dáng như 1 chiếc móc câu, hương thơm nhẹ, màu xanh nhạt, ngọt hậu', 'Là loại chè Tân Cương Thái Nguyên được hái 1 tôm 2 lá, búp chè sau khi chế biến có hình dáng như 1 chiếc móc câu, hương thơm nhẹ, màu xanh nhạt, ngọt hậu<br />Đóng gói 200gram khách hàng uống ít có thể mua sử dụng tránh mua nhiều để lâu', '', '', '', ''), 
(13, 2, 1, 1712910888, 1712910888, 1, 1712910888, 0, 2, 'S000013', 1, '350000', '', '0', 'VND', 2, '500', 'g', 0, '2024_04/tra-moc-cau-tan-cuong-thai-nguyen.jpg', 1, 'Chè Móc Câu Tân Cương 500gram Thái Nguyên', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 2, 0, 0, 0, 1, 'Chè Móc Câu Tân Cương 500gram', 'che-moc-cau-tan-cuong-500gram', 'Là loại chè được hái 1 tôm 2 lá, đóng gói túi chân không 500gram. Có túi giấy tặng kèm', 'Là loại chè được hái 1 tôm 2 lá, đóng gói túi chân không 500gram. Có túi giấy tặng kèm', '', '', '', ''), 
(14, 3, 1, 1712940254, 1712940254, 1, 1712940254, 0, 2, 'S000014', 1, '350000', '', '0', 'VND', 1, '500', 'g', 0, '2024_04/z4881061494672-bef18896541894c93568d5b21d06817d.jpg', 1, 'Nõn tôm mẫu', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 0, 0, 0, 0, 1, 'Nõn tôm mẫu', 'non-tom-mau', 'Nõn tôm mẫu', 'Nõn tôm mẫu', '', '', '', ''), 
(15, 4, 1, 1712940345, 1712940345, 1, 1712940345, 0, 2, 'S000015', 1, '3500000', '', '0', 'VND', 1, '500', 'g', 0, '2024_04/che-bup-trung-du-tan-cuong-thai-nguyen-goi-500gram_1.jpg', 1, 'Đinh cao cấp', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 7, 0, 0, 0, 1, 'Đinh cao cấp', 'dinh-cao-cap', 'Đinh cao cấp', 'Đinh cao cấp', '', '', '', '');


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_shops`
--

DROP TABLE IF EXISTS `nv4_san_pham_shops`;
CREATE TABLE `nv4_san_pham_shops` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `address` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` tinyint(3) unsigned NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_shops`
--

INSERT INTO `nv4_san_pham_shops` VALUES
(1, 'Kho', 1, '', '', 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_shops_carrier`
--

DROP TABLE IF EXISTS `nv4_san_pham_shops_carrier`;
CREATE TABLE `nv4_san_pham_shops_carrier` (
  `shops_id` tinyint(3) unsigned NOT NULL,
  `carrier_id` tinyint(3) unsigned NOT NULL,
  `config_id` tinyint(3) unsigned NOT NULL,
  UNIQUE KEY `shops_id` (`shops_id`,`carrier_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_shops_carrier`
--

INSERT INTO `nv4_san_pham_shops_carrier` VALUES
(1, 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_tabs`
--

DROP TABLE IF EXISTS `nv4_san_pham_tabs`;
CREATE TABLE `nv4_san_pham_tabs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `icon` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `content` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` int(10) unsigned NOT NULL DEFAULT '1',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `vi_title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_tabs`
--

INSERT INTO `nv4_san_pham_tabs` VALUES
(4, '', 'content_customdata', 2, 1, 'Thông tin khác'), 
(3, '', 'content_detail', 1, 1, 'Mô tả');


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_tags_id_vi`
--

DROP TABLE IF EXISTS `nv4_san_pham_tags_id_vi`;
CREATE TABLE `nv4_san_pham_tags_id_vi` (
  `id` int(11) NOT NULL,
  `tid` mediumint(9) NOT NULL,
  `keyword` varchar(65)  COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `sid` (`id`,`tid`),
  KEY `tid` (`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_tags_id_vi`
--

INSERT INTO `nv4_san_pham_tags_id_vi` VALUES
(1, 1, 'Ví dụ hộp chè'), 
(7, 2, 'mô tả'), 
(8, 3, 'trung du'), 
(8, 4, 'thái nguyên'), 
(8, 5, 'chăm sóc'), 
(8, 6, 'phương pháp'), 
(8, 7, 'hữu cơ'), 
(8, 8, 'giá thành'), 
(8, 9, 'hợp lý'), 
(8, 10, 'đa số'), 
(8, 11, 'chè búp thái nguyên'), 
(8, 12, 'chè trung du'), 
(9, 5, 'chăm sóc'), 
(9, 11, 'chè búp thái nguyên'), 
(9, 12, 'chè trung du'), 
(9, 10, 'đa số'), 
(9, 8, 'giá thành'), 
(9, 9, 'hợp lý'), 
(9, 7, 'hữu cơ'), 
(9, 6, 'phương pháp'), 
(9, 4, 'thái nguyên'), 
(9, 3, 'trung du'), 
(10, 5, 'chăm sóc'), 
(10, 11, 'chè búp thái nguyên'), 
(10, 12, 'chè trung du'), 
(10, 10, 'đa số'), 
(10, 8, 'giá thành'), 
(10, 9, 'hợp lý'), 
(10, 7, 'hữu cơ'), 
(10, 6, 'phương pháp'), 
(10, 4, 'thái nguyên'), 
(10, 3, 'trung du'), 
(11, 13, 'trà móc câu tân cương thái nguyên'), 
(11, 14, 'trà móc câu thái nguyên'), 
(12, 13, 'trà móc câu tân cương thái nguyên'), 
(12, 14, 'trà móc câu thái nguyên'), 
(13, 15, 'chè móc câu'), 
(13, 16, 'chè thái nguyên'), 
(14, 17, 'Nõn tôm mẫu'), 
(15, 18, 'Đinh cao cấp');


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_tags_vi`
--

DROP TABLE IF EXISTS `nv4_san_pham_tags_vi`;
CREATE TABLE `nv4_san_pham_tags_vi` (
  `tid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `numpro` mediumint(9) NOT NULL DEFAULT '0',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `bodytext` text  COLLATE utf8mb4_unicode_ci,
  `keywords` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`tid`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=19  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_tags_vi`
--

INSERT INTO `nv4_san_pham_tags_vi` VALUES
(1, 1, 'ví-dụ-hộp-chè', '', '', '', 'Ví dụ hộp chè'), 
(2, 1, 'mô-tả', '', '', '', 'mô tả'), 
(3, 3, 'trung-du', '', '', '', 'trung du'), 
(4, 3, 'thái-nguyên', '', '', '', 'thái nguyên'), 
(5, 3, 'chăm-sóc', '', '', '', 'chăm sóc'), 
(6, 3, 'phương-pháp', '', '', '', 'phương pháp'), 
(7, 3, 'hữu-cơ', '', '', '', 'hữu cơ'), 
(8, 3, 'giá-thành', '', '', '', 'giá thành'), 
(9, 3, 'hợp-lý', '', '', '', 'hợp lý'), 
(10, 3, 'đa-số', '', '', '', 'đa số'), 
(11, 3, 'chè-búp-thái-nguyên', '', '', '', 'chè búp thái nguyên'), 
(12, 3, 'chè-trung-du', '', '', '', 'chè trung du'), 
(13, 2, 'trà-móc-câu-tân-cương-thái-nguyên', '', '', '', 'trà móc câu tân cương thái nguyên'), 
(14, 2, 'trà-móc-câu-thái-nguyên', '', '', '', 'trà móc câu thái nguyên'), 
(15, 1, 'chè-móc-câu', '', '', '', 'chè móc câu'), 
(16, 1, 'chè-thái-nguyên', '', '', '', 'chè thái nguyên'), 
(17, 1, 'nõn-tôm-mẫu', '', '', '', 'Nõn tôm mẫu'), 
(18, 1, 'đinh-cao-cấp', '', '', '', 'Đinh cao cấp');


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_template`
--

DROP TABLE IF EXISTS `nv4_san_pham_template`;
CREATE TABLE `nv4_san_pham_template` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '1',
  `vi_title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_template`
--

INSERT INTO `nv4_san_pham_template` VALUES
(2, 1, 'thong-tin-khac', 1, 'Thông tin khác');


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_transaction`
--

DROP TABLE IF EXISTS `nv4_san_pham_transaction`;
CREATE TABLE `nv4_san_pham_transaction` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_time` int(11) NOT NULL DEFAULT '0',
  `transaction_status` int(11) NOT NULL,
  `order_id` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `payment` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `payment_id` varchar(22)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `payment_time` int(11) NOT NULL DEFAULT '0',
  `payment_amount` double NOT NULL DEFAULT '0',
  `payment_data` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`transaction_id`),
  KEY `order_id` (`order_id`),
  KEY `payment_id` (`payment_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_units`
--

DROP TABLE IF EXISTS `nv4_san_pham_units`;
CREATE TABLE `nv4_san_pham_units` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vi_title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_note` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_units`
--

INSERT INTO `nv4_san_pham_units` VALUES
(1, 'Hộp', ''), 
(2, 'Gói', ''), 
(3, 'Túi', '');


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_warehouse`
--

DROP TABLE IF EXISTS `nv4_san_pham_warehouse`;
CREATE TABLE `nv4_san_pham_warehouse` (
  `wid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` mediumint(9) NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`wid`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_warehouse`
--

INSERT INTO `nv4_san_pham_warehouse` VALUES
(1, 'Nhập kho ngày 09/04/2024', '', 1, 1712670764);


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_warehouse_logs`
--

DROP TABLE IF EXISTS `nv4_san_pham_warehouse_logs`;
CREATE TABLE `nv4_san_pham_warehouse_logs` (
  `logid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wid` int(10) unsigned NOT NULL DEFAULT '0',
  `pro_id` int(10) unsigned NOT NULL DEFAULT '0',
  `quantity` int(10) unsigned NOT NULL DEFAULT '0',
  `price` double NOT NULL DEFAULT '0',
  `money_unit` char(3)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`logid`),
  KEY `wid` (`wid`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_warehouse_logs`
--

INSERT INTO `nv4_san_pham_warehouse_logs` VALUES
(1, 1, 7, 11, '207000', 'VND');


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_warehouse_logs_group`
--

DROP TABLE IF EXISTS `nv4_san_pham_warehouse_logs_group`;
CREATE TABLE `nv4_san_pham_warehouse_logs_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `logid` int(10) unsigned NOT NULL DEFAULT '0',
  `listgroup` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(10) unsigned NOT NULL DEFAULT '0',
  `price` double NOT NULL DEFAULT '0',
  `money_unit` char(3)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `logid` (`logid`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_warehouse_logs_group`
--

INSERT INTO `nv4_san_pham_warehouse_logs_group` VALUES
(1, 1, '4', 1, '100000', 'VND'), 
(2, 1, '2', 10, '107000', 'VND');


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_weight_vi`
--

DROP TABLE IF EXISTS `nv4_san_pham_weight_vi`;
CREATE TABLE `nv4_san_pham_weight_vi` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `code` char(20)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `exchange` double NOT NULL DEFAULT '0',
  `round` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_san_pham_weight_vi`
--

INSERT INTO `nv4_san_pham_weight_vi` VALUES
(1, 'g', 'Gram', '1', '0.1'), 
(2, 'kg', 'Kilogam', '1000', '0.1');


-- ---------------------------------------


--
-- Table structure for table `nv4_san_pham_wishlist`
--

DROP TABLE IF EXISTS `nv4_san_pham_wishlist`;
CREATE TABLE `nv4_san_pham_wishlist` (
  `wid` smallint(6) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `listid` text  COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`wid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_sessions`
--

DROP TABLE IF EXISTS `nv4_sessions`;
CREATE TABLE `nv4_sessions` (
  `session_id` varchar(50)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `onl_time` int(10) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `session_id` (`session_id`),
  KEY `onl_time` (`onl_time`)
) ENGINE=MEMORY  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_sessions`
--

INSERT INTO `nv4_sessions` VALUES
('pdirtdl6vrv8sppctn30qncvh3', 0, 'guest', 1713253336);


-- ---------------------------------------


--
-- Table structure for table `nv4_setup_extensions`
--

DROP TABLE IF EXISTS `nv4_setup_extensions`;
CREATE TABLE `nv4_setup_extensions` (
  `id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'other',
  `title` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_sys` tinyint(1) NOT NULL DEFAULT '0',
  `is_virtual` tinyint(1) NOT NULL DEFAULT '0',
  `basename` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `table_prefix` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `version` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `author` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  UNIQUE KEY `title` (`type`,`title`),
  KEY `id` (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_setup_extensions`
--

INSERT INTO `nv4_setup_extensions` VALUES
(0, 'module', 'about', 0, 0, 'page', 'about', '4.5.04 1689930000', 1712405092, 'VINADES <contact@vinades.vn>', ''), 
(0, 'module', 'siteterms', 0, 0, 'page', 'siteterms', '4.5.04 1689930000', 1712405092, 'VINADES <contact@vinades.vn>', ''), 
(19, 'module', 'banners', 1, 0, 'banners', 'banners', '4.5.04 1689930000', 1712405092, 'VINADES <contact@vinades.vn>', ''), 
(20, 'module', 'contact', 0, 1, 'contact', 'contact', '4.5.04 1689930000', 1712405092, 'VINADES <contact@vinades.vn>', ''), 
(1, 'module', 'news', 0, 1, 'news', 'news', '4.5.04 1689930000', 1712405092, 'VINADES <contact@vinades.vn>', ''), 
(21, 'module', 'voting', 0, 0, 'voting', 'voting', '4.5.04 1689930000', 1712405092, 'VINADES <contact@vinades.vn>', ''), 
(31, 'module', 'shops', 0, 1, 'shops', 'shops', '4.5.04 1712405953', 1712405953, 'vinades (nukeviet.store@vinades.vn)', 'Module shops cho phép xây dựng website thương mại điện tử nhanh chóng và chuyên nghiệp.'), 
(284, 'module', 'seek', 1, 0, 'seek', 'seek', '4.5.04 1689930000', 1712405092, 'VINADES <contact@vinades.vn>', ''), 
(24, 'module', 'users', 1, 1, 'users', 'users', '4.5.04 1689930000', 1712405092, 'VINADES <contact@vinades.vn>', ''), 
(27, 'module', 'statistics', 0, 0, 'statistics', 'statistics', '4.5.04 1689930000', 1712405092, 'VINADES <contact@vinades.vn>', ''), 
(29, 'module', 'menu', 0, 0, 'menu', 'menu', '4.5.04 1689930000', 1712405092, 'VINADES <contact@vinades.vn>', ''), 
(283, 'module', 'feeds', 1, 0, 'feeds', 'feeds', '4.5.04 1689930000', 1712405092, 'VINADES <contact@vinades.vn>', ''), 
(282, 'module', 'page', 1, 1, 'page', 'page', '4.5.04 1689930000', 1712405092, 'VINADES <contact@vinades.vn>', ''), 
(281, 'module', 'comment', 1, 0, 'comment', 'comment', '4.5.04 1689930000', 1712405092, 'VINADES <contact@vinades.vn>', ''), 
(312, 'module', 'freecontent', 0, 1, 'freecontent', 'freecontent', '4.5.04 1689930000', 1712405092, 'VINADES <contact@vinades.vn>', ''), 
(327, 'module', 'two-step-verification', 1, 0, 'two-step-verification', 'two_step_verification', '4.5.04 1689930000', 1712405092, 'VINADES <contact@vinades.vn>', ''), 
(307, 'theme', 'default', 0, 0, 'default', 'default', '4.5.04 1689930000', 1712405092, 'VINADES <contact@vinades.vn>', ''), 
(311, 'theme', 'mobile_default', 0, 0, 'mobile_default', 'mobile_default', '4.5.04 1689930000', 1712405092, 'VINADES <contact@vinades.vn>', ''), 
(0, 'module', 'san-pham', 0, 0, 'shops', 'san_pham', '', 1712405967, '', ''), 
(0, 'module', 'gioi-thieu', 0, 0, 'page', 'gioi_thieu', '', 1712405988, '', ''), 
(0, 'module', 'lien-he', 0, 0, 'contact', 'lien_he', '', 1712405997, '', ''), 
(0, 'module', 'tin-tuc', 0, 0, 'news', 'tin_tuc', '', 1712406004, '', ''), 
(0, 'module', 'thong-tin', 0, 0, 'page', 'thong_tin', '', 1712406018, '', '');


-- ---------------------------------------


--
-- Table structure for table `nv4_setup_language`
--

DROP TABLE IF EXISTS `nv4_setup_language`;
CREATE TABLE `nv4_setup_language` (
  `lang` char(2)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `setup` tinyint(1) NOT NULL DEFAULT '0',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_setup_language`
--

INSERT INTO `nv4_setup_language` VALUES
('vi', 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_upload_dir`
--

DROP TABLE IF EXISTS `nv4_upload_dir`;
CREATE TABLE `nv4_upload_dir` (
  `did` mediumint(9) NOT NULL AUTO_INCREMENT,
  `dirname` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  `total_size` double unsigned NOT NULL DEFAULT '0' COMMENT 'Dung lượng thư mục',
  `thumb_type` tinyint(4) NOT NULL DEFAULT '0',
  `thumb_width` smallint(6) NOT NULL DEFAULT '0',
  `thumb_height` smallint(6) NOT NULL DEFAULT '0',
  `thumb_quality` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`did`),
  UNIQUE KEY `name` (`dirname`)
) ENGINE=MyISAM  AUTO_INCREMENT=31  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_upload_dir`
--

INSERT INTO `nv4_upload_dir` VALUES
(0, '', 0, '0', 3, 300, 300, 90), 
(1, 'uploads', 1712405147, '1426237', 0, 0, 0, 0), 
(2, 'uploads/about', 1712405147, '242102', 0, 0, 0, 0), 
(3, 'uploads/banners', 1712405147, '179287', 0, 0, 0, 0), 
(4, 'uploads/banners/files', 1712405147, '0', 0, 0, 0, 0), 
(5, 'uploads/comment', 1712405147, '0', 0, 0, 0, 0), 
(6, 'uploads/contact', 1712405147, '0', 0, 0, 0, 0), 
(7, 'uploads/freecontent', 1712405147, '138096', 0, 0, 0, 0), 
(8, 'uploads/menu', 1712405147, '0', 0, 0, 0, 0), 
(9, 'uploads/news', 1712405147, '866752', 0, 0, 0, 0), 
(10, 'uploads/news/authors', 1712405147, '0', 0, 0, 0, 0), 
(11, 'uploads/news/source', 1712405147, '0', 0, 0, 0, 0), 
(12, 'uploads/news/temp_pic', 1712405147, '0', 0, 0, 0, 0), 
(13, 'uploads/news/topics', 1712405147, '0', 0, 0, 0, 0), 
(14, 'uploads/page', 1712405147, '0', 0, 0, 0, 0), 
(15, 'uploads/siteterms', 1712405147, '0', 0, 0, 0, 0), 
(16, 'uploads/users', 1712405147, '0', 0, 0, 0, 0), 
(17, 'uploads/users/groups', 1712405147, '0', 0, 0, 0, 0), 
(18, 'uploads/san-pham', 0, '0', 0, 0, 0, 0), 
(19, 'uploads/san-pham/temp_pic', 0, '0', 0, 0, 0, 0), 
(20, 'uploads/san-pham/2024_04', 1712834405, '0', 0, 0, 0, 0), 
(21, 'uploads/san-pham/files', 0, '0', 0, 0, 0, 0), 
(22, 'uploads/gioi-thieu', 0, '0', 0, 0, 0, 0), 
(23, 'uploads/lien-he', 0, '0', 0, 0, 0, 0), 
(24, 'uploads/tin-tuc', 0, '0', 0, 0, 0, 0), 
(25, 'uploads/tin-tuc/source', 0, '0', 0, 0, 0, 0), 
(26, 'uploads/tin-tuc/temp_pic', 0, '0', 0, 0, 0, 0), 
(27, 'uploads/tin-tuc/topics', 0, '0', 0, 0, 0, 0), 
(28, 'uploads/thong-tin', 0, '0', 0, 0, 0, 0), 
(30, 'uploads/tin-tuc/2024_04', 0, '0', 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_upload_file`
--

DROP TABLE IF EXISTS `nv4_upload_file`;
CREATE TABLE `nv4_upload_file` (
  `name` varchar(245)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `ext` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `type` varchar(5)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `filesize` double NOT NULL DEFAULT '0',
  `src` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `srcwidth` int(11) NOT NULL DEFAULT '0',
  `srcheight` int(11) NOT NULL DEFAULT '0',
  `sizes` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `mtime` int(11) NOT NULL DEFAULT '0',
  `did` int(11) NOT NULL DEFAULT '0',
  `title` varchar(245)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alt` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  UNIQUE KEY `did` (`did`,`title`),
  KEY `userid` (`userid`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_upload_file`
--

INSERT INTO `nv4_upload_file` VALUES
('logo-nukev...png', 'png', 'image', '13223', 'assets/about/logo-nukeviet3-flag-180x75.png', 80, 34, '180|75', 1, 1690186812, 2, 'logo-nukeviet3-flag-180x75.png', 'logo nukeviet3 flag 180x75'), 
('nukevietcm...png', 'png', 'image', '11974', 'assets/about/nukevietcms-180x84.png', 80, 38, '180|84', 1, 1690186812, 2, 'nukevietcms-180x84.png', 'nukevietcms 180x84'), 
('nukevietcms.png', 'png', 'image', '85684', 'assets/about/nukevietcms.png', 80, 38, '1500|700', 1, 1690186812, 2, 'nukevietcms.png', 'nukevietcms'), 
('nukevietcm...png', 'png', 'image', '13125', 'assets/about/nukevietcms_laco_180x57.png', 80, 26, '180|57', 1, 1690186812, 2, 'nukevietcms_laco_180x57.png', 'nukevietcms laco 180x57'), 
('nukevietcm...png', 'png', 'image', '13319', 'assets/about/nukevietcms_mu_noel_180x84.png', 80, 38, '180|84', 1, 1690186812, 2, 'nukevietcms_mu_noel_180x84.png', 'nukevietcms mu noel 180x84'), 
('nukevietvn.png', 'png', 'image', '81035', 'assets/about/nukevietvn.png', 80, 38, '1500|700', 1, 1690186812, 2, 'nukevietvn.png', 'nukevietvn'), 
('nukevietvn...png', 'png', 'image', '11586', 'assets/about/nukevietvn_180x84.png', 80, 38, '180|84', 1, 1690186812, 2, 'nukevietvn_180x84.png', 'nukevietvn 180x84'), 
('w.png', 'png', 'image', '12156', 'assets/about/w.png', 80, 40, '288|143', 1, 1690186812, 2, 'w.png', 'w'), 
('vinades.jpg', 'jpg', 'image', '104940', 'assets/banners/vinades.jpg', 43, 80, '212|400', 1, 1690186812, 3, 'vinades.jpg', 'vinades'), 
('webnhanh.jpg', 'jpg', 'image', '74347', 'assets/banners/webnhanh.jpg', 80, 10, '572|72', 1, 1690186812, 3, 'webnhanh.jpg', 'webnhanh'), 
('cms.jpg', 'jpg', 'image', '29026', 'assets/freecontent/cms.jpg', 80, 44, '130|71', 1, 1690186812, 7, 'cms.jpg', 'cms'), 
('edugate.jpg', 'jpg', 'image', '28008', 'assets/freecontent/edugate.jpg', 80, 44, '130|71', 1, 1690186812, 7, 'edugate.jpg', 'edugate'), 
('portal.jpg', 'jpg', 'image', '25973', 'assets/freecontent/portal.jpg', 80, 44, '130|71', 1, 1690186812, 7, 'portal.jpg', 'portal'), 
('shop.jpg', 'jpg', 'image', '26352', 'assets/freecontent/shop.jpg', 80, 44, '130|71', 1, 1690186812, 7, 'shop.jpg', 'shop'), 
('toa-soan-d...jpg', 'jpg', 'image', '28737', 'assets/freecontent/toa-soan-dien-tu.jpg', 80, 44, '130|71', 1, 1690186812, 7, 'toa-soan-dien-tu.jpg', 'toa soan dien tu'), 
('chuc-mung-...jpg', 'jpg', 'image', '130708', 'assets/news/chuc-mung-nukeviet-thong-tu-20-bo-tttt.jpg', 80, 62, '461|360', 1, 1690186812, 9, 'chuc-mung-nukeviet-thong-tu-20-bo-tttt.jpg', 'chuc mung nukeviet thong tu 20 bo tttt'), 
('hoc-viec-t...jpg', 'jpg', 'image', '167193', 'assets/news/hoc-viec-tai-cong-ty-vinades.jpg', 80, 63, '460|360', 1, 1690186812, 9, 'hoc-viec-tai-cong-ty-vinades.jpg', 'hoc viec tai cong ty vinades'), 
('hoptac 6.jpg', 'jpg', 'image', '12871', 'uploads/news/hoptac 6.jpg', 80, 66, '382|314', 1, 1690186812, 9, 'hoptac 6.jpg', 'hoptac 6'), 
('hoptac.jpg', 'jpg', 'image', '12871', 'assets/news/hoptac.jpg', 80, 66, '382|314', 1, 1690186812, 9, 'hoptac.jpg', 'hoptac'), 
('nangly.jpg', 'jpg', 'image', '34802', 'assets/news/nangly.jpg', 80, 53, '500|332', 1, 1690186812, 9, 'nangly.jpg', 'nangly'), 
('nukeviet-cms.jpg', 'jpg', 'image', '83489', 'assets/news/nukeviet-cms.jpg', 80, 55, '500|345', 1, 1690186812, 9, 'nukeviet-cms.jpg', 'nukeviet cms'), 
('nukeviet-n...jpg', 'jpg', 'image', '18611', 'assets/news/nukeviet-nhantaidatviet2011.jpg', 80, 54, '400|268', 1, 1690186812, 9, 'nukeviet-nhantaidatviet2011.jpg', 'nukeviet nhantaidatviet2011'), 
('tap-huan-p...jpg', 'jpg', 'image', '132379', 'assets/news/tap-huan-pgd-ha-dong-2015.jpg', 80, 52, '460|295', 1, 1690186812, 9, 'tap-huan-pgd-ha-dong-2015.jpg', 'tap huan pgd ha dong 2015'), 
('thuc-tap-sinh.jpg', 'jpg', 'image', '71135', 'assets/news/thuc-tap-sinh.jpg', 80, 63, '460|360', 1, 1690186812, 9, 'thuc-tap-sinh.jpg', 'thuc tap sinh'), 
('tuyen-dung...png', 'png', 'image', '118910', 'assets/news/tuyen-dung-nvkd.png', 80, 56, '400|279', 1, 1690186812, 9, 'tuyen-dung-nvkd.png', 'tuyen dung nvkd'), 
('tuyendung-...jpg', 'jpg', 'image', '83783', 'assets/news/tuyendung-kythuat.jpg', 80, 80, '300|300', 1, 1690186812, 9, 'tuyendung-kythuat.jpg', 'tuyendung kythuat'), 
('logo-huon...webp', 'webp', 'image', '46306', 'assets/logo-huong-van-tra-1.png.webp', 80, 58, '800|577', 1, 1712563449, 1, 'logo-huong-van-tra-1.png.webp', 'logo huong van tra 1 png'), 
('logo-che-t...png', 'png', 'image', '49705', 'assets/logo-che-tan-cuong-hoang-dat.png', 80, 46, '576|324', 1, 1712826331, 1, 'logo-che-tan-cuong-hoang-dat.png', 'logo che tan cuong hoang dat'), 
('che-bup-tr...jpg', 'jpg', 'image', '140491', 'assets/san-pham/2024_04/che-bup-trung-du-tan-cuong-thai-nguyen.jpg', 80, 60, '800|600', 1, 1712834417, 20, 'che-bup-trung-du-tan-cuong-thai-nguyen.jpg', 'chè búp trung du tân cương thái nguyên'), 
('che-bup-tr...jpg', 'jpg', 'image', '46627', 'assets/san-pham/2024_04/che-bup-trung-du-tan-cuong-thai-nguyen_1.jpg', 80, 80, '500|500', 1, 1712834704, 20, 'che-bup-trung-du-tan-cuong-thai-nguyen_1.jpg', 'chè búp trung du tân cương thái nguyên'), 
('che-bup-tr...jpg', 'jpg', 'image', '230479', 'assets/san-pham/2024_04/che-bup-trung-du-tan-cuong-thai-nguyen-goi-500gram.jpg', 80, 80, '640|640', 1, 1712834796, 20, 'che-bup-trung-du-tan-cuong-thai-nguyen-goi-500gram.jpg', 'chè búp trung du tân cương thái nguyên   gói 500gram'), 
('tra-moc-ca...jpg', 'jpg', 'image', '155594', 'assets/san-pham/2024_04/tra-moc-cau-tan-cuong-thai-nguyen.jpg', 80, 80, '800|800', 1, 1712835167, 20, 'tra-moc-cau-tan-cuong-thai-nguyen.jpg', 'trà móc câu tân cương thái nguyên'), 
('z488106149...jpg', 'jpg', 'image', '138502', 'assets/san-pham/2024_04/z4881061494672-bef18896541894c93568d5b21d06817d.jpg', 75, 80, '454|480', 1, 1712940233, 20, 'z4881061494672-bef18896541894c93568d5b21d06817d.jpg', 'z4881061494672 bef18896541894c93568d5b21d06817d'), 
('che-bup-tr...jpg', 'jpg', 'image', '230479', 'assets/san-pham/2024_04/che-bup-trung-du-tan-cuong-thai-nguyen-goi-500gram_1.jpg', 80, 80, '640|640', 1, 1712940333, 20, 'che-bup-trung-du-tan-cuong-thai-nguyen-goi-500gram_1.jpg', 'che bup trung du tan cuong thai nguyen goi 500gram'), 
('logo-che-t...png', 'png', 'image', '38651', 'assets/logo-che-tan-cuong-hoang-dat-thai-nguyen.png', 80, 29, '981|354', 1, 1712984495, 1, 'logo-che-tan-cuong-hoang-dat-thai-nguyen.png', 'logo chè tân cương hoàng đạt thái nguyên'), 
('che-tan-cu...png', 'png', 'image', '14363', 'assets/che-tan-cuong-hoang-dat-thai-nguyen.png', 80, 27, '300|100', 1, 1712984871, 1, 'che-tan-cuong-hoang-dat-thai-nguyen.png', 'chè tân cương hoàng đạt thái nguyên'), 
('favicon.png', 'png', 'image', '11859', 'assets/favicon.png', 80, 39, '196|95', 1, 1713099139, 1, 'favicon.png', 'favicon'), 
('logo-an-th...png', 'png', 'image', '13516', 'assets/logo-an-thai-tan-cuong-tra.png', 80, 48, '225|134', 1, 1713148070, 1, 'logo-an-thai-tan-cuong-tra.png', 'logo an thai tan cuong tra'), 
('favicon_1.png', 'png', 'image', '8782', 'assets/favicon_1.png', 76, 76, '76|76', 1, 1713148142, 1, 'favicon_1.png', 'favicon'), 
('logo-an-th...png', 'png', 'image', '13831', 'assets/logo-an-thai-tan-cuong-tra_1.png', 80, 48, '225|134', 1, 1713149174, 1, 'logo-an-thai-tan-cuong-tra_1.png', 'logo an thai tan cuong tra'), 
('favicon_2.png', 'png', 'image', '8169', 'assets/favicon_2.png', 76, 76, '76|76', 1, 1713150023, 1, 'favicon_2.png', 'favicon');


-- ---------------------------------------


--
-- Table structure for table `nv4_users`
--

DROP TABLE IF EXISTS `nv4_users`;
CREATE TABLE `nv4_users` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `username` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `md5username` char(32)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(150)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `gender` char(1)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `photo` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `birthday` int(11) NOT NULL,
  `sig` text  COLLATE utf8mb4_unicode_ci,
  `regdate` int(11) NOT NULL DEFAULT '0',
  `question` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `passlostkey` varchar(50)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `view_mail` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `remember` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `in_groups` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `active` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `active2step` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `secretkey` varchar(20)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `checknum` varchar(40)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_login` int(10) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_agent` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_openid` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_update` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Thời điểm cập nhật thông tin lần cuối',
  `idsite` int(11) NOT NULL DEFAULT '0',
  `safemode` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `safekey` varchar(40)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `email_verification_time` int(11) NOT NULL DEFAULT '-1' COMMENT '-3: Tài khoản sys, -2: Admin kích hoạt, -1 không cần kích hoạt, 0: Chưa xác minh, > 0 thời gian xác minh',
  `active_obj` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'SYSTEM' COMMENT 'SYSTEM, EMAIL, OAUTH:xxxx, quản trị kích hoạt thì lưu userid',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`),
  KEY `idsite` (`idsite`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_users`
--

INSERT INTO `nv4_users` VALUES
(1, 1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '{SSHA512}VP1vi0EucTMxG/TrLEOb+t1BhtwhxPUeokDXMNOdaQWMNkdGDiJ+RrZgZmxSuJGqI4ct0Jb9cQPR2eMyK0P2AjNhOGI=', 'vucongtinh@gmail.com', 'admin', '', 'M', '', 544208400, '', 1712405147, 'ten', 'tjnh', '', 0, 1, '1,4', 1, 0, '', '', 1712405147, '', '', '', 1712916152, 0, 0, '', -3, 'SYSTEM');


-- ---------------------------------------


--
-- Table structure for table `nv4_users_backupcodes`
--

DROP TABLE IF EXISTS `nv4_users_backupcodes`;
CREATE TABLE `nv4_users_backupcodes` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_used` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `time_used` int(10) unsigned NOT NULL DEFAULT '0',
  `time_creat` int(10) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`,`code`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_users_config`
--

DROP TABLE IF EXISTS `nv4_users_config`;
CREATE TABLE `nv4_users_config` (
  `config` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text  COLLATE utf8mb4_unicode_ci,
  `edit_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`config`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_users_config`
--

INSERT INTO `nv4_users_config` VALUES
('access_admin', 'a:8:{s:15:\"access_viewlist\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:12:\"access_addus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:14:\"access_waiting\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:17:\"access_editcensor\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_editus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:12:\"access_delus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_passus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_groups\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}}', 1352873462), 
('password_simple', '000000|1234|2000|12345|111111|123123|123456|11223344|654321|696969|1234567|12345678|87654321|123456789|23456789|1234567890|66666666|68686868|66668888|88888888|99999999|999999999|1234569|12345679|aaaaaa|abc123|abc123@|abc@123|admin123|admin123@|admin@123|nuke123|nuke123@|nuke@123|adobe1|adobe123|azerty|baseball|dragon|football|harley|iloveyou|jennifer|jordan|letmein|macromedia|master|michael|monkey|mustang|password|photoshop|pussy|qwerty|shadow|superman|hoilamgi|khongbiet|khongco|khongcopass', 1712405092), 
('deny_email', 'yoursite.com|mysite.com|localhost|xxx', 1712405092), 
('deny_name', 'anonimo|anonymous|god|linux|nobody|operator|root', 1712405092), 
('avatar_width', '80', 1712405092), 
('avatar_height', '80', 1712405092), 
('active_group_newusers', '0', 1712405092), 
('active_editinfo_censor', '0', 1712405092), 
('active_user_logs', '1', 1712405092), 
('min_old_user', '16', 1712405092), 
('register_active_time', '86400', 1712405092), 
('auto_assign_oauthuser', '0', 1712405092), 
('admin_email', '0', 1712405092), 
('siteterms_vi', '<p> Để trở thành thành viên, bạn phải cam kết đồng ý với các điều khoản dưới đây. Chúng tôi có thể thay đổi lại những điều khoản này vào bất cứ lúc nào và chúng tôi sẽ cố gắng thông báo đến bạn kịp thời.<br /> <br /> Bạn cam kết không gửi bất cứ bài viết có nội dung lừa đảo, thô tục, thiếu văn hoá; vu khống, khiêu khích, đe doạ người khác; liên quan đến các vấn đề tình dục hay bất cứ nội dung nào vi phạm luật pháp của quốc gia mà bạn đang sống, luật pháp của quốc gia nơi đặt máy chủ của website này hay luật pháp quốc tế. Nếu vẫn cố tình vi phạm, ngay lập tức bạn sẽ bị cấm tham gia vào website. Địa chỉ IP của tất cả các bài viết đều được ghi nhận lại để bảo vệ các điều khoản cam kết này trong trường hợp bạn không tuân thủ.<br /> <br /> Bạn đồng ý rằng website có quyền gỡ bỏ, sửa, di chuyển hoặc khoá bất kỳ bài viết nào trong website vào bất cứ lúc nào tuỳ theo nhu cầu công việc.<br /> <br /> Đăng ký làm thành viên của chúng tôi, bạn cũng phải đồng ý rằng, bất kỳ thông tin cá nhân nào mà bạn cung cấp đều được lưu trữ trong cơ sở dữ liệu của hệ thống. Mặc dù những thông tin này sẽ không được cung cấp cho bất kỳ người thứ ba nào khác mà không được sự đồng ý của bạn, chúng tôi không chịu trách nhiệm về việc những thông tin cá nhân này của bạn bị lộ ra bên ngoài từ những kẻ phá hoại có ý đồ xấu tấn công vào cơ sở dữ liệu của hệ thống.</p>', 1274757129);


-- ---------------------------------------


--
-- Table structure for table `nv4_users_edit`
--

DROP TABLE IF EXISTS `nv4_users_edit`;
CREATE TABLE `nv4_users_edit` (
  `userid` mediumint(8) unsigned NOT NULL,
  `lastedit` int(10) unsigned NOT NULL DEFAULT '0',
  `info_basic` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `info_custom` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_users_field`
--

DROP TABLE IF EXISTS `nv4_users_field`;
CREATE TABLE `nv4_users_field` (
  `fid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `field` varchar(25)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` int(10) unsigned NOT NULL DEFAULT '1',
  `field_type` enum('number','date','textbox','textarea','editor','select','radio','checkbox','multiselect')  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'textbox',
  `field_choices` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `sql_choices` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `match_type` enum('none','alphanumeric','unicodename','email','url','regex','callback')  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `match_regex` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `func_callback` varchar(75)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `min_length` int(11) NOT NULL DEFAULT '0',
  `max_length` bigint(20) unsigned NOT NULL DEFAULT '0',
  `required` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `show_register` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `user_editable` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `show_profile` tinyint(4) NOT NULL DEFAULT '1',
  `class` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `default_value` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `is_system` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`fid`),
  UNIQUE KEY `field` (`field`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_users_field`
--

INSERT INTO `nv4_users_field` VALUES
(1, 'first_name', 1, 'textbox', '', '', 'none', '', '', 0, 100, 1, 1, 1, 1, 'input', 'a:1:{s:2:\"vi\";a:2:{i:0;s:4:\"Tên\";i:1;s:0:\"\";}}', '', 1), 
(2, 'last_name', 2, 'textbox', '', '', 'none', '', '', 0, 100, 0, 1, 1, 1, 'input', 'a:1:{s:2:\"vi\";a:2:{i:0;s:20:\"Họ và tên đệm\";i:1;s:0:\"\";}}', '', 1), 
(3, 'gender', 3, 'select', 'a:3:{s:1:\"N\";s:0:\"\";s:1:\"M\";s:0:\"\";s:1:\"F\";s:0:\"\";}', '', 'none', '', '', 0, 1, 0, 1, 1, 1, 'input', 'a:1:{s:2:\"vi\";a:2:{i:0;s:12:\"Giới tính\";i:1;s:0:\"\";}}', '2', 1), 
(4, 'birthday', 4, 'date', 'a:1:{s:12:\"current_date\";i:0;}', '', 'none', '', '', 0, 0, 1, 1, 1, 1, 'input', 'a:1:{s:2:\"vi\";a:2:{i:0;s:22:\"Ngày tháng năm sinh\";i:1;s:0:\"\";}}', '0', 1), 
(5, 'sig', 5, 'textarea', '', '', 'none', '', '', 0, 1000, 0, 1, 1, 1, 'input', 'a:1:{s:2:\"vi\";a:2:{i:0;s:9:\"Chữ ký\";i:1;s:0:\"\";}}', '', 1), 
(6, 'question', 6, 'textbox', '', '', 'none', '', '', 3, 255, 1, 1, 1, 1, 'input', 'a:1:{s:2:\"vi\";a:2:{i:0;s:22:\"Câu hỏi bảo mật\";i:1;s:0:\"\";}}', '', 1), 
(7, 'answer', 7, 'textbox', '', '', 'none', '', '', 3, 255, 1, 1, 1, 1, 'input', 'a:1:{s:2:\"vi\";a:2:{i:0;s:22:\"Trả lời câu hỏi\";i:1;s:0:\"\";}}', '', 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_users_groups`
--

DROP TABLE IF EXISTS `nv4_users_groups`;
CREATE TABLE `nv4_users_groups` (
  `group_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `alias` varchar(240)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `group_type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0:Sys, 1:approval, 2:public',
  `group_color` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_avatar` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `require_2step_admin` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `require_2step_site` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `is_default` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL,
  `exp_time` int(11) NOT NULL,
  `weight` int(10) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(3) unsigned NOT NULL,
  `idsite` int(10) unsigned NOT NULL DEFAULT '0',
  `numbers` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `siteus` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `config` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `kalias` (`alias`,`idsite`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=13  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_users_groups`
--

INSERT INTO `nv4_users_groups` VALUES
(1, 'Super-Admin', '', 0, '', '', 0, 0, 0, 1712405092, 0, 1, 1, 0, 1, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(2, 'General-Admin', '', 0, '', '', 0, 0, 0, 1712405092, 0, 2, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(3, 'Module-Admin', '', 0, '', '', 0, 0, 0, 1712405092, 0, 3, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(4, 'Users', '', 0, '', '', 0, 0, 0, 1712405092, 0, 4, 1, 0, 1, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(7, 'New-Users', '', 0, '', '', 0, 0, 0, 1712405092, 0, 5, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(5, 'Guest', '', 0, '', '', 0, 0, 0, 1712405092, 0, 6, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(6, 'All', '', 0, '', '', 0, 0, 0, 1712405092, 0, 7, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(10, 'NukeViet-Fans', '', 2, '', '', 0, 0, 1, 1712405092, 0, 8, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(11, 'NukeViet-Admins', '', 2, '', '', 0, 0, 0, 1712405092, 0, 9, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(12, 'NukeViet-Programmers', '', 1, '', '', 0, 0, 0, 1712405092, 0, 10, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}');


-- ---------------------------------------


--
-- Table structure for table `nv4_users_groups_detail`
--

DROP TABLE IF EXISTS `nv4_users_groups_detail`;
CREATE TABLE `nv4_users_groups_detail` (
  `group_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `lang` char(2)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(240)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(240)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `content` text  COLLATE utf8mb4_unicode_ci,
  UNIQUE KEY `group_id_lang` (`lang`,`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_users_groups_detail`
--

INSERT INTO `nv4_users_groups_detail` VALUES
(1, 'vi', 'Super Admin', '', ''), 
(2, 'vi', 'General Admin', '', ''), 
(3, 'vi', 'Module Admin', '', ''), 
(4, 'vi', 'Users', '', ''), 
(7, 'vi', 'New Users', '', ''), 
(5, 'vi', 'Guest', '', ''), 
(6, 'vi', 'All', '', ''), 
(10, 'vi', 'Người hâm mộ', 'Nhóm những người hâm mộ hệ thống NukeViet', ''), 
(11, 'vi', 'Người quản lý', 'Nhóm những người quản lý website xây dựng bằng hệ thống NukeViet', ''), 
(12, 'vi', 'Lập trình viên', 'Nhóm Lập trình viên hệ thống NukeViet', '');


-- ---------------------------------------


--
-- Table structure for table `nv4_users_groups_users`
--

DROP TABLE IF EXISTS `nv4_users_groups_users`;
CREATE TABLE `nv4_users_groups_users` (
  `group_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `is_leader` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `approved` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `data` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `time_requested` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Thời gian yêu cầu tham gia',
  `time_approved` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Thời gian duyệt yêu cầu tham gia',
  PRIMARY KEY (`group_id`,`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_users_groups_users`
--

INSERT INTO `nv4_users_groups_users` VALUES
(1, 1, 1, 1, '0', 1712405147, 1712405147);


-- ---------------------------------------


--
-- Table structure for table `nv4_users_info`
--

DROP TABLE IF EXISTS `nv4_users_info`;
CREATE TABLE `nv4_users_info` (
  `userid` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_users_info`
--

INSERT INTO `nv4_users_info` VALUES
(1);


-- ---------------------------------------


--
-- Table structure for table `nv4_users_openid`
--

DROP TABLE IF EXISTS `nv4_users_openid`;
CREATE TABLE `nv4_users_openid` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `openid` char(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `opid` char(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `id` char(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  UNIQUE KEY `opid` (`openid`,`opid`),
  KEY `userid` (`userid`),
  KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_users_question`
--

DROP TABLE IF EXISTS `nv4_users_question`;
CREATE TABLE `nv4_users_question` (
  `qid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(240)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lang` char(2)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`qid`),
  UNIQUE KEY `title` (`title`,`lang`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_users_question`
--

INSERT INTO `nv4_users_question` VALUES
(1, 'Bạn thích môn thể thao nào nhất', 'vi', 1, 1274840238, 1274840238), 
(2, 'Món ăn mà bạn yêu thích', 'vi', 2, 1274840250, 1274840250), 
(3, 'Thần tượng điện ảnh của bạn', 'vi', 3, 1274840257, 1274840257), 
(4, 'Bạn thích nhạc sỹ nào nhất', 'vi', 4, 1274840264, 1274840264), 
(5, 'Quê ngoại của bạn ở đâu', 'vi', 5, 1274840270, 1274840270), 
(6, 'Tên cuốn sách &quot;gối đầu giường&quot;', 'vi', 6, 1274840278, 1274840278), 
(7, 'Ngày lễ mà bạn luôn mong đợi', 'vi', 7, 1274840285, 1274840285);


-- ---------------------------------------


--
-- Table structure for table `nv4_users_reg`
--

DROP TABLE IF EXISTS `nv4_users_reg`;
CREATE TABLE `nv4_users_reg` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `md5username` char(32)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(150)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `gender` char(1)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `birthday` int(11) NOT NULL,
  `sig` text  COLLATE utf8mb4_unicode_ci,
  `regdate` int(10) unsigned NOT NULL DEFAULT '0',
  `question` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `checknum` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `users_info` text  COLLATE utf8mb4_unicode_ci,
  `openid_info` text  COLLATE utf8mb4_unicode_ci,
  `idsite` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `login` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_about`
--

DROP TABLE IF EXISTS `nv4_vi_about`;
CREATE TABLE `nv4_vi_about` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imagealt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imageposition` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `bodytext` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `layout_func` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` smallint(6) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hot_post` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=9  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_about`
--

INSERT INTO `nv4_vi_about` VALUES
(1, 'Giới thiệu về NukeViet', 'gioi-thieu-ve-nukeviet', '', '', 0, '', '<h2><span style=\"font-size:20px;\"><strong>Giới thiệu khái quát</strong></span></h2>  <p>NukeViet là một ứng dụng trên nền web có thể sử dụng vào nhiều mục đích khác nhau. Phiên bản đang được phát hành theo giấy phép phần mềm tự do nguồn mở có tên gọi đầy đủ là <a href=\"/about/Gioi-thieu-ve-NukeViet-CMS.html\"><b>NukeViet CMS</b></a> gồm 2 phần chính là phần nhân (core) của hệ thống NukeViet và nhóm chức năng quản trị nội dung của CMS thường được sử dụng để xây dựng các website tin tức do đó người dùng thường nghĩ rằng NukeViet mạnh về hệ thống tin tức. Tuy nhiên, đội ngũ phát triển NukeViet đã phát triển nhiều hệ thống khác nhau cho NukeViet, nổi bật nhất là:</p>  <ul> 	<li>NukeViet Portal: Cổng thông tin hai chiều dùng cho doanh nghiệp.</li> 	<li><a href=\"http://edu.nukeviet.vn\" target=\"_blank\">NukeViet Edu Gate</a>: Cổng thông tin tích hợp nhiều website, sử dụng cho phòng giáo dục, sở giáo dục.</li> 	<li><a href=\"http://toasoandientu.vn\" target=\"_blank\">NukeViet Tòa Soạn Điện Tử</a>: Sử dụng cho các tòa soạn báo điện tử, trang tin điện tử.</li> </ul> Theo định hướng phát triển của NukeViet, ngoài NukeViet CMS đã được phát hành theo giấy phép tự do nguồn mở trong nhiều năm qua, NukeViet sẽ có thêm 2 nhóm ứng dụng nữa là:  <ul> 	<li>NukeViet Blog: Dành cho các website và người dùng tạo các trang nhật ký cá nhân.</li> 	<li>NukeViet Shop: dành cho các website thương mại điện tử với hoạt động chính là bán hàng trực tuyến, hiện đã có thể sử dụng bằng cách cài bổ sung <a href=\"https://github.com/nukeviet/module-shops\" target=\"_blank\">module Shop</a> lên NukeViet CMS.</li> </ul> &nbsp;  <h2><span style=\"font-size:20px;\"><strong>Video giới thiệu</strong></span></h2> <span style=\"font-size:14px;\">Video clip &quot;Giới thiệu mã nguồn mở NukeViet&quot; trong bản tin Tiêu điểm của chương trình Xã hội thông tin<br  /> (Đài truyền hình kỹ thuật số VTC) phát sóng lúc 20h chủ nhật, ngày 05-09-2010 trên VTC1</span>  <div style=\"text-align: center;\"> <div style=\"text-align: center;\"> <div class=\"youtube-embed-wrapper\" style=\"position:relative;padding-bottom:56.25%;padding-top:30px;height:0;overflow:hidden;\"><iframe allowfullscreen=\"\" height=\"480\" src=\"//www.youtube.com/embed/Cxp1kCyVhqY?rel=0&amp;autoplay=1\" style=\"position: absolute;top: 0;left: 0;width: 100%;height: 100%;\" width=\"640\"></iframe></div> <br  /> <span style=\"font-size:12px;\"><em>Video clip &quot;Giới thiệu mã nguồn mở NukeViet&quot;</em></span></div> </div>  <h2><br  /> <span style=\"font-size:20px;\"><strong><span class=\"mw-headline\" id=\".E1.BB.A8ng_d.E1.BB.A5ng\">Lịch sử phát triển</span></strong></span></h2> NukeViet ra đời từ năm 2004, bắt đầu từ việc sử dụng sản phẩm PHP-Nuke để làm cho website cá nhân, anh Nguyễn Anh Tú - một lưu học sinh người Việt tại Nga - đã cùng cộng đồng Việt hóa, cải tiến theo nhu cầu sử dụng của người Việt. Được sự đón nhận của đông đảo người sử dụng, NukeViet đã liên tục được phát triển và trở thành một ứng dụng thuần Việt. Cho đến phiên bản 3.0, NukeViet đã được phát triển thành một ứng dụng khác biệt hoàn toàn, và không chỉ là một CMS, NukeViet được định hướng để trở thành phần mềm đa chức năng trên nền web.<br  /> <br  /> Kể từ năm 2010, NukeViet đã phát triển theo mô hình chuyên nghiệp, đội ngũ quản trị đã thành lập doanh nghiệp chuyên quản và đạt được những tiến bộ vượt bậc. NukeViet đã trở thành hệ quản trị nội dung nguồn mở duy nhất của Việt Nam được Bộ GD&amp;ĐT khuyến khích sử dụng trong giáo dục (thông tư 08/2010/TT-BGDĐT). Tiếp đó, NukeViet CMS đã được trao giải Nhân Tài Đất Việt 2011 và trở thành phần mềm nguồn mở đầu tiên đạt giải thưởng cao quý này. <h2><br  /> <span style=\"font-size:20px;\"><strong><span class=\"mw-headline\" id=\"Di.E1.BB.85n_.C4.91.C3.A0n_NukeViet.vn\">Diễn đàn NukeViet.vn</span></strong></span></h2>  <p>Diễn đàn NukeViet hoạt động trên website: <a href=\"http://nukeviet.vn\">http://nukeviet.vn</a>, đây là kênh chính thức và hữu hiệu cho các bạn đam mê về NukeViet có thể chia sẻ các kiến thức về NukeViet với nhau. Tính đến tháng 12 năm 2015 diễn đàn đã có trên 34.500 thành viên tham gia, bao gồm học sinh, sinh viên &amp; nhiều thành phần khác thuộc giới trí thức ở trong và ngoài nước.</p>  <p>Là một diễn đàn của các nhà quản lý website, rất nhiều thành viên trong diễn đàn NukeViet là cán bộ, lãnh đạo từ đủ mọi lĩnh vực: công nghệ thông tin, xây dựng, văn hóa - xã hội, thể thao, dịch vụ - du lịch... từ cử nhân, bác sĩ, kỹ sư cho đến bộ đội, công an..</p>  <h2><br  /> <span style=\"font-size:20px;\"><span class=\"mw-headline\" id=\"Th.C3.A0nh_t.C3.ADch_.26_gi.E1.BA.A3i_th.C6.B0.E1.BB.9Fng\"><strong>Thành tích &amp; giải thưởng</strong></span></span></h2>  <h3><span style=\"font-size:14px;\"><em><strong><span class=\"mw-headline\" id=\"Khen_th.C6.B0.E1.BB.9Fng_.26_Th.C3.A0nh_t.C3.ADch\">Khen thưởng &amp; Thành tích</span></strong></em></span></h3>  <ul> 	<li>Giải Ba Nhân tài Đất Việt 2011 ở Lĩnh vực Công nghệ thông tin/Sản phẩm đã ứng dụng rộng rãi (không có giải nhất, nhì).</li> 	<li>Bằng khen của Hội Tin học Việt Nam vì những đóng góp xuất sắc cho sự phát triển của cộng đồng nguồn mở tại Việt Nam.</li> </ul> <span style=\"font-size:14px;\"><em><strong><span class=\"mw-headline\" id=\".C4.90.C6.B0.E1.BB.A3c_B.E1.BB.99_gi.C3.A1o_d.E1.BB.A5c_.26_.C4.90.C3.A0o_t.E1.BA.A1o_.E1.BB.A7ng_h.E1.BB.99\">Được Bộ giáo dục &amp; Đào tạo ủng hộ</span></strong></em></span>  <p>NukeViet CMS là hệ quản trị nội dung nguồn mở duy nhất của Việt Nam nằm trong danh mục các sản phẩm phần mềm nguồn mở được khuyến khích sử dụng trong thông tư số 08/2010/TT-BGDĐT do Bộ GD&amp;ĐT ban hành ngày 01-03-2010 quy định về sử dụng phần mềm tự do mã nguồn mở trong các cơ sở giáo dục). Trong bài thuyết trình &quot;Hiện trạng triển khai nội dung thông tư 08/2010/TT-BGDĐT về sử dụng PMNM trong các cơ sở giáo dục và định hướng cho thời gian tới&quot;<sup> </sup>tại Hội thảo phần mềm nguồn mở trong các cơ quan, tổ chức nhà nước năm 2012, Cục trưởng cục CNTT Quách Tuấn Ngọc cho biết: &quot;NukeViet có thể thay thế SharePoint server&quot;, &quot;NukeViet được nhiều cơ sở giáo dục thích dùng&quot;<sup> </sup>NukeViet được Bộ GD&amp;ĐT đưa vào văn bản hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016. Trong văn bản số 4983/BGDĐT-CNTT của Bộ Giáo dục và Đào tạo (Bộ GDĐT) hướng dẫn việc triển khai nhiệm vụ công nghệ thông tin (CNTT) cho năm học 2015 - 2016 có những nội dung như sau liên quan đến NukeViet:</p>  <ul> 	<li>Nhiệm vụ số &quot;5. Công tác bồi dưỡng ứng dụng CNTT cho giáo viên và cán bộ quản lý giáo dục&quot;, mục &quot;5.1 Một số nội dung cần bồi dưỡng&quot; có ghi &quot;Tập huấn sử dụng phần mềm nguồn mở NukeViet.&quot;</li> 	<li>Nhiệm vụ số &quot; 10. Khai thác, sử dụng và dạy học bằng phần mềm nguồn mở&quot; có ghi: &quot;Khai thác và áp dụng phần mềm nguồn mở NukeViet trong giáo dục.&quot;</li> 	<li>Phụ lục văn bản, có trong nội dung &quot;Khuyến cáo khi sử dụng các hệ thống CNTT&quot;, hạng mục số 3 ghi rõ &quot;Không nên làm website mã nguồn đóng&quot; và &quot;Nên làm NukeViet: phần mềm nguồn mở&quot;.</li> </ul>  <h3><span style=\"font-size:14px;\"><em><strong><span class=\"mw-headline\" id=\".C4.90.C6.B0.E1.BB.A3c_.C6.B0u_ti.C3.AAn_mua_s.E1.BA.AFm_s.E1.BB.AD_d.E1.BB.A5ng_trong_ch.C3.ADnh_ph.E1.BB.A7\">Được ưu tiên mua sắm sử dụng trong chính phủ</span></strong></em></span></h3>  <p>NukeViet CMS là hệ quản trị nội dung nguồn mở được quy định ưu tiên mua sắm, sử dụng trong các cơ quan, tổ chức nhà nước Việt Nam theo thông tư 20/2014/TT-BTTTT ký ngày 05/12/2014 và có hiệu lực từ ngày 20/1/2015 quy định về các sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước</p>  <h2><br  /> <span style=\"font-size:20px;\"><span class=\"mw-headline\" id=\"T.C3.ADnh_n.C4.83ng\"><strong>Tính năng</strong></span></span></h2>  <h3><span style=\"font-size:14px;\"><strong>NukeViet CMS 3.0 bản gốc có các module cơ bản là:</strong></span></h3>  <ul> 	<li>Quản lý Tin tức (<i>News</i>: Tạo bản tin chủ đề đa cấp, phân quyền theo chủ đề, hẹn giờ đăng tin, tạo bản in, bản tải về, thảo luận bản tin),</li> 	<li>Giới thiệu (<i>About</i>),</li> 	<li>Quản lý quảng cáo thương mại (banners),</li> 	<li>Quản lý người dùng (<i>users</i>),</li> 	<li>Liên hệ qua site (<i>Contact</i>),</li> 	<li>Cấp tin RSS (<i>RSS feeds</i>) và thu thập tin RSS (&quot;RSS reader&quot;),</li> 	<li>Bình chọn (thăm dò ý kiến - <i>Voting</i>),</li> 	<li>Thư viện file (<i>Download</i>),</li> 	<li>Thư viện Web (<i>Weblinks</i>),</li> 	<li>Hỏi nhanh đáp gọn(<i>Faq</i>),</li> 	<li>Thống kê truy cập (<i>statistics</i>),</li> 	<li>Tìm kiếm trong site (<i>Search</i>),</li> 	<li>Bán hàng trực tuyến (<i>Shop</i>) (có từ NukeViet 3.1)...</li> </ul>  <h3><span style=\"font-size:14px;\"><strong>Tính năng hệ thống:</strong></span></h3>  <ul> 	<li>Cài đặt, nâng cấp và đóng gói tự động.</li> 	<li>Hỗ trợ đa ngôn ngữ giao diện và đa ngôn ngữ Cơ sở dữ liệu 100%, cho phép người sử dụng tự xây dựng ngôn ngữ mới.</li> 	<li>Thay đổi &amp; tùy biến giao diện nhiều cấp độ, cho phép người sử dụng có thể cài thêm giao diện mới hoặc tùy biến giao diện trên site theo ý thích. Người sử dụng có thể tùy biến bố cục giao diện theo layout, theo block ở các khu vực khác nhau của website.</li> 	<li>Quản lý module với khả năng xử lý đa nhân module (ảo hóa module).</li> 	<li>Cho phép phân nhóm thành viên và phân quyền người quản trị theo nhiều cấp độ khác nhau.</li> 	<li>Hỗ trợ tối ưu hóa cho các công cụ tìm kiếm (SEO): Rewrite, tạo Sitemap, Ping sitemap, chẩn đoán site, phân tích từ khóa, tạo keyword, quản lý máy chủ tìm kiếm (Bot)...</li> 	<li>Quản lý và sao lưu cơ sở dữ liệu.</li> 	<li>Cấu hình tùy biến, tường lửa đa cấp, xử lý tiến trình tự động...</li> 	<li>Hỗ trợ thiết bị di động (mobile), cho phép thay đổi giao diện tương thích (từ phiên bản 3.3)</li> 	<li>...</li> </ul>  <h2><span style=\"font-size:20px;\"><strong><span class=\"mw-headline\" id=\".E1.BB.A8ng_d.E1.BB.A5ng\">Ứng dụng</span></strong></span></h2>  <p>NukeViet được sử dụng ở nhiều website, từ những website cá nhân cho tới những hệ thống website doanh nghiệp, nó cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng bằng cách cài thêm các module, block... Trước đây, NukeViet chủ yếu được sử dụng làm trang tin tức nhờ module News tích hợp sẵn trong NukeViet được viết rất công phu, nó lại đặc biệt phù hợp với yêu cầu và đặc điểm sử dụng cho hệ thống tin tức. Kể từ phiên bản NukeViet 3, đội ngũ phát triển NukeViet đã định nghĩa lại NukeViet, theo đó, NukeViet được coi như phần mềm trực tuyến mà chức năng CMS chỉ là một module của NukeViet. NukeViet có thể dễ dàng cài đặt, dễ dàng quản lý kể cả với những người mới sử dụng do đó thường được những đối tượng người dùng không chuyên ưa thích.<br  /> <br  /> NukeViet có mã nguồn mở do đó việc sử dụng NukeViet là hoàn toàn miễn phí cho tất cả mọi người trên thế giới. Từ bản 2.0 trở về trước, đối tượng người dùng chủ yếu của NukeViet là người Việt vì những đặc điểm của bản thân mã nguồn (có nguồn gốc từ PHP-Nuke) và vì chính sách của nhóm phát triển là: &quot;hệ thống Portal dành cho người Việt&quot;. Kể từ phiên bản 3.0, đội ngũ phát triển NukeViet định hướng đưa NukeViet ra cộng đồng quốc tế.</p>  <ul> 	<li>Các cổng thông tin điện tử</li> 	<li>Các tập đoàn kinh tế</li> 	<li>Giải trí trực tuyến, văn hóa, nghệ thuật.</li> 	<li>Báo điện tử, tạp chí điện tử</li> 	<li>Website của các doanh nghiệp vừa và nhỏ</li> 	<li>Website của các cơ quan, tổ chức chính phủ</li> 	<li>Website giáo dục, trường học</li> 	<li>Website của gia đình, cá nhân, nhóm sở thích...</li> </ul>  <p><br  /> Ngoài các ứng dụng website ở trên, thực tế NukeViet đã được ứng dụng làm rất nhiều phần mềm khác như: Phần mềm quản lý kho hàng, phần mềm bán hàng, phần mềm quản lý quán BI-A trợ giúp bật tắt điện đèn bàn bóng, phần mềm tòa soạn điện tử, phần mềm quản lý hồ sơ, quản lý nhân sự trực tuyến, phần mềm tra cứu điểm thi hỗ trợ SMS...</p>', '', 0, '4', '', 1, 1, 1712405092, 1712405092, 1, 0, 0), 
(2, 'Giới thiệu về NukeViet CMS', 'gioi-thieu-ve-nukeviet-cms', '', '', 0, '', '<p>CMS là gì?<br  /> CMS là từ viết tắt từ Content Management System. Theo wikipedia</p>  <blockquote> <p><strong>Định nghĩa.</strong><br  /> Hệ quản trị nội dung, cũng được gọi là hệ thống quản lý nội dung hay CMS (từ Content Management System của tiếng Anh) là phần mềm để tổ chức và tạo môi trường cộng tác thuận lợi nhằm mục đích xây dựng một hệ thống tài liệu và các loại nội dung khác một cách thống nhất. Mới đây thuật ngữ này liên kết với chương trình quản lý nội dung của website. Quản lý nội dung web (web content management) cũng đồng nghĩa như vậy.<br  /> <br  /> <span class=\"mw-headline\" id=\"Ch.E1.BB.A9c_n.C4.83ng\"><strong>Chức năng</strong>.</span><br  /> Quản trị những nội dung tài liệu điện tử (bao gồm những tài liệu, văn bản số và đã được số hoá) của tổ chức. Những chức năng bao gồm:</p>  <ul> 	<li>Tạo lập nội dung;</li> 	<li>Lưu trữ nội dung;</li> 	<li>Chỉnh sửa nội dung;</li> 	<li>Chuyển tải nội dung;</li> 	<li>Chia sẻ nội dung;</li> 	<li>Tìm kiếm nội dung;</li> 	<li>Phân quyền người dùng và nội dung...</li> </ul>  <p><strong>Đặc điểm.</strong><br  /> Các đặc điểm cơ bản của CMS bao gồm:</p>  <ul> 	<li>Phê chuẩn việc tạo hoặc thay đổi nội dung trực tuyến</li> 	<li>Chế độ Soạn thảo &quot;Nhìn là biết&quot; WYSIWYG</li> 	<li>Quản lý người dùng</li> 	<li>Tìm kiếm và lập chỉ mục</li> 	<li>Lưu trữ</li> 	<li>Tùy biến giao diện</li> 	<li>Quản lý ảnh và các liên kết (URL)</li> </ul> </blockquote>  <p><br  /> NukeViet CMS là một <strong>hệ quản trị nội dung</strong> (<em>Content Management System - CMS</em>) cho phép bạn quản lý các cổng thông tin điện tử trên Internet. Nói đơn giản, NukeViet giống như một phần mềm giúp bạn<strong> xây dựng</strong> và <strong>vận hành</strong> các trang web của mình một cách dễ dàng nhất.</p>  <p>NukeViet CMS là một phần mềm <strong>mã nguồn mở</strong>, do đó việc sử dụng <strong>hoàn toàn miễn phí</strong>, bạn có thể tải NukeViet CMS về bất cứ lúc nào tại website chính thức của NukeViet là <strong><a href=\"http://nukeviet.vn\">nukeviet.vn</a></strong>. Bạn có thể cài NukeViet lên hosting để sử dụng hoặc cũng có thể thử nghiệm bằng cách cài ngay lên máy tính cá nhân.</p>  <p>NukeViet cho phép xây dựng một website động, đa chức năng, hiện đại một cách nhanh chóng mà người vận hành nó thậm chí <strong>không cần phải biết một tí gì về lập trình</strong> bởi tất cả các tác vụ quản lý phức tạp đều được tự động hóa ở mức cao. NukeViet đặc biệt dễ dàng sử dụng vì hoàn toàn bằng tiếng Việt và được thiết kế phù hợp nhất với thói quen sử dụng mạng của <strong>người Việt Nam</strong>.</p>  <p>Bằng việc sử dụng các công nghệ web mới nhất hiện nay, thiết kế hệ thống uyển chuyển và sở hữu những tính năng độc đáo, NukeViet sẽ giúp bạn triển khai các ứng dụng web từ nhỏ đến lớn một cách nhanh chóng và tiết kiệm: từ các website cá nhân cho tới các cổng thông tin điện tử; từ các gian hàng trực tuyến cho tới các mạng xã hội...</p> NukeViet là CMS <strong>mã nguồn mở đầu tiên của Việt Nam</strong> có quá trình phát triển lâu dài nhất, có lượng người sử dụng đông nhất. Hiện NukeViet cũng là một trong những mã nguồn mở chuyên nghiệp đầu tiên của Việt Nam, cơ quan chủ quản của NukeViet là <a href=\"http://vinades.vn\" target=\"_blank\">VINADES.,JSC</a> - đơn vị chịu trách nhiệm phát triển NukeViet và triển khai NukeViet thành các ứng dụng cụ thể cho doanh nghiệp.', '', 0, '4', '', 2, 1, 1712405092, 1712405092, 1, 0, 0), 
(3, 'Logo và tên gọi NukeViet', 'logo-va-ten-goi-nukeviet', '', '', 0, '', '<p><span style=\"color: rgb(255, 0, 0);\"><span style=\"font-size: 14px;\"><strong>Tên gọi:</strong></span></span><br  /> <strong>NukeViet </strong>phát âm là <strong>&#91;Nu-Ke-Việt</strong>&#93;, đây là cách đọc riêng, không phải là cách phát âm chuẩn của tiếng Anh.<br  /> <br  /> <strong>Ý nghĩa:</strong><br  /> NukeViet là từ ghép từ chữ <strong>Nuke </strong>và <strong>Việt Nam</strong>.<br  /> <br  /> Sở dĩ có tên gọi này là vì phiên bản 1.0 và 2.0 của NukeViet được phát triển từ mã nguồn mở<strong> PHP-Nuke</strong>.</p>  <p>Mặc dù từ phiên bản 3.0, NukeViet được viết mới hoàn toàn và trong quá trình phát triển của mình, nhiều cái tên đã được đưa ra để thay thế nhưng cuối cùng cái tên NukeViet đã được giữ lại để nhớ rằng <strong>NukeViet </strong>được khởi đầu từ <strong>PHP-Nuke</strong> và để cảm ơn <strong>Franscisco Burzi</strong> - Tác giả PHP-Nuke - vì chính ông là nhân tố để có một cộng đồng mã nguồn mở NukeViet với hàng chục ngàn người dùng như hiện nay.</p>  <p><strong>Nuke</strong> trong tiếng Anh (từ lóng) có nghĩa là &quot;<strong>vũ khí hạt nhân</strong>&quot; (nuclear weapons). Xem: <a href=\"http://vi.wiktionary.org/wiki/nuke\" target=\"_blank\">http://vi.wiktionary.org/wiki/nuke</a></p>  <p>Đội ngũ phát triển cũng hy vọng rằng <strong>NukeViet </strong>sẽ phát triển bùng nổ như đúng tên gọi của nó.</p>  <p><span style=\"color: rgb(255, 0, 0);\"><span style=\"font-size: 14px;\"><strong>Logo NukeViet 3.0:</strong></span></span><br  /> Sau thời gian dài lựa chọn từ hàng chục mẫu thiết kế của thành viên diễn đàn NukeViet.VN và các nhà thiết kế đồ họa chuyên nghiệp... logo chính thức của NukeViet 3.0 đã được Ban Quản Trị chọn lựa đúng trước ngày Offline phát hành bản NukeViet 3.0 một ngày.<br  /> <br  /> Logo NukeViet 3.0 được lấy hình tượng từ Biển, Đêm, và Ánh Trăng trong khung hình giọt nước:</p>  <p style=\"text-align:center\"><img alt=\"w\" height=\"143\" src=\"/uploads/about/w.png\" style=\"width: 288px; height: 143px; border-width: 0px; border-style: solid;\" width=\"288\" /></p>  <p>Dưới nền trắng, cả logo nhìn như cảnh biển đêm huyền ảo, tĩnh mịch với mặt nước biển, bầu trời, thuyền buồm và ánh trăng. Đây là những hình ảnh biểu tượng cho sự thanh bình mà bất cứ ai cũng mong ước được thấy khi ngắm biển về đêm.<br  /> <br  /> Màu xanh thẫm là màu hòa quyện của của mặt biển, bầu trời về đêm, màu này cũng gần với màu xanh tượng trưng cho hòa bình.<br  /> Hai vệt khuyết chính là ánh trăng sáng màu bạc phản chiếu lên giọt nước.<br  /> <br  /> Giọt nước còn là biểu tượng cho sự sống, cho khát khao bất diệt của vạn vật trên trái đất này.<br  /> <br  /> <strong>Thông số chuẩn của màu logo:</strong><br  /> -&nbsp;&nbsp;&nbsp; Màu xanh: C80, M60, Y0, K0<br  /> <br  /> <strong>Tác giả mẫu thiết kế:</strong> Lê Thanh Xuân, chuyên viên thiết kế đồ họa của VINADES.,JSC</p>  <p><span style=\"color: rgb(255, 0, 0);\"><span style=\"font-size: 14px;\"><strong>Slogan NukeViet 3.0:</strong></span></span> “Chia sẻ thành công, kết nối đam mê”, Tiếng Anh: “Sharing success, connect passions”</p>  <p>Slogan này của tác giả HoaiNamDr, đây là slogan đã đoạt giải trong cuộc thi sáng tác slogan trên diễn đàn NukeViet.VN</p>  <div style=\"text-align:center\"><img alt=\"nukevietcms 180x84\" height=\"84\" src=\"/uploads/about/nukevietcms-180x84.png\" width=\"180\" /></div>  <p style=\"text-align: center;\">Mẫu phối Logo, slogan và tên NukeViet CMS (180x84px)<br  /> Tải về mẫu kích thước lớn <a href=\"/uploads/about/nukevietcms.png\">logo-nukeviet-cms.png</a> (1500x700px)</p>  <div style=\"text-align:center\"><img alt=\"nukevietcms mu noel 180x84\" height=\"84\" src=\"/uploads/about/nukevietcms_mu_noel_180x84.png\" width=\"180\" /></div>  <p style=\"text-align: center;\">Mẫu phối Logo, slogan và tên NukeViet CMS với chiếc mũ ông già Noel (184x84px)<br  /> &nbsp;</p>  <div style=\"text-align:center\"><img alt=\"logo nukeviet3 flag 180x75\" height=\"75\" src=\"/uploads/about/logo-nukeviet3-flag-180x75.png\" width=\"180\" /></div>  <p style=\"text-align: center;\">Mẫu phối Logo, slogan và tên NukeViet CMS cắm cờ Việt Nam (180x75px)<br  /> &nbsp;</p>  <div style=\"text-align:center\"><img alt=\"nukevietcms laco 180x57\" height=\"57\" src=\"/uploads/about/nukevietcms_laco_180x57.png\" width=\"180\" /></div>  <p style=\"text-align: center;\">Mẫu phối Logo, slogan và tên NukeViet CMS với chiếc ruy băng cờ Việt Nam (180x57px)</p>  <div style=\"text-align:center\"><img alt=\"nukevietvn 180x84\" height=\"84\" src=\"/uploads/about/nukevietvn_180x84.png\" width=\"180\" /></div>  <p style=\"text-align: center;\">Mẫu phối Logo, slogan và tên NukeViet.VN (180x84px)<br  /> Tải về mẫu kích thước lớn <a href=\"/uploads/about/nukevietvn.png\">logo-nukeviet-big.png</a> (1500x700px)</p>  <p><br  /> <strong>Tải về file đồ họa gốc:</strong><br  /> - <a href=\"http://nukeviet.vn/vi/download/Tai-lieu/NukeViet-logo/\">NukeViet logo</a> - hình ảnh gốc có độ phân giải cao, bao gồm cả font chữ, có thể sử dụng cho in ấn sticker, in logo lên áo hoặc in Backdrop, Standy khổ lớn.</p>', '', 0, '4', '', 3, 1, 1712405092, 1712405092, 1, 0, 0), 
(4, 'Giấy phép sử dụng NukeViet', 'giay-phep-su-dung-nukeviet', '', '', 0, 'Giấy phép công cộng GNU (tiếng Anh: GNU General Public License, viết tắt GNU GPL hay chỉ GPL) là giấy phép phần mềm tự do được sử dụng để phân phối mã nguồn mở NukeViet.', '<p><strong>Bản dịch tiếng Việt của Giấy phép Công cộng GNU</strong></p>  <p>Người dịch&nbsp;<a href=\"mailto:dangtuan@vietkey.net\">Đặng Minh Tuấn &lt;dangtuan@vietkey.net&gt;</a></p>  <p>Đây là bản dịch tiếng Việt không chính thức của Giấy phép Công cộng GNU. Bản dịch này không phải do Tổ chức Phần mềm Tự do ấn hành, và nó không quy định về mặt pháp lý các điều khoản cho các phần mềm sử dụng giấy phép GNU GPL -- chỉ có bản tiếng Anh gốc của GNU GPL mới có tính pháp lý. Tuy nhiên, chúng tôi hy vọng rằng bản dịch này sẽ giúp cho những người nói tiếng Việt hiểu rõ hơn về GNU GPL.</p>  <p>This is an unofficial translation of the GNU General Public License into Vietnamese. It was not published by the Free Software Foundation, and does not legally state the distribution terms for software that uses the GNU GPL--only the original English text of the GNU GPL does that. However, we hope that this translation will help Vietnamese speakers understand the GNU GPL better.</p>  <hr  /> <h3>GIẤY PHÉP CÔNG CỘNG GNU (GPL)</h3> Giấy phép công cộng GNU<br /> Phiên bản 2, tháng 6/1991<br /> Copyright (C) 1989, 1991 Free Software Foundation, Inc. &nbsp;<br /> 59 Temple Place - Suite 330, Boston, MA&nbsp; 02111-1307, USA <p>Mọi người đều được phép sao chép và lưu hành bản sao nguyên bản nhưng không được phép thay đổi nội dung của giấy phép này.<br /> <br /> <strong>Lời nói đầu</strong><br /> <br /> Giấy phép sử dụng của hầu hết các phần mềm đều được đưa ra nhằm hạn chế bạn tự do chia sẻ và thay đổi nó. Ngược lại, Giấy phép Công cộng của GNU có mục đích đảm bảo cho bạn có thể tự do chia sẻ và thay đổi phần mềm tự do - tức là đảm bảo rằng phần mềm đó là tự do đối với mọi người sử dụng. Giấy phép Công cộng này áp dụng cho hầu hết các phần mềm của Tổ chức Phần mềm Tự do và cho tất cả các chương trình khác mà tác giả cho phép sử dụng. (Đối với một số phần mềm khác của Tổ chức Phần Mềm Tự do, áp dụng Giấy phép Công cộng Hạn chế của GNU thay cho giấy phép công cộng). Bạn cũng có thể áp dụng nó cho các chương trình của mình.<br /> <br /> Khi nói đến phần mềm tự do, chúng ta nói đến sự tự do sử dụng chứ không quan tâm về giá cả. Giấy phép Công cộng của chúng tôi được thiết kế để đảm bảo rằng bạn hoàn toàn tự do cung cấp các bản sao của phần mềm tự do (cũng như kinh doanh dịch vụ này nếu bạn muốn), rằng bạn có thể nhận được mã nguồn nếu bạn có yêu cầu, rằng bạn có thể thay đổi phần mềm hoặc sử dụng các thành phần của phần mềm đó cho những chương trình tự do mới; và rằng bạn biết chắc là bạn có thể làm được những điều này.<br /> <br /> Để bảo vệ bản quyền của bạn, chúng tôi cần đưa ra những hạn chế để ngăn chặn những ai chối bỏ quyền của bạn, hoặc yêu cầu bạn chối bỏ quyền của mình. Những hạn chế này cũng có nghĩa là những trách nhiệm nhất định của bạn khi cung cấp các bản sao phần mềm hoặc khi chỉnh sửa phần mềm đó.<br /> <br /> Ví dụ, nếu bạn cung cấp các bản sao của một chương trình, dù miễn phí hay không, bạn phải cho người nhận tất cả các quyền mà bạn có. Bạn cũng phải đảm bảo rằng họ cũng nhận được hoặc tiếp cận được mã nguồn. Và bạn phải thông báo những điều khoản này cho họ để họ biết rõ về quyền của mình.<br /> <br /> Chúng tôi bảo vệ quyền của bạn với hai bước: (1) bảo vệ bản quyền phần mềm, và (2) cung cấp giấy phép này để bạn có thể sao chép, lưu hành và/hoặc chỉnh sửa phần mềm một cách hợp pháp.<br /> <br /> Ngoài ra, để bảo vệ các tác giả cũng như để bảo vệ chính mình, chúng tôi muốn chắc chắn rằng tất cả mọi người đều hiểu rõ rằng không hề có bảo hành đối với phần mềm tự do này. Nếu phần mềm được chỉnh sửa thay đổi bởi một người khác và sau đó lưu hành, thì chúng tôi muốn những người sử dụng biết rằng phiên bản họ đang có không phải là bản gốc, do đó tất cả những trục trặc do những người khác gây ra hoàn toàn không ảnh hưởng tới uy tín của tác giả ban đầu.<br /> <br /> Cuối cùng, bất kỳ một chương trình tự do nào cũng đều thường xuyên có nguy cơ bị đe doạ về giấy phép bản quyền. Chúng tôi muốn tránh nguy cơ khi những người cung cấp lại một chương trình tự do có thể có được giấy phép bản quyền cho bản thân họ, từ đó trở thành độc quyền đối với chương trình đó. Để ngăn ngừa trường hợp này, chúng tôi đã nêu rõ rằng mỗi giấy phép bản quyền hoặc phải được cấp cho tất cả mọi người sử dụng một cách tự do hoặc hoàn toàn không cấp phép.<br /> <br /> Dưới đây là những điều khoản và điều kiện rõ ràng đối với việc sao chép, lưu hành và chỉnh sửa.<br /> <br /> <strong>Những điều khoản và điều kiện đối với việc sao chép, lưu hành và chỉnh sửa</strong><br /> <br /> <strong>0.</strong>&nbsp;Giấy phép này áp dụng cho bất kỳ một chương trình hay sản phẩm nào mà người giữ bản quyền công bố rằng nó có thể được cung cấp trong khuôn khổ những điều khoản của Giấy phép Công cộng này. Từ “Chương trình” dưới đây có nghĩa là tất cả các chương trình hay sản phẩm như vậy, và “sản phẩm dựa trên Chương trình” có nghĩa là Chương trình hoặc bất kỳ một sản phẩm nào bắt nguồn từ chương trình đó tuân theo luật bản quyền, nghĩa là một sản phẩm dựa trên Chương trình hoặc một phần của nó, đúng nguyên bản hoặc có một số chỉnh sửa và/hoặc được dịch ra một ngôn ngữ khác. (Dưới đây, việc dịch cũng được hiểu trong khái niệm “chỉnh sửa”). Mỗi người được cấp phép được gọi là “bạn”.<br /> <br /> Trong Giấy phép này không đề cập tới các hoạt động khác ngoài việc sao chép, lưu hành và chỉnh sửa; chúng nằm ngoài phạm vi của giấy phép này. Hành động chạy chương trình không bị hạn chế, và những kết quả từ việc chạy chương trình chỉ được đề cập tới nếu nội dung của nó tạo thành một sản phẩm dựa trên chương trình (độc lập với việc chạy chương trình). Điều này đúng hay không là phụ thuộc vào Chương trình.<br /> <br /> <strong>1.</strong>&nbsp;Bạn có thể sao chép và lưu hành những phiên bản nguyên bản của mã nguồn Chương trình đúng như khi bạn nhận được, qua bất kỳ phương tiện phân phối nào, với điều kiện trên mỗi bản sao bạn đều kèm theo một ghi chú bản quyền rõ ràng và từ chối bảo hành; giữ nguyên tất cả các ghi chú về Giấy phép và về việc không có bất kỳ một sự bảo hành nào; và cùng với Chương trình bạn cung cấp cho người sử dụng một bản sao của Giấy phép này.<br /> <br /> Bạn có thể tính phí cho việc chuyển giao bản sao, và tuỳ theo quyết định của mình bạn có thể cung cấp bảo hành để đổi lại với chi phí mà bạn đã tính.<br /> <br /> <strong>2.</strong>&nbsp;Bạn có thể chỉnh sửa bản sao của bạn hoặc các bản sao của Chương trình hoặc của bất kỳ phần nào của nó, từ đó hình thành một sản phẩm dựa trên Chương trình, và sao chép cũng như lưu hành sản phẩm đó hoặc những chỉnh sửa đó theo điều khoản trong Mục 1 ở trên, với điều kiện bạn đáp ứng được những điều kiện dưới đây:<br /> •&nbsp;&nbsp; &nbsp;a) Bạn phải có ghi chú rõ ràng trong những tập tin đã chỉnh sửa là bạn đã chỉnh sửa nó, và ngày tháng của bất kỳ một thay đổi nào.<br /> •&nbsp;&nbsp; &nbsp;b) Bạn phải cấp phép miễn phí cho tất cả các bên thứ ba đối với các sản phẩm bạn cung cấp hoặc phát hành, bao gồm Chương trình nguyên bản, từng phần của nó hay các sản phẩm dựa trên Chương trình hay dựa trên từng phần của Chương trình, theo những điều khoản của Giấy phép này.<br /> •&nbsp;&nbsp; &nbsp;c) Nếu chương trình đã chỉnh sửa thường đọc lệnh tương tác trong khi chạy, bạn phải thực hiện sao cho khi bắt đầu chạy để sử dụng tương tác theo cách thông thường nhất phải có một thông báo bao gồm bản quyền và thông báo về việc không có bảo hành (hoặc thông báo bạn là người cung cấp bảo hành), và rằng người sử dụng có thể cung cấp lại Chương trình theo những điều kiện này, và thông báo để người sử dụng có thể xem bản sao của Giấy phép này. (Ngoại lệ: nếu bản thân Chương trình là tương tác nhưng không có một thông báo nào như trên, thì sản phẩm của bạn dựa trên Chương trình đó cũng không bắt buộc phải có thông báo như vậy).<br /> <br /> Những yêu cầu trên áp dụng cho toàn bộ các sản phẩm chỉnh sửa. Nếu có những phần của sản phẩm rõ ràng không bắt nguồn từ Chương trình, và có thể được xem là độc lập và riêng biệt, thì Giấy phép này và các điều khoản của nó sẽ không áp dụng cho những phần đó khi bạn cung cấp chúng như những sản phẩm riêng biệt. Nhưng khi bạn cung cấp những phần đó như những phần nhỏ trong cả một sản phẩm dựa trên Chương trình, thì việc cung cấp này phải tuân theo những điều khoản của Giấy phép này, cho phép những người được cấp phép có quyền đối với toàn bộ sản phẩm, cũng như đối với từng phần trong đó, bất kể ai đã viết nó.<br /> <br /> Như vậy, điều khoản này không nhằm mục đích xác nhận quyền hoặc tranh giành quyền của bạn đối với những sản phẩm hoàn toàn do bạn viết; mà mục đích của nó là nhằm thi hành quyền kiểm soát đối với việc cung cấp những sản phẩm bắt nguồn hoặc tổng hợp dựa trên Chương trình.<br /> <br /> Ngoài ra, việc kết hợp thuần tuý Chương trình (hoặc một sản phẩm dựa trên Chương trình) với một sản phẩm không dựa trên Chương trình với mục đích lưu trữ hoặc quảng bá không đưa sản phẩm đó vào trong phạm vi áp dụng của Giấy phép này.<br /> <br /> <strong>3.</strong>&nbsp;Bạn có thể sao chép và cung cấp Chương trình (hoặc một sản phẩm dựa trên Chương trình, nêu trong Mục 2) dưới hình thức mã đã biên dịch hoặc dạng có thể thực thi được trong khuôn khổ các điều khoản nêu trong Mục 1 và 2 ở trên, nếu như bạn:<br /> •&nbsp;&nbsp; &nbsp;a) Kèm theo đó một bản mã nguồn dạng đầy đủ có thể biên dịch được theo các điều khoản trong Mục 1 và 2 nêu trên trong một môi trường trao đổi phần mềm thông thường; hoặc,<br /> •&nbsp;&nbsp; &nbsp;b) Kèm theo đó một đề nghị có hạn trong ít nhất 3 năm, theo đó cung cấp cho bất kỳ một bên thứ ba nào một bản sao đầy đủ của mã nguồn tương ứng, và phải được cung cấp với giá chi phí không cao hơn giá chi phí vật lý của việc cung cấp theo các điều khoản trong Mục 1 và 2 nêu trên trong một môi trường trao đổi phần mềm thông thường; hoặc<br /> •&nbsp;&nbsp; &nbsp;c) Kèm theo đó thông tin bạn đã nhận được để đề nghị cung cấp mã nguồn tương ứng. (Phương án này chỉ được phép đối với việc cung cấp phi thương mại và chỉ với điều kiện nếu bạn nhận được Chương trình dưới hình thức mã đã biên dịch hoặc dạng có thể thực thi được cùng với lời đề nghị như vậy, theo phần b trong điều khoản nêu trên).<br /> <br /> Mã nguồn của một sản phẩm là một dạng ưu tiên của sản phẩm dành cho việc chỉnh sửa nó. Với một sản phẩm có thể thi hành, mã nguồn hoàn chỉnh có nghĩa là tất cả các mã nguồn cho các môđun trong sản phẩm đó, cộng với tất cả các tệp tin định nghĩa giao diện đi kèm với nó, cộng với các hướng dẫn dùng để kiểm soát việc biên dịch và cài đặt các tệp thi hành. Tuy nhiên, một ngoại lệ đặc biệt là mã nguồn không cần chứa bất kỳ một thứ gì mà bình thường được cung cấp (từ nguồn khác hoặc hình thức nhị phân) cùng với những thành phần chính (chương trình biên dịch, nhân, và những phần tương tự) của hệ điều hành mà các chương trình chạy trong đó, trừ khi bản thân thành phần đó lại đi kèm với một tệp thi hành.<br /> <br /> Nếu việc cung cấp lưu hành mã đã biên dịch hoặc tập tin thi hành được thực hiện qua việc cho phép tiếp cận và sao chép từ một địa điểm được chỉ định, thì việc cho phép tiếp cận tương đương tới việc sao chép mã nguồn từ cùng địa điểm cũng được tính như việc cung cấp mã nguồn, mặc dù thậm chí các bên thứ ba không bị buộc phải sao chép mã nguồn cùng với mã đã biên dịch.<br /> <br /> <strong>4.</strong>&nbsp;Bạn không được phép sao chép, chỉnh sửa, cấp phép hoặc cung cấp Chương trình trừ phi phải tuân thủ một cách chính xác các điều khoản trong Giấy phép. Bất kỳ ý định sao chép, chỉnh sửa, cấp phép hoặc cung cấp Chương trình theo cách khác đều làm mất hiệu lực và tự động huỷ bỏ quyền của bạn trong khuôn khổ Giấy phép này. Tuy nhiên, các bên đã nhận được bản sao hoặc quyền từ bạn với Giấy phép này sẽ không bị huỷ bỏ giấy phép nếu các bên đó vẫn tuân thủ đầy đủ các điều khoản của giấy phép.<br /> <br /> <strong>5.</strong>&nbsp;Bạn không bắt buộc phải chấp nhận Giấy phép này khi bạn chưa ký vào đó. Tuy nhiên, không có gì khác đảm bảo cho bạn được phép chỉnh sửa hoặc cung cấp Chương trình hoặc các sản phẩm bắt nguồn từ Chương trình. Những hành động này bị luật pháp nghiêm cấm nếu bạn không chấp nhận Giấy phép này. Do vậy, bằng việc chỉnh sửa hoặc cung cấp Chương trình (hoặc bất kỳ một sản phẩm nào dựa trên Chương trình), bạn đã thể hiện sự chấp thuận đối với Giấy phép này, cùng với tất cả các điều khoản và điều kiện đối với việc sao chép, cung cấp hoặc chỉnh sửa Chương trình hoặc các sản phẩm dựa trên nó.<br /> <br /> <strong>6.</strong> Mỗi khi bạn cung cấp lại Chương trình (hoặc bất kỳ một sản phẩm nào dựa trên Chương trình), người nhận sẽ tự động nhận được giấy phép từ người cấp phép đầu tiên cho phép sao chép, cung cấp và chỉnh sửa Chương trình theo các điều khoản và điều kiện này. Bạn không thể áp đặt bất cứ hạn chế nào khác đối với việc thực hiện quyền của người nhận đã được cấp phép từ thời điểm đó. Bạn cũng không phải chịu trách nhiệm bắt buộc các bên thứ ba tuân thủ theo Giấy phép này.<br /> <br /> <strong>7.</strong>&nbsp;Nếu như, theo quyết định của toà án hoặc với những bằng chứng về việc vi phạm bản quyền hoặc vì bất kỳ lý do nào khác (không giới hạn trong các vấn đề về bản quyền), mà bạn phải tuân theo các điều kiện (nêu ra trong lệnh của toà án, biên bản thoả thuận hoặc ở nơi khác) trái với các điều kiện của Giấy phép này, thì chúng cũng không thể miễn cho bạn khỏi những điều kiện của Giấy phép này. Nếu bạn không thể đồng thời thực hiện các nghĩa vụ của mình trong khuôn khổ Giấy phép này và các nghĩa vụ thích đáng khác, thì hậu quả là bạn hoàn toàn không được cung cấp Chương trình. Ví dụ, nếu trong giấy phép bản quyền không cho phép những người nhận được bản sao trực tiếp hoặc gián tiếp qua bạn có thể cung cấp lại Chương trình thì trong trường hợp này cách duy nhất bạn có thể thoả mãn cả hai điều kiện là hoàn toàn không cung cấp Chương trình.<br /> <br /> Nếu bất kỳ một phần nào trong điều khoản này không có hiệu lực hoặc không thể thi hành trong một hoàn cảnh cụ thể, thì sẽ cân đối áp dụng các điều khoản, và toàn bộ điều khoản sẽ được áp dụng trong những hoàn cảnh khác.<br /> <br /> Mục đích của điều khoản này không nhằm buộc bạn phải vi phạm bất kỳ một bản quyền nào hoặc các quyền sở hữu khác hoặc tranh luận về giá trị hiệu lực của bất kỳ quyền hạn nào như vậy; mục đích duy nhất của điều khoản này là nhằm bảo vệ sự toàn vẹn của hệ thống cung cấp phần mềm tự do đang được thực hiện với giấy phép công cộng. Nhiều người đã đóng góp rất nhiều vào sự đa dạng của các phần mềm tự do được cung cấp thông qua hệ thống này với sự tin tưởng rằng hệ thống được sử dụng một cách thống nhất; tác giả/người cung cấp có quyền quyết định rằng họ có mong muốn cung cấp phần mềm thông qua hệ thống nào khác hay không, và người được cấp phép không thể có ảnh hưởng tới sự lựa chọn này.<br /> <br /> Điều khoản này nhằm làm rõ những hệ quả của các phần còn lại của Giấy phép này.<br /> <br /> <strong>8.</strong>&nbsp;Nếu việc cung cấp và/hoặc sử dụng Chương trình bị cấm ở một số nước nhất định bởi quy định về bản quyền, người giữ bản quyền gốc đã đưa Chương trình vào dưới Giấy phép này có thể bổ sung một điều khoản hạn chế việc cung cấp ở những nước đó, nghĩa là việc cung cấp chỉ được phép ở các nước không bị liệt kê trong danh sách hạn chế. Trong trường hợp này, Giấy phép đưa vào những hạn chế được ghi trong nội dung của nó.<br /> <br /> <strong>9.&nbsp;</strong>Tổ chức Phần mềm Tự do có thể theo thời gian công bố những phiên bản chỉnh sửa và/hoặc phiên bản mới của Giấy phép Công cộng. Những phiên bản đó sẽ đồng nhất với tinh thần của phiên bản hiện này, nhưng có thể khác ở một số chi tiết nhằm giải quyết những vấn đề hay những lo ngại mới.<br /> <br /> Mỗi phiên bản sẽ có một mã số phiên bản riêng. Nếu Chương trình và &quot;bất kỳ một phiên bản nào sau đó&quot; có áp dụng một phiên bản Giấy phép cụ thể, bạn có quyền lựa chọn tuân theo những điều khoản và điều kiện của phiên bản giấy phép đó hoặc của bất kỳ một phiên bản nào sau đó do Tổ chức Phần mềm Tự do công bố. Nếu Chương trình không nêu cụ thể mã số phiên bản giấy phép, bạn có thể lựa chọn bất kỳ một phiên bản nào đã từng được công bố bởi Tổ chức Phần mềm Tự do.<br /> <br /> <strong>10.</strong>&nbsp;Nếu bạn muốn kết hợp các phần của Chương trình vào các chương trình tự do khác mà điều kiện cung cấp khác với chương trình này, hãy viết cho tác giả để được phép. Đối với các phần mềm được cấp bản quyền bởi Tổ chức Phầm mềm Tự do, hãy đề xuất với tổ chức này; đôi khi chúng tôi cũng có những ngoại lệ. Quyết định của chúng tôi sẽ dựa trên hai mục tiêu là bảo hộ tình trạng tự do của tất cả các sản phẩm bắt nguồn từ phần mềm tự do của chúng tôi, và thúc đẩy việc chia sẻ và tái sử dụng phần mềm nói chung.<br /> <br /> <strong>KHÔNG BẢO HÀNH</strong><br /> DO CHƯƠNG TRÌNH ĐƯỢC CẤP PHÉP MIỄN PHÍ NÊN KHÔNG CÓ MỘT CHẾ ĐỘ BẢO HÀNH NÀO TRONG MỨC ĐỘ CHO PHÉP CỦA LUẬT PHÁP. TRỪ KHI ĐƯỢC CÔNG BỐ KHÁC ĐI BẰNG VĂN BẢN, NHỮNG NGƯỜI GIỮ BẢN QUYỀN VÀ/HOẶC CÁC BÊN CUNG CẤP CHƯƠNG TRÌNH NGUYÊN BẢN SẼ KHÔNG BẢO HÀNH DƯỚI BẤT KỲ HÌNH THỨC NÀO, BAO GỒM NHƯNG KHÔNG GIỚI HẠN TRONG CÁC HÌNH THỨC BẢO HÀNH ĐỐI VỚI TÍNH THƯƠNG MẠI CŨNG NHƯ TÍNH THÍCH HỢP CHO MỘT MỤC ĐÍCH CỤ THỂ. BẠN LÀ NGƯỜI CHỊU TOÀN BỘ RỦI RO VỀ CHẤT LƯỢNG CŨNG NHƯ VIỆC VẬN HÀNH CHƯƠNG TRÌNH. TRONG TRƯỜNG HỢP CHƯƠNG TRÌNH CÓ KHIẾM KHUYẾT, BẠN PHẢI CHỊU TOÀN BỘ CHI PHÍ CHO NHỮNG DỊCH VỤ SỬA CHỮA CẦN THIẾT.<br /> <br /> TRONG TẤT CẢ CÁC TRƯỜNG HỢP TRỪ KHI CÓ YÊU CẦU CỦA LUẬT PHÁP HOẶC CÓ THOẢ THUẬN BẰNG VĂN BẢN, NHỮNG NGƯỜI CÓ BẢN QUYỀN HOẶC BẤT KỲ MỘT BÊN NÀO CHỈNH SỬA VÀ/HOẶC CUNG CẤP LẠI CHƯƠNG TRÌNH TRONG CÁC ĐIỀU KIỆN NHƯ ĐÃ NÊU TRÊN ĐỀU KHÔNG CÓ TRÁCH NHIỆM VỚI BẠN VỀ CÁC LỖI HỎNG HÓC, BAO GỒM CÁC LỖI CHUNG HAY ĐẶC BIỆT, NGẪU NHIÊN HAY TẤT YẾU NẢY SINH DO VIỆC SỬ DỤNG HOẶC KHÔNG SỬ DỤNG ĐƯỢC CHƯƠNG TRÌNH (BAO GỒM NHƯNG KHÔNG GIỚI HẠN TRONG VIỆC MẤT DỮ LIỆU, DỮ LIỆU THIẾU CHÍNH XÁC HOẶC CHƯƠNG TRÌNH KHÔNG VẬN HÀNH ĐƯỢC VỚI CÁC CHƯƠNG TRÌNH KHÁC), THẬM CHÍ CẢ KHI NGƯỜI CÓ BẢN QUYỀN VÀ CÁC BÊN KHÁC ĐÃ ĐƯỢC THÔNG BÁO VỀ KHẢ NĂNG XẢY RA NHỮNG THIỆT HẠI ĐÓ.<br /> <br /> <strong>KẾT THÚC CÁC ĐIỀU KIỆN VÀ ĐIỀU KHOẢN.</strong></p>  <p><strong>Áp dụng những điều khoản trên như thế nào đối với chương trình của bạn</strong><br /> <br /> Nếu bạn xây dựng một chương trình mới, và bạn muốn cung cấp một cách tối đa cho công chúng sử dụng, thì biện pháp tốt nhất để đạt được điều này là phát triển chương trình đó thành phần mềm tự do để ai cũng có thể cung cấp lại và thay đổi theo những điều khoản như trên.<br /> <br /> Để làm được việc này, hãy đính kèm những thông báo như sau cùng với chương trình của mình. An toàn nhất là đính kèm chúng trong phần đầu của tập tin mã nguồn để thông báo một cách hiệu quả nhất về việc không có bảo hành; và mỗi tệp tin đều phải có ít nhất một dòng về “bản quyền” và trỏ đến toàn bộ thông báo.</p>  <blockquote> <p>&nbsp; &nbsp; &nbsp; &nbsp; <strong>Một dòng đề tên chương trình và nội dung của nó.<br /> &nbsp; &nbsp; &nbsp; &nbsp; Bản quyền (C) năm,&nbsp; tên tác giả.</strong><br /> <br /> Chương trình này là phần mềm tự do, bạn có thể cung cấp lại và/hoặc chỉnh sửa nó theo những điều khoản của Giấy phép Công cộng của GNU do Tổ chức Phần mềm Tự do công bố; phiên bản 2 của Giấy phép, hoặc bất kỳ một phiên bản sau đó (tuỳ sự lựa chọn của bạn).<br /> <br /> Chương trình này được cung cấp với hy vọng nó sẽ hữu ích, tuy nhiên KHÔNG CÓ BẤT KỲ MỘT BẢO HÀNH NÀO; thậm chí kể cả bảo hành về KHẢ NĂNG THƯƠNG MẠI hoặc TÍNH THÍCH HỢP CHO MỘT MỤC ĐÍCH CỤ THỂ. Xin xem Giấy phép Công cộng của GNU để biết thêm chi tiết.<br /> <br /> Bạn phải nhận được một bản sao của Giấy phép Công cộng của GNU kèm theo chương trình này; nếu bạn chưa nhận được, xin gửi thư về Tổ chức Phần mềm Tự do, 59 Temple Place - Suite 330, Boston, MA&nbsp; 02111-1307, USA.<br /> <br /> Xin hãy bổ sung thông tin về địa chỉ liên lạc của bạn (thư điện tử và bưu điện).</p> </blockquote>  <p>Nếu chương trình chạy tương tác, hãy đưa một thông báo ngắn khi bắt đầu chạy chương trình như sau:</p>  <blockquote> <p>Gnomovision phiên bản 69, Copyright (C) năm, tên tác giả.<br /> <br /> Gnomovision HOÀN TOÀN KHÔNG CÓ BẢO HÀNH; để xem chi tiết hãy gõ `show w&#039;.&nbsp; Đây là một phần mềm miễn phí, bạn có thể cung cấp lại với những điều kiện nhất định, gõ ‘show c’ để xem chi tiết.<br /> Giả thiết lệnh `show w&#039; và `show c&#039; cho xem những phần tương ứng trong Giấy phép Công cộng. Tất nhiên những lệnh mà bạn dùng có thể khác với ‘show w&#039; và `show c&#039;; những lệnh này có thể là nhấn chuột hoặc lệnh trong thanh công cụ - tuỳ theo chương trình của bạn.</p> </blockquote>  <p>Bạn cũng cần phải lấy chữ ký của người phụ trách (nếu bạn là người lập trình) hoặc của trường học (nếu có) xác nhận từ chối bản quyền đối với chương trình. Sau đây là ví dụ:</p>  <blockquote> <p>Yoyodyne, Inc., tại đây từ chối tất cả các quyền lợi bản quyền đối với chương trình `Gnomovision&#039; viết bởi James Hacker.<br /> <br /> chữ ký của Ty Coon, 1 April 1989<br /> Ty Coon, Phó Tổng Giám đốc.</p> </blockquote>  <p>Giấy phép Công cộng này không cho phép đưa chương trình của bạn vào trong các chương trình độc quyền. Nếu chương trình của bạn là một thư viện thủ tục phụ, bạn có thể thấy nó hữu ích hơn nếu cho thư viện liên kết với các ứng dụng độc quyền. Nếu đây là việc bạn muốn làm, hãy sử dụng Giấy phép Công cộng Hạn chế của GNU thay cho Giấy phép này.</p>  <hr  /> <p><strong>Bản gốc của giấy phép bằng tiếng Anh có tại các địa chỉ sau:</strong></p>  <ol> 	<li>GNU General Public License, version 1, February 1989:&nbsp;<a href=\"http://www.gnu.org/licenses/old-licenses/gpl-1.0.txt\" target=\"_blank\">http://www.gnu.org/licenses/old-licenses/gpl-1.0.txt</a></li> 	<li>GNU General Public License, version 2, June 1991:&nbsp;<a href=\"http://www.gnu.org/licenses/old-licenses/gpl-2.0.html\" target=\"_blank\">http://www.gnu.org/licenses/old-licenses/gpl-2.0.html</a></li> 	<li>GNU General Public License, version 3, 29 June 2007:&nbsp;<a href=\"http://www.gnu.org/licenses/gpl-3.0.txt\" target=\"_blank\">http://www.gnu.org/licenses/gpl-3.0.txt</a></li> </ol>  <p><strong>Tài liệu tham khảo:</strong></p>  <ol> 	<li>Bản dịch tiếng Việt của Giấy phép Công cộng GNU tại OpenOffice.org:&nbsp;<br /> 	<a href=\"http://vi.openoffice.org/gplv.html\" target=\"_blank\">http://vi.openoffice.org/gplv.html</a></li> 	<li>GPL tại&nbsp;Văn thư lưu trữ mở Wikisource:&nbsp;<a href=\"http://vi.wikisource.org/wiki/GPL\" target=\"_blank\">http://vi.wikisource.org/wiki/GPL</a></li> </ol>  <p><strong>Xem thêm:</strong></p>  <ol> 	<li>LGPL tại&nbsp;Văn thư lưu trữ mở Wikisource:&nbsp;<a href=\"http://vi.wikisource.org/wiki/LGPL\" target=\"_blank\">http://vi.wikisource.org/wiki/LGPL</a></li> 	<li>Giấy phép Công cộng GNU - WikiPedia:&nbsp;<br /> 	<a href=\"http://vi.wikipedia.org/wiki/Gi%E1%BA%A5y_ph%C3%A9p_C%C3%B4ng_c%E1%BB%99ng_GNU\" target=\"_blank\">http://vi.wikipedia.org/wiki/Giấy_phép_Công_cộng_GNU</a></li> 	<li>Thảo luận giấy phép GNU GPL - HVA:<br /> 	&nbsp;<a href=\"http://www.hvaonline.net/hvaonline/posts/list/7120.hva\" target=\"_blank\">http://www.hvaonline.net/hvaonline/posts/list/7120.hva</a></li> 	<li>Thảo luận tại diễn đàn:&nbsp;<a href=\"http://nukeviet.vn/phpbb/viewtopic.php?f=83&amp;t=1591\" target=\"_blank\">http://nukeviet.vn/phpbb/viewtopic.php?f=83&amp;t=1591</a></li> </ol>', 'giấy phép,công cộng,tiếng anh,gnu general,public license,gnu gpl,phần mềm,là tự,sử dụng,mã nguồn,bản dịch,tiếng việt,của gnu,đây là,này không,do tổ,chức tự,hành và,các điều,cho các,có bản,tuy nhiên,chúng tôi,cho những,phiên bản,mọi người,được phép,sao chép,lưu hành,bản sao,nguyên bản,nhưng không,và thay,nội dung,của này,hạn chế,tự do,chia sẻ,nukeviet,portal,mysql,php,cms,mã nguồn mở,thiết kế website', 0, '4', '', 4, 1, 1712405092, 1712405092, 1, 0, 0), 
(5, 'Những tính năng của NukeViet CMS 4.0', 'nhung-tinh-nang-cua-nukeviet-cms-4-0', '', '', 0, '', '<p><span style=\"font-size: 150%; line-height: 116%;\"><span style=\"font-weight: bold;\">Giới thiệu chung</span></span><br  /> <span style=\"font-weight: bold;\">Mã nguồn mở NukeViet là sản phẩm của sự làm việc chuyên nghiệp: </span><br  /> Để xây dựng lên NukeViet 4, đội ngũ phát triển đã thành lập công ty VINADES.,JSC. Trong quá trình phát triển NukeViet 4, VINADES.,JSC đã hợp tác với nhiều đơn vị cung cấp hosting trong và ngoài nước để thử nghiệm host, đảm bảo tương thích với đa số các hosting chuyên nghiệp.<br  /> NukeViet 4 cũng được vận hành thử nghiệm, góp ý bởi nhiều webmaster có kinh nghiệm quản trị ở nhiều hệ thống khác nhau nhằm tối ưu các tính năng hệ thống cho người sử dụng.<br  /> NukeViet 4 được lập trình bởi các lập trình viên mà kinh nghiệm và tên tuổi của họ đã được xác lập cùng với tên tuổi của bộ mã nguồn mở tạo web đầu tiên của Việt Nam.<br  /> <br  /> <span style=\"font-weight: bold;\">NukeViet 4 là một hệ thống mạnh:</span><br  /> Rút kinh nghiệm từ chính NukeViet 2, NukeViet 3, NukeViet 4 được viết mới hoàn toàn trên nền tảng kỹ thuật tiên tiến nhất hiện nay cho phép xây dựng các nền tảng ứng dụng trực tuyến lớn như Các cổng thông tin điện tử, các tòa soạn báo điện tử, các mạng xã hội và các hệ thống thương mại trực tuyến.<br  /> NukeViet 4 đã được thử nghiệm vận hành với dữ liệu lớn lên tới hàng triệu bản tin. Trên thực tế, NukeViet 4 cũng đã triển khai thành công cho các hiệp hội, doanh nghiệp có lượng truy cập rất lớn.<br  /> <br  /> <span style=\"font-weight: bold;\">NukeViet 4 thích hợp cho mọi đối tượng:</span><br  /> NukeViet lấy người sử dụng làm trọng tâm, những tính năng của NukeViet tạo nên chuẩn mực trong việc sử dụng và quản trị. Vì thế, NukeViet 4 tốt cho cả người sử dụng lẫn người phát triển.<br  /> Với người sử dụng, NukeViet 4 cho phép tùy biến dễ dàng và sử dụng ngay mà không cần can thiệp vào hệ thống.<br  /> Với người phát triển, sử dụng NukeViet cho phép nhanh chóng xây dựng các nền tảng khác nhau nhờ việc viết thêm các module cho hệ thống thay vì phải tự mình viết cả một hệ thống.</p>  <p><span style=\"font-size: 150%; line-height: 116%;\"><span style=\"font-weight: bold;\">Các tính năng của NukeViet 4</span></span></p> <span style=\"font-weight: bold;\">Nền tảng công nghệ</span>  <ul> 	<li><span id=\"cke_bm_178S\" style=\"display: none;\">&nbsp;</span>NukeViet CMS 4 lập trình trên PHP 5.4 và MySQL 5, Sử dụng PDO để kết nối với MySQL (Sẵn sàng kết nối với các CSDL khác) cho phép vận dụng tối đa sức mạnh của công nghệ mới.</li> 	<li>Sử dụng Composer để quản lý các thư viện PHP được cài vào hệ thống.</li> 	<li>Từng bước áp dụng các tiêu chuẩn viết code PHP theo khuyến nghị của http://www.php-fig.org/psr/</li> 	<li>Ứng dụng Xtemplate và jQuery cho phép vận dụng Ajax uyển chuyển từ trong nhân hệ thống.</li> 	<li>Giai diện trong NukeViet 4 được làm mới, tương thích với nhiều màn hình hơn, Sử dụng thư viện bootstrap để việc phát triển giao diện thống nhất và dễ dàng hơn.</li> 	<li>Tận dụng các thành tựu mã nguồn mở có sẵn nhưng NukeViet 4 vẫn đảm bảo rằng từng dòng code là được code tay. Điều này có nghĩa là NukeViet 4 hoàn toàn không lệ thuộc vào bất cứ framework nào trong quá trình phát triển của mình; Bạn hoàn toàn có thể đọc hiểu để tự lập trình trên NukeViet 4 nếu bạn biết PHP và MySQL (đồng nghĩa với việc NukeViet 4 hoàn toàn mở và dễ nghiên cứu cho bất cứ ai muốn tìm hiểu về code của NukeViet).<span id=\"cke_bm_178E\" style=\"display: none;\">&nbsp;</span></li> </ul>  <ul id=\"docs-internal-guid-7ec786f5-1ade-f016-4c9b-c9a8e36cc922\"> </ul>  <p><span style=\"font-weight: bold;\">Kiến trúc Module</span></p>  <ul> 	<li>NukeViet CMS 4 tái cấu trúc lại module, theo đó, toàn bộ tệp tin của mỗi module được gói gọn trong một thư mục riêng nhằm đơn giản trong việc quản lý và đóng gói ứng dụng. Kiến trúc module này tạo ra khái niệm block của module và theme của module giúp đa dạng hóa việc trình bày module.</li> 	<li>Hệ thống NukeViet 4 hỗ trợ công nghệ đa nhân module. Chúng tôi gọi đó là công nghệ ảo hóa module. Công nghệ này cho phép người sử dụng có thể khởi tạo hàng ngàn module một cách tự động mà không cần động đến một dòng code. Các module được sinh ra từ công nghệ này gọi là module ảo. Module ảo là module được nhân bản từ một module bất kỳ của hệ thống nukeviet nếu module đó cho phép tạo module ảo.</li> 	<li>NukeViet 4 cũng hỗ trợ việc cài đặt từ động 100% các module kèm theo block, theme từ Admin Control Panel, người sử dụng có thể cài module mà không cần làm bất cứ thao tác phức tạp nào. NukeViet 4 còn cho phép bạn đóng gói module để chia sẻ cho người khác.</li> 	<li>Hệ thống cho phép quản lý module từ trong Admin Control Panel, quản trị cấp cao có thể phân quyền truy cập cũng như tạm ngưng hoạt động hay thậm chí cài lại hoặc xóa module tùy theo nhu cầu sử dụng.</li> </ul>  <p><br  /> <span style=\"font-weight: bold;\">Đa ngôn ngữ</span></p>  <ul> 	<li>NukeViet 4 đa ngôn ngữ 100% với 2 loại: đa ngôn ngữ giao diện và đa ngôn ngữ xử lý dữ liệu (database).</li> 	<li>NukeViet 4 có tính năng cho phép người quản trị tự xây dựng ngôn ngữ mới cho site. Cho phép đóng gói file ngôn ngữ để chia sẻ cho cộng đồng...</li> 	<li>NukeViet cũng có trung tâm dịch thuật riêng dành cho việc chung tay góp sức xây dựng những ngôn ngữ mới tại địa chỉ: <a href=\"http://translate.nukeviet.vn\" target=\"_blank\">http://translate.nukeviet.vn</a></li> 	<li>NukeViet 4 tách bạch ngôn ngữ quản trị và ngôn ngữ người dùng, ngôn ngữ giao diện và ngôn ngữ database giúp dễ dàng xây dựng và quản lý các hệ thống đa ngôn ngữ.</li> 	<li>NukeViet 4 còn có khả năng tự động nhận diện và chuyển ngôn ngữ phù hợp cho người sử dụng.</li> 	<li>NukeViet 4 còn có sẵn 3 ngôn ngữ mặc định là Việt, Anh và Pháp.</li> </ul>  <p><span style=\"font-weight: bold;\">Phân quyền</span><strong> cấp độ hệ thống</strong><br  /> NukeViet 4 tách biệt 2 khu vực: Khu vực quản trị và Khu vực người dùng. Toàn bộ các tính năng quản lý nằm trong khu vực quản trị nhằm đảm bảo việc phân quyền được thực hiện chính xác và an toàn nhất.<br  /> <br  /> <span style=\"font-weight: bold;\">Phân quyền Quản trị</span><br  /> NukeViet 4 phân quyền theo module và theo ngôn ngữ, do đó dễ dàng xác lập quyền quản trị cho các hệ thống lớn, nhiều người quản trị cùng làm việc.<br  /> <br  /> <span style=\"font-weight: bold;\">Phân quyền thành viên</span><br  /> NukeViet 4 cho phép quản lý và phân nhóm người sử dụng thành các nhóm khác nhau để dễ dàng phân quyền người sử dụng theo từng module cụ thể.<br  /> <br  /> <strong>Phân quyền cấp độ module</strong><br  /> Ở cấp module, tùy chức năng module được thiết kế mà nó có thể được phân quyền theo các cơ chế khác nhau, việc này đặc biệt linh hoạt khi xây dựng các hệ thống lớn. Với module News tích hợp trong hệ thống được trang bị việc phân quyền tới từng chuyên mục.<br  /> <br  /> <span style=\"font-weight: bold;\">Đa giao diện</span></p>  <ul> 	<li>Cài đặt: NukeViet 4 hỗ trợ cài đặt và gỡ bỏ giao diện hoàn toàn tự động. Hơn thế nữa, bạn có thể đóng gói giao diện để chia sẻ cho website khác một cách dễ dàng.</li> 	<li>NukeViet hỗ trợ giao diện theo ngôn ngữ, giao diện theo module, định nghĩa giao diện mobile (NukeViet 4) và giao diện PC tùy theo ý người quản trị.</li> 	<li>NukeViet hỗ trợ hệ thống đa giao diện cực kỳ uyển chuyển cho cả người sử dụng lẫn người lập trình. Với NukeViet 4, người sử dụng có thể tùy biến một cách dễ dàng: gán giao diện theo module, thiết lập bố cục giao diện cho từng tính năng của module.</li> 	<li>Với người thiết kế giao diện: có thể tùy ý thiết kế không giới hạn bố cục giao diện. Giao diện đã được tách bạch phần HTML và CSS khỏi PHP vì vậy người thiết kế tùy trình độ mà có thể can thiệp vào các lớp giao diện để chỉnh sửa hoặc thiết kế giao diện mới một cách dễ dàng.</li> </ul>  <p><strong>Hỗ trợ truy cập từ điện thoại, máy tính bảng.</strong><br  /> Từ bản NukeViet 4, NukeViet có thể tự động nhận diện thiết bị di động để chuyển giao diện và chế độ tương tác phù hợp. Ngoài ra NukeViet 4 còn có giao diện tùy biến, để có thể hiển thị tốt trên các màn hình khác nhau.<br  /> <br  /> <span style=\"font-weight: bold;\">Tùy biến site bằng Block</span><br  /> NukeViet cho phép đa dạng hóa bố cục và chức năng cho website nhờ các khối (block) khác nhau trên website. Các khối này có thể là các ứng dụng, các khối quảng cáo hoặc dữ liệu bất kỳ nào được người sử dụng định nghĩa. Block của NukeViet 4 cũng phân theo 2 cấp: Block của hệ thống và block cho từng module.<br  /> Người sử dụng có thể tùy ý bố trí vị trí block ở các vị trí khác nhau: toàn bộ website, theo từng module và thậm chí là từng tính năng của module. Block có thể có các giao diện khác nhau theo theme. Có thể hẹn giờ bật/tắt cũng như phân quyền cho từng đối tượng người truy cập.<br  /> Việc bố trí block có thể thực hiện trong Admin Control Panel hoặc kéo thả trực quan ngay tại giao diện người dùng.<br  /> <br  /> <span style=\"font-weight: bold;\">An ninh, bảo mật</span><br  /> NukeViet 4 được thiết kế để nhận biết và chống các truy cập bất hợp pháp vào hệ thống cũng như gửi các dữ liệu có hại lên hệ thống.</p>  <ul> 	<li>Sau khi các chuyên giả bảo mật của HP gửi đánh giá, chúng tôi đã tối ưu NukeViet 4.0 để hệ thống an toàn hơn.</li> 	<li>Mã hóa các mật khẩu lưu trữ trong hệ thống: Các mật khẩu như FTP, SMTP,... đã được mã hóa, bảo mật thông tin người dùng.<br  /> 	Tường lửa Admin bảo vệ khu vực bằng mật khẩu và IP.</li> 	<li>Bộ lọc IP cấm và bộ lọc file cấm giúp ngăn ngừa các nguy cơ biết trước.</li> 	<li>Dữ liệu gửi qua hệ thống được kiểm duyệt bằng bộ lọc an ninh kép nhằm ngăn chặn các dữ liệu có khả năng tấn công vào hệ thống.</li> 	<li>NukeViet có khả năng ngăn chặn, theo dõi và kiểm soát truy cập vào hệ thống của tất cả các máy chủ tìm kiếm như yahoo và google hay bất cứ máy chủ tìm kiếm nào khác.</li> 	<li>Hệ thống có khả năng chống Spam bằng Captcha, chống lụt dữ liệu bằng nhiều hình thức như giới hạn thời gian gửi dữ liệu (sử dụng các công thức kép)...</li> 	<li>Hệ thống cho phép theo dõi, ghi nhận các thông số của máy tính truy cập đến site như: Hệ điều hành, Trình duyệt, quốc gia, các liên kết đến site (referer) để từ đó có thể kịp thời ngăn ngừa các nguy cơ tấn công bằng các hình thức như: kiểm tra và chặn các máy tình dùng proxy, chặn IP truy cập...</li> 	<li>hật ký hệ thống sẽ ghi nhận truy cập và thao tác tới cơ sở dữ liệu &amp; tệp tin, giúp người quản trị cũng như các thành viên dễ dàng phát hiện ra những đăng nhập bất hợp pháp từ lần đăng nhập trước đó.</li> 	<li>Hệ thống có thể phát hiện các bản nâng cấp mới của phần mềm để nhắc nhở người sử dụng nâng cấp và sửa chữa các lỗi (nếu có)</li> </ul>  <p><span style=\"font-weight: bold;\">Quản lý CSDL</span></p>  <ul> 	<li>NukeViet 4 cho phép quản lý CSDL, người sử dụng có thể tối ưu, sao lưu trên máy chủ và tải dữ liệu về để phục vụ cho công tác phục hồi nếu xảy ra sự cố.</li> 	<li>Hỗ trợ mô hình CSDL theo mô hình master/slave để phân tải CSDL.</li> </ul>  <p><span style=\"font-weight: bold;\">Kiểm soát lỗi tự động và báo lỗi thông minh</span></p>  <ul> 	<li>NukeViet 4 có hệ thống kiểm soát lỗi tự động và báo lỗi cho người dùng.</li> 	<li>Các lỗi (nếu có) sẽ được hệ thống kiểm soát có chủ đích, nó chỉ hiển thị lên màn hình người sử dụng ở lần đầu nó xuất hiện, sau đó hệ thống ghi nhận và báo về cho người quản trị qua email.</li> 	<li>Quản trị có thể cấu hình việc bật tắt việc có ghi nhận lỗi hay không.</li> </ul>  <p><span style=\"font-weight: bold;\">Tối ưu hóa cho công cụ tìm kiếm (SEO)</span></p>  <ul> 	<li>Loại bỏ tên module khỏi URL khi không dùng đa ngôn ngữ.</li> 	<li>Cho phép đổi đường dẫn module</li> 	<li>Thêm chức năng xác thực Google+ (Bản quyền tác giả)</li> 	<li>Thêm chức năng ping đến các công cụ tìm kiếm: Submit url mới đến google để việc hiển thị bài viết mới lên kết quả tìm kiếm nhanh chóng hơn.</li> 	<li>Hỗ trợ Meta OG của facebook</li> 	<li>Hỗ trợ chèn Meta GEO qua Cấu hình Meta-Tags<br  /> 	Hỗ trợ SEO link.</li> 	<li>Quản lý và tùy biến tiêu đề site, description</li> 	<li>Hỗ trợ quản lý các thẻ meta như: keywords, description</li> 	<li>Hỗ trợ sử dụng keywords để phát sinh trang thống kê một cách tự động nhờ công cụ tìm kiếm.</li> 	<li>Hỗ trợ quản lý máy chủ tìm kiếm.</li> 	<li>Hỗ trợ quản lý cấu hình robots.txt</li> 	<li>Hỗ trợ chuẩn đoán site (site Diagnostic).</li> </ul>  <p><span style=\"font-weight: bold;\">Sẵn sàng cho việc tích hợp các ứng dụng của bên thứ 3</span><br  /> NukeViet 3.4 sử dụng Cơ sở dữ liệu thành viên độc lập và xây dựng sẵn các phương thức kết nối với các ứng dụng Forum. Cơ sở dữ liệu thành viên độc lập giúp việc quản lý thành viên được chủ động, khi có nhu cầu kết nối hoặc trao quyền quản lý cho các ứng dụng từ bên thứ 3, NukeViet 3.4 vẫn hoàn toàn chủ động với dữ liệu thành viên của mình. Với NukeViet 3.4, các kết nối trực tiếp dành cho Forum như PHPBB hay VBB đều sẵn sàng.<br  /> <br  /> <span style=\"font-weight: bold;\">Hỗ trợ Đăng nhập phân tán</span><br  /> NukeViet hỗ trợ thư viện OAuth , cho phép người truy cập có thể đăng nhập phân tán từ các hệ thống như FaceBook và Google hay các hệ thống OpenID khác giúp các website mới xây dựng có cơ hội thu hút lượng người sử dụng khổng lồ từ các hệ thống lớn.<br  /> Trong mọi trường hợp, hệ thống cho phép admin kiểm duyệt việc login OAuth. Tùy nhu cầu sử dụng mà có thể thiết đặt mức độ login cao nhất (tự động) tới mức độ vẫn phải đăng ký thành viên (bớt bước kích hoạt qua email). Người sử dụng cũng có thể quản lý nhiều tài khoản OAuth để từ đó có thể đăng nhập bằng tài khoản bất kỳ (nếu hệ thống cho phép).</p>  <p><strong>Trình soạn thảo tích hợp sẵn:</strong></p>  <p>Tại những vị trí phù hợp, NukeViet tích hợp sẵn trình soạn thảo CKeditor giúp người sử dụng dễ dàng biên tập nội dung trên giao diện trực quan và thân thiện như làm việc với phần mềm Microsoft Word hay OpenOffice. Hiện tại NukeViet 4 cũng đã mở sẵn để tích hợp các trình soạn thảo khác.</p>  <p><span style=\"font-weight: bold;\">Các tiện ích khác</span><br  /> Hệ thống cho phép gửi mail bằng các phương thức: SMTP, Linux Mail, PHPmail.<br  /> Cho phép sử dụng phương thức FTP để ghi file nếu máy chủ không cho phép làm điều đó bằng PHP<br  /> Cho phép xây dựng và quản lý các tác vụ xử lý tự động như tự động sao lưu CSDL, tự động xóa các dữ liệu cũ hoặc gửi báo lỗi tới người quản trị...<br  /> Cung cấp đầy đủ các thông tin về hệ thống giúp nhà phát triển dễ dàng sử dụng các thông tin này phục vụ cho việc lập trình, kiểm tra và báo lỗi hệ thống.<br  /> <br  /> <span style=\"font-size: 150%; line-height: 116%;\"><span style=\"font-weight: bold;\">Các module tích hợp sẵn trong NukeViet CMS 4:</span></span><br  /> <span style=\"font-weight: bold;\">Quản lý Upload</span></p>  <ul> 	<li>Upload file từ máy tính hoặc một địa chỉ bất kỳ trên mạng.</li> 	<li>Quản lý: Di chuyển, đổi tên, sửa, xóa, tạo hình thu nhỏ...</li> 	<li>Hỗ trợ tìm kiểm các file và mô tả các file được upload lên trong khu vực quản trị.</li> </ul>  <p><span style=\"font-weight: bold;\">Quản trị và xuất bản Tin tức:</span> (cho phép tạo module ảo)<br  /> Hệ thống tin tức của NukeViet là hệ thống quản trị tin tức chuyên nghiệp đặc biệt phù hợp với các website tin tức. Nó cho phép xử lý nhiều tác vụ nền thông minh mà không cần người sử dụng can thiệp nhằm tối ưu cho hệ thống tin tức, Ví dụ: tạo hình thu nhỏ, tự động chia thư mục và sắp xếp hình vào các thư mục theo thời gian...</p>  <ul> 	<li>Quản lý chủ đề đa cấp trong đó bản tin có thể nằm ở 1 hoặc nhiều chủ đề không phụ thuộc quan hệ cha con giữa các chủ đề.</li> 	<li>Phân quyền cho người quản lý module, đến từng chủ đề</li> 	<li>Quản lý nhóm tin liên quan (phân luồn tin theo dòng đơn)</li> 	<li>Quản lý block tin (nhóm tin đa luồng)</li> 	<li>Quản lý Tags</li> 	<li>Quản lý nguồn tin</li> 	<li>Tùy chỉnh bố cục trang tin.</li> 	<li>Gửi bài viết, hẹn giờ đăng và nhiều tùy chỉnh khác: cho phép gửi bản tin, in, lưu bản tin.</li> 	<li>Cấp tin RSS</li> 	<li>Công cụ tương tác với mạng xã&nbsp; hội.</li> </ul>  <p><span style=\"font-weight: bold;\">Module Page:</span></p>  <ul> 	<li>Module này thích hợp làm các bài viết không cần quản lý chủ đề, như các module ảo: giới thiệu, nội quy site ...</li> 	<li>Hỗ trợ SEO: Ảnh minh họa, chú thích ảnh minh họa, mô tả, từ khóa cho bài viết, hiển thị các công cụ tương tác với các mạng xã hội.</li> 	<li>Hỗ trợ RSS</li> 	<li>Cấu hình phương án hiển thị các bài viết trên trang chính.</li> </ul>  <p><span style=\"font-weight: bold;\">Quản lý thành viên:</span></p>  <ul> 	<li>Quản lý việc đăng nhập, đăng ký.</li> 	<li>Quản lý phương thức đăng nhập: Qua openid hoặc đăng nhập trực tiếp.</li> 	<li>Quản lý câu hỏi bảo mật.</li> 	<li>Quản lý nội quy.</li> 	<li>Quản lý thông tin thành viên.</li> 	<li>Cho phép đăng nhập 1 lần tài khoản người dùng NukeViet với Alfresco, Zimbra, Moodle, Koha thông qua CAS.</li> 	<li>Chức năng tùy biến trường dữ liệu thành viên</li> 	<li>Chức năng phân quyền sử dụng module users</li> 	<li>Cấu hình Số ký tự username, độ phức tạp mật khẩu, tạo mật khảu ngẫu nhiên,....</li> 	<li>Cho phép sử dụng tên truy cập, hoặc email để đăng nhập</li> </ul>  <p><span style=\"font-weight: bold;\">Quản lý liên hệ gửi đến website</span></p>  <ul> 	<li>Quản lý thông tin liên hệ trên site.</li> 	<li>Quản lý các bộ phận tiếp nhận liên hệ.</li> 	<li>Quản lý và trả lời các thư gửi tới. Admin có thể trả lời khách nhiều lần, hệ thống lưu lại lịch sử trao đổi đó.</li> 	<li>Hệ thống nhận thông báo: đây là một tiện ích nhỏ, song nó rất hữu dụng để admin tương tác với hệ thống một cách nhanh chóng. Admin có thể nhận thông báo từ hệ thống (hoặc từ module) khi có sự kiện nào đó. Ví dụ: Khi có khách gửi liên hệ (qua module contact) đến thì hệ thống xuất hiện biểu tượng thông báo “Có liên hệ mới” ở góc phải, Admin sẽ nhận được ngay lập tức thông báo khi người dùng đang ở Admin control panel (ACP).</li> </ul>  <p><span style=\"font-weight: bold;\">Quản lý thăm dò ý kiến:</span></p>  <ul> 	<li>Tạo các thăm dò ý kiến</li> </ul>  <p><span style=\"font-weight: bold;\">Quản lý quảng cáo chuyên nghiệp:</span></p>  <ul> 	<li>Quản lý khách hàng.</li> 	<li>Quản lý các khu vực quảng cáo</li> 	<li>Quản lý các nội dung quảng cáo.</li> 	<li>Kết hợp với việc quản lý block. Các quản cáo có thể đặt vào các khu vực khác nhau, dễ dàng thay đổi theo nhu cầu của người dùng.</li> </ul>  <p><span style=\"font-weight: bold;\">Thống kê:</span> Thống kê theo năm, tháng, ngày, tuần, giờ.</p>  <ul> 	<li>Theo liên kết đến site</li> 	<li>Theo quốc gia</li> 	<li>Theo trình duyệt</li> 	<li>Theo hệ điều hành</li> 	<li>Máy chủ tìm kiếm</li> </ul>  <p><span style=\"font-weight: bold;\">Tìm kiếm</span></p>  <ul> 	<li>Tìm kiếm chung toàn hệ thống</li> 	<li>Tìm kiếm nâng cao từng khu vực</li> </ul>  <div><strong>Module menu:</strong></div>  <ul> 	<li>Module này cung cấp để quản lý các menu tùy biên, có thể lấy liên kết từ nhiều mục khác nhau.</li> 	<li>Phương án quản lý menu được thay đổi hướng tới việc quản lý menu nhanh chóng, tiện lợi nhất cho admin.</li> 	<li>Admin có thể nạp nhanh menu theo các tùy chọn mà hệ thống cung cấp.</li> 	<li>Mẫu menu cũng được thay đổi, đa dạng và hiển thị tốt với các giao diện hiện đại.</li> </ul>  <p><strong>Quản lý Bình luận</strong></p>  <ul> 	<li>Các bình luận của các module sẽ được tích hợp quản lý tập trung để cấu hình, phân quyền.</li> 	<li>Khi xây dựng mới module, Chỉ cần nhúng 1 đoạn mã vào. Tránh phải việc copy mã code gây khó khăn cho bảo trì.</li> </ul>  <p><br  /> Trên đây là các tính năng chính của bộ nhân hệ thống NukeViet 4, để xem đầy đủ hơn các tính năng <strong><a href=\"http://wiki.nukeviet.vn/nukeviet4:feature\">click vào đây</a></strong>. Với NukeViet, việc mở rộng thêm các tính năng là không hạn chế, đơn giản là cài thêm các module tương ứng hoặc xây dựng thêm các module đó cho NukeViet.</p>', '', 0, '4', '', 5, 1, 1712405092, 1712405092, 1, 0, 0), 
(6, 'Yêu cầu sử dụng NukeViet 4', 'Yeu-cau-su-dung-NukeViet-4', '', '', 0, '', '<h2 class=\"sectionedit2\" id=\"moi_truong_may_chủ\">1. Môi trường máy chủ</h2>  <div class=\"level2\"> <p><strong>Yêu cầu bắt buộc</strong></p>  <ul> 	<li class=\"level1\"> 	<div class=\"li\">Hệ điều hành: Unix (Linux, Ubuntu, Fedora …) hoặc Windows</div> 	</li> 	<li class=\"level1\"> 	<div class=\"li\">PHP: PHP 5.4 hoặc phiên bản mới nhất.</div> 	</li> 	<li class=\"level1\"> 	<div class=\"li\">MySQL: MySQL 5.5 hoặc phiên bản mới nhất</div> 	</li> </ul>  <p><strong>Tùy chọn bổ sung</strong></p>  <ul> 	<li class=\"level1\"> 	<div class=\"li\">Máy chủ Apache cần hỗ trợ mod mod_rewrite.</div> 	</li> 	<li class=\"level1\"> 	<div class=\"li\">Máy chủ Nginx cấu hình các thông số rewite.</div> 	</li> 	<li class=\"level1\"> 	<div class=\"li\">Máy chủ IIS 7.0 hoặc IIS 7.5 cần cài thêm module rewrite</div> 	</li> 	<li class=\"level1\"> 	<div class=\"li\">Môi trường PHP mở rộng: Các thư viện PHP cần có: file_uploads, session, mbstring, curl, gd2, zlib, soap, php_zip.</div> 	</li> </ul>  <p><em class=\"u\"><strong>Ghi chú:</strong></em></p>  <ul> 	<li class=\"level1\"> 	<div class=\"li\">Những yêu cầu trên không có nghĩa là NukeViet 4 không làm việc trên các hệ thống khác, điều quan trọng là cần thiết lập môi trường làm việc phù hợp.</div> 	</li> 	<li class=\"level1\"> 	<div class=\"li\">Với những website sử dụng hosting, NukeViet 4 làm việc tốt nhất trên các hosting Linux cài sẵn Apache 2.2, PHP 5, MySQL 5, DirectAdmin hoặc Cpanel.</div> 	</li> 	<li class=\"level1\"> 	<div class=\"li\">Với các website cần chịu tải cao, nên sử dụng Nginx, PHP7 (php-fpm). Tham khảo thêm mô hình <a class=\"urlextern\" href=\"http://wiki.nukeviet.vn/web_server:cai-dat-server-chi-tai-cao\" rel=\"nofollow\" target=\"_blank\" title=\"http://wiki.nukeviet.vn/web_server:cai-dat-server-chi-tai-cao\">http://wiki.nukeviet.vn/web_server:cai-dat-server-chi-tai-cao</a></div> 	</li> </ul> </div>  <div class=\"secedit editbutton_section editbutton_2\">  <div class=\"no\">&nbsp;</div>  </div>  <h2 class=\"sectionedit3\" id=\"may_tinh_nguời_truy_cập\">2. Máy tính người truy cập</h2>  <div class=\"level2\"> <p>NukeViet 4 cho kết quả là chuẩn HTML5 và CSS 3, đây là định dạng chuẩn mà hầu hết các trình duyệt hiện nay đang hỗ trợ. Chính vì vậy các website làm trên nền NukeViet 4 có thể truy cập tốt trên các phiên bản mới nhất của trình duyệt FireFox, Internet Explorer 9, Google Chrome … Máy tính người truy cập chỉ cần cài một trong các trình duyệt này là có thể tương tác với NukeViet thông qua internet hoặc intranet.</p> </div>', '', 0, '4', '', 6, 1, 1712405092, 1712405092, 1, 0, 0), 
(7, 'Giới thiệu về Công ty cổ phần phát triển nguồn mở Việt Nam', 'gioi-thieu-ve-cong-ty-co-phan-phat-trien-nguon-mo-viet-nam', '', '', 0, '', '<p><strong>Công ty cổ phần phát triển nguồn mở Việt Nam</strong> (VINADES.,JSC) là công ty mã nguồn mở đầu tiên của Việt Nam sở hữu riêng một mã nguồn mở nổi tiếng và đang được sử dụng ở hàng ngàn website lớn nhỏ trong mọi lĩnh vực. Wbsite đang hoạt động chính thức: <a href=\"http://vinades.vn/\">http://vinades.vn/</a><br  /> <br  /> Ra đời từ hoạt động của tổ chức nguồn mở NukeViet (từ năm 2004) và chính thức được thành lập đầu 2010 tại Hà Nội, khi đó báo chí đã gọi VINADES.,JSC là <em><strong>&quot;Công ty mã nguồn mở đầu tiên tại Việt Nam&quot;</strong></em>.<br  /> <br  /> Ngay sau khi thành lập, VINADES.,JSC đã thành công trong việc xây dựng <strong><a href=\"http://nukeviet.vn/\" target=\"_blank\">NukeViet</a></strong> thành một <a href=\"http://nukeviet.vn/\" target=\"_blank\">mã nguồn mở</a> thuần Việt. Với khả năng mạnh mẽ, cùng các ưu điểm vượt trội về công nghệ, độ an toàn và bảo mật, NukeViet đã được hàng ngàn website lựa chọn sử dụng trong năm qua. Ngay khi ra mắt phiên bản mới năm 2010, NukeViet đã tạo nên hiệu ứng truyền thông chưa từng có trong lịch sử mã nguồn mở Việt Nam. Tiếp đó, năm 2011 Mã nguồn mở NukeViet đã giành giải thưởng Nhân tài đất Việt cho sản phẩm Công nghệ thông tin đã được ứng dụng rộng rãi.</p>  <div style=\"text-align: center;\"> <div class=\"youtube-embed-wrapper\" style=\"position:relative;padding-bottom:56.25%;padding-top:30px;height:0;overflow:hidden;\"><iframe allowfullscreen=\"\" height=\"480\" src=\"//www.youtube.com/embed/ZOhu2bLE-eA?rel=0&amp;autoplay=1\" style=\"position: absolute;top: 0;left: 0;width: 100%;height: 100%;\" width=\"640\"></iframe></div> <br  /> <span style=\"font-size:12px;\"><strong>Video clip trao giải Nhân tài đất Việt 2011.</strong><br  /> Sản phẩm &quot;Mã nguồn mở NukeViet&quot; đã nhận giải cao nhất (Giải ba, không có giải nhất, giải nhì) của Giải thưởng Nhân Tài Đất Việt 2011 ở lĩnh vực Công nghệ thông tin - Sản phẩm đã có ứng dụng rộng rãi.</span></div>  <p><br  /> Tự chuyên nghiệp hóa mình, thoát khỏi mô hình phát triển tự phát, công ty đã nỗ lực vươn mình ra thế giới và đang phấn đấu trở thành một trong những hiện tượng của thời &quot;dotcom&quot; ở Việt Nam.<br  /> <br  /> Để phục vụ hoạt động của công ty, công ty liên tục mở rộng và tuyển thêm nhân sự ở các vị trí: Lập trình viên, chuyên viên đồ họa, nhân viên kinh doanh... Hãy liên hệ ngay để gia nhập VINADES.,JSC và cùng chúng tôi trở thành một công ty phát triển nguồn mở thành công nhất Việt Nam.</p>  <p>Nếu bạn có nhu cầu triển khai các hệ thống <strong><a href=\"http://toasoandientu.vn\" target=\"_blank\">Tòa Soạn Điện Tử</a></strong>, <strong><a href=\"http://webnhanh.vn\" target=\"_blank\">phần mềm trực tuyến</a></strong>, <strong><a href=\"http://vinades.vn\" target=\"_blank\">thiết kế website</a></strong> theo yêu cầu hoặc dịch vụ có liên quan, hãy liên hệ công ty chuyên quản NukeViet theo thông tin dưới đây:</p>  <p><strong><span style=\"font-family: Tahoma; color: rgb(255, 69, 0); font-size: 14px;\">CÔNG TY CỔ PHẦN PHÁT TRIỂN NGUỒN MỞ VIỆT NAM</span></strong><br  /> <strong>VIET NAM OPEN SOURCE DEVELOPMENT JOINT STOCK COMPANY</strong> (<strong>VINADES.,JSC</strong>)<br  /> Website: <a href=\"http://vinades.vn/\">http://vinades.vn</a> | <a href=\"http://nukeviet.vn/\">http://nukeviet.vn</a> | <a href=\"http://webnhanh.vn/\">http://webnhanh.vn</a><br  /> Trụ sở: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.<br  /> - Tel: +84-4-85872007<br  /> - Fax: +84-4-35500914<br  /> - Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a></p>', 'giới thiệu,công ty,cổ phần,phát triển', 0, '4', '', 7, 1, 1712405092, 1712405092, 1, 0, 0), 
(8, 'Ủng hộ, hỗ trợ và tham gia phát triển NukeViet', 'ung-ho-ho-tro-va-tham-gia-phat-trien-nukeviet', '', '', 0, 'Nếu bạn yêu thích NukeViet, bạn có thể ủng hộ và hỗ trợ NukeViet bằng nhiều cách', '<h2>1. Ủng hộ bằng tiền mặt vào Quỹ tài trợ NukeViet</h2> Qua tài khoản Paypal:  <p style=\"text-align:center\"><a href=\"https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&amp;hosted_button_id=5LUSNE2SV5RR2\" target=\"_blank\"><img alt=\"\" src=\"https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif\" /></a></p> Chuyển khoản ngân hàng trực tiếp:  <ul> 	<li>Người đứng tên tài khoản:&nbsp;NGUYEN THE HUNG</li> 	<li>Số tài khoản:&nbsp;0031000792053</li> 	<li>Loại tài khoản: VND (Việt Nam Đồng)</li> 	<li>Ngân hàng Vietcombank chi nhánh Hải Phòng.</li> 	<li>Website:&nbsp;<a href=\"http://www.vietcombank.com.vn/\">http://www.vietcombank.com.vn</a></li> </ul>  <div class=\"alert alert-info\">Lưu ý: Đây là tài khoản hợp lệ duy nhất mà NukeViet.VN sử dụng cho&nbsp;Quỹ tài trợ NukeViet.</div> Thảo luận tại đây:&nbsp;<a href=\"http://forum.nukeviet.vn/viewtopic.php?f=3&amp;t=3592\" target=\"_blank\">http://forum.nukeviet.vn/viewtopic.php?f=3&amp;t=3592</a>  <h2>2. Ủng hộ bằng cách sử dụng và phổ biến NukeViet đến nhiều người hơn</h2> Cách đơn giản nhất để ủng hộ NukeViet phát triển là sử dụng NukeViet và giúp NukeViet phổ biến đến nhiều người hơn (ví dụ như giữ lại dòng chữ &quot;Powered by&nbsp;<a href=\"http://nukeviet.vn/\" target=\"_blank\">NukeViet</a>&quot; hoặc &quot;Sử dụng&nbsp;<a href=\"http://nukeviet.vn/\" target=\"_blank\">NukeViet</a>&quot; trên website của bạn, viết bài giới thiệu NukeViet đến mọi người).<br /> Nếu bạn có thời gian, bạn có thể tham gia&nbsp;<a href=\"http://forum.nukeviet.vn/\" target=\"_blank\">diễn đàn NukeViet</a>&nbsp;thường xuyên và giúp đỡ những người mới sử dụng NukeViet.  <h2>3. Ủng hộ bằng cách tham gia phát triển NukeViet</h2>  <h3>3.1. Phát triển module, giao diện cho NukeViet</h3> Nếu bạn biết code, hãy tham gia viết module, block, theme cho NukeViet và đưa lên&nbsp;<a href=\"http://nukeviet.vn/vi/store/\" target=\"_blank\">NukeViet Store</a>&nbsp;để cung cấp cho cộng đồng. Bạn cũng có thể tham gia đội ngũ phát triển NukeViet.  <h3>3.2. Tham gia phát triển nhân hệ thống</h3> Toàn bộ code nhân hệ thống NukeViet đã được đưa lên GitHub.com (truy cập tắt:&nbsp;<a href=\"http://code.nukeviet.vn/\" target=\"_blank\">http://code.nukeviet.vn</a>), dù bạn là ai, cá nhân hay doanh nghiệp chỉ cần có một tài khoản tại GitHub và học cách sử dụng&nbsp;<a href=\"#git\">git&nbsp;(1)</a>&nbsp;là bạn có thể tham gia phát triển code NukeViet. Tìm hiểu thêm về việc tham gia phát triển code nhân hệ thống NukeViet tại đây:&nbsp;<a href=\"http://wiki.nukeviet.vn/programming:github_rule\" target=\"_blank\">http://wiki.nukeviet.vn/programming:github_rule</a>  <h3>3.3. Tham gia dịch thuật</h3> Nếu bạn biết ngoại ngữ, hãy đăng ký tham gia đội ngũ dịch thuật tình nguyện tại&nbsp;<a href=\"http://translate.nukeviet.vn/\" target=\"_blank\">NukeViet Stranslate System</a>&nbsp;để dịch thuật NukeViet sang các ngôn ngữ khác, quảng bá NukeViet ra với thế giới.  <h3>3.4. Tham gia viết tài liệu hướng dẫn sử dụng</h3> Nếu bạn không biết code, không biết ngoại ngữ, bạn vẫn có thể tham gia đóng góp cho NukeViet bằng cách biên soạn tài liệu hướng dẫn người dùng NukeViet tại thư viện tài liệu mở của NukeViet ở địa chỉ&nbsp;<a href=\"http://wiki.nukeviet.vn/\" target=\"_blank\">http://wiki.nukeviet.vn</a>  <hr  /> <a id=\"git\" name=\"git\">(1)</a>: Tìm hiểu về git:&nbsp;<a href=\"http://wiki.nukeviet.vn/programming:vcs:git\" target=\"_blank\">http://wiki.nukeviet.vn/programming:vcs:git</a>', 'ủng hộ,hỗ trợ,tham gia,phát triển', 0, '4', '', 8, 1, 1712405092, 1712405092, 1, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_about_config`
--

DROP TABLE IF EXISTS `nv4_vi_about_config`;
CREATE TABLE `nv4_vi_about_config` (
  `config_name` varchar(30)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_about_config`
--

INSERT INTO `nv4_vi_about_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '20'), 
('news_first', '0'), 
('related_articles', '5'), 
('copy_page', '0'), 
('alias_lower', '1'), 
('socialbutton', 'facebook,twitter');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_blocks_groups`
--

DROP TABLE IF EXISTS `nv4_vi_blocks_groups`;
CREATE TABLE `nv4_vi_blocks_groups` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `theme` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(55)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template` varchar(55)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(55)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exp_time` int(11) DEFAULT '0',
  `active` varchar(10)  COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `act` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `groups_view` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `all_func` tinyint(4) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `config` text  COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`bid`),
  KEY `theme` (`theme`),
  KEY `module` (`module`),
  KEY `position` (`position`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=44  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_blocks_groups`
--

INSERT INTO `nv4_vi_blocks_groups` VALUES
(1, 'default', 'news', 'module.block_newscenter.php', 'Tin mới nhất', '', 'no_title', '[TOP]', 0, '1', 1, '6', 0, 1, 'a:10:{s:6:\"numrow\";i:6;s:11:\"showtooltip\";i:1;s:16:\"tooltip_position\";s:6:\"bottom\";s:14:\"tooltip_length\";s:3:\"150\";s:12:\"length_title\";i:0;s:15:\"length_hometext\";i:0;s:17:\"length_othertitle\";i:60;s:5:\"width\";i:500;s:6:\"height\";i:0;s:7:\"nocatid\";a:0:{}}'), 
(2, 'default', 'banners', 'global.banners.php', 'Quảng cáo giữa trang', '', 'no_title', '[TOP]', 0, '1', 1, '6', 0, 2, 'a:1:{s:12:\"idplanbanner\";i:1;}'), 
(3, 'default', 'news', 'global.block_category.php', 'Chủ đề', '', 'no_title', '[LEFT]', 0, '1', 1, '6', 0, 1, 'a:2:{s:5:\"catid\";i:0;s:12:\"title_length\";i:0;}'), 
(4, 'default', 'theme', 'global.module_menu.php', 'Module Menu', '', 'no_title', '[LEFT]', 0, '1', 1, '6', 0, 2, ''), 
(5, 'default', 'banners', 'global.banners.php', 'Quảng cáo cột trái', '', 'no_title', '[LEFT]', 0, '1', 1, '6', 1, 3, 'a:1:{s:12:\"idplanbanner\";i:2;}'), 
(6, 'default', 'statistics', 'global.counter.php', 'Thống kê', '', 'primary', '[LEFT]', 0, '1', 1, '6', 1, 4, ''), 
(8, 'default', 'san-pham', 'global.block_relates_product.php', 'Bán chạy', '', 'panel_kengang', '[RIGHT]', 0, '1', 1, '6', 1, 2, 'a:3:{s:7:\"blockid\";i:2;s:6:\"numrow\";i:10;s:7:\"cut_num\";i:40;}'), 
(10, 'default', 'statistics', 'global.counter.php', 'Thống kê', '', 'panel_sidebar', '[RIGHT]', 0, '1', 1, '3', 0, 4, ''), 
(12, 'default', 'contact', 'global.contact_form.php', 'Feedback', '', 'no_title', '[FOOTER_SITE]', 0, '1', 1, '6', 1, 1, ''), 
(16, 'default', 'theme', 'global.company_info.php', 'Thông tin công ty', '', 'simple', '[MENU_FOOTER]', 0, '1', 1, '6', 1, 1, 'a:13:{s:12:\"company_name\";s:52:\"Công Ty Cổ Phần Trà Tân Cương Hoàng Đạt\";s:16:\"company_sortname\";s:23:\"TAN CUONG HOANG DAT TEA\";s:15:\"company_regcode\";s:0:\"\";s:16:\"company_regplace\";s:0:\"\";s:21:\"company_licensenumber\";s:0:\"\";s:22:\"company_responsibility\";s:0:\"\";s:15:\"company_address\";s:64:\"Tổ 3, Phường Tân Thịnh, TP. Thái Nguyên, Thái Nguyên\";s:15:\"company_showmap\";i:1;s:14:\"company_mapurl\";s:326:\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2634.116366996857!2d105.79399620326203!3d20.9844946314258!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135ac93055e2f2f%3A0x91f4b423089193dd!2zQ8O0bmcgdHkgQ-G7lSBwaOG6p24gUGjDoXQgdHJp4buDbiBOZ3Xhu5NuIG3hu58gVmnhu4d0IE5hbQ!5e0!3m2!1svi!2s!4v1558315703646!5m2!1svi!2s\";s:13:\"company_phone\";s:10:\"0336050020\";s:11:\"company_fax\";s:0:\"\";s:13:\"company_email\";s:26:\"tancuonghoangdat@gmail.com\";s:15:\"company_website\";s:27:\"https://tancuonghoangdat.vn\";}'), 
(17, 'default', 'menu', 'global.bootstrap.php', 'Menu Site', '', 'no_title', '[MENU_SITE]', 0, '1', 1, '6', 1, 1, 'a:2:{s:6:\"menuid\";i:1;s:12:\"title_length\";i:0;}'), 
(19, 'default', 'theme', 'global.social.php', 'Social icon', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 1, 'a:3:{s:8:\"facebook\";s:40:\"http://www.facebook.com/tancuonghoangdat\";s:7:\"youtube\";s:45:\"https://www.youtube.com/user/tancuonghoangdat\";s:7:\"twitter\";s:36:\"https://twitter.com/tancuonghoangdat\";}'), 
(20, 'default', 'theme', 'global.menu_footer.php', 'Các chuyên mục chính', '', 'simple', '[COMPANY_INFO]', 0, '1', 1, '6', 1, 1, 'a:1:{s:14:\"module_in_menu\";a:8:{i:0;s:5:\"about\";i:1;s:4:\"news\";i:2;s:5:\"users\";i:3;s:7:\"contact\";i:4;s:6:\"voting\";i:5;s:7:\"banners\";i:6;s:4:\"seek\";i:7;s:5:\"feeds\";}}'), 
(21, 'default', 'freecontent', 'global.free_content.php', 'Sản phẩm', '', 'no_title', '[FEATURED_PRODUCT]', 0, '1', 1, '6', 1, 1, 'a:2:{s:7:\"blockid\";i:1;s:7:\"numrows\";i:2;}'), 
(22, 'mobile_default', 'menu', 'global.metismenu.php', 'Menu Site', '', 'no_title', '[MENU_SITE]', 0, '1', 1, '6', 1, 1, 'a:2:{s:6:\"menuid\";i:1;s:12:\"title_length\";i:0;}'), 
(23, 'mobile_default', 'users', 'global.user_button.php', 'Sign In', '', 'no_title', '[MENU_SITE]', 0, '1', 1, '6', 1, 2, ''), 
(24, 'mobile_default', 'contact', 'global.contact_default.php', 'Contact Default', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 1, ''), 
(25, 'mobile_default', 'contact', 'global.contact_form.php', 'Feedback', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 2, ''), 
(26, 'mobile_default', 'theme', 'global.social.php', 'Social icon', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 3, 'a:3:{s:8:\"facebook\";s:32:\"http://www.facebook.com/nukeviet\";s:7:\"youtube\";s:37:\"https://www.youtube.com/user/nukeviet\";s:7:\"twitter\";s:28:\"https://twitter.com/nukeviet\";}'), 
(27, 'mobile_default', 'theme', 'global.QR_code.php', 'QR code', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 4, ''), 
(28, 'mobile_default', 'theme', 'global.copyright.php', 'Copyright', '', 'no_title', '[FOOTER_SITE]', 0, '1', 1, '6', 1, 1, 'a:5:{s:12:\"copyright_by\";s:0:\"\";s:13:\"copyright_url\";s:0:\"\";s:9:\"design_by\";s:12:\"VINADES.,JSC\";s:10:\"design_url\";s:18:\"http://vinades.vn/\";s:13:\"siteterms_url\";s:39:\"/index.php?language=vi&amp;nv=siteterms\";}'), 
(29, 'mobile_default', 'theme', 'global.menu_footer.php', 'Các chuyên mục chính', '', 'primary', '[MENU_FOOTER]', 0, '1', 1, '6', 1, 1, 'a:1:{s:14:\"module_in_menu\";a:9:{i:0;s:5:\"about\";i:1;s:4:\"news\";i:2;s:5:\"users\";i:3;s:7:\"contact\";i:4;s:6:\"voting\";i:5;s:7:\"banners\";i:6;s:4:\"seek\";i:7;s:5:\"feeds\";i:8;s:9:\"siteterms\";}}'), 
(30, 'mobile_default', 'theme', 'global.company_info.php', 'Công ty chủ quản', '', 'primary', '[COMPANY_INFO]', 0, '1', 1, '6', 1, 1, 'a:13:{s:12:\"company_name\";s:58:\"Công ty cổ phần phát triển nguồn mở Việt Nam\";s:15:\"company_address\";s:72:\"Phòng 1706 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội\";s:16:\"company_sortname\";s:12:\"VINADES.,JSC\";s:15:\"company_regcode\";s:0:\"\";s:16:\"company_regplace\";s:0:\"\";s:21:\"company_licensenumber\";s:0:\"\";s:22:\"company_responsibility\";s:0:\"\";s:15:\"company_showmap\";i:1;s:14:\"company_mapurl\";s:326:\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2634.116366996857!2d105.79399620326203!3d20.9844946314258!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135ac93055e2f2f%3A0x91f4b423089193dd!2zQ8O0bmcgdHkgQ-G7lSBwaOG6p24gUGjDoXQgdHJp4buDbiBOZ3Xhu5NuIG3hu58gVmnhu4d0IE5hbQ!5e0!3m2!1svi!2s!4v1558315703646!5m2!1svi!2s\";s:13:\"company_phone\";s:58:\"+84-24-85872007[+842485872007]|+84-904762534[+84904762534]\";s:11:\"company_fax\";s:15:\"+84-24-35500914\";s:13:\"company_email\";s:18:\"contact@vinades.vn\";s:15:\"company_website\";s:17:\"http://vinades.vn\";}'), 
(31, 'default', 'san-pham', 'global.block_catalogs.php', 'Danh mục sản phẩm', '', 'panel_tancuonghoangdat', '[HOME_CATEGORY]', 0, '1', 1, '6', 0, 1, 'a:1:{s:7:\"cut_num\";i:24;}'), 
(32, 'default', 'thong-tin', 'global.html.php', 'header-cty', '', 'no_title', '[CONTACT_DEFAULT]', 0, '1', 1, '6', 1, 1, 'a:1:{s:11:\"htmlcontent\";s:40:\"Công ty TNHH Tân Cương Hoàng Đạt\";}'), 
(33, 'default', 'san-pham', 'global.block_bxproduct_center.php', 'Sản phẩm mới', '', 'panel_kengang', '[HOMEPRODUCT1]', 0, '1', 1, '6', 0, 1, 'a:10:{s:7:\"blockid\";i:1;s:6:\"numrow\";i:5;s:6:\"numget\";i:30;s:4:\"auto\";i:1;s:4:\"mode\";s:10:\"horizontal\";s:5:\"speed\";i:500;s:5:\"width\";i:250;s:6:\"margin\";i:5;s:4:\"move\";i:1;s:5:\"pager\";i:1;}'), 
(34, 'default', 'san-pham', 'global.block_product_center.php', 'Sản phẩm bán chạy', '', '', '[HOMEPRODUCT2]', 0, '1', 1, '6', 0, 1, 'a:3:{s:7:\"blockid\";i:2;s:6:\"numrow\";i:5;s:6:\"numget\";i:30;}'), 
(37, 'default', 'san-pham', 'global.block_bxproduct_center.php', 'Sản phẩm mới', '', 'panel_kengang', '[TOP]', 0, '1', 1, '6', 0, 3, 'a:10:{s:7:\"blockid\";i:1;s:6:\"numrow\";i:4;s:6:\"numget\";i:30;s:4:\"auto\";i:1;s:4:\"mode\";s:10:\"horizontal\";s:5:\"speed\";i:500;s:5:\"width\";i:250;s:6:\"margin\";i:0;s:4:\"move\";i:1;s:5:\"pager\";i:1;}'), 
(38, 'default', 'tin-tuc', 'global.block_groups.php', 'Tin tức - Bài viết', '', 'panel_kengang', '[BOTTOM]', 0, '1', 1, '6', 0, 1, 'a:6:{s:7:\"blockid\";i:1;s:6:\"numrow\";i:4;s:12:\"title_length\";i:0;s:11:\"showtooltip\";i:0;s:16:\"tooltip_position\";s:6:\"bottom\";s:14:\"tooltip_length\";s:3:\"120\";}'), 
(39, 'default', 'thong-tin', 'global.html.php', 'Phản hồi khách hàng', '', 'panel_phanhoi', '[BOTTOM]', 0, '1', 1, '6', 0, 2, 'a:1:{s:11:\"htmlcontent\";s:4:\"ewgf\";}'), 
(40, 'default', 'san-pham', 'global.block_catalogs.php', 'Danh mục sản phẩm', '', 'panel_sidebar', '[RIGHT]', 0, '1', 1, '6', 0, 1, 'a:1:{s:7:\"cut_num\";i:24;}'), 
(41, 'default', 'san-pham', 'global.block_cart.php', 'Giỏ hàng', '', 'no_title', '[HEADER_CART]', 0, '1', 1, '6', 0, 1, ''), 
(43, 'default', 'san-pham', 'global.block_relates_product.php', 'Sản phẩm mới', '', 'panel_kengang', '[RIGHT]', 0, '1', 1, '6', 1, 3, 'a:3:{s:7:\"blockid\";i:1;s:6:\"numrow\";i:5;s:7:\"cut_num\";i:24;}');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_blocks_weight`
--

DROP TABLE IF EXISTS `nv4_vi_blocks_weight`;
CREATE TABLE `nv4_vi_blocks_weight` (
  `bid` mediumint(9) NOT NULL DEFAULT '0',
  `func_id` mediumint(9) NOT NULL DEFAULT '0',
  `weight` mediumint(9) NOT NULL DEFAULT '0',
  UNIQUE KEY `bid` (`bid`,`func_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_blocks_weight`
--

INSERT INTO `nv4_vi_blocks_weight` VALUES
(1, 4, 1), 
(2, 4, 2), 
(3, 4, 1), 
(3, 5, 1), 
(3, 6, 1), 
(3, 7, 1), 
(3, 8, 1), 
(3, 9, 1), 
(3, 10, 1), 
(3, 11, 1), 
(3, 12, 1), 
(4, 20, 1), 
(4, 21, 1), 
(4, 22, 1), 
(4, 23, 1), 
(4, 24, 1), 
(4, 25, 1), 
(4, 26, 1), 
(4, 27, 1), 
(4, 28, 1), 
(4, 29, 1), 
(4, 30, 1), 
(4, 33, 1), 
(4, 34, 1), 
(4, 35, 1), 
(4, 36, 1), 
(4, 37, 1), 
(4, 38, 1), 
(4, 39, 1), 
(5, 1, 1), 
(5, 2, 1), 
(5, 3, 1), 
(5, 4, 2), 
(5, 5, 2), 
(5, 6, 2), 
(5, 7, 2), 
(5, 8, 2), 
(5, 9, 2), 
(5, 10, 2), 
(5, 11, 2), 
(5, 12, 2), 
(5, 13, 1), 
(5, 14, 1), 
(5, 15, 1), 
(5, 16, 1), 
(5, 17, 1), 
(5, 18, 1), 
(5, 19, 1), 
(5, 20, 2), 
(5, 21, 2), 
(5, 22, 2), 
(5, 23, 2), 
(5, 24, 2), 
(5, 25, 2), 
(5, 26, 2), 
(5, 27, 2), 
(5, 28, 2), 
(5, 29, 2), 
(5, 30, 2), 
(5, 31, 1), 
(5, 32, 1), 
(5, 33, 2), 
(5, 34, 2), 
(5, 35, 2), 
(5, 36, 2), 
(5, 37, 2), 
(5, 38, 2), 
(5, 39, 2), 
(5, 40, 1), 
(5, 41, 1), 
(5, 42, 1), 
(5, 43, 1), 
(5, 44, 1), 
(5, 45, 1), 
(5, 46, 1), 
(5, 47, 1), 
(5, 48, 1), 
(5, 49, 1), 
(5, 50, 1), 
(5, 51, 1), 
(5, 52, 1), 
(5, 53, 1), 
(5, 54, 1), 
(5, 55, 1), 
(5, 56, 1), 
(5, 57, 1), 
(5, 58, 1), 
(5, 59, 1), 
(5, 60, 1), 
(5, 61, 1), 
(5, 62, 1), 
(5, 63, 1), 
(5, 64, 1), 
(5, 65, 1), 
(6, 1, 2), 
(6, 2, 2), 
(6, 3, 2), 
(6, 4, 3), 
(6, 5, 3), 
(6, 6, 3), 
(6, 7, 3), 
(6, 8, 3), 
(6, 9, 3), 
(6, 10, 3), 
(6, 11, 3), 
(6, 12, 3), 
(6, 13, 2), 
(6, 14, 2), 
(6, 15, 2), 
(6, 16, 2), 
(6, 17, 2), 
(6, 18, 2), 
(6, 19, 2), 
(6, 20, 3), 
(6, 21, 3), 
(6, 22, 3), 
(6, 23, 3), 
(6, 24, 3), 
(6, 25, 3), 
(6, 26, 3), 
(6, 27, 3), 
(6, 28, 3), 
(6, 29, 3), 
(6, 30, 3), 
(6, 31, 2), 
(6, 32, 2), 
(6, 33, 3), 
(6, 34, 3), 
(6, 35, 3), 
(6, 36, 3), 
(6, 37, 3), 
(6, 38, 3), 
(6, 39, 3), 
(6, 40, 2), 
(6, 41, 2), 
(6, 42, 2), 
(6, 43, 2), 
(6, 44, 2), 
(6, 45, 2), 
(6, 46, 2), 
(6, 47, 2), 
(6, 48, 2), 
(6, 49, 2), 
(6, 50, 2), 
(6, 51, 2), 
(6, 52, 2), 
(6, 53, 2), 
(6, 54, 2), 
(6, 55, 2), 
(6, 56, 2), 
(6, 57, 2), 
(6, 58, 2), 
(6, 59, 2), 
(6, 60, 2), 
(6, 61, 2), 
(6, 62, 2), 
(6, 63, 2), 
(6, 64, 2), 
(6, 65, 2), 
(8, 20, 2), 
(8, 21, 2), 
(8, 22, 2), 
(8, 23, 2), 
(8, 24, 2), 
(8, 25, 2), 
(8, 26, 2), 
(8, 27, 2), 
(8, 28, 2), 
(8, 29, 2), 
(8, 30, 2), 
(8, 33, 2), 
(8, 34, 2), 
(8, 35, 2), 
(8, 36, 2), 
(8, 37, 2), 
(8, 38, 2), 
(8, 39, 2), 
(8, 40, 2), 
(8, 41, 2), 
(8, 42, 2), 
(8, 43, 2), 
(8, 44, 2), 
(8, 50, 2), 
(8, 51, 2), 
(8, 52, 2), 
(8, 55, 2), 
(8, 56, 2), 
(8, 57, 2), 
(8, 58, 2), 
(8, 59, 2), 
(8, 60, 2), 
(8, 61, 2), 
(8, 63, 2), 
(8, 64, 2), 
(8, 65, 2), 
(10, 20, 4), 
(10, 21, 4), 
(10, 22, 4), 
(10, 23, 4), 
(10, 24, 4), 
(10, 25, 4), 
(10, 26, 4), 
(10, 27, 4), 
(10, 28, 4), 
(10, 29, 4), 
(10, 30, 4), 
(10, 33, 4), 
(10, 34, 4), 
(10, 35, 4), 
(10, 36, 4), 
(10, 37, 4), 
(10, 38, 4), 
(10, 39, 4), 
(10, 40, 4), 
(10, 41, 4), 
(10, 42, 4), 
(10, 43, 4), 
(10, 44, 4), 
(10, 50, 4), 
(10, 51, 4), 
(10, 52, 4), 
(10, 55, 4), 
(10, 56, 4), 
(10, 57, 4), 
(10, 58, 4), 
(10, 59, 4), 
(10, 60, 4), 
(10, 61, 4), 
(10, 63, 4), 
(10, 64, 4), 
(10, 65, 4), 
(12, 1, 1), 
(12, 2, 1), 
(12, 3, 1), 
(12, 4, 1), 
(12, 5, 1), 
(12, 6, 1), 
(12, 7, 1), 
(12, 8, 1), 
(12, 9, 1), 
(12, 10, 1), 
(12, 11, 1), 
(12, 12, 1), 
(12, 13, 1), 
(12, 14, 1), 
(12, 15, 1), 
(12, 16, 1), 
(12, 17, 1), 
(12, 18, 1), 
(12, 19, 1), 
(12, 20, 1), 
(12, 21, 1), 
(12, 22, 1), 
(12, 23, 1), 
(12, 24, 1), 
(12, 25, 1), 
(12, 26, 1), 
(12, 27, 1), 
(12, 28, 1), 
(12, 29, 1), 
(12, 30, 1), 
(12, 31, 1), 
(12, 32, 1), 
(12, 33, 1), 
(12, 34, 1), 
(12, 35, 1), 
(12, 36, 1), 
(12, 37, 1), 
(12, 38, 1), 
(12, 39, 1), 
(12, 40, 1), 
(12, 41, 1), 
(12, 42, 1), 
(12, 43, 1), 
(12, 44, 1), 
(12, 45, 1), 
(12, 46, 1), 
(12, 47, 1), 
(12, 48, 1), 
(12, 49, 1), 
(12, 50, 1), 
(12, 51, 1), 
(12, 52, 1), 
(12, 53, 1), 
(12, 54, 1), 
(12, 55, 1), 
(12, 56, 1), 
(12, 57, 1), 
(12, 58, 1), 
(12, 59, 1), 
(12, 60, 1), 
(12, 61, 1), 
(12, 62, 1), 
(12, 63, 1), 
(12, 64, 1), 
(12, 65, 1), 
(16, 20, 1), 
(16, 21, 1), 
(16, 22, 1), 
(16, 23, 1), 
(16, 24, 1), 
(16, 25, 1), 
(16, 26, 1), 
(16, 27, 1), 
(16, 28, 1), 
(16, 29, 1), 
(16, 30, 1), 
(16, 33, 1), 
(16, 34, 1), 
(16, 35, 1), 
(16, 36, 1), 
(16, 37, 1), 
(16, 38, 1), 
(16, 39, 1), 
(16, 40, 1), 
(16, 41, 1), 
(16, 42, 1), 
(16, 43, 1), 
(16, 44, 1), 
(16, 50, 1), 
(16, 51, 1), 
(16, 52, 1), 
(16, 55, 1), 
(16, 56, 1), 
(16, 57, 1), 
(16, 58, 1), 
(16, 59, 1), 
(16, 60, 1), 
(16, 61, 1), 
(16, 63, 1), 
(16, 64, 1), 
(16, 65, 1), 
(17, 1, 1), 
(17, 2, 1), 
(17, 3, 1), 
(17, 4, 1), 
(17, 5, 1), 
(17, 6, 1), 
(17, 7, 1), 
(17, 8, 1), 
(17, 9, 1), 
(17, 10, 1), 
(17, 11, 1), 
(17, 12, 1), 
(17, 13, 1), 
(17, 14, 1), 
(17, 15, 1), 
(17, 16, 1), 
(17, 17, 1), 
(17, 18, 1), 
(17, 19, 1), 
(17, 20, 1), 
(17, 21, 1), 
(17, 22, 1), 
(17, 23, 1), 
(17, 24, 1), 
(17, 25, 1), 
(17, 26, 1), 
(17, 27, 1), 
(17, 28, 1), 
(17, 29, 1), 
(17, 30, 1), 
(17, 31, 1), 
(17, 32, 1), 
(17, 33, 1), 
(17, 34, 1), 
(17, 35, 1), 
(17, 36, 1), 
(17, 37, 1), 
(17, 38, 1), 
(17, 39, 1), 
(17, 40, 1), 
(17, 41, 1), 
(17, 42, 1), 
(17, 43, 1), 
(17, 44, 1), 
(17, 45, 1), 
(17, 46, 1), 
(17, 47, 1), 
(17, 48, 1), 
(17, 49, 1), 
(17, 50, 1), 
(17, 51, 1), 
(17, 52, 1), 
(17, 53, 1), 
(17, 54, 1), 
(17, 55, 1), 
(17, 56, 1), 
(17, 57, 1), 
(17, 58, 1), 
(17, 59, 1), 
(17, 60, 1), 
(17, 61, 1), 
(17, 62, 1), 
(17, 63, 1), 
(17, 64, 1), 
(17, 65, 1), 
(19, 20, 1), 
(19, 21, 1), 
(19, 22, 1), 
(19, 23, 1), 
(19, 24, 1), 
(19, 25, 1), 
(19, 26, 1), 
(19, 27, 1), 
(19, 28, 1), 
(19, 29, 1), 
(19, 30, 1), 
(19, 33, 1), 
(19, 34, 1), 
(19, 35, 1), 
(19, 36, 1), 
(19, 37, 1), 
(19, 38, 1), 
(19, 39, 1), 
(19, 40, 1), 
(19, 41, 1), 
(19, 42, 1), 
(19, 43, 1), 
(19, 44, 1), 
(19, 50, 1), 
(19, 51, 1), 
(19, 52, 1), 
(19, 55, 1), 
(19, 56, 1), 
(19, 57, 1), 
(19, 58, 1), 
(19, 59, 1), 
(19, 60, 1), 
(19, 61, 1), 
(19, 63, 1), 
(19, 64, 1), 
(19, 65, 1), 
(20, 1, 1), 
(20, 2, 1), 
(20, 3, 1), 
(20, 4, 1), 
(20, 5, 1), 
(20, 6, 1), 
(20, 7, 1), 
(20, 8, 1), 
(20, 9, 1), 
(20, 10, 1), 
(20, 11, 1), 
(20, 12, 1), 
(20, 13, 1), 
(20, 14, 1), 
(20, 15, 1), 
(20, 16, 1), 
(20, 17, 1), 
(20, 18, 1), 
(20, 19, 1), 
(20, 20, 1), 
(20, 21, 1), 
(20, 22, 1), 
(20, 23, 1), 
(20, 24, 1), 
(20, 25, 1), 
(20, 26, 1), 
(20, 27, 1), 
(20, 28, 1), 
(20, 29, 1), 
(20, 30, 1), 
(20, 31, 1), 
(20, 32, 1), 
(20, 33, 1), 
(20, 34, 1), 
(20, 35, 1), 
(20, 36, 1), 
(20, 37, 1), 
(20, 38, 1), 
(20, 39, 1), 
(20, 40, 1), 
(20, 41, 1), 
(20, 42, 1), 
(20, 43, 1), 
(20, 44, 1), 
(20, 45, 1), 
(20, 46, 1), 
(20, 47, 1), 
(20, 48, 1), 
(20, 49, 1), 
(20, 50, 1), 
(20, 51, 1), 
(20, 52, 1), 
(20, 53, 1), 
(20, 54, 1), 
(20, 55, 1), 
(20, 56, 1), 
(20, 57, 1), 
(20, 58, 1), 
(20, 59, 1), 
(20, 60, 1), 
(20, 61, 1), 
(20, 62, 1), 
(20, 63, 1), 
(20, 64, 1), 
(20, 65, 1), 
(21, 1, 1), 
(21, 2, 1), 
(21, 3, 1), 
(21, 4, 1), 
(21, 5, 1), 
(21, 6, 1), 
(21, 7, 1), 
(21, 8, 1), 
(21, 9, 1), 
(21, 10, 1), 
(21, 11, 1), 
(21, 12, 1), 
(21, 13, 1), 
(21, 14, 1), 
(21, 15, 1), 
(21, 16, 1), 
(21, 17, 1), 
(21, 18, 1), 
(21, 19, 1), 
(21, 20, 1), 
(21, 21, 1), 
(21, 22, 1), 
(21, 23, 1), 
(21, 24, 1), 
(21, 25, 1), 
(21, 26, 1), 
(21, 27, 1), 
(21, 28, 1), 
(21, 29, 1), 
(21, 30, 1), 
(21, 31, 1), 
(21, 32, 1), 
(21, 33, 1), 
(21, 34, 1), 
(21, 35, 1), 
(21, 36, 1), 
(21, 37, 1), 
(21, 38, 1), 
(21, 39, 1), 
(21, 40, 1), 
(21, 41, 1), 
(21, 42, 1), 
(21, 43, 1), 
(21, 44, 1), 
(21, 45, 1), 
(21, 46, 1), 
(21, 47, 1), 
(21, 48, 1), 
(21, 49, 1), 
(21, 50, 1), 
(21, 51, 1), 
(21, 52, 1), 
(21, 53, 1), 
(21, 54, 1), 
(21, 55, 1), 
(21, 56, 1), 
(21, 57, 1), 
(21, 58, 1), 
(21, 59, 1), 
(21, 60, 1), 
(21, 61, 1), 
(21, 62, 1), 
(21, 63, 1), 
(21, 64, 1), 
(21, 65, 1), 
(22, 1, 1), 
(22, 2, 1), 
(22, 3, 1), 
(22, 4, 1), 
(22, 5, 1), 
(22, 6, 1), 
(22, 7, 1), 
(22, 8, 1), 
(22, 9, 1), 
(22, 10, 1), 
(22, 11, 1), 
(22, 12, 1), 
(22, 13, 1), 
(22, 14, 1), 
(22, 15, 1), 
(22, 16, 1), 
(22, 17, 1), 
(22, 18, 1), 
(22, 19, 1), 
(22, 20, 1), 
(22, 21, 1), 
(22, 22, 1), 
(22, 23, 1), 
(22, 24, 1), 
(22, 25, 1), 
(22, 26, 1), 
(22, 27, 1), 
(22, 28, 1), 
(22, 29, 1), 
(22, 30, 1), 
(22, 31, 1), 
(22, 32, 1), 
(22, 33, 1), 
(22, 34, 1), 
(22, 35, 1), 
(22, 36, 1), 
(22, 37, 1), 
(22, 38, 1), 
(22, 39, 1), 
(22, 40, 1), 
(22, 41, 1), 
(22, 42, 1), 
(22, 43, 1), 
(22, 44, 1), 
(22, 45, 1), 
(22, 46, 1), 
(22, 47, 1), 
(22, 48, 1), 
(22, 49, 1), 
(22, 50, 1), 
(22, 51, 1), 
(22, 52, 1), 
(22, 53, 1), 
(22, 54, 1), 
(22, 55, 1), 
(22, 56, 1), 
(22, 57, 1), 
(22, 58, 1), 
(22, 59, 1), 
(22, 60, 1), 
(22, 61, 1), 
(22, 62, 1), 
(22, 63, 1), 
(22, 64, 1), 
(22, 65, 1), 
(23, 1, 2), 
(23, 2, 2), 
(23, 3, 2), 
(23, 4, 2), 
(23, 5, 2), 
(23, 6, 2), 
(23, 7, 2), 
(23, 8, 2), 
(23, 9, 2), 
(23, 10, 2), 
(23, 11, 2), 
(23, 12, 2), 
(23, 13, 2), 
(23, 14, 2), 
(23, 15, 2), 
(23, 16, 2), 
(23, 17, 2), 
(23, 18, 2), 
(23, 19, 2), 
(23, 20, 2), 
(23, 21, 2), 
(23, 22, 2), 
(23, 23, 2), 
(23, 24, 2), 
(23, 25, 2), 
(23, 26, 2), 
(23, 27, 2), 
(23, 28, 2), 
(23, 29, 2), 
(23, 30, 2), 
(23, 31, 2), 
(23, 32, 2), 
(23, 33, 2), 
(23, 34, 2), 
(23, 35, 2), 
(23, 36, 2), 
(23, 37, 2), 
(23, 38, 2), 
(23, 39, 2), 
(23, 40, 2), 
(23, 41, 2), 
(23, 42, 2), 
(23, 43, 2), 
(23, 44, 2), 
(23, 45, 2), 
(23, 46, 2), 
(23, 47, 2), 
(23, 48, 2), 
(23, 49, 2), 
(23, 50, 2), 
(23, 51, 2), 
(23, 52, 2), 
(23, 53, 2), 
(23, 54, 2), 
(23, 55, 2), 
(23, 56, 2), 
(23, 57, 2), 
(23, 58, 2), 
(23, 59, 2), 
(23, 60, 2), 
(23, 61, 2), 
(23, 62, 2), 
(23, 63, 2), 
(23, 64, 2), 
(23, 65, 2), 
(24, 1, 1), 
(24, 2, 1), 
(24, 3, 1), 
(24, 4, 1), 
(24, 5, 1), 
(24, 6, 1), 
(24, 7, 1), 
(24, 8, 1), 
(24, 9, 1), 
(24, 10, 1), 
(24, 11, 1), 
(24, 12, 1), 
(24, 13, 1), 
(24, 14, 1), 
(24, 15, 1), 
(24, 16, 1), 
(24, 17, 1), 
(24, 18, 1), 
(24, 19, 1), 
(24, 20, 1), 
(24, 21, 1), 
(24, 22, 1), 
(24, 23, 1), 
(24, 24, 1), 
(24, 25, 1), 
(24, 26, 1), 
(24, 27, 1), 
(24, 28, 1), 
(24, 29, 1), 
(24, 30, 1), 
(24, 31, 1), 
(24, 32, 1), 
(24, 33, 1), 
(24, 34, 1), 
(24, 35, 1), 
(24, 36, 1), 
(24, 37, 1), 
(24, 38, 1), 
(24, 39, 1), 
(24, 40, 1), 
(24, 41, 1), 
(24, 42, 1), 
(24, 43, 1), 
(24, 44, 1), 
(24, 45, 1), 
(24, 46, 1), 
(24, 47, 1), 
(24, 48, 1), 
(24, 49, 1), 
(24, 50, 1), 
(24, 51, 1), 
(24, 52, 1), 
(24, 53, 1), 
(24, 54, 1), 
(24, 55, 1), 
(24, 56, 1), 
(24, 57, 1), 
(24, 58, 1), 
(24, 59, 1), 
(24, 60, 1), 
(24, 61, 1), 
(24, 62, 1), 
(24, 63, 1), 
(24, 64, 1), 
(24, 65, 1), 
(25, 1, 2), 
(25, 2, 2), 
(25, 3, 2), 
(25, 4, 2), 
(25, 5, 2), 
(25, 6, 2), 
(25, 7, 2), 
(25, 8, 2), 
(25, 9, 2), 
(25, 10, 2), 
(25, 11, 2), 
(25, 12, 2), 
(25, 13, 2), 
(25, 14, 2), 
(25, 15, 2), 
(25, 16, 2), 
(25, 17, 2), 
(25, 18, 2), 
(25, 19, 2), 
(25, 20, 2), 
(25, 21, 2), 
(25, 22, 2), 
(25, 23, 2), 
(25, 24, 2), 
(25, 25, 2), 
(25, 26, 2), 
(25, 27, 2), 
(25, 28, 2), 
(25, 29, 2), 
(25, 30, 2), 
(25, 31, 2), 
(25, 32, 2), 
(25, 33, 2), 
(25, 34, 2), 
(25, 35, 2), 
(25, 36, 2), 
(25, 37, 2), 
(25, 38, 2), 
(25, 39, 2), 
(25, 40, 2), 
(25, 41, 2), 
(25, 42, 2), 
(25, 43, 2), 
(25, 44, 2), 
(25, 45, 2), 
(25, 46, 2), 
(25, 47, 2), 
(25, 48, 2), 
(25, 49, 2), 
(25, 50, 2), 
(25, 51, 2), 
(25, 52, 2), 
(25, 53, 2), 
(25, 54, 2), 
(25, 55, 2), 
(25, 56, 2), 
(25, 57, 2), 
(25, 58, 2), 
(25, 59, 2), 
(25, 60, 2), 
(25, 61, 2), 
(25, 62, 2), 
(25, 63, 2), 
(25, 64, 2), 
(25, 65, 2), 
(26, 1, 3), 
(26, 2, 3), 
(26, 3, 3), 
(26, 4, 3), 
(26, 5, 3), 
(26, 6, 3), 
(26, 7, 3), 
(26, 8, 3), 
(26, 9, 3), 
(26, 10, 3), 
(26, 11, 3), 
(26, 12, 3), 
(26, 13, 3), 
(26, 14, 3), 
(26, 15, 3), 
(26, 16, 3), 
(26, 17, 3), 
(26, 18, 3), 
(26, 19, 3), 
(26, 20, 3), 
(26, 21, 3), 
(26, 22, 3), 
(26, 23, 3), 
(26, 24, 3), 
(26, 25, 3), 
(26, 26, 3), 
(26, 27, 3), 
(26, 28, 3), 
(26, 29, 3), 
(26, 30, 3), 
(26, 31, 3), 
(26, 32, 3), 
(26, 33, 3), 
(26, 34, 3), 
(26, 35, 3), 
(26, 36, 3), 
(26, 37, 3), 
(26, 38, 3), 
(26, 39, 3), 
(26, 40, 3), 
(26, 41, 3), 
(26, 42, 3), 
(26, 43, 3), 
(26, 44, 3), 
(26, 45, 3), 
(26, 46, 3), 
(26, 47, 3), 
(26, 48, 3), 
(26, 49, 3), 
(26, 50, 3), 
(26, 51, 3), 
(26, 52, 3), 
(26, 53, 3), 
(26, 54, 3), 
(26, 55, 3), 
(26, 56, 3), 
(26, 57, 3), 
(26, 58, 3), 
(26, 59, 3), 
(26, 60, 3), 
(26, 61, 3), 
(26, 62, 3), 
(26, 63, 3), 
(26, 64, 3), 
(26, 65, 3), 
(27, 1, 4), 
(27, 2, 4), 
(27, 3, 4), 
(27, 4, 4), 
(27, 5, 4), 
(27, 6, 4), 
(27, 7, 4), 
(27, 8, 4), 
(27, 9, 4), 
(27, 10, 4), 
(27, 11, 4), 
(27, 12, 4), 
(27, 13, 4), 
(27, 14, 4), 
(27, 15, 4), 
(27, 16, 4), 
(27, 17, 4), 
(27, 18, 4), 
(27, 19, 4), 
(27, 20, 4), 
(27, 21, 4), 
(27, 22, 4), 
(27, 23, 4), 
(27, 24, 4), 
(27, 25, 4), 
(27, 26, 4), 
(27, 27, 4), 
(27, 28, 4), 
(27, 29, 4), 
(27, 30, 4), 
(27, 31, 4), 
(27, 32, 4), 
(27, 33, 4), 
(27, 34, 4), 
(27, 35, 4), 
(27, 36, 4), 
(27, 37, 4), 
(27, 38, 4), 
(27, 39, 4), 
(27, 40, 4), 
(27, 41, 4), 
(27, 42, 4), 
(27, 43, 4), 
(27, 44, 4), 
(27, 45, 4), 
(27, 46, 4), 
(27, 47, 4), 
(27, 48, 4), 
(27, 49, 4), 
(27, 50, 4), 
(27, 51, 4), 
(27, 52, 4), 
(27, 53, 4), 
(27, 54, 4), 
(27, 55, 4), 
(27, 56, 4), 
(27, 57, 4), 
(27, 58, 4), 
(27, 59, 4), 
(27, 60, 4), 
(27, 61, 4), 
(27, 62, 4), 
(27, 63, 4), 
(27, 64, 4), 
(27, 65, 4), 
(28, 1, 1), 
(28, 2, 1), 
(28, 3, 1), 
(28, 4, 1), 
(28, 5, 1), 
(28, 6, 1), 
(28, 7, 1), 
(28, 8, 1), 
(28, 9, 1), 
(28, 10, 1), 
(28, 11, 1), 
(28, 12, 1), 
(28, 13, 1), 
(28, 14, 1), 
(28, 15, 1), 
(28, 16, 1), 
(28, 17, 1), 
(28, 18, 1), 
(28, 19, 1), 
(28, 20, 1), 
(28, 21, 1), 
(28, 22, 1), 
(28, 23, 1), 
(28, 24, 1), 
(28, 25, 1), 
(28, 26, 1), 
(28, 27, 1), 
(28, 28, 1), 
(28, 29, 1), 
(28, 30, 1), 
(28, 31, 1), 
(28, 32, 1), 
(28, 33, 1), 
(28, 34, 1), 
(28, 35, 1), 
(28, 36, 1), 
(28, 37, 1), 
(28, 38, 1), 
(28, 39, 1), 
(28, 40, 1), 
(28, 41, 1), 
(28, 42, 1), 
(28, 43, 1), 
(28, 44, 1), 
(28, 45, 1), 
(28, 46, 1), 
(28, 47, 1), 
(28, 48, 1), 
(28, 49, 1), 
(28, 50, 1), 
(28, 51, 1), 
(28, 52, 1), 
(28, 53, 1), 
(28, 54, 1), 
(28, 55, 1), 
(28, 56, 1), 
(28, 57, 1), 
(28, 58, 1), 
(28, 59, 1), 
(28, 60, 1), 
(28, 61, 1), 
(28, 62, 1), 
(28, 63, 1), 
(28, 64, 1), 
(28, 65, 1), 
(29, 1, 1), 
(29, 2, 1), 
(29, 3, 1), 
(29, 4, 1), 
(29, 5, 1), 
(29, 6, 1), 
(29, 7, 1), 
(29, 8, 1), 
(29, 9, 1), 
(29, 10, 1), 
(29, 11, 1), 
(29, 12, 1), 
(29, 13, 1), 
(29, 14, 1), 
(29, 15, 1), 
(29, 16, 1), 
(29, 17, 1), 
(29, 18, 1), 
(29, 19, 1), 
(29, 20, 1), 
(29, 21, 1), 
(29, 22, 1), 
(29, 23, 1), 
(29, 24, 1), 
(29, 25, 1), 
(29, 26, 1), 
(29, 27, 1), 
(29, 28, 1), 
(29, 29, 1), 
(29, 30, 1), 
(29, 31, 1), 
(29, 32, 1), 
(29, 33, 1), 
(29, 34, 1), 
(29, 35, 1), 
(29, 36, 1), 
(29, 37, 1), 
(29, 38, 1), 
(29, 39, 1), 
(29, 40, 1), 
(29, 41, 1), 
(29, 42, 1), 
(29, 43, 1), 
(29, 44, 1), 
(29, 45, 1), 
(29, 46, 1), 
(29, 47, 1), 
(29, 48, 1), 
(29, 49, 1), 
(29, 50, 1), 
(29, 51, 1), 
(29, 52, 1), 
(29, 53, 1), 
(29, 54, 1), 
(29, 55, 1), 
(29, 56, 1), 
(29, 57, 1), 
(29, 58, 1), 
(29, 59, 1), 
(29, 60, 1), 
(29, 61, 1), 
(29, 62, 1), 
(29, 63, 1), 
(29, 64, 1), 
(29, 65, 1), 
(30, 1, 1), 
(30, 2, 1), 
(30, 3, 1), 
(30, 4, 1), 
(30, 5, 1), 
(30, 6, 1), 
(30, 7, 1), 
(30, 8, 1), 
(30, 9, 1), 
(30, 10, 1), 
(30, 11, 1), 
(30, 12, 1), 
(30, 13, 1), 
(30, 14, 1), 
(30, 15, 1), 
(30, 16, 1), 
(30, 17, 1), 
(30, 18, 1), 
(30, 19, 1), 
(30, 20, 1), 
(30, 21, 1), 
(30, 22, 1), 
(30, 23, 1), 
(30, 24, 1), 
(30, 25, 1), 
(30, 26, 1), 
(30, 27, 1), 
(30, 28, 1), 
(30, 29, 1), 
(30, 30, 1), 
(30, 31, 1), 
(30, 32, 1), 
(30, 33, 1), 
(30, 34, 1), 
(30, 35, 1), 
(30, 36, 1), 
(30, 37, 1), 
(30, 38, 1), 
(30, 39, 1), 
(30, 40, 1), 
(30, 41, 1), 
(30, 42, 1), 
(30, 43, 1), 
(30, 44, 1), 
(30, 45, 1), 
(30, 46, 1), 
(30, 47, 1), 
(30, 48, 1), 
(30, 49, 1), 
(30, 50, 1), 
(30, 51, 1), 
(30, 52, 1), 
(30, 53, 1), 
(30, 54, 1), 
(30, 55, 1), 
(30, 56, 1), 
(30, 57, 1), 
(30, 58, 1), 
(30, 59, 1), 
(30, 60, 1), 
(30, 61, 1), 
(30, 62, 1), 
(30, 63, 1), 
(30, 64, 1), 
(30, 65, 1), 
(16, 77, 1), 
(16, 92, 1), 
(16, 72, 1), 
(16, 86, 1), 
(16, 68, 1), 
(16, 78, 1), 
(16, 79, 1), 
(16, 75, 1), 
(16, 74, 1), 
(16, 70, 1), 
(16, 93, 1), 
(16, 91, 1), 
(16, 80, 1), 
(16, 89, 1), 
(16, 73, 1), 
(16, 67, 1), 
(16, 66, 1), 
(21, 77, 1), 
(21, 92, 1), 
(21, 72, 1), 
(21, 86, 1), 
(21, 68, 1), 
(21, 78, 1), 
(21, 79, 1), 
(21, 75, 1), 
(21, 74, 1), 
(21, 70, 1), 
(21, 93, 1), 
(21, 91, 1), 
(21, 80, 1), 
(21, 89, 1), 
(21, 73, 1), 
(21, 67, 1), 
(21, 66, 1), 
(12, 77, 1), 
(12, 92, 1), 
(12, 72, 1), 
(12, 86, 1), 
(12, 68, 1), 
(12, 78, 1), 
(12, 79, 1), 
(12, 75, 1), 
(12, 74, 1), 
(12, 70, 1), 
(12, 93, 1), 
(12, 91, 1), 
(12, 80, 1), 
(12, 89, 1), 
(12, 73, 1), 
(12, 67, 1), 
(12, 66, 1), 
(5, 77, 1), 
(5, 92, 1), 
(5, 72, 1), 
(5, 86, 1), 
(5, 68, 1), 
(5, 78, 1), 
(5, 79, 1), 
(5, 75, 1), 
(5, 74, 1), 
(5, 70, 1), 
(5, 93, 1), 
(5, 91, 1), 
(5, 80, 1), 
(5, 89, 1), 
(5, 73, 1), 
(5, 67, 1), 
(5, 66, 1), 
(6, 77, 2), 
(6, 92, 2), 
(6, 72, 2), 
(6, 86, 2), 
(6, 68, 2), 
(6, 78, 2), 
(6, 79, 2), 
(6, 75, 2), 
(6, 74, 2), 
(6, 70, 2), 
(6, 93, 2), 
(6, 91, 2), 
(6, 80, 2), 
(6, 89, 2), 
(6, 73, 2), 
(6, 67, 2), 
(6, 66, 2), 
(20, 77, 1), 
(20, 92, 1), 
(20, 72, 1), 
(20, 86, 1), 
(20, 68, 1), 
(20, 78, 1), 
(20, 79, 1), 
(20, 75, 1), 
(20, 74, 1), 
(20, 70, 1), 
(20, 93, 1), 
(20, 91, 1), 
(20, 80, 1), 
(20, 89, 1), 
(20, 73, 1), 
(20, 67, 1), 
(20, 66, 1), 
(17, 77, 1), 
(17, 92, 1), 
(17, 72, 1), 
(17, 86, 1), 
(17, 68, 1), 
(17, 78, 1), 
(17, 79, 1), 
(17, 75, 1), 
(17, 74, 1), 
(17, 70, 1), 
(17, 93, 1), 
(17, 91, 1), 
(17, 80, 1), 
(17, 89, 1), 
(17, 73, 1), 
(17, 67, 1), 
(17, 66, 1), 
(8, 77, 1), 
(8, 92, 2), 
(8, 72, 2), 
(8, 86, 2), 
(8, 68, 2), 
(8, 78, 2), 
(8, 79, 2), 
(8, 75, 2), 
(8, 74, 2), 
(8, 70, 2), 
(8, 93, 2), 
(8, 91, 2), 
(8, 80, 2), 
(8, 89, 2), 
(8, 73, 2), 
(8, 67, 2), 
(8, 66, 2), 
(10, 77, 3), 
(10, 92, 4), 
(10, 72, 4), 
(10, 86, 4), 
(10, 68, 4), 
(10, 78, 4), 
(10, 79, 4), 
(10, 75, 4), 
(10, 74, 4), 
(10, 70, 4), 
(10, 93, 4), 
(10, 91, 4), 
(10, 80, 4), 
(10, 89, 4), 
(10, 73, 4), 
(10, 67, 4), 
(10, 66, 4), 
(19, 77, 1), 
(19, 92, 1), 
(19, 72, 1), 
(19, 86, 1), 
(19, 68, 1), 
(19, 78, 1), 
(19, 79, 1), 
(19, 75, 1), 
(19, 74, 1), 
(19, 70, 1), 
(19, 93, 1), 
(19, 91, 1), 
(19, 80, 1), 
(19, 89, 1), 
(19, 73, 1), 
(19, 67, 1), 
(19, 66, 1), 
(30, 77, 1), 
(30, 92, 1), 
(30, 72, 1), 
(30, 86, 1), 
(30, 68, 1), 
(30, 78, 1), 
(30, 79, 1), 
(30, 75, 1), 
(30, 74, 1), 
(30, 70, 1), 
(30, 93, 1), 
(30, 91, 1), 
(30, 80, 1), 
(30, 89, 1), 
(30, 73, 1), 
(30, 67, 1), 
(30, 66, 1), 
(28, 77, 1), 
(28, 92, 1), 
(28, 72, 1), 
(28, 86, 1), 
(28, 68, 1), 
(28, 78, 1), 
(28, 79, 1), 
(28, 75, 1), 
(28, 74, 1), 
(28, 70, 1), 
(28, 93, 1), 
(28, 91, 1), 
(28, 80, 1), 
(28, 89, 1), 
(28, 73, 1), 
(28, 67, 1), 
(28, 66, 1), 
(29, 77, 1), 
(29, 92, 1), 
(29, 72, 1), 
(29, 86, 1), 
(29, 68, 1), 
(29, 78, 1), 
(29, 79, 1), 
(29, 75, 1), 
(29, 74, 1), 
(29, 70, 1), 
(29, 93, 1), 
(29, 91, 1), 
(29, 80, 1), 
(29, 89, 1), 
(29, 73, 1), 
(29, 67, 1), 
(29, 66, 1), 
(22, 77, 1), 
(22, 92, 1), 
(22, 72, 1), 
(22, 86, 1), 
(22, 68, 1), 
(22, 78, 1), 
(22, 79, 1), 
(22, 75, 1), 
(22, 74, 1), 
(22, 70, 1), 
(22, 93, 1), 
(22, 91, 1), 
(22, 80, 1), 
(22, 89, 1), 
(22, 73, 1), 
(22, 67, 1), 
(22, 66, 1), 
(23, 77, 2), 
(23, 92, 2), 
(23, 72, 2), 
(23, 86, 2), 
(23, 68, 2), 
(23, 78, 2), 
(23, 79, 2), 
(23, 75, 2), 
(23, 74, 2), 
(23, 70, 2), 
(23, 93, 2), 
(23, 91, 2), 
(23, 80, 2), 
(23, 89, 2), 
(23, 73, 2), 
(23, 67, 2), 
(23, 66, 2), 
(24, 77, 1), 
(24, 92, 1), 
(24, 72, 1), 
(24, 86, 1), 
(24, 68, 1), 
(24, 78, 1), 
(24, 79, 1), 
(24, 75, 1), 
(24, 74, 1), 
(24, 70, 1), 
(24, 93, 1), 
(24, 91, 1), 
(24, 80, 1), 
(24, 89, 1), 
(24, 73, 1), 
(24, 67, 1), 
(24, 66, 1), 
(25, 77, 2), 
(25, 92, 2), 
(25, 72, 2), 
(25, 86, 2), 
(25, 68, 2), 
(25, 78, 2), 
(25, 79, 2), 
(25, 75, 2), 
(25, 74, 2), 
(25, 70, 2), 
(25, 93, 2), 
(25, 91, 2), 
(25, 80, 2), 
(25, 89, 2), 
(25, 73, 2), 
(25, 67, 2), 
(25, 66, 2), 
(26, 77, 3), 
(26, 92, 3), 
(26, 72, 3), 
(26, 86, 3), 
(26, 68, 3), 
(26, 78, 3), 
(26, 79, 3), 
(26, 75, 3), 
(26, 74, 3), 
(26, 70, 3), 
(26, 93, 3), 
(26, 91, 3), 
(26, 80, 3), 
(26, 89, 3), 
(26, 73, 3), 
(26, 67, 3), 
(26, 66, 3), 
(27, 77, 4), 
(27, 92, 4), 
(27, 72, 4), 
(27, 86, 4), 
(27, 68, 4), 
(27, 78, 4), 
(27, 79, 4), 
(27, 75, 4), 
(27, 74, 4), 
(27, 70, 4), 
(27, 93, 4), 
(27, 91, 4), 
(27, 80, 4), 
(27, 89, 4), 
(27, 73, 4), 
(27, 67, 4), 
(27, 66, 4), 
(16, 95, 1), 
(16, 96, 1), 
(21, 95, 1), 
(21, 96, 1), 
(12, 95, 1), 
(12, 96, 1), 
(5, 95, 1), 
(5, 96, 1), 
(6, 95, 2), 
(6, 96, 2), 
(20, 95, 1), 
(20, 96, 1), 
(17, 95, 1), 
(17, 96, 1), 
(8, 95, 2), 
(8, 96, 2), 
(10, 95, 4), 
(10, 96, 4), 
(19, 95, 1), 
(19, 96, 1), 
(30, 95, 1), 
(30, 96, 1), 
(28, 95, 1), 
(28, 96, 1), 
(29, 95, 1), 
(29, 96, 1), 
(22, 95, 1), 
(22, 96, 1), 
(23, 95, 2), 
(23, 96, 2), 
(24, 95, 1), 
(24, 96, 1), 
(25, 95, 2), 
(25, 96, 2), 
(26, 95, 3), 
(26, 96, 3), 
(27, 95, 4), 
(27, 96, 4), 
(16, 98, 1), 
(21, 98, 1), 
(12, 98, 1), 
(5, 98, 1), 
(6, 98, 2), 
(20, 98, 1), 
(17, 98, 1), 
(8, 98, 2), 
(10, 98, 4), 
(19, 98, 1), 
(30, 98, 1), 
(28, 98, 1), 
(29, 98, 1), 
(22, 98, 1), 
(23, 98, 2), 
(24, 98, 1), 
(25, 98, 2), 
(26, 98, 3), 
(27, 98, 4), 
(16, 104, 1), 
(16, 114, 1), 
(16, 113, 1), 
(16, 102, 1), 
(16, 99, 1), 
(16, 101, 1), 
(16, 109, 1), 
(16, 100, 1), 
(16, 112, 1), 
(16, 107, 1), 
(21, 104, 1), 
(21, 114, 1), 
(21, 113, 1), 
(21, 102, 1), 
(21, 99, 1), 
(21, 101, 1), 
(21, 109, 1), 
(21, 100, 1), 
(21, 112, 1), 
(21, 107, 1), 
(12, 104, 1), 
(12, 114, 1), 
(12, 113, 1), 
(12, 102, 1), 
(12, 99, 1), 
(12, 101, 1), 
(12, 109, 1), 
(12, 100, 1), 
(12, 112, 1), 
(12, 107, 1), 
(5, 104, 1), 
(5, 114, 1), 
(5, 113, 1), 
(5, 102, 1), 
(5, 99, 1), 
(5, 101, 1), 
(5, 109, 1), 
(5, 100, 1), 
(5, 112, 1), 
(5, 107, 1), 
(6, 104, 2), 
(6, 114, 2), 
(6, 113, 2), 
(6, 102, 2), 
(6, 99, 2), 
(6, 101, 2), 
(6, 109, 2), 
(6, 100, 2), 
(6, 112, 2), 
(6, 107, 2), 
(20, 104, 1), 
(20, 114, 1), 
(20, 113, 1), 
(20, 102, 1), 
(20, 99, 1), 
(20, 101, 1), 
(20, 109, 1), 
(20, 100, 1), 
(20, 112, 1), 
(20, 107, 1), 
(17, 104, 1), 
(17, 114, 1), 
(17, 113, 1), 
(17, 102, 1), 
(17, 99, 1), 
(17, 101, 1), 
(17, 109, 1), 
(17, 100, 1), 
(17, 112, 1), 
(17, 107, 1), 
(8, 104, 2), 
(8, 114, 2), 
(8, 113, 2), 
(8, 102, 2), 
(8, 99, 2), 
(8, 101, 2), 
(8, 109, 2), 
(8, 100, 2), 
(8, 112, 2), 
(8, 107, 2), 
(10, 104, 4), 
(10, 114, 4), 
(10, 113, 4), 
(10, 102, 4), 
(10, 99, 4), 
(10, 101, 4), 
(10, 109, 4), 
(10, 100, 4), 
(10, 112, 4), 
(10, 107, 4), 
(19, 104, 1), 
(19, 114, 1), 
(19, 113, 1), 
(19, 102, 1), 
(19, 99, 1), 
(19, 101, 1), 
(19, 109, 1), 
(19, 100, 1), 
(19, 112, 1), 
(19, 107, 1), 
(30, 104, 1), 
(30, 114, 1), 
(30, 113, 1), 
(30, 102, 1), 
(30, 99, 1), 
(30, 101, 1), 
(30, 109, 1), 
(30, 100, 1), 
(30, 112, 1), 
(30, 107, 1), 
(28, 104, 1), 
(28, 114, 1), 
(28, 113, 1), 
(28, 102, 1), 
(28, 99, 1), 
(28, 101, 1), 
(28, 109, 1), 
(28, 100, 1), 
(28, 112, 1), 
(28, 107, 1), 
(29, 104, 1), 
(29, 114, 1), 
(29, 113, 1), 
(29, 102, 1), 
(29, 99, 1), 
(29, 101, 1), 
(29, 109, 1), 
(29, 100, 1), 
(29, 112, 1), 
(29, 107, 1), 
(22, 104, 1), 
(22, 114, 1), 
(22, 113, 1), 
(22, 102, 1), 
(22, 99, 1), 
(22, 101, 1), 
(22, 109, 1), 
(22, 100, 1), 
(22, 112, 1), 
(22, 107, 1), 
(23, 104, 2), 
(23, 114, 2), 
(23, 113, 2), 
(23, 102, 2), 
(23, 99, 2), 
(23, 101, 2), 
(23, 109, 2), 
(23, 100, 2), 
(23, 112, 2), 
(23, 107, 2), 
(24, 104, 1), 
(24, 114, 1), 
(24, 113, 1), 
(24, 102, 1), 
(24, 99, 1), 
(24, 101, 1), 
(24, 109, 1), 
(24, 100, 1), 
(24, 112, 1), 
(24, 107, 1), 
(25, 104, 2), 
(25, 114, 2), 
(25, 113, 2), 
(25, 102, 2), 
(25, 99, 2), 
(25, 101, 2), 
(25, 109, 2), 
(25, 100, 2), 
(25, 112, 2), 
(25, 107, 2), 
(26, 104, 3), 
(26, 114, 3), 
(26, 113, 3), 
(26, 102, 3), 
(26, 99, 3), 
(26, 101, 3), 
(26, 109, 3), 
(26, 100, 3), 
(26, 112, 3), 
(26, 107, 3), 
(27, 104, 4), 
(27, 114, 4), 
(27, 113, 4), 
(27, 102, 4), 
(27, 99, 4), 
(27, 101, 4), 
(27, 109, 4), 
(27, 100, 4), 
(27, 112, 4), 
(27, 107, 4), 
(16, 115, 1), 
(16, 116, 1), 
(21, 115, 1), 
(21, 116, 1), 
(12, 115, 1), 
(12, 116, 1), 
(5, 115, 1), 
(5, 116, 1), 
(6, 115, 2), 
(6, 116, 2), 
(20, 115, 1), 
(20, 116, 1), 
(17, 115, 1), 
(17, 116, 1), 
(8, 115, 2), 
(8, 116, 2), 
(10, 115, 4), 
(10, 116, 4), 
(19, 115, 1), 
(19, 116, 1), 
(30, 115, 1), 
(30, 116, 1), 
(28, 115, 1), 
(28, 116, 1), 
(29, 115, 1), 
(29, 116, 1), 
(22, 115, 1), 
(22, 116, 1), 
(23, 115, 2), 
(23, 116, 2), 
(24, 115, 1), 
(24, 116, 1), 
(25, 115, 2), 
(25, 116, 2), 
(26, 115, 3), 
(26, 116, 3), 
(27, 115, 4), 
(27, 116, 4), 
(21, 118, 1), 
(21, 119, 1), 
(12, 118, 1), 
(12, 119, 1), 
(5, 118, 1), 
(5, 119, 1), 
(6, 118, 2), 
(6, 119, 2), 
(20, 118, 1), 
(20, 119, 1), 
(17, 118, 1), 
(17, 119, 1), 
(40, 68, 1), 
(40, 86, 1), 
(40, 72, 1), 
(40, 92, 1), 
(40, 96, 1), 
(40, 95, 1), 
(30, 118, 1), 
(30, 119, 1), 
(28, 118, 1), 
(28, 119, 1), 
(29, 118, 1), 
(29, 119, 1), 
(22, 118, 1), 
(22, 119, 1), 
(23, 118, 2), 
(23, 119, 2), 
(24, 118, 1), 
(24, 119, 1), 
(25, 118, 2), 
(25, 119, 2), 
(26, 118, 3), 
(26, 119, 3), 
(27, 118, 4), 
(27, 119, 4), 
(31, 118, 1), 
(31, 119, 1), 
(32, 95, 1), 
(32, 96, 1), 
(32, 77, 1), 
(32, 92, 1), 
(32, 72, 1), 
(32, 86, 1), 
(32, 68, 1), 
(32, 78, 1), 
(32, 79, 1), 
(32, 75, 1), 
(32, 74, 1), 
(32, 70, 1), 
(32, 93, 1), 
(32, 91, 1), 
(32, 80, 1), 
(32, 89, 1), 
(32, 73, 1), 
(32, 67, 1), 
(32, 66, 1), 
(32, 104, 1), 
(32, 114, 1), 
(32, 113, 1), 
(32, 102, 1), 
(32, 99, 1), 
(32, 101, 1), 
(32, 109, 1), 
(32, 100, 1), 
(32, 112, 1), 
(32, 107, 1), 
(32, 98, 1), 
(32, 115, 1), 
(32, 116, 1), 
(32, 20, 1), 
(32, 21, 1), 
(32, 22, 1), 
(32, 23, 1), 
(32, 24, 1), 
(32, 25, 1), 
(32, 26, 1), 
(32, 27, 1), 
(32, 28, 1), 
(32, 29, 1), 
(32, 30, 1), 
(32, 33, 1), 
(32, 34, 1), 
(32, 35, 1), 
(32, 36, 1), 
(32, 37, 1), 
(32, 38, 1), 
(32, 39, 1), 
(32, 40, 1), 
(32, 41, 1), 
(32, 42, 1), 
(32, 43, 1), 
(32, 44, 1), 
(32, 50, 1), 
(32, 51, 1), 
(32, 52, 1), 
(32, 55, 1), 
(32, 56, 1), 
(32, 57, 1), 
(32, 58, 1), 
(32, 59, 1), 
(32, 60, 1), 
(32, 61, 1), 
(32, 63, 1), 
(32, 64, 1), 
(32, 65, 1), 
(33, 118, 1), 
(33, 119, 1), 
(34, 118, 1), 
(34, 119, 1), 
(31, 77, 1), 
(37, 77, 1), 
(38, 77, 1), 
(39, 77, 2), 
(40, 78, 1), 
(40, 79, 1), 
(40, 75, 1), 
(40, 74, 1), 
(40, 70, 1), 
(40, 93, 1), 
(40, 91, 1), 
(40, 80, 1), 
(40, 89, 1), 
(40, 73, 1), 
(40, 67, 1), 
(40, 66, 1), 
(40, 104, 1), 
(40, 114, 1), 
(40, 113, 1), 
(40, 102, 1), 
(40, 99, 1), 
(40, 101, 1), 
(40, 109, 1), 
(40, 100, 1), 
(40, 112, 1), 
(40, 107, 1), 
(40, 98, 1), 
(40, 115, 1), 
(40, 116, 1), 
(40, 20, 1), 
(40, 21, 1), 
(40, 22, 1), 
(40, 23, 1), 
(40, 24, 1), 
(40, 25, 1), 
(40, 26, 1), 
(40, 27, 1), 
(40, 28, 1), 
(40, 29, 1), 
(40, 30, 1), 
(40, 33, 1), 
(40, 34, 1), 
(40, 35, 1), 
(40, 36, 1), 
(40, 37, 1), 
(40, 38, 1), 
(40, 39, 1), 
(40, 40, 1), 
(40, 41, 1), 
(40, 42, 1), 
(40, 43, 1), 
(40, 44, 1), 
(40, 50, 1), 
(40, 51, 1), 
(40, 52, 1), 
(40, 55, 1), 
(40, 56, 1), 
(40, 57, 1), 
(40, 58, 1), 
(40, 59, 1), 
(40, 60, 1), 
(40, 61, 1), 
(40, 63, 1), 
(40, 64, 1), 
(40, 65, 1), 
(41, 95, 1), 
(41, 96, 1), 
(41, 77, 1), 
(41, 92, 1), 
(41, 72, 1), 
(41, 86, 1), 
(41, 68, 1), 
(41, 78, 1), 
(41, 79, 1), 
(41, 75, 1), 
(41, 74, 1), 
(41, 70, 1), 
(41, 93, 1), 
(41, 91, 1), 
(41, 80, 1), 
(41, 89, 1), 
(41, 73, 1), 
(41, 67, 1), 
(41, 66, 1), 
(41, 104, 1), 
(41, 114, 1), 
(41, 113, 1), 
(41, 102, 1), 
(41, 99, 1), 
(41, 101, 1), 
(41, 109, 1), 
(41, 100, 1), 
(41, 112, 1), 
(41, 107, 1), 
(41, 98, 1), 
(41, 115, 1), 
(41, 116, 1), 
(41, 20, 1), 
(41, 21, 1), 
(41, 22, 1), 
(41, 23, 1), 
(41, 24, 1), 
(41, 25, 1), 
(41, 26, 1), 
(41, 27, 1), 
(41, 28, 1), 
(41, 29, 1), 
(41, 30, 1), 
(41, 33, 1), 
(41, 34, 1), 
(41, 35, 1), 
(41, 36, 1), 
(41, 37, 1), 
(41, 38, 1), 
(41, 39, 1), 
(41, 40, 1), 
(41, 41, 1), 
(41, 42, 1), 
(41, 43, 1), 
(41, 44, 1), 
(41, 50, 1), 
(41, 51, 1), 
(41, 52, 1), 
(41, 55, 1), 
(41, 56, 1), 
(41, 57, 1), 
(41, 58, 1), 
(41, 59, 1), 
(41, 60, 1), 
(41, 61, 1), 
(41, 63, 1), 
(41, 64, 1), 
(41, 65, 1), 
(43, 95, 3), 
(43, 96, 3), 
(43, 77, 2), 
(43, 92, 3), 
(43, 72, 3), 
(43, 86, 3), 
(43, 68, 3), 
(43, 78, 3), 
(43, 79, 3), 
(43, 75, 3), 
(43, 74, 3), 
(43, 70, 3), 
(43, 93, 3), 
(43, 91, 3), 
(43, 80, 3), 
(43, 89, 3), 
(43, 73, 3), 
(43, 67, 3), 
(43, 66, 3), 
(43, 104, 3), 
(43, 114, 3), 
(43, 113, 3), 
(43, 102, 3), 
(43, 99, 3), 
(43, 101, 3), 
(43, 109, 3), 
(43, 100, 3), 
(43, 112, 3), 
(43, 107, 3), 
(43, 98, 3), 
(43, 115, 3), 
(43, 116, 3), 
(43, 20, 3), 
(43, 21, 3), 
(43, 22, 3), 
(43, 23, 3), 
(43, 24, 3), 
(43, 25, 3), 
(43, 26, 3), 
(43, 27, 3), 
(43, 28, 3), 
(43, 29, 3), 
(43, 30, 3), 
(43, 33, 3), 
(43, 34, 3), 
(43, 35, 3), 
(43, 36, 3), 
(43, 37, 3), 
(43, 38, 3), 
(43, 39, 3), 
(43, 40, 3), 
(43, 41, 3), 
(43, 42, 3), 
(43, 43, 3), 
(43, 44, 3), 
(43, 50, 3), 
(43, 51, 3), 
(43, 52, 3), 
(43, 55, 3), 
(43, 56, 3), 
(43, 57, 3), 
(43, 58, 3), 
(43, 59, 3), 
(43, 60, 3), 
(43, 61, 3), 
(43, 63, 3), 
(43, 64, 3), 
(43, 65, 3), 
(8, 1, 1), 
(8, 32, 1), 
(8, 4, 1), 
(8, 5, 1), 
(8, 6, 1), 
(8, 7, 1), 
(8, 8, 1), 
(8, 9, 1), 
(8, 10, 1), 
(8, 11, 1), 
(8, 12, 1), 
(8, 13, 1), 
(19, 1, 1), 
(19, 32, 1), 
(19, 4, 1), 
(19, 5, 1), 
(19, 6, 1), 
(19, 7, 1), 
(19, 8, 1), 
(19, 9, 1), 
(19, 10, 1), 
(19, 11, 1), 
(19, 12, 1), 
(19, 13, 1), 
(43, 1, 2), 
(43, 32, 2), 
(43, 4, 2), 
(43, 5, 2), 
(43, 6, 2), 
(43, 7, 2), 
(43, 8, 2), 
(43, 9, 2), 
(43, 10, 2), 
(43, 11, 2), 
(43, 12, 2), 
(43, 13, 2);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_comment`
--

DROP TABLE IF EXISTS `nv4_vi_comment`;
CREATE TABLE `nv4_vi_comment` (
  `cid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `area` int(11) NOT NULL DEFAULT '0',
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `pid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `attach` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_time` int(10) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `post_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_ip` varchar(39)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `likes` mediumint(9) NOT NULL DEFAULT '0',
  `dislikes` mediumint(9) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `mod_id` (`module`,`area`,`id`),
  KEY `post_time` (`post_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_contact_department`
--

DROP TABLE IF EXISTS `nv4_vi_contact_department`;
CREATE TABLE `nv4_vi_contact_department` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `phone` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `fax` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `others` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `cats` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `admins` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `act` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `weight` smallint(6) NOT NULL,
  `is_default` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `full_name` (`full_name`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_contact_department`
--

INSERT INTO `nv4_vi_contact_department` VALUES
(1, 'Phòng Chăm sóc khách hàng', 'Cham-soc-khach-hang', '', '(08) 38.000.000[+84838000000]', '08 38.000.001', 'customer@mysite.com', '', 'Bộ phận tiếp nhận và giải quyết các yêu cầu, đề nghị, ý kiến liên quan đến hoạt động chính của doanh nghiệp', '{\"viber\":\"myViber\",\"skype\":\"mySkype\",\"yahoo\":\"myYahoo\"}', 'Tư vấn|Khiếu nại, phản ánh|Đề nghị hợp tác', '1/1/1/0;', 1, 1, 1), 
(2, 'Phòng Kỹ thuật', 'Ky-thuat', '', '(08) 38.000.002[+84838000002]', '08 38.000.003', 'technical@mysite.com', '', 'Bộ phận tiếp nhận và giải quyết các câu hỏi liên quan đến kỹ thuật', '{\"viber\":\"myViber2\",\"skype\":\"mySkype2\",\"yahoo\":\"myYahoo2\"}', 'Thông báo lỗi|Góp ý cải tiến', '1/1/1/0;', 1, 2, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_contact_reply`
--

DROP TABLE IF EXISTS `nv4_vi_contact_reply`;
CREATE TABLE `nv4_vi_contact_reply` (
  `rid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `reply_content` text  COLLATE utf8mb4_unicode_ci,
  `reply_time` int(10) unsigned NOT NULL DEFAULT '0',
  `reply_aid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`rid`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_contact_send`
--

DROP TABLE IF EXISTS `nv4_vi_contact_send`;
CREATE TABLE `nv4_vi_contact_send` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `cat` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `send_time` int(10) unsigned NOT NULL DEFAULT '0',
  `sender_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `sender_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_address` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_phone` varchar(20)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sender_ip` varchar(39)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `is_read` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `is_reply` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `is_processed` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `processed_by` int(10) unsigned NOT NULL DEFAULT '0',
  `processed_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sender_name` (`sender_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_contact_supporter`
--

DROP TABLE IF EXISTS `nv4_vi_contact_supporter`;
CREATE TABLE `nv4_vi_contact_supporter` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `departmentid` smallint(5) unsigned NOT NULL,
  `full_name` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `phone` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `others` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `act` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `weight` smallint(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_freecontent_blocks`
--

DROP TABLE IF EXISTS `nv4_vi_freecontent_blocks`;
CREATE TABLE `nv4_vi_freecontent_blocks` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`bid`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_freecontent_blocks`
--

INSERT INTO `nv4_vi_freecontent_blocks` VALUES
(1, 'Sản phẩm', 'Sản phẩm của công ty cổ phần phát triển nguồn mở Việt Nam - VINADES.,JSC');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_freecontent_rows`
--

DROP TABLE IF EXISTS `nv4_vi_freecontent_rows`;
CREATE TABLE `nv4_vi_freecontent_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `bid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `target` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '_blank|_self|_parent|_top',
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `start_time` int(11) NOT NULL DEFAULT '0',
  `end_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0: In-Active, 1: Active, 2: Expired',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_freecontent_rows`
--

INSERT INTO `nv4_vi_freecontent_rows` VALUES
(1, 1, 'Hệ quản trị nội dung NukeViet', '<ul>
	<li>Giải thưởng Nhân tài đất Việt 2011, 10.000+ website đang sử dụng</li>
	<li>Được Bộ GD&amp;ĐT khuyến khích sử dụng trong các cơ sở giáo dục</li>
	<li>Bộ TT&amp;TT quy định ưu tiên sử dụng trong cơ quan nhà nước</li>
</ul>', 'http://vinades.vn/vi/san-pham/nukeviet/', '_blank', 'cms.jpg', 1712405092, 0, 1), 
(2, 1, 'Cổng thông tin doanh nghiệp', '<ul>
	<li>Tích hợp bán hàng trực tuyến</li>
	<li>Tích hợp các nghiệp vụ quản lý (quản lý khách hàng, quản lý nhân sự, quản lý tài liệu)</li>
</ul>', 'http://vinades.vn/vi/san-pham/Cong-thong-tin-doanh-nghiep-NukeViet-portal/', '_blank', 'portal.jpg', 1712405092, 0, 1), 
(3, 1, 'Cổng thông tin Phòng giáo dục, Sở giáo dục', '<ul>
	<li>Tích hợp chung website hàng trăm trường</li>
	<li>Tích hợp các ứng dụng trực tuyến (Tra điểm SMS, Tra cứu văn bằng, Học bạ điện tử ...)</li>
</ul>', 'http://vinades.vn/vi/san-pham/Cong-thong-tin-giao-duc-NukeViet-Edugate/', '_blank', 'edugate.jpg', 1712405092, 0, 1), 
(4, 1, 'Tòa soạn báo điện tử chuyên nghiệp', '<ul>
	<li>Bảo mật đa tầng, phân quyền linh hoạt</li>
	<li>Hệ thống bóc tin tự động, đăng bài tự động, cùng nhiều chức năng tiên tiến khác...</li>
</ul>', 'http://vinades.vn/vi/san-pham/Toa-soan-bao-dien-tu/', '_blank', 'toa-soan-dien-tu.jpg', 1712405092, 0, 1), 
(5, 1, 'Giải pháp bán hàng trực tuyến', '<ul><li>Tích hợp các tính năng cơ bản bán hàng trực tuyến</li><li>Tích hợp với các cổng thanh toán, ví điện tử trên toàn quốc</li></ul>', 'http://vinades.vn', '_blank', 'shop.jpg', 1712405092, 0, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_gioi_thieu`
--

DROP TABLE IF EXISTS `nv4_vi_gioi_thieu`;
CREATE TABLE `nv4_vi_gioi_thieu` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imagealt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imageposition` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `bodytext` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `layout_func` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` smallint(6) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hot_post` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_gioi_thieu_config`
--

DROP TABLE IF EXISTS `nv4_vi_gioi_thieu_config`;
CREATE TABLE `nv4_vi_gioi_thieu_config` (
  `config_name` varchar(30)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_gioi_thieu_config`
--

INSERT INTO `nv4_vi_gioi_thieu_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '20'), 
('news_first', '0'), 
('related_articles', '5'), 
('copy_page', '0'), 
('alias_lower', '1'), 
('socialbutton', 'facebook,twitter');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_lien_he_department`
--

DROP TABLE IF EXISTS `nv4_vi_lien_he_department`;
CREATE TABLE `nv4_vi_lien_he_department` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `phone` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `fax` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `others` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `cats` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `admins` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `act` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `weight` smallint(6) NOT NULL,
  `is_default` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `full_name` (`full_name`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_lien_he_reply`
--

DROP TABLE IF EXISTS `nv4_vi_lien_he_reply`;
CREATE TABLE `nv4_vi_lien_he_reply` (
  `rid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `reply_content` text  COLLATE utf8mb4_unicode_ci,
  `reply_time` int(10) unsigned NOT NULL DEFAULT '0',
  `reply_aid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`rid`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_lien_he_send`
--

DROP TABLE IF EXISTS `nv4_vi_lien_he_send`;
CREATE TABLE `nv4_vi_lien_he_send` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `cat` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `send_time` int(10) unsigned NOT NULL DEFAULT '0',
  `sender_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `sender_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_address` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_phone` varchar(20)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sender_ip` varchar(39)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `is_read` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `is_reply` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `is_processed` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `processed_by` int(10) unsigned NOT NULL DEFAULT '0',
  `processed_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sender_name` (`sender_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_lien_he_supporter`
--

DROP TABLE IF EXISTS `nv4_vi_lien_he_supporter`;
CREATE TABLE `nv4_vi_lien_he_supporter` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `departmentid` smallint(5) unsigned NOT NULL,
  `full_name` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `phone` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `others` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `act` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `weight` smallint(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_menu`
--

DROP TABLE IF EXISTS `nv4_vi_menu`;
CREATE TABLE `nv4_vi_menu` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_menu`
--

INSERT INTO `nv4_vi_menu` VALUES
(1, 'Top Menu');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_menu_rows`
--

DROP TABLE IF EXISTS `nv4_vi_menu_rows`;
CREATE TABLE `nv4_vi_menu_rows` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL,
  `mid` smallint(6) NOT NULL DEFAULT '0',
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `note` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` int(11) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  `lev` int(11) NOT NULL DEFAULT '0',
  `subitem` text  COLLATE utf8mb4_unicode_ci,
  `groups_view` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `module_name` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `op` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `target` tinyint(4) DEFAULT '0',
  `css` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `active_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parentid` (`parentid`,`mid`)
) ENGINE=MyISAM  AUTO_INCREMENT=35  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_menu_rows`
--

INSERT INTO `nv4_vi_menu_rows` VALUES
(1, 0, 1, 'Giới thiệu', '/index.php?language=vi&nv=gioi-thieu', '', '', '', 1, 1, 0, '', '6', 'gioi-thieu', '', 1, '', 0, 1), 
(2, 0, 1, 'Tin tức', '/index.php?language=vi&nv=tin-tuc', '', '', '', 2, 2, 0, '28,29,30', '6', 'tin-tuc', '', 1, '', 0, 1), 
(25, 0, 1, 'Cửa hàng', '/index.php?language=vi&nv=thong-tin&op=danh-sach-dai-ly.html', '', '', '', 4, 10, 0, '', '6', 'thong-tin', 'danh-sach-dai-ly.html', 1, '', 0, 1), 
(31, 0, 1, 'Đăng ký đại lý', '/index.php?language=vi&nv=thong-tin&op=dang-ky-dai-ly.html', '', '', '', 5, 11, 0, '', '6', 'thong-tin', '', 1, '', 0, 1), 
(23, 0, 1, 'Sản phẩm', '/index.php?language=vi&nv=san-pham', '', '', '', 3, 6, 0, '32,33,34', '6', 'san-pham', '', 1, '', 0, 1), 
(32, 23, 1, 'Chè dùng thử', '/index.php?language=vi&nv=san-pham&op=che-dung-thu', '', '', '', 1, 7, 1, '', '6', 'san-pham', '', 1, '', 0, 1), 
(26, 0, 1, 'Kiến thức', '/index.php?language=vi&nv=tin-tuc&op=kien-thuc', '', '', '', 6, 12, 0, '', '6', 'tin-tuc', 'kien-thuc', 1, '', 0, 1), 
(28, 2, 1, 'Tin nội bộ', '/index.php?language=vi&nv=tin-tuc&op=tin-noi-bo', '', '', '', 1, 3, 1, '', '6', 'tin-tuc', '', 1, '', 0, 1), 
(29, 2, 1, 'Tin hoạt động', '/index.php?language=vi&nv=tin-tuc&op=tin-hoat-dong', '', '', '', 2, 4, 1, '', '6', 'tin-tuc', '', 1, '', 0, 1), 
(30, 2, 1, 'Ngành chè', '/index.php?language=vi&nv=tin-tuc&op=nganh-che', '', '', '', 3, 5, 1, '', '6', 'tin-tuc', '', 1, '', 0, 1), 
(33, 23, 1, 'Chè Móc câu', '/index.php?language=vi&nv=san-pham&op=che-moc-cau', '', '', '', 2, 8, 1, '', '6', 'san-pham', '', 1, '', 0, 1), 
(34, 23, 1, 'Chè Tôm nõn', '/index.php?language=vi&nv=san-pham&op=che-tom-non', '', '', '', 3, 9, 1, '', '6', 'san-pham', '', 1, '', 0, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_modfuncs`
--

DROP TABLE IF EXISTS `nv4_vi_modfuncs`;
CREATE TABLE `nv4_vi_modfuncs` (
  `func_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `func_name` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `func_custom_name` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `func_site_title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `in_module` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `show_func` tinyint(4) NOT NULL DEFAULT '0',
  `in_submenu` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `subweight` smallint(5) unsigned NOT NULL DEFAULT '1',
  `setting` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`func_id`),
  UNIQUE KEY `func_name` (`func_name`,`in_module`),
  UNIQUE KEY `alias` (`alias`,`in_module`)
) ENGINE=MyISAM  AUTO_INCREMENT=121  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_modfuncs`
--

INSERT INTO `nv4_vi_modfuncs` VALUES
(1, 'main', 'main', 'Main', '', 'about', 1, 0, 1, ''), 
(2, 'sitemap', 'sitemap', 'Sitemap', '', 'about', 0, 0, 0, ''), 
(3, 'rss', 'rss', 'Rss', '', 'about', 0, 0, 0, ''), 
(4, 'main', 'main', 'Main', '', 'news', 1, 0, 1, ''), 
(5, 'viewcat', 'viewcat', 'Viewcat', '', 'news', 1, 0, 2, ''), 
(6, 'topic', 'topic', 'Topic', '', 'news', 1, 0, 3, ''), 
(7, 'content', 'content', 'Content', '', 'news', 1, 1, 4, ''), 
(8, 'detail', 'detail', 'Detail', '', 'news', 1, 0, 5, ''), 
(9, 'tag', 'tag', 'Tag', '', 'news', 1, 0, 6, ''), 
(10, 'rss', 'rss', 'Rss', '', 'news', 1, 1, 7, ''), 
(11, 'search', 'search', 'Search', '', 'news', 1, 1, 8, ''), 
(12, 'groups', 'groups', 'Groups', '', 'news', 1, 0, 9, ''), 
(13, 'author', 'author', 'Author', '', 'news', 1, 0, 10, ''), 
(14, 'sitemap', 'sitemap', 'Sitemap', '', 'news', 0, 0, 0, ''), 
(15, 'print', 'print', 'Print', '', 'news', 0, 0, 0, ''), 
(16, 'rating', 'rating', 'Rating', '', 'news', 0, 0, 0, ''), 
(17, 'savefile', 'savefile', 'Savefile', '', 'news', 0, 0, 0, ''), 
(18, 'sendmail', 'sendmail', 'Sendmail', '', 'news', 0, 0, 0, ''), 
(19, 'instant-rss', 'instant-rss', 'Instant Articles RSS', '', 'news', 0, 0, 0, ''), 
(20, 'main', 'main', 'Main', '', 'users', 1, 0, 1, ''), 
(21, 'login', 'login', 'Đăng nhập', '', 'users', 1, 1, 2, ''), 
(22, 'register', 'register', 'Đăng ký', '', 'users', 1, 1, 3, ''), 
(23, 'lostpass', 'lostpass', 'Khôi phục mật khẩu', '', 'users', 1, 1, 4, ''), 
(24, 'active', 'active', 'Kích hoạt tài khoản', '', 'users', 1, 0, 5, ''), 
(25, 'lostactivelink', 'lostactivelink', 'Lostactivelink', '', 'users', 1, 0, 6, ''), 
(26, 'editinfo', 'editinfo', 'Thiết lập tài khoản', '', 'users', 1, 1, 7, ''), 
(27, 'memberlist', 'memberlist', 'Danh sách thành viên', '', 'users', 1, 1, 8, ''), 
(28, 'groups', 'groups', 'Quản lý nhóm', '', 'users', 1, 1, 9, ''), 
(29, 'avatar', 'avatar', 'Avatar', '', 'users', 1, 0, 10, ''), 
(30, 'logout', 'logout', 'Thoát', '', 'users', 1, 1, 11, ''), 
(31, 'oauth', 'oauth', 'Oauth', '', 'users', 0, 0, 0, ''), 
(32, 'main', 'main', 'Main', '', 'contact', 1, 0, 1, ''), 
(33, 'main', 'main', 'Main', '', 'statistics', 1, 0, 1, ''), 
(34, 'allreferers', 'allreferers', 'Theo đường dẫn đến site', '', 'statistics', 1, 1, 2, ''), 
(35, 'allcountries', 'allcountries', 'Theo quốc gia', '', 'statistics', 1, 1, 3, ''), 
(36, 'allbrowsers', 'allbrowsers', 'Theo trình duyệt', '', 'statistics', 1, 1, 4, ''), 
(37, 'allos', 'allos', 'Theo hệ điều hành', '', 'statistics', 1, 1, 5, ''), 
(38, 'allbots', 'allbots', 'Theo máy chủ tìm kiếm', '', 'statistics', 1, 1, 6, ''), 
(39, 'referer', 'referer', 'Đường dẫn đến site theo tháng', '', 'statistics', 1, 0, 7, ''), 
(40, 'main', 'main', 'Main', '', 'voting', 1, 0, 1, ''), 
(41, 'main', 'main', 'Main', '', 'banners', 1, 0, 1, ''), 
(42, 'addads', 'addads', 'Addads', '', 'banners', 1, 0, 2, ''), 
(43, 'clientinfo', 'clientinfo', 'Clientinfo', '', 'banners', 1, 0, 3, ''), 
(44, 'stats', 'stats', 'Stats', '', 'banners', 1, 0, 4, ''), 
(45, 'cledit', 'cledit', 'Cledit', '', 'banners', 0, 0, 0, ''), 
(46, 'click', 'click', 'Click', '', 'banners', 0, 0, 0, ''), 
(47, 'clinfo', 'clinfo', 'Clinfo', '', 'banners', 0, 0, 0, ''), 
(48, 'logininfo', 'logininfo', 'Logininfo', '', 'banners', 0, 0, 0, ''), 
(49, 'viewmap', 'viewmap', 'Viewmap', '', 'banners', 0, 0, 0, ''), 
(50, 'main', 'main', 'Main', '', 'seek', 1, 0, 1, ''), 
(51, 'main', 'main', 'Main', '', 'feeds', 1, 0, 1, ''), 
(52, 'main', 'main', 'Main', '', 'page', 1, 0, 1, ''), 
(53, 'sitemap', 'sitemap', 'Sitemap', '', 'page', 0, 0, 0, ''), 
(54, 'rss', 'rss', 'Rss', '', 'page', 0, 0, 0, ''), 
(55, 'main', 'main', 'Main', '', 'comment', 1, 0, 1, ''), 
(56, 'post', 'post', 'Post', '', 'comment', 1, 0, 2, ''), 
(57, 'like', 'like', 'Like', '', 'comment', 1, 0, 3, ''), 
(58, 'delete', 'delete', 'Delete', '', 'comment', 1, 0, 4, ''), 
(59, 'down', 'down', 'Down', '', 'comment', 1, 0, 5, ''), 
(60, 'main', 'main', 'Main', '', 'siteterms', 1, 0, 1, ''), 
(61, 'rss', 'rss', 'Rss', '', 'siteterms', 1, 0, 2, ''), 
(62, 'sitemap', 'sitemap', 'Sitemap', '', 'siteterms', 0, 0, 0, ''), 
(63, 'main', 'main', 'Main', '', 'two-step-verification', 1, 0, 1, ''), 
(64, 'confirm', 'confirm', 'Confirm', '', 'two-step-verification', 1, 0, 2, ''), 
(65, 'setup', 'setup', 'Setup', '', 'two-step-verification', 1, 0, 3, ''), 
(66, 'ajax', 'ajax', 'Ajax', '', 'san-pham', 1, 0, 17, ''), 
(67, 'blockcat', 'blockcat', 'Blockcat', '', 'san-pham', 1, 0, 16, ''), 
(68, 'cart', 'cart', 'Cart', '', 'san-pham', 1, 0, 5, ''), 
(69, 'checkorder', 'checkorder', 'Checkorder', '', 'san-pham', 0, 0, 0, ''), 
(70, 'compare', 'compare', 'Compare', '', 'san-pham', 1, 0, 10, ''), 
(71, 'delhis', 'delhis', 'Delhis', '', 'san-pham', 0, 0, 0, ''), 
(72, 'detail', 'detail', 'Detail', '', 'san-pham', 1, 0, 3, ''), 
(73, 'download', 'download', 'Download', '', 'san-pham', 1, 0, 15, ''), 
(74, 'group', 'group', 'Group', '', 'san-pham', 1, 0, 9, ''), 
(75, 'history', 'history', 'History', '', 'san-pham', 1, 0, 8, ''), 
(76, 'loadcart', 'loadcart', 'Loadcart', '', 'san-pham', 0, 0, 0, ''), 
(77, 'main', 'main', 'Main', '', 'san-pham', 1, 0, 1, ''), 
(78, 'order', 'order', 'Order', '', 'san-pham', 1, 0, 6, ''), 
(79, 'payment', 'payment', 'Payment', '', 'san-pham', 1, 0, 7, ''), 
(80, 'point', 'point', 'Point', '', 'san-pham', 1, 0, 13, ''), 
(81, 'print', 'print', 'Print', '', 'san-pham', 0, 0, 0, ''), 
(82, 'print_pro', 'print_pro', 'Print_pro', '', 'san-pham', 0, 0, 0, ''), 
(83, 'remove', 'remove', 'Remove', '', 'san-pham', 0, 0, 0, ''), 
(84, 'review', 'review', 'Review', '', 'san-pham', 0, 0, 0, ''), 
(85, 'rss', 'rss', 'Rss', '', 'san-pham', 0, 0, 0, ''), 
(86, 'search', 'search', 'Search', '', 'san-pham', 1, 0, 4, ''), 
(87, 'sendmail', 'sendmail', 'Sendmail', '', 'san-pham', 0, 0, 0, ''), 
(88, 'setcart', 'setcart', 'Setcart', '', 'san-pham', 0, 0, 0, ''), 
(89, 'shippingajax', 'shippingajax', 'Shippingajax', '', 'san-pham', 1, 0, 14, ''), 
(90, 'sitemap', 'sitemap', 'Sitemap', '', 'san-pham', 0, 0, 0, ''), 
(91, 'tag', 'tag', 'Tag', '', 'san-pham', 1, 0, 12, ''), 
(92, 'viewcat', 'viewcat', 'Viewcat', '', 'san-pham', 1, 0, 2, ''), 
(93, 'wishlist', 'wishlist', 'Wishlist', '', 'san-pham', 1, 0, 11, ''), 
(94, 'wishlist_update', 'wishlist_update', 'Wishlist_update', '', 'san-pham', 0, 0, 0, ''), 
(95, 'main', 'main', 'Main', '', 'gioi-thieu', 1, 0, 1, ''), 
(96, 'rss', 'rss', 'Rss', '', 'gioi-thieu', 1, 0, 2, ''), 
(97, 'sitemap', 'sitemap', 'Sitemap', '', 'gioi-thieu', 0, 0, 0, ''), 
(98, 'main', 'main', 'Main', '', 'lien-he', 1, 0, 1, ''), 
(99, 'author', 'author', 'Author', '', 'tin-tuc', 1, 0, 5, ''), 
(100, 'content', 'content', 'Content', '', 'tin-tuc', 1, 1, 8, ''), 
(101, 'detail', 'detail', 'Detail', '', 'tin-tuc', 1, 0, 6, ''), 
(102, 'groups', 'groups', 'Groups', '', 'tin-tuc', 1, 0, 4, ''), 
(103, 'instant-rss', 'instant-rss', 'Instant-rss', '', 'tin-tuc', 0, 0, 0, ''), 
(104, 'main', 'main', 'Main', '', 'tin-tuc', 1, 0, 1, ''), 
(105, 'print', 'print', 'Print', '', 'tin-tuc', 0, 0, 0, ''), 
(106, 'rating', 'rating', 'Rating', '', 'tin-tuc', 0, 0, 0, ''), 
(107, 'rss', 'rss', 'Rss', '', 'tin-tuc', 1, 1, 10, ''), 
(108, 'savefile', 'savefile', 'Savefile', '', 'tin-tuc', 0, 0, 0, ''), 
(109, 'search', 'search', 'Search', '', 'tin-tuc', 1, 1, 7, ''), 
(110, 'sendmail', 'sendmail', 'Sendmail', '', 'tin-tuc', 0, 0, 0, ''), 
(111, 'sitemap', 'sitemap', 'Sitemap', '', 'tin-tuc', 0, 0, 0, ''), 
(112, 'tag', 'tag', 'Tag', '', 'tin-tuc', 1, 0, 9, ''), 
(113, 'topic', 'topic', 'Topic', '', 'tin-tuc', 1, 0, 3, ''), 
(114, 'viewcat', 'viewcat', 'Viewcat', '', 'tin-tuc', 1, 0, 2, ''), 
(115, 'main', 'main', 'Main', '', 'thong-tin', 1, 0, 1, ''), 
(116, 'rss', 'rss', 'Rss', '', 'thong-tin', 1, 0, 2, ''), 
(117, 'sitemap', 'sitemap', 'Sitemap', '', 'thong-tin', 0, 0, 0, '');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_modthemes`
--

DROP TABLE IF EXISTS `nv4_vi_modthemes`;
CREATE TABLE `nv4_vi_modthemes` (
  `func_id` mediumint(9) DEFAULT NULL,
  `layout` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  UNIQUE KEY `func_id` (`func_id`,`layout`,`theme`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_modthemes`
--

INSERT INTO `nv4_vi_modthemes` VALUES
(0, 'left-main-right', 'default'), 
(0, 'main', 'mobile_default'), 
(1, 'main', 'mobile_default'), 
(1, 'main-right', 'default'), 
(4, 'main', 'mobile_default'), 
(4, 'main-right', 'default'), 
(5, 'main', 'mobile_default'), 
(5, 'main-right', 'default'), 
(6, 'main', 'mobile_default'), 
(6, 'main-right', 'default'), 
(7, 'main', 'mobile_default'), 
(7, 'main-right', 'default'), 
(8, 'main', 'mobile_default'), 
(8, 'main-right', 'default'), 
(9, 'main', 'mobile_default'), 
(9, 'main-right', 'default'), 
(10, 'main-right', 'default'), 
(11, 'main', 'mobile_default'), 
(11, 'main-right', 'default'), 
(12, 'main', 'mobile_default'), 
(12, 'main-right', 'default'), 
(13, 'main', 'mobile_default'), 
(13, 'main-right', 'default'), 
(20, 'main', 'mobile_default'), 
(20, 'main-right', 'default'), 
(21, 'main', 'mobile_default'), 
(21, 'main-right', 'default'), 
(22, 'main', 'mobile_default'), 
(22, 'main-right', 'default'), 
(23, 'main', 'mobile_default'), 
(23, 'main-right', 'default'), 
(24, 'main', 'mobile_default'), 
(24, 'main-right', 'default'), 
(25, 'main', 'mobile_default'), 
(25, 'main-right', 'default'), 
(26, 'main', 'mobile_default'), 
(26, 'main-right', 'default'), 
(27, 'main', 'mobile_default'), 
(27, 'main-right', 'default'), 
(28, 'main', 'mobile_default'), 
(28, 'main-right', 'default'), 
(29, 'main-right', 'default'), 
(30, 'main', 'mobile_default'), 
(30, 'main-right', 'default'), 
(32, 'main', 'mobile_default'), 
(32, 'main-right', 'default'), 
(33, 'main', 'mobile_default'), 
(33, 'main-right', 'default'), 
(34, 'main', 'mobile_default'), 
(34, 'main-right', 'default'), 
(35, 'main', 'mobile_default'), 
(35, 'main-right', 'default'), 
(36, 'main', 'mobile_default'), 
(36, 'main-right', 'default'), 
(37, 'main', 'mobile_default'), 
(37, 'main-right', 'default'), 
(38, 'main', 'mobile_default'), 
(38, 'main-right', 'default'), 
(39, 'main', 'mobile_default'), 
(39, 'main-right', 'default'), 
(40, 'main', 'mobile_default'), 
(40, 'main-right', 'default'), 
(41, 'main', 'mobile_default'), 
(41, 'main-right', 'default'), 
(42, 'main', 'mobile_default'), 
(42, 'main-right', 'default'), 
(43, 'main', 'mobile_default'), 
(43, 'main-right', 'default'), 
(44, 'main', 'mobile_default'), 
(44, 'main-right', 'default'), 
(50, 'main', 'mobile_default'), 
(50, 'main-right', 'default'), 
(51, 'main', 'mobile_default'), 
(51, 'main-right', 'default'), 
(52, 'main', 'mobile_default'), 
(52, 'main-right', 'default'), 
(55, 'main', 'mobile_default'), 
(55, 'main-right', 'default'), 
(56, 'main', 'mobile_default'), 
(56, 'main-right', 'default'), 
(57, 'main', 'mobile_default'), 
(57, 'main-right', 'default'), 
(58, 'main', 'mobile_default'), 
(58, 'main-right', 'default'), 
(59, 'main-right', 'default'), 
(60, 'main', 'mobile_default'), 
(60, 'main-right', 'default'), 
(61, 'main', 'mobile_default'), 
(61, 'main-right', 'default'), 
(63, 'main', 'mobile_default'), 
(63, 'main-right', 'default'), 
(64, 'main', 'mobile_default'), 
(64, 'main-right', 'default'), 
(65, 'main', 'mobile_default'), 
(65, 'main-right', 'default'), 
(66, 'main', 'mobile_default'), 
(66, 'main-right', 'default'), 
(67, 'main', 'mobile_default'), 
(67, 'main-right', 'default'), 
(68, 'main', 'mobile_default'), 
(68, 'main-right', 'default'), 
(69, 'left-main-right', 'default'), 
(70, 'main', 'mobile_default'), 
(70, 'main-right', 'default'), 
(71, 'left-main-right', 'default'), 
(72, 'main', 'mobile_default'), 
(72, 'main-right', 'default'), 
(73, 'main', 'mobile_default'), 
(73, 'main-right', 'default'), 
(74, 'main', 'mobile_default'), 
(74, 'main-right', 'default'), 
(75, 'main', 'mobile_default'), 
(75, 'main-right', 'default'), 
(76, 'left-main-right', 'default'), 
(77, 'main', 'mobile_default'), 
(77, 'main-homepage', 'default'), 
(78, 'main', 'mobile_default'), 
(78, 'main-right', 'default'), 
(79, 'main', 'mobile_default'), 
(79, 'main-right', 'default'), 
(80, 'main', 'mobile_default'), 
(80, 'main-right', 'default'), 
(81, 'left-main-right', 'default'), 
(82, 'left-main-right', 'default'), 
(83, 'left-main-right', 'default'), 
(84, 'left-main-right', 'default'), 
(85, 'left-main-right', 'default'), 
(86, 'main', 'mobile_default'), 
(86, 'main-right', 'default'), 
(87, 'left-main-right', 'default'), 
(88, 'left-main-right', 'default'), 
(89, 'main', 'mobile_default'), 
(89, 'main-right', 'default'), 
(90, 'left-main-right', 'default'), 
(91, 'main', 'mobile_default'), 
(91, 'main-right', 'default'), 
(92, 'main', 'default'), 
(92, 'main', 'mobile_default'), 
(93, 'main', 'mobile_default'), 
(93, 'main-right', 'default'), 
(94, 'left-main-right', 'default'), 
(95, 'main', 'mobile_default'), 
(95, 'main-right', 'default'), 
(96, 'main', 'mobile_default'), 
(96, 'main-right', 'default'), 
(97, 'left-main-right', 'default'), 
(98, 'main', 'mobile_default'), 
(98, 'main-right', 'default'), 
(99, 'main', 'mobile_default'), 
(99, 'main-right', 'default'), 
(100, 'main', 'mobile_default'), 
(100, 'main-right', 'default'), 
(101, 'main', 'mobile_default'), 
(101, 'main-right', 'default'), 
(102, 'main', 'mobile_default'), 
(102, 'main-right', 'default'), 
(103, 'left-main-right', 'default'), 
(104, 'main', 'mobile_default'), 
(104, 'main-right', 'default'), 
(105, 'left-main-right', 'default'), 
(106, 'left-main-right', 'default'), 
(107, 'main', 'mobile_default'), 
(107, 'main-right', 'default'), 
(108, 'left-main-right', 'default'), 
(109, 'main', 'mobile_default'), 
(109, 'main-right', 'default'), 
(110, 'left-main-right', 'default'), 
(111, 'left-main-right', 'default'), 
(112, 'main', 'mobile_default'), 
(112, 'main-right', 'default'), 
(113, 'main', 'mobile_default'), 
(113, 'main-right', 'default'), 
(114, 'main', 'mobile_default'), 
(114, 'main-right', 'default'), 
(115, 'main', 'mobile_default'), 
(115, 'main-right', 'default'), 
(116, 'main', 'mobile_default'), 
(116, 'main-right', 'default'), 
(117, 'left-main-right', 'default');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_modules`
--

DROP TABLE IF EXISTS `nv4_vi_modules`;
CREATE TABLE `nv4_vi_modules` (
  `title` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `module_file` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `module_data` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `module_upload` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `module_theme` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `custom_title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `site_title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `admin_title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `set_time` int(10) unsigned NOT NULL DEFAULT '0',
  `main_file` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `admin_file` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `theme` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `mobile` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `groups_view` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `act` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `admins` varchar(4000)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `rss` tinyint(4) NOT NULL DEFAULT '1',
  `sitemap` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_modules`
--

INSERT INTO `nv4_vi_modules` VALUES
('about', 'page', 'about', 'about', 'page', 'Giới thiệu', '', '', 1712405092, 1, 1, '', '', '', '', '6', 6, 0, '', 1, 1), 
('news', 'news', 'news', 'news', 'news', 'Tin Tức', '', '', 1712405092, 1, 1, '', '', '', '', '6', 7, 0, '', 1, 1), 
('users', 'users', 'users', 'users', 'users', 'Thành viên', '', 'Tài khoản', 1712405092, 1, 1, '', '', '', '', '6', 8, 1, '', 0, 1), 
('contact', 'contact', 'contact', 'contact', 'contact', 'Liên hệ', '', '', 1712405092, 1, 1, '', '', '', '', '6', 9, 0, '', 0, 1), 
('statistics', 'statistics', 'statistics', 'statistics', 'statistics', 'Thống kê', '', '', 1712405092, 1, 1, '', '', '', 'online, statistics', '6', 10, 1, '', 0, 1), 
('voting', 'voting', 'voting', 'voting', 'voting', 'Thăm dò ý kiến', '', '', 1712405092, 1, 1, '', '', '', '', '6', 11, 1, '', 1, 1), 
('banners', 'banners', 'banners', 'banners', 'banners', 'Quảng cáo', '', '', 1712405092, 1, 1, '', '', '', '', '6', 12, 1, '', 0, 1), 
('seek', 'seek', 'seek', 'seek', 'seek', 'Tìm kiếm', '', '', 1712405092, 1, 0, '', '', '', '', '6', 13, 1, '', 0, 1), 
('menu', 'menu', 'menu', 'menu', 'menu', 'Menu Site', '', '', 1712405092, 0, 1, '', '', '', '', '6', 14, 1, '', 0, 1), 
('feeds', 'feeds', 'feeds', 'feeds', 'feeds', 'RSS-feeds', '', '', 1712405092, 1, 1, '', '', '', '', '6', 15, 1, '', 0, 1), 
('page', 'page', 'page', 'page', 'page', 'Page', '', '', 1712405092, 1, 1, '', '', '', '', '6', 16, 1, '', 1, 0), 
('comment', 'comment', 'comment', 'comment', 'comment', 'Bình luận', '', 'Quản lý bình luận', 1712405092, 0, 1, '', '', '', '', '6', 17, 1, '', 0, 1), 
('siteterms', 'page', 'siteterms', 'siteterms', 'page', 'Điều khoản sử dụng', '', '', 1712405092, 1, 1, '', '', '', '', '6', 18, 1, '', 1, 1), 
('freecontent', 'freecontent', 'freecontent', 'freecontent', 'freecontent', 'Giới thiệu sản phẩm', '', '', 1712405092, 0, 1, '', '', '', '', '6', 19, 1, '', 0, 1), 
('two-step-verification', 'two-step-verification', 'two_step_verification', 'two_step_verification', 'two-step-verification', 'Xác thực hai bước', '', '', 1712405092, 1, 0, '', '', '', '', '6', 20, 1, '', 0, 1), 
('san-pham', 'shops', 'san_pham', 'san-pham', 'shops', 'Sản phẩm', '', '', 1712406028, 1, 1, '', '', '', '', '6', 2, 1, '', 1, 1), 
('gioi-thieu', 'page', 'gioi_thieu', 'gioi-thieu', 'page', 'Giới thiệu', '', '', 1712406043, 1, 1, '', '', '', '', '6', 1, 1, '', 1, 1), 
('lien-he', 'contact', 'lien_he', 'lien-he', 'contact', 'Liên hệ', '', '', 1712406054, 1, 1, '', '', '', '', '6', 4, 1, '', 0, 0), 
('tin-tuc', 'news', 'tin_tuc', 'tin-tuc', 'news', 'Tin tức', '', '', 1712406063, 1, 1, '', '', '', '', '6', 3, 1, '', 1, 1), 
('thong-tin', 'page', 'thong_tin', 'thong-tin', 'page', 'Thông tin', '', '', 1712406088, 1, 1, '', '', '', '', '6', 5, 1, '', 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_1`
--

DROP TABLE IF EXISTS `nv4_vi_news_1`;
CREATE TABLE `nv4_vi_news_1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(9) NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `weight` int(10) unsigned NOT NULL DEFAULT '0',
  `publtime` int(10) unsigned NOT NULL DEFAULT '0',
  `exptime` int(10) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `external_link` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `instant_active` tinyint(1) NOT NULL DEFAULT '0',
  `instant_template` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `instant_creatauto` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `edittime` (`edittime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`),
  KEY `instant_active` (`instant_active`),
  KEY `instant_creatauto` (`instant_creatauto`)
) ENGINE=MyISAM  AUTO_INCREMENT=13  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_news_1`
--

INSERT INTO `nv4_vi_news_1` VALUES
(1, 1, '1,5,7', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', 'nangly.jpg', 'Thành lập VINADES.,JSC', 1, 1, '6', 1, 0, 2, 0, 0, 0, 0, '', 0), 
(6, 1, '1,6', 0, 1, '', 3, 1322685920, 1322686042, 1, 2, 1322685920, 0, 2, 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 'Ma-nguon-mo-NukeViet-gianh-giai-ba-Nhan-tai-dat-Viet-2011', 'Không có giải nhất và giải nhì, sản phẩm Mã nguồn mở NukeViet của VINADES.,JSC là một trong ba sản phẩm đã đoạt giải ba Nhân tài đất Việt 2011 - Lĩnh vực Công nghệ thông tin (Sản phẩm đã ứng dụng rộng rãi).', 'nukeviet-nhantaidatviet2011.jpg', 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 1, 1, '6', 1, 0, 1, 0, 0, 0, 0, '', 0), 
(7, 1, '1', 0, 1, '', 4, 1445309676, 1445309676, 1, 3, 1445309520, 0, 2, 'NukeViet được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước', 'nukeviet-duoc-uu-tien-mua-sam-su-dung-trong-co-quan-to-chuc-nha-nuoc', 'Ngày 5/12/2014, Bộ trưởng Bộ TT&TT Nguyễn Bắc Son đã ký ban hành Thông tư 20/2014/TT-BTTTT (Thông tư 20) quy định về các sản phẩm phần mềm nguồn mở (PMNM) được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước. NukeViet (phiên bản 3.4.02 trở lên) là phần mềm được nằm trong danh sách này.', 'chuc-mung-nukeviet-thong-tu-20-bo-tttt.jpg', 'NukeViet được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước', 1, 1, '4', 1, 0, 2, 0, 0, 0, 0, '', 0), 
(9, 1, '1,4', 0, 1, 'Trần Thị Thu', 0, 1445391118, 1445394180, 1, 7, 1445391060, 0, 2, 'Chương trình thực tập sinh tại công ty VINADES', 'chuong-trinh-thuc-tap-sinh-tai-cong-ty-vinades', 'Cơ hội để những sinh viên năng động được học tập, trải nghiệm, thử thách sớm với những tình huống thực tế, được làm việc cùng các chuyên gia có nhiều kinh nghiệm của công ty VINADES.', 'thuc-tap-sinh.jpg', '', 1, 1, '4', 1, 0, 0, 0, 0, 0, 0, '', 0), 
(11, 1, '1', 0, 1, '', 0, 1445391182, 1445394133, 1, 9, 1445391120, 0, 2, 'NukeViet được Bộ GD&amp;ĐT đưa vào Hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016', 'nukeviet-duoc-bo-gd-dt-dua-vao-huong-dan-thuc-hien-nhiem-vu-cntt-nam-hoc-2015-2016', 'Trong Hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016 của Bộ Giáo dục và Đào tạo, NukeViet được đưa vào các hạng mục: Tập huấn sử dụng phần mềm nguồn mở cho giáo viên và cán bộ quản lý giáo dục; Khai thác, sử dụng và dạy học; đặc biệt phần &quot;khuyến cáo khi sử dụng các hệ thống CNTT&quot; có chỉ rõ &quot;Không nên làm website mã nguồn đóng&quot; và &quot;Nên làm NukeViet: phần mềm nguồn mở&quot;.', 'nukeviet-cms.jpg', '', 1, 1, '4', 1, 0, 0, 0, 0, 0, 0, '', 0), 
(12, 1, '1,3', 0, 1, '', 0, 1445391217, 1445393997, 1, 10, 1445391180, 0, 2, 'Hỗ trợ tập huấn và triển khai NukeViet cho các Phòng, Sở GD&amp;ĐT', 'ho-tro-tap-huan-va-trien-khai-nukeviet-cho-cac-phong-so-gd-dt', 'Trên cơ sở Hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016 của Bộ Giáo dục và Đào tạo, Công ty cổ phần phát triển nguồn mở Việt Nam và các doanh nghiệp phát triển NukeViet trong cộng đồng NukeViet đang tích cực công tác hỗ trợ cho các phòng GD&ĐT, Sở GD&ĐT triển khai 2 nội dung chính: Hỗ trợ công tác đào tạo tập huấn hướng dẫn sử dụng NukeViet và Hỗ trợ triển khai NukeViet cho các trường, Phòng và Sở GD&ĐT', 'tap-huan-pgd-ha-dong-2015.jpg', 'Tập huấn triển khai NukeViet tại Phòng Giáo dục và Đào tạo Hà Đông - Hà Nội', 1, 1, '4', 1, 0, 1, 0, 0, 0, 0, '', 0), 
(2, 7, '1,7', 0, 1, 'Nguyễn Thế Hùng', 7, 1453192444, 1453192444, 1, 12, 1453192444, 0, 2, 'Hãy trở thành nhà cung cấp dịch vụ của NukeViet&#33;', 'hay-tro-thanh-nha-cung-cap-dich-vu-cua-nukeviet', 'Nếu bạn là công ty hosting, là công ty thiết kế web có sử dụng mã nguồn NukeViet, là cơ sở đào tạo NukeViet hay là công ty bất kỳ có kinh doanh dịch vụ liên quan đến NukeViet... hãy cho chúng tôi biết thông tin liên hệ của bạn để NukeViet hỗ trợ bạn trong công việc kinh doanh nhé!', 'hoptac.jpg', '', 1, 1, '6', 1, 0, 13, 0, 0, 0, 0, '', 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_2`
--

DROP TABLE IF EXISTS `nv4_vi_news_2`;
CREATE TABLE `nv4_vi_news_2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(9) NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `weight` int(10) unsigned NOT NULL DEFAULT '0',
  `publtime` int(10) unsigned NOT NULL DEFAULT '0',
  `exptime` int(10) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `external_link` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `instant_active` tinyint(1) NOT NULL DEFAULT '0',
  `instant_template` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `instant_creatauto` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `edittime` (`edittime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`),
  KEY `instant_active` (`instant_active`),
  KEY `instant_creatauto` (`instant_creatauto`)
) ENGINE=MyISAM  AUTO_INCREMENT=16  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_news_2`
--

INSERT INTO `nv4_vi_news_2` VALUES
(13, 2, '2', 0, 1, 'VINADES', 0, 1453194455, 1453194455, 1, 13, 1453194455, 0, 2, 'NukeViet 4.0 có gì mới?', 'nukeviet-4-0-co-gi-moi', 'NukeViet 4 là phiên bản NukeViet được cộng đồng đánh giá cao, hứa hẹn nhiều điểm vượt trội về công nghệ đến thời điểm hiện tại. NukeViet 4 thay đổi gần như hoàn toàn từ nhân hệ thống đến chức năng, giao diện người dùng. Vậy, có gì mới trong phiên bản này?', 'chuc-mung-nukeviet-thong-tu-20-bo-tttt.jpg', '', 1, 1, '4', 1, 0, 2, 0, 0, 0, 0, '', 0), 
(14, 2, '2', 0, 1, 'VINADES', 0, 1501837620, 1501837620, 1, 14, 1501837620, 0, 2, 'NukeViet 4.2 có gì mới?', 'nukeviet-4-2-co-gi-moi', 'NukeViet 4.2 là phiên bản nâng cấp của phiên bản NukeViet 4.0 tập trung vào việc fix các vấn đề bất cập còn tồn tại của NukeViet 4.0, Thêm các tính năng mới để tăng cường bảo mật của hệ thống cũng như tối ưu trải nghiệm của người dùng.', 'chuc-mung-nukeviet-thong-tu-20-bo-tttt.jpg', '', 1, 1, '4', 1, 1, 2, 0, 0, 0, 0, '', 0), 
(15, 2, '2', 0, 1, 'VINADES', 0, 1510215907, 1510215907, 1, 15, 1510215907, 0, 2, 'NukeViet 4.3 có gì mới?', 'nukeviet-4-3-co-gi-moi', 'NukeViet 4.3 là phiên bản nâng cấp của phiên bản NukeViet 4.2 tập trung vào việc fix các vấn đề bất cập còn tồn tại, tối ưu trải nghiệm của người dùng.', 'chuc-mung-nukeviet-thong-tu-20-bo-tttt.jpg', '', 1, 1, '4', 1, 1, 2, 0, 0, 0, 0, '', 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_3`
--

DROP TABLE IF EXISTS `nv4_vi_news_3`;
CREATE TABLE `nv4_vi_news_3` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(9) NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `weight` int(10) unsigned NOT NULL DEFAULT '0',
  `publtime` int(10) unsigned NOT NULL DEFAULT '0',
  `exptime` int(10) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `external_link` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `instant_active` tinyint(1) NOT NULL DEFAULT '0',
  `instant_template` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `instant_creatauto` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `edittime` (`edittime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`),
  KEY `instant_active` (`instant_active`),
  KEY `instant_creatauto` (`instant_creatauto`)
) ENGINE=MyISAM  AUTO_INCREMENT=13  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_news_3`
--

INSERT INTO `nv4_vi_news_3` VALUES
(12, 1, '1,3', 0, 1, '', 0, 1445391217, 1445393997, 1, 10, 1445391180, 0, 2, 'Hỗ trợ tập huấn và triển khai NukeViet cho các Phòng, Sở GD&amp;ĐT', 'ho-tro-tap-huan-va-trien-khai-nukeviet-cho-cac-phong-so-gd-dt', 'Trên cơ sở Hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016 của Bộ Giáo dục và Đào tạo, Công ty cổ phần phát triển nguồn mở Việt Nam và các doanh nghiệp phát triển NukeViet trong cộng đồng NukeViet đang tích cực công tác hỗ trợ cho các phòng GD&ĐT, Sở GD&ĐT triển khai 2 nội dung chính: Hỗ trợ công tác đào tạo tập huấn hướng dẫn sử dụng NukeViet và Hỗ trợ triển khai NukeViet cho các trường, Phòng và Sở GD&ĐT', 'tap-huan-pgd-ha-dong-2015.jpg', 'Tập huấn triển khai NukeViet tại Phòng Giáo dục và Đào tạo Hà Đông - Hà Nội', 1, 1, '4', 1, 0, 1, 0, 0, 0, 0, '', 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_4`
--

DROP TABLE IF EXISTS `nv4_vi_news_4`;
CREATE TABLE `nv4_vi_news_4` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(9) NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `weight` int(10) unsigned NOT NULL DEFAULT '0',
  `publtime` int(10) unsigned NOT NULL DEFAULT '0',
  `exptime` int(10) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `external_link` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `instant_active` tinyint(1) NOT NULL DEFAULT '0',
  `instant_template` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `instant_creatauto` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `edittime` (`edittime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`),
  KEY `instant_active` (`instant_active`),
  KEY `instant_creatauto` (`instant_creatauto`)
) ENGINE=MyISAM  AUTO_INCREMENT=11  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_news_4`
--

INSERT INTO `nv4_vi_news_4` VALUES
(8, 4, '4', 0, 1, 'Vũ Bích Ngọc', 0, 1445391061, 1445394203, 1, 4, 1445391000, 0, 2, 'Công ty VINADES tuyển dụng nhân viên kinh doanh', 'cong-ty-vinades-tuyen-dung-nhan-vien-kinh-doanh', 'Công ty cổ phần phát triển nguồn mở Việt Nam là đơn vị chủ quản của phần mềm mã nguồn mở NukeViet - một mã nguồn được tin dùng trong cơ quan nhà nước, đặc biệt là ngành giáo dục. Chúng tôi cần tuyển 05 nhân viên kinh doanh cho lĩnh vực này.', 'tuyen-dung-nvkd.png', '', 1, 1, '4', 1, 0, 0, 0, 0, 0, 0, '', 0), 
(4, 4, '4', 0, 1, 'Phạm Quốc Tiến', 0, 1445391089, 1445394192, 1, 5, 1445391060, 0, 2, 'Tuyển dụng chuyên viên đồ hoạ phát triển NukeViet', 'Tuyen-dung-chuyen-vien-do-hoa', 'Bạn đam mê nguồn mở? Bạn là chuyên gia đồ họa? Chúng tôi sẽ giúp bạn hiện thực hóa ước mơ của mình với một mức lương đảm bảo. Hãy gia nhập VINADES.,JSC để xây dựng mã nguồn mở hàng đầu cho Việt Nam.', 'tuyendung-kythuat.jpg', 'Tuyển dụng', 1, 1, '6', 1, 0, 0, 0, 0, 0, 0, '', 0), 
(5, 4, '4', 0, 1, 'Phạm Quốc Tiến', 0, 1445391090, 1445394193, 1, 6, 1445391060, 0, 2, 'Tuyển dụng lập trình viên front-end (HTML/CSS/JS) phát triển NukeViet', 'Tuyen-dung-lap-trinh-vien-front-end-HTML-CSS-JS', 'Bạn đam mê nguồn mở? Bạn đang cần tìm một công việc phù hợp với thế mạnh của bạn về front-end (HTML/CSS/JS)? Hãy gia nhập VINADES.,JSC để xây dựng mã nguồn mở hàng đầu cho Việt Nam.', 'tuyendung-kythuat.jpg', 'Tuyển dụng', 1, 1, '6', 1, 0, 0, 0, 0, 0, 0, '', 0), 
(9, 1, '1,4', 0, 1, 'Trần Thị Thu', 0, 1445391118, 1445394180, 1, 7, 1445391060, 0, 2, 'Chương trình thực tập sinh tại công ty VINADES', 'chuong-trinh-thuc-tap-sinh-tai-cong-ty-vinades', 'Cơ hội để những sinh viên năng động được học tập, trải nghiệm, thử thách sớm với những tình huống thực tế, được làm việc cùng các chuyên gia có nhiều kinh nghiệm của công ty VINADES.', 'thuc-tap-sinh.jpg', '', 1, 1, '4', 1, 0, 0, 0, 0, 0, 0, '', 0), 
(10, 4, '4', 0, 1, 'Trần Thị Thu', 0, 1445391135, 1445394444, 1, 8, 1445391120, 0, 2, 'Học việc tại công ty VINADES', 'hoc-viec-tai-cong-ty-vinades', 'Công ty cổ phần phát triển nguồn mở Việt Nam tạo cơ hội việc làm và học việc miễn phí cho những ứng viên có đam mê thiết kế web, lập trình PHP… được học tập và rèn luyện cùng đội ngũ lập trình viên phát triển NukeViet.', 'hoc-viec-tai-cong-ty-vinades.jpg', '', 1, 1, '4', 1, 0, 0, 0, 0, 0, 0, '', 0), 
(3, 4, '4', 0, 1, 'Phạm Quốc Tiến', 2, 1453192400, 1453192400, 1, 11, 1453192400, 0, 2, 'Tuyển dụng lập trình viên PHP phát triển NukeViet', 'Tuyen-dung-lap-trinh-vien-PHP', 'Bạn đam mê nguồn mở? Bạn đang cần tìm một công việc phù hợp với thế mạnh của bạn về PHP và MySQL? Hãy gia nhập VINADES.,JSC để xây dựng mã nguồn mở hàng đầu cho Việt Nam.', 'tuyendung-kythuat.jpg', 'Tuyển dụng', 1, 1, '6', 1, 0, 0, 0, 0, 0, 0, '', 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_5`
--

DROP TABLE IF EXISTS `nv4_vi_news_5`;
CREATE TABLE `nv4_vi_news_5` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(9) NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `weight` int(10) unsigned NOT NULL DEFAULT '0',
  `publtime` int(10) unsigned NOT NULL DEFAULT '0',
  `exptime` int(10) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `external_link` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `instant_active` tinyint(1) NOT NULL DEFAULT '0',
  `instant_template` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `instant_creatauto` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `edittime` (`edittime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`),
  KEY `instant_active` (`instant_active`),
  KEY `instant_creatauto` (`instant_creatauto`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_news_5`
--

INSERT INTO `nv4_vi_news_5` VALUES
(1, 1, '1,5,7', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', 'nangly.jpg', 'Thành lập VINADES.,JSC', 1, 1, '6', 1, 0, 2, 0, 0, 0, 0, '', 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_6`
--

DROP TABLE IF EXISTS `nv4_vi_news_6`;
CREATE TABLE `nv4_vi_news_6` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(9) NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `weight` int(10) unsigned NOT NULL DEFAULT '0',
  `publtime` int(10) unsigned NOT NULL DEFAULT '0',
  `exptime` int(10) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `external_link` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `instant_active` tinyint(1) NOT NULL DEFAULT '0',
  `instant_template` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `instant_creatauto` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `edittime` (`edittime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`),
  KEY `instant_active` (`instant_active`),
  KEY `instant_creatauto` (`instant_creatauto`)
) ENGINE=MyISAM  AUTO_INCREMENT=7  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_news_6`
--

INSERT INTO `nv4_vi_news_6` VALUES
(6, 1, '1,6', 0, 1, '', 3, 1322685920, 1322686042, 1, 2, 1322685920, 0, 2, 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 'Ma-nguon-mo-NukeViet-gianh-giai-ba-Nhan-tai-dat-Viet-2011', 'Không có giải nhất và giải nhì, sản phẩm Mã nguồn mở NukeViet của VINADES.,JSC là một trong ba sản phẩm đã đoạt giải ba Nhân tài đất Việt 2011 - Lĩnh vực Công nghệ thông tin (Sản phẩm đã ứng dụng rộng rãi).', 'nukeviet-nhantaidatviet2011.jpg', 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 1, 1, '6', 1, 0, 1, 0, 0, 0, 0, '', 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_7`
--

DROP TABLE IF EXISTS `nv4_vi_news_7`;
CREATE TABLE `nv4_vi_news_7` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(9) NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `weight` int(10) unsigned NOT NULL DEFAULT '0',
  `publtime` int(10) unsigned NOT NULL DEFAULT '0',
  `exptime` int(10) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `external_link` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `instant_active` tinyint(1) NOT NULL DEFAULT '0',
  `instant_template` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `instant_creatauto` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `edittime` (`edittime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`),
  KEY `instant_active` (`instant_active`),
  KEY `instant_creatauto` (`instant_creatauto`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_news_7`
--

INSERT INTO `nv4_vi_news_7` VALUES
(1, 1, '1,5,7', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', 'nangly.jpg', 'Thành lập VINADES.,JSC', 1, 1, '6', 1, 0, 2, 0, 0, 0, 0, '', 0), 
(2, 7, '1,7', 0, 1, 'Nguyễn Thế Hùng', 7, 1453192444, 1453192444, 1, 12, 1453192444, 0, 2, 'Hãy trở thành nhà cung cấp dịch vụ của NukeViet&#33;', 'hay-tro-thanh-nha-cung-cap-dich-vu-cua-nukeviet', 'Nếu bạn là công ty hosting, là công ty thiết kế web có sử dụng mã nguồn NukeViet, là cơ sở đào tạo NukeViet hay là công ty bất kỳ có kinh doanh dịch vụ liên quan đến NukeViet... hãy cho chúng tôi biết thông tin liên hệ của bạn để NukeViet hỗ trợ bạn trong công việc kinh doanh nhé!', 'hoptac.jpg', '', 1, 1, '6', 1, 0, 13, 0, 0, 0, 0, '', 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_admins`
--

DROP TABLE IF EXISTS `nv4_vi_news_admins`;
CREATE TABLE `nv4_vi_news_admins` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(6) NOT NULL DEFAULT '0',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `add_content` tinyint(4) NOT NULL DEFAULT '0',
  `pub_content` tinyint(4) NOT NULL DEFAULT '0',
  `edit_content` tinyint(4) NOT NULL DEFAULT '0',
  `del_content` tinyint(4) NOT NULL DEFAULT '0',
  `app_content` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`,`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_author`
--

DROP TABLE IF EXISTS `nv4_vi_news_author`;
CREATE TABLE `nv4_vi_news_author` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `alias` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `pseudonym` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(10) unsigned NOT NULL DEFAULT '0',
  `active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `numnews` mediumint(9) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid` (`uid`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_authorlist`
--

DROP TABLE IF EXISTS `nv4_vi_news_authorlist`;
CREATE TABLE `nv4_vi_news_authorlist` (
  `id` int(11) NOT NULL,
  `aid` mediumint(9) NOT NULL,
  `alias` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `pseudonym` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  UNIQUE KEY `id_aid` (`id`,`aid`),
  KEY `aid` (`aid`),
  KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_block`
--

DROP TABLE IF EXISTS `nv4_vi_news_block`;
CREATE TABLE `nv4_vi_news_block` (
  `bid` smallint(5) unsigned NOT NULL,
  `id` int(10) unsigned NOT NULL,
  `weight` int(10) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_news_block`
--

INSERT INTO `nv4_vi_news_block` VALUES
(1, 1, 1), 
(2, 12, 1), 
(2, 11, 2), 
(2, 10, 3), 
(2, 9, 4), 
(2, 8, 5), 
(2, 7, 6), 
(2, 1, 7), 
(2, 2, 8);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_block_cat`
--

DROP TABLE IF EXISTS `nv4_vi_news_block_cat`;
CREATE TABLE `nv4_vi_news_block_cat` (
  `bid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `numbers` smallint(6) NOT NULL DEFAULT '10',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` smallint(6) NOT NULL DEFAULT '0',
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_news_block_cat`
--

INSERT INTO `nv4_vi_news_block_cat` VALUES
(1, 0, 4, 'Tin tiêu điểm', 'Tin-tieu-diem', '', 'Tin tiêu điểm', 1, '', 1279945710, 1279956943), 
(2, 1, 4, 'Tin mới nhất', 'Tin-moi-nhat', '', 'Tin mới nhất', 2, '', 1279945725, 1279956445);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_cat`
--

DROP TABLE IF EXISTS `nv4_vi_news_cat`;
CREATE TABLE `nv4_vi_news_cat` (
  `catid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `titlesite` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `descriptionhtml` text  COLLATE utf8mb4_unicode_ci,
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `viewdescription` tinyint(4) NOT NULL DEFAULT '0',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sort` smallint(6) NOT NULL DEFAULT '0',
  `lev` smallint(6) NOT NULL DEFAULT '0',
  `viewcat` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` smallint(6) NOT NULL DEFAULT '0',
  `subcatid` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `numlinks` tinyint(3) unsigned NOT NULL DEFAULT '3',
  `newday` tinyint(3) unsigned NOT NULL DEFAULT '2',
  `featured` int(11) NOT NULL DEFAULT '0',
  `ad_block_cat` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `admins` text  COLLATE utf8mb4_unicode_ci,
  `add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(10) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` smallint(6) NOT NULL DEFAULT '1',
  PRIMARY KEY (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_news_cat`
--

INSERT INTO `nv4_vi_news_cat` VALUES
(1, 0, 'Tin tức', '', 'Tin-tuc', '', '', '', 0, 1, 1, 0, 'viewcat_main_right', 3, '5,6,7', 4, 2, 0, '', '', '', 1274986690, 1274986690, '6', 1), 
(2, 0, 'Sản phẩm', '', 'San-pham', '', '', '', 0, 2, 5, 0, 'viewcat_page_new', 0, '', 4, 2, 0, '', '', '', 1274986705, 1274986705, '6', 1), 
(3, 0, 'Đối tác', '', 'Doi-tac', '', '', '', 0, 3, 9, 0, 'viewcat_page_new', 0, '', 4, 2, 0, '', '', '', 1274987460, 1274987460, '6', 1), 
(4, 0, 'Tuyển dụng', '', 'Tuyen-dung', '', '', '', 0, 4, 12, 0, 'viewcat_page_new', 0, '', 4, 2, 0, '', '', '', 1274987538, 1274987538, '6', 1), 
(5, 1, 'Thông cáo báo chí', '', 'thong-cao-bao-chi', '', '', '', 0, 1, 2, 1, 'viewcat_page_new', 0, '', 4, 2, 0, '', '', '', 1274987105, 1274987244, '6', 1), 
(6, 1, 'Tin công nghệ', '', 'Tin-cong-nghe', '', '', '', 0, 3, 4, 1, 'viewcat_page_new', 0, '', 4, 2, 0, '', '', '', 1274987212, 1274987212, '6', 1), 
(7, 1, 'Bản tin nội bộ', '', 'Ban-tin-noi-bo', '', '', '', 0, 2, 3, 1, 'viewcat_page_new', 0, '', 4, 2, 0, '', '', '', 1274987902, 1274987902, '6', 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_config_post`
--

DROP TABLE IF EXISTS `nv4_vi_news_config_post`;
CREATE TABLE `nv4_vi_news_config_post` (
  `group_id` smallint(6) NOT NULL,
  `addcontent` tinyint(4) NOT NULL,
  `postcontent` tinyint(4) NOT NULL,
  `editcontent` tinyint(4) NOT NULL,
  `delcontent` tinyint(4) NOT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_detail`
--

DROP TABLE IF EXISTS `nv4_vi_news_detail`;
CREATE TABLE `nv4_vi_news_detail` (
  `id` int(10) unsigned NOT NULL,
  `titlesite` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `bodyhtml` longtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `voicedata` text  COLLATE utf8mb4_unicode_ci COMMENT 'Data giọng đọc json',
  `keywords` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourcetext` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `files` text  COLLATE utf8mb4_unicode_ci,
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `layout_func` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `copyright` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_send` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_news_detail`
--

INSERT INTO `nv4_vi_news_detail` VALUES
(1, '', '', '<p>Để chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet, Ban quản trị NukeViet quyết định thành lập doanh nghiệp chuyên quản NukeViet mang tên Công ty cổ phần Phát triển nguồn mở Việt Nam (Viết tắt là VINADES.,JSC), chính thức ra mắt vào ngày 25-2-2010 (trụ sở tại Hà Nội) nhằm phát triển, phổ biến hệ thống NukeViet tại Việt Nam.<br /> <br /> Theo ông Nguyễn Anh Tú, Chủ tịch HĐQT VINADES, công ty sẽ phát triển bộ mã nguồn NukeViet nhất quán theo con đường mã nguồn mở đã chọn, chuyên nghiệp và quy mô hơn bao giờ hết. Đặc biệt là hoàn toàn miễn phí đúng tinh thần mã nguồn mở quốc tế.<br /> <br /> NukeViet là một hệ quản trị nội dung mã nguồn mở (Opensource Content Management System) thuần Việt từ nền tảng PHP-Nuke và cơ sở dữ liệu MySQL. Người sử dụng thường gọi NukeViet là portal vì nó có khả năng tích hợp nhiều ứng dụng trên nền web, cho phép người sử dụng có thể dễ dàng xuất bản và quản trị các nội dung của họ lên internet hoặc intranet.<br /> <br /> NukeViet cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng thêm các module, block... tạo sự dễ dàng cài đặt, quản lý, ngay cả với những người mới tiếp cận với website. Người dùng có thể tìm hiểu thêm thông tin và tải về sản phẩm tại địa chỉ http://nukeviet.vn</p><blockquote> <p> <em>Thông tin ra mắt công ty VINADES có thể tìm thấy trên trang 7 báo Hà Nội Mới ra ngày 25/02/2010 (<a href=\"http://hanoimoi.com.vn/newsdetail/Cong_nghe/309750/ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-viet-nam.htm\" target=\"_blank\">xem chi tiết</a>), Bản tin tiếng Anh của đài tiếng nói Việt Nam ngày 26/02/2010 (<a href=\"http://english.vovnews.vn/Home/First-opensource-company-starts-operation/20102/112960.vov\" target=\"_blank\">xem chi tiết</a>); trang 7 báo An ninh Thủ Đô số 2858 ra vào thứ 2 ngày 01/03/2010 và các trang tin tức, báo điện tử khác.</em></p></blockquote>', NULL, '', 'http://hanoimoi.com.vn/newsdetail/Cong_nghe/309750/ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-viet-nam.htm', NULL, 2, '', 0, 1, 1, 1), 
(2, '', '', '<div>Tính đến năm 2015, ước tính có hơn 10.000 website đang sử dụng NukeViet. Nhu cầu triển khai NukeViet không chỉ dừng lại ở các cá nhân, doanh nghiệp, cơ sở giáo dục mà đã lan rộng ra khối chính phủ.</div><div><br  />Cộng đồng NukeViet cũng đã lớn mạnh hơn trước. Nếu như đầu năm 2010, ngoài Công ty VINADES chỉ có một vài công ty cung cấp dịch vụ cho NukeViet nhưng không chuyên, thì theo thống kê năm 2015 đã có hàng trăm doanh nghiệp đang cung cấp dịch vụ có liên quan đến NukeViet như: đào tạo NukeViet, thiết kế web, phát triển phần mềm, cung cấp giao diện, module... trên nền tảng NukeViet. Đặc biệt có nhiều doanh nghiệp hoàn toàn cung cấp dịch vụ thiết kế web, cung cấp giao diện, module... sử dụng nền tảng NukeViet. Nhiều sản phẩm phái sinh từ NukeViet đã ra đời, NukeViet được phát triển thành nhiều phần mềm quản lý sử dụng trên mạng LAN hay trên internet, được phát triển thành các phần mềm dùng riêng hay sử dụng như một nền tảng để cung cấp dịch vụ online, thậm chí đã được thử nghiệm tích hợp vào trong các thiết bị phần cứng để bán cùng thiết bị (NukeViet Captive Portal - dùng để quản lý người dùng truy cập internet, tích hợp trong thiết bị quản lý wifi)...<br  /><br  />Tuy nhiên, cùng với những cơ hội, cộng đồng NukeViet đang đứng trước một thách thức mới. NukeViet cần tập hợp tất cả các doanh nghiệp, tổ chức và cá nhân đang cung cấp dịch vụ cho NukeViet và liên kết các đơn vị này với nhau để giúp nhau chuyên nghiệp hóa, cùng nhau chia sẻ những cơ hội kinh doanh và trở lên lớn mạnh hơn.<br  /><br  />Nếu cộng đồng NukeViet có 500 công ty siêu nhỏ chỉ 2-3 người và những công ty này đứng riêng rẽ như hiện nay thì NukeViet mãi bé nhỏ và sẽ không làm được việc gì. Nhưng nếu 500 công ty này biết nhau, cùng làm một số việc, cùng tham gia phát triển NukeViet, đó sẽ là sức mạnh rất lớn cho một phần mềm nguồn mở như NukeViet, và đó cũng là cơ hội rất lớn để các công ty nhỏ ấy trở lên chuyên nghiệp và vững mạnh.<br  /><br  />Cho dù bạn là doanh nghiệp hay một nhóm kinh doanh, cho dù bạn đang cung cấp bất kỳ dịch vụ có liên quan trực tiếp đến NukeViet như: đào tạo NukeViet, thiết kế web, phát triển phần mềm, cung cấp giao diện, module... hoặc gián tiếp có liên quan đến NukeViet (ví dụ các công ty hosting, các nhà cung cấp dịch vụ thanh toán điện tử...). Bạn đều là một thành phần quan trọng của NukeViet. Dù bạn là công ty to hay một nhóm nhỏ, hãy đăng ký vào danh sách các đối tác của NukeViet để thiết lập kênh liên lạc với các doanh nghiệp khác trong cộng đồng NukeViet và nhận sự hỗ trợ từ Ban Quản Trị NukeViet cũng như từ các cơ quan nhà nước đang có nhu cầu tìm kiếm các đơn vị cung ứng dịch vụ cho NukeViet.<br  /><br  />Hãy gửi email cho Ban Quản Trị NukeViet về địa chỉ: admin@nukeviet.vn để đăng ký vào danh sách các đơn vị hỗ trợ NukeViet.<br  /><br  />Tiêu đề email: Đăng ký vào danh sách các đơn vị cung cấp dịch vụ dựa trên NukeViet<br  />Nội dung email: Thông tin về đơn vị, dịch vụ cung cấp.<br  /><br  />Hoặc gửi yêu cầu tại đây: <a href=\"http://nukeviet.vn/vi/contact/\" target=\"_blank\">http://nukeviet.vn/vi/contact/</a><br  /><br  />Mọi yêu cầu sẽ được phản hồi trong vòng 24h. Trường hợp không nhận được phản hồi, hãy liên hệ với Ban Quản Trị NukeViet qua các kênh liên lạc khác như:<br  /><br  />- Diễn đàn doanh nghiệp NukeViet: <a href=\"http://forum.nukeviet.vn/viewforum.php?f=4\" target=\"_blank\">http://forum.nukeviet.vn/viewforum.php?f=4</a><br  />- Fanpage NukeViet trên FaceBook: <a href=\"http://fb.com/nukeviet/\" target=\"_blank\">http://fb.com/nukeviet/</a><br  /><br  />Vui lòng truy cập địa chỉ sau để xem danh sách các đơn vị: <a href=\"https://nukeviet.vn/vi/partner/\" target=\"_blank\">https://nukeviet.vn/vi/partner/</a></div>', NULL, '', 'http://vinades.vn/vi/news/thong-cao-bao-chi/Thu-moi-hop-tac-6/', NULL, 2, '', 0, 1, 1, 1), 
(3, '', '', 'Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC) đang thu hút tuyển dụng nhân tài ở các vị trí:<ol><li><a href=\"/Tuyen-dung/Tuyen-dung-lap-trinh-vien-PHP-7.html\">Lập trình viên PHP và MySQL.</a></li><li><a href=\"/Tuyen-dung/Tuyen-dung-lap-trinh-vien-front-end-HTML-CSS-JS-9.html\">Lập trình viên front-end (HTML/CSS/JS).</a></li><li><a href=\"/Tuyen-dung/Tuyen-dung-chuyen-vien-do-hoa-8.html\">Chuyên Viên Đồ Hoạ.</a></li></ol><br />Tại VINADES.,JSC bạn sẽ được tham gia các dự án của công ty, tham gia xây dựng và phát triển bộ nhân hệ thống NukeViet, được học hỏi và trau dồi nâng cao kiến thức và kỹ năng cá nhân. Ngoài ra, nếu bạn đam mê về nguồn mở và có mong muốn cống hiến cho quá trình phát triển nguồn mở của Việt Nam nói riêng và của thế giới nói chung, thì đây là cơ hội lớn nhất để bạn đạt được mong muốn của mình. Tham gia công tác tại công ty là bạn đã góp phần xây dựng một cộng đồng nguồn mở chuyên nghiệp cho Việt Nam để vươn xa ra thế giới.<br /><br /><span style=\"font-size:16px;\"><strong>1. Vị trí dự tuyển:</strong></span> Lập trình viên PHP và MySQL<br /><br /><span style=\"font-size:16px;\"><strong>2. Mô tả công việc:</strong></span><ul><li>Phát triển hệ thống NukeViet.</li><li>Phân tích yêu cầu và lập trình riêng cho các dự án cụ thể.</li><li>Thực hiện các công đoạn để dưa website vào hoạt động như upload dữ liệu lên host, xử lý lỗi, sự cố liên quan.</li><li>Chịu trách nhiệm về chất lượng, trải nghiệm người dùng của sản phẩm trong khi sản phẩm hoạt động.</li><li>Thực hiện các công việc theo sự phân công của cấp trên.</li><li>Chịu trách nhiệm về chất lượng và tiến độ công việc.</li></ul><br /><span style=\"font-size:16px;\"><strong>3. Yêu cầu:</strong></span><ul><li>Nắm vững kiến thức hướng đối tượng, cấu trúc dữ liệu và giải thuật.</li><li>Có kinh nghiệm về PHP và các hệ cơ sở dữ liệu MySQL.…</li><li>Tư duy lập trình tốt, thiết kế CSDL chuẩn, biết xử lý nhanh các vấn đề khi phát sinh nghiệp vụ mới.</li><li>Sửa được các lỗi, nâng cấp tính năng cho các module đã có. 6. Viết module mới.</li><li>Biết đưa website lên host, xử lý lỗi, sự cố liên quan.</li><li>Chịu trách nhiệm về chất lượng và tiến độ công việc phụ trách.</li><li>Khả năng sáng tạo.</li><li>Đam mê công việc về lập trình web.</li></ul><br /><em><strong>Ưu tiên các ứng viên:</strong></em><ul><li>Có kiến thức cơ bản về quản trị website NukeViệt.</li><li>Sử dụng và nắm rõ các tính năng, block thường dùng của NukeViet.</li><li>Biết sử dụng git để quản lý source code (nếu ứng viên chưa biết công ty sẽ đào tạo thêm).</li><li>Có khả năng giao tiếp với khách hàng (Trực tiếp, điện thoại, email).</li><li>Có khả năng làm việc độc lập và làm việc theo nhóm.</li><li>Có tinh thần trách nhiệm cao và chủ động trong công việc.</li><li>Có khả năng trình bày ý tưởng.</li></ul><br /><span style=\"font-size:16px;\"><strong>4. Quyền lợi:</strong></span><ul><li>Lương thoả thuận, trả qua ATM.</li><li>Thưởng theo dự án, các ngày lễ tết.</li><li>Hưởng các chế độ khác theo quy định của công ty và pháp luật: Bảo hiểm y tế, bảo hiểm xã hội...</li></ul><br /><span style=\"font-size:16px;\"><strong>5. Thời gian làm việc:</strong></span> Toàn thời gian cố định hoặc làm online.<br /><br /><span style=\"font-size:16px;\"><strong>6. Hạn nộp hồ sơ:</strong></span> Không hạn chế, vui lòng kiểm tra tại <a href=\"http://vinades.vn/vi/news/Tuyen-dung/\">http://vinades.vn/vi/news/Tuyen-dung/</a><br /><br /><span style=\"font-size:16px;\"><strong>7. Cách thức đăng ký dự tuyển:</strong></span> Làm Hồ sơ xin việc<em><strong> (download tại đây: <strong><a href=\"http://vinades.vn/vi/download/Tai-lieu/Ban-khai-so-yeu-ly-lich-ky-thuat-vien/\" target=\"_blank\"><u>Mẫu lý lịch ứng viên</u></a></strong>)</strong></em> và gửi về hòm thư <a href=\"mailto:tuyendung@vinades.vn\">tuyendung@vinades.vn</a><br /><br /><span style=\"font-size:16px;\"><strong>8. Hồ sơ bao gồm:</strong></span><ul><li>Đơn xin việc: Tự biên soạn.</li><li>Thông tin ứng viên: Theo mẫu của VINADES.,JSC</li></ul>&nbsp;<p><strong>Chi tiết vui lòng tham khảo tại:</strong> <a href=\"http://vinades.vn/vi/news/Tuyen-dung/\" target=\"_blank\">http://vinades.vn/vi/news/Tuyen-dung/</a><br /><br /><strong>Mọi thắc mắc vui lòng liên hệ:</strong></p><blockquote><p><strong>Công ty cổ phần phát triển nguồn mở Việt Nam.</strong><br />Trụ sở chính: Phòng 1706 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.</p><div>- Tel: +84-24-85872007 - Fax: +84-24-35500914<br />- Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a> - Website: <a href=\"http://www.vinades.vn/\">http://www.vinades.vn</a></div></blockquote>', NULL, '', 'http://vinades.vn/vi/news/Tuyen-dung/', NULL, 2, '', 0, 1, 1, 1), 
(4, '', '', 'Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC) đang thu hút tuyển dụng nhân tài ở các vị trí:<ol><li><a href=\"/Tuyen-dung/Tuyen-dung-lap-trinh-vien-PHP-7.html\">Lập trình viên PHP và MySQL.</a></li><li><a href=\"/Tuyen-dung/Tuyen-dung-lap-trinh-vien-front-end-HTML-CSS-JS-9.html\">Lập trình viên front-end (HTML/CSS/JS).</a></li><li><a href=\"/Tuyen-dung/Tuyen-dung-chuyen-vien-do-hoa-8.html\">Chuyên Viên Đồ Hoạ.</a></li></ol><br />Tại VINADES.,JSC bạn sẽ được tham gia các dự án của công ty, tham gia xây dựng và phát triển bộ nhân hệ thống NukeViet, được học hỏi và trau dồi nâng cao kiến thức và kỹ năng cá nhân. Ngoài ra, nếu bạn đam mê về nguồn mở và có mong muốn cống hiến cho quá trình phát triển nguồn mở của Việt Nam nói riêng và của thế giới nói chung, thì đây là cơ hội lớn nhất để bạn đạt được mong muốn của mình. Tham gia công tác tại công ty là bạn đã góp phần xây dựng một cộng đồng nguồn mở chuyên nghiệp cho Việt Nam để vươn xa ra thế giới.<br /><br /><span style=\"font-size:16px;\"><strong>1. Vị trí dự tuyển:</strong></span> Chuyên viên đồ hoạ.<br /><br /><span style=\"font-size:16px;\"><strong>2. Mô tả công việc:</strong></span><br /><br /><em><strong>Công việc chính:</strong></em><ul><li>Thiết kế layout, banner, logo website theo yêu cầu của dự án.</li><li>Đưa ra sản phẩm sáng tạo dựa trên ý tưởng của khách hàng.</li><li>Thực hiện các công việc theo sự phân công của cấp trên.</li><li>Chịu trách nhiệm về chất lượng và tiến độ công việc.</li></ul><br /><em><strong>Ngoài ra bạn cần có khả năng thực hiện các công việc sau:</strong></em><ul><li>Cắt và ghép giao diện cho hệ thống.</li><li>Valid CSS, xHTML.</li></ul><br /><span style=\"font-size:16px;\"><strong>3. Yêu cầu:</strong></span><ul><li>Sử dụng thành thạo phần mềm thiết kế: Photoshop ngoài ra cần biết cách sử dụng các phần mềm thiết kế khác là một lợi thế.</li><li>Có kiến thức cơ bản về thiết kế website: Am hiểu các dạng layout, thành phần của một website.</li><li>Có kinh nghiệm, kỹ năng thiết kế giao diện web, logo, banner.</li><li>Chịu trách nhiệm về chất lượng và tiến độ công việc phụ trách.</li><li>Khả năng sáng tạo, tính thẩm mỹ tốt</li><li>Đam mê công việc thiết kế và website.</li></ul><br /><em><strong>Ưu tiên các ứng viên:</strong></em><ul><li>Có kiến thức cơ bản về quản trị website NukeViệt</li><li>Am hiểu về Responsive và có thể thiết kế giao diện, layout trên mobile (Boostrap).</li><li>Sử dụng và nắm rõ các tính năng, block thường dùng của NukeViet.</li><li>Biết sử dụng git để quản lý source code (nếu ứng viên chưa biết công ty sẽ đào tạo thêm).</li><li>Sử dụng thành thạo HTML5, CSS3 &amp; Javascrip/Jquery và Xtemplate</li><li>Khả năng chuyển PSD sang NukeViet tốt.</li><li>Hiểu rõ và nắm chắc cách làm Theme/Template.</li><li>Có khả năng giao tiếp với khách hàng (Trực tiếp, điện thoại, email).</li><li>Có khả năng làm việc độc lập và làm việc theo nhóm.</li><li>Có tinh thần trách nhiệm cao và chủ động trong công việc.</li><li>Có khả năng trình bày ý tưởng</li></ul><br /><span style=\"font-size:16px;\"><strong>4. Quyền lợi:</strong></span><ul><li>Lương thoả thuận, trả qua ATM.</li><li>Thưởng theo dự án, các ngày lễ tết.</li><li>Hưởng các chế độ khác theo quy định của công ty và pháp luật: Bảo hiểm y tế, bảo hiểm xã hội...</li></ul><br /><span style=\"font-size:16px;\"><strong>5. Thời gian làm việc:</strong></span> Toàn thời gian cố định hoặc làm online.<br /><br /><span style=\"font-size:16px;\"><strong>6. Hạn nộp hồ sơ:</strong></span> Không hạn chế, vui lòng kiểm tra tại <a href=\"http://vinades.vn/vi/news/Tuyen-dung/\">http://vinades.vn/vi/news/Tuyen-dung/</a><br /><br /><span style=\"font-size:16px;\"><strong>7. Cách thức đăng ký dự tuyển:</strong></span> Làm Hồ sơ xin việc<em><strong> (download tại đây: <strong><a href=\"http://vinades.vn/vi/download/Tai-lieu/Ban-khai-so-yeu-ly-lich-ky-thuat-vien/\" target=\"_blank\"><u>Mẫu lý lịch ứng viên</u></a></strong>)</strong></em> và gửi về hòm thư <a href=\"mailto:tuyendung@vinades.vn\">tuyendung@vinades.vn</a><br /><br /><span style=\"font-size:16px;\"><strong>8. Hồ sơ bao gồm:</strong></span><ul><li>Đơn xin việc: Tự biên soạn.</li><li>Thông tin ứng viên: Theo mẫu của VINADES.,JSC</li></ul>&nbsp;<p><strong>Chi tiết vui lòng tham khảo tại:</strong> <a href=\"http://vinades.vn/vi/news/Tuyen-dung/\" target=\"_blank\">http://vinades.vn/vi/news/Tuyen-dung/</a><br /><br /><strong>Mọi thắc mắc vui lòng liên hệ:</strong></p><blockquote><p><strong>Công ty cổ phần phát triển nguồn mở Việt Nam.</strong><br />Trụ sở chính: Phòng 1706 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.</p><div>- Tel: +84-24-85872007 - Fax: +84-24-35500914<br />- Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a> - Website: <a href=\"http://www.vinades.vn/\">http://www.vinades.vn</a></div></blockquote>', NULL, '', '', NULL, 2, '', 0, 1, 1, 1), 
(5, '', '', 'Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC) đang thu hút tuyển dụng nhân tài ở các vị trí:<ol><li><a href=\"/Tuyen-dung/Tuyen-dung-lap-trinh-vien-PHP-7.html\">Lập trình viên PHP và MySQL.</a></li><li><a href=\"/Tuyen-dung/Tuyen-dung-lap-trinh-vien-front-end-HTML-CSS-JS-9.html\">Lập trình viên front-end (HTML/CSS/JS).</a></li><li><a href=\"/Tuyen-dung/Tuyen-dung-chuyen-vien-do-hoa-8.html\">Chuyên Viên Đồ Hoạ.</a></li></ol><br />Tại VINADES.,JSC bạn sẽ được tham gia các dự án của công ty, tham gia xây dựng và phát triển bộ nhân hệ thống NukeViet, được học hỏi và trau dồi nâng cao kiến thức và kỹ năng cá nhân. Ngoài ra, nếu bạn đam mê về nguồn mở và có mong muốn cống hiến cho quá trình phát triển nguồn mở của Việt Nam nói riêng và của thế giới nói chung, thì đây là cơ hội lớn nhất để bạn đạt được mong muốn của mình. Tham gia công tác tại công ty là bạn đã góp phần xây dựng một cộng đồng nguồn mở chuyên nghiệp cho Việt Nam để vươn xa ra thế giới.<br /><br /><span style=\"font-size:16px;\"><strong>1. Vị trí dự tuyển:</strong></span> Lập trình viên front-end (HTML/ CSS/ JS)<br /><br /><span style=\"font-size:16px;\"><strong>2. Mô tả công việc:</strong></span><ul><li>Cắt, làm giao diện website từ bản thiết kế (sử dụng Photoshop) trên nền hệ thống NukeViet.</li><li>Tham gia vào việc phát triển Front-End các ứng dụng nền web.</li><li>Thực hiện các công đoạn để dưa website vào hoạt động như upload dữ liệu lên host, xử lý lỗi, sự cố liên quan.</li><li>Chịu trách nhiệm về chất lượng, trải nghiệm người dùng, thẩm mỹ của sản phẩm trong khi sản phẩm hoạt động Tham mưu, tư vấn về chất lượng, thẩm mỹ, trải nghiệm người dùng về các sản phẩm.</li><li>Đảm bảo website theo các tiêu chuẩn web (W3c, XHTML, CSS 3.0, Tableless, no inline style, … ).</li><li>Đảm bảo website hiển thị đúng trên tất cả các trình duyệt.</li><li>Đảm bảo website theo chuẩn “Responsive Web Design.</li><li>Đảm bảo việc đưa sản phẩm thiết kế đến người dùng cuối cùng một cách chính xác và đẹp.</li><li>Thực hiện các công việc theo sự phân công của cấp trên.</li><li>Chịu trách nhiệm về chất lượng và tiến độ công việc.</li></ul><br /><span style=\"font-size:16px;\"><strong>3. Yêu cầu:</strong></span><ul><li>Có kiến thức cơ bản về thiết kế website: Am hiểu các dạng layout, thành phần của một website.</li><li>Hiểu rõ và nắm chắc cách làm Theme/Template.</li><li>Sử dụng thành thạo HTML5, CSS3 &amp; Javascrip/Jquery và Xtemplate</li><li>Khả năng chuyển PSD sang NukeViet tốt.</li><li>Biết đưa website lên host, xử lý lỗi, sự cố liên quan.</li><li>Chịu trách nhiệm về chất lượng và tiến độ công việc phụ trách.</li><li>Khả năng sáng tạo, tính thẩm mỹ tốt.</li><li>Đam mê công việc về web.</li></ul><br /><em><strong>Ưu tiên các ứng viên:</strong></em><ul><li>Có kiến thức cơ bản về quản trị website NukeViệt.</li><li>Am hiểu về Responsive và có thể thiết kế giao diện, layout trên mobile (Boostrap).</li><li>Sử dụng và nắm rõ các tính năng, block thường dùng của NukeViet.</li><li>Biết sử dụng git để quản lý source code (nếu ứng viên chưa biết công ty sẽ đào tạo thêm).</li><li>Có khả năng giao tiếp với khách hàng (Trực tiếp, điện thoại, email).</li><li>Có khả năng làm việc độc lập và làm việc theo nhóm.</li><li>Có tinh thần trách nhiệm cao và chủ động trong công việc.</li><li>Có khả năng trình bày ý tưởng.</li></ul><br /><span style=\"font-size:16px;\"><strong>4. Quyền lợi:</strong></span><ul><li>Lương thoả thuận, trả qua ATM.</li><li>Thưởng theo dự án, các ngày lễ tết.</li><li>Hưởng các chế độ khác theo quy định của công ty và pháp luật: Bảo hiểm y tế, bảo hiểm xã hội...</li></ul><br /><span style=\"font-size:16px;\"><strong>5. Thời gian làm việc:</strong></span> Toàn thời gian cố định hoặc làm online.<br /><br /><span style=\"font-size:16px;\"><strong>6. Hạn nộp hồ sơ:</strong></span> Không hạn chế, vui lòng kiểm tra tại <a href=\"http://vinades.vn/vi/news/Tuyen-dung/\">http://vinades.vn/vi/news/Tuyen-dung/</a><br /><br /><span style=\"font-size:16px;\"><strong>7. Cách thức đăng ký dự tuyển:</strong></span> Làm Hồ sơ xin việc<em><strong> (download tại đây: <strong><a href=\"http://vinades.vn/vi/download/Tai-lieu/Ban-khai-so-yeu-ly-lich-ky-thuat-vien/\" target=\"_blank\"><u>Mẫu lý lịch ứng viên</u></a></strong>)</strong></em> và gửi về hòm thư <a href=\"mailto:tuyendung@vinades.vn\">tuyendung@vinades.vn</a><br /><br /><span style=\"font-size:16px;\"><strong>8. Hồ sơ bao gồm:</strong></span><ul><li>Đơn xin việc: Tự biên soạn.</li><li>Thông tin ứng viên: Theo mẫu của VINADES.,JSC</li></ul>&nbsp;<p><strong>Chi tiết vui lòng tham khảo tại:</strong> <a href=\"http://vinades.vn/vi/news/Tuyen-dung/\" target=\"_blank\">http://vinades.vn/vi/news/Tuyen-dung/</a><br /><br /><strong>Mọi thắc mắc vui lòng liên hệ:</strong></p><blockquote><p><strong>Công ty cổ phần phát triển nguồn mở Việt Nam.</strong><br />Trụ sở chính: Phòng 1706 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.</p><div>- Tel: +84-24-85872007 - Fax: +84-24-35500914<br />- Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a> - Website: <a href=\"http://www.vinades.vn/\">http://www.vinades.vn</a></div></blockquote>', NULL, '', '', NULL, 2, '', 0, 1, 1, 1), 
(6, '', '', 'Cả hội trường như vỡ òa, rộn tiếng vỗ tay, tiếng cười nói chúc mừng các nhà khoa học, các nhóm tác giả đoạt Giải thưởng Nhân tài Đất Việt năm 2011. Năm thứ 7 liên tiếp, Giải thưởng đã phát hiện và tôn vinh nhiều tài năng của đất nước.<div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/01_b7d3f.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Sân khấu trước lễ trao giải.</span></div><div> &nbsp;</div><div align=\"center\"> &nbsp;</div><div align=\"left\"> Cơ cấu Giải thưởng của Nhân tài Đất Việt 2011 trong lĩnh vực CNTT bao gồm 2 hệ thống giải dành cho “Sản phẩm có tiềm năng ứng dụng” và “Sản phẩm đã ứng dụng rộng rãi trong thực tế”. Mỗi hệ thống giải sẽ có 1 giải Nhất, 1 giải Nhì và 1 giải Ba với trị giá giải thưởng tương đương là 100 triệu đồng, 50 triệu đồng và 30 triệu đồng cùng phần thưởng của các đơn vị tài trợ.</div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/03_f19bd.jpg\" width=\"350\" /></div> <div align=\"center\"> Nhiều tác giả, nhóm tác giả đến lễ trao giải từ rất sớm.</div></div><p> Giải thưởng Nhân tài Đất Việt 2011 trong lĩnh vực Khoa học Tự nhiên được gọi chính thức là Giải thưởng Khoa học Tự nhiên Việt Nam sẽ có tối đa 6 giải, trị giá 100 triệu đồng/giải dành cho các lĩnh vực: Toán học, Cơ học, Vật lý, Hoá học, Các khoa học về sự sống, Các khoa học về trái đất (gồm cả biển) và môi trường, và các lĩnh vực khoa học liên ngành hoặc đa ngành của hai hoặc nhiều ngành nói trên. Viện Khoa học và Công nghệ Việt Nam thành lập Hội đồng giám khảo gồm các nhà khoa học tự nhiên hàng đầu trong nước để thực hiện việc đánh giá và trao giải.</p><div> Sau thành công của việc trao Giải thưởng Nhân tài Đất Việt trong lĩnh vực Y dược năm 2010, Ban Tổ chức tiếp tục tìm kiếm những chủ nhân xứng đáng cho Giải thưởng này trong năm 2011.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/07_78b85.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nguyên Tổng Bí thư BCH TW Đảng Cộng sản Việt Nam Lê Khả Phiêu tới&nbsp;dự Lễ trao giải.</span></div><div> &nbsp;</div><div> 45 phút trước lễ trao giải, không khí tại Cung Văn hóa Hữu nghị Việt - Xô đã trở nên nhộn nhịp. Sảnh phía trước Cung gần như chật kín. Rất đông bạn trẻ yêu thích công nghệ thông tin, sinh viên các trường đại học đã đổ về đây, cùng với đó là những bó hoa tươi tắn sẽ được dành cho các tác giả, nhóm tác giả đoạt giải.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/09_aef87.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Phó Chủ tịch nước CHXHCN Việt Nam Nguyễn Thị Doan.</span></div><div> &nbsp;</div><div> Các vị khách quý cũng đến từ rất sớm. Tới tham dự lễ trao giải năm nay có ông Lê Khả Phiêu, nguyên Tổng Bí thư BCH TW Đảng Cộng sản Việt Nam; bà Nguyễn Thị Doan, Phó Chủ tịch nước CHXHCN Việt Nam; ông Vũ Oanh, nguyên Ủy viên Bộ Chính trị, nguyên Chủ tịch Hội Khuyến học Việt Nam; ông Nguyễn Bắc Son, Bộ trưởng Bộ Thông tin và Truyền thông; ông Đặng Ngọc Tùng, Chủ tịch Tổng Liên đoàn lao động Việt Nam; ông Phạm Văn Linh, Phó trưởng ban Tuyên giáo Trung ương; ông Đỗ Trung Tá, Phái viên của Thủ tướng Chính phủ về CNTT, Chủ tịch Hội đồng Khoa học công nghệ quốc gia; ông Nguyễn Quốc Triệu, nguyên Bộ trưởng Bộ Y tế, Trưởng Ban Bảo vệ Sức khỏe TƯ; bà Cù Thị Hậu, Chủ tịch Hội người cao tuổi Việt Nam; ông Lê Doãn Hợp, nguyên Bộ trưởng Bộ Thông tin Truyền thông, Chủ tịch Hội thông tin truyền thông số…</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/08_ba46c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Bộ trưởng Bộ Thông tin và Truyền thông Nguyễn Bắc Son.</span></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/06_29592.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Giáo sư - Viện sỹ Nguyễn Văn Hiệu.</span></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/04_051f2.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nguyên Bộ trưởng Bộ Y tế Nguyễn Quốc Triệu.</span></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/05_c7ea4.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Ông Vũ Oanh, nguyên Ủy viên Bộ Chính trị, nguyên Chủ tịch Hội Khuyến học Việt Nam.</span></div><p> Do tuổi cao, sức yếu hoặc bận công tác không đến tham dự lễ trao giải nhưng Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang cũng gửi lẵng hoa đến chúc mừng lễ trao giải.</p><div> Đúng 20h, Lễ trao giải bắt đầu với bài hát “Nhân tài Đất Việt” do ca sỹ Thái Thùy Linh cùng ca sĩ nhí và nhóm múa biểu diễn. Các nhóm tác giả tham dự Giải thưởng năm 2011 và những tác giả của các năm trước từ từ bước ra sân khấu trong tiếng vỗ tay tán dương của khán giả.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/12_74abf.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN15999_3e629.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Tiết mục mở màn Lễ trao giải.</span></div><p> Trước Lễ trao giải Giải thưởng Nhân tài Đất Việt năm 2011, Đại tướng Võ Nguyên Giáp, Chủ tịch danh dự Hội Khuyến học Việt Nam, đã gửi thư chúc mừng, khích lệ Ban tổ chức Giải thưởng cũng như các nhà khoa học, các tác giả tham dự.</p><blockquote> <p> <em><span style=\"FONT-STYLE: italic\">Hà Nội, ngày 16 tháng 11 năm 2011</span></em></p> <div> <em>Giải thưởng “Nhân tài đất Việt” do Hội Khuyến học Việt Nam khởi xướng đã bước vào năm thứ bảy (2005 - 2011) với ba lĩnh vực: Công nghệ thông tin, Khoa học tự nhiên và Y dược.</em></div></blockquote><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/thuDaituong1_767f4.jpg\" style=\"MARGIN: 5px\" width=\"400\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Thư của Đại tướng Võ Nguyên Giáp gửi BTC Giải thưởng Nhân tài đất Việt.</span></div><blockquote> <p> <em>Tôi gửi lời chúc mừng các nhà khoa học và các thí sinh được nhận giải thưởng “Nhân tài đất Việt” năm nay.</em></p> <p> <em>Mong rằng, các sản phẩm và các công trình nghiên cứu được trao giải sẽ được tiếp tục hoàn thiện và được ứng dụng rộng rãi trong đời sống, đem lại hiệu quả kinh tế và xã hội thiết thực.</em></p> <p> <em>Nhân ngày “Nhà giáo Việt Nam”, chúc Hội Khuyến học Việt nam, chúc các thầy giáo và cô giáo, với tâm huyết và trí tuệ của mình, sẽ đóng góp xứng đáng vào công cuộc đổi mới căn bản và toàn diện nền giáo dục nước nhà, để cho nền giáo dục Việt Nam thực sự là cội nguồn của nguyên khí quốc gia, đảm bảo cho mọi nhân cách và tài năng đất Việt được vun đắp và phát huy vì sự trường tồn, sự phát triển tiến bộ và bền vững của đất nước trong thời đại toàn cầu hóa và hội nhập quốc tế.</em></p> <p> <em>Chào thân ái,</em></p> <p> <strong><em>Chủ tịch danh dự Hội Khuyến học Việt Nam</em></strong></p> <p> <strong><em>Đại tướng Võ Nguyên Giáp</em></strong></p></blockquote><p> Phát biểu khai mạc Lễ trao giải, Nhà báo Phạm Huy Hoàn, TBT báo điện tử Dân trí, Trưởng Ban tổ chức, bày tỏ lời cám ơn chân thành về những tình cảm cao đẹp và sự quan tâm chăm sóc của Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang đã và đang dành cho Nhân tài Đất Việt.</p><div> Nhà báo Phạm Huy Hoàn nhấn mạnh, Giải thưởng Nhân tài Đất Việt suốt 7 năm qua đều nhận được sự quan tâm của các vị lãnh đạo Đảng, Nhà nước và của toàn xã hội. Tại Lễ trao giải, Ban tổ chức luôn có vinh dự được đón tiếp&nbsp;các vị lãnh đạo&nbsp; Đảng và Nhà nước đến dự và trực tiếp trao Giải thưởng.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/15_4670c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Trưởng Ban tổ chức Phạm Huy Hoàn phát biểu khai mạc buổi lễ.</span></div><p> Năm 2011, Giải thưởng có 3 lĩnh vực được xét trao giải là CNTT, Khoa học tự nhiên và Y dược. Lĩnh&nbsp; vực CNTT đã đón nhận 204 sản phẩm tham dự từ mọi miền đất nước và cả nước ngoài như thí sinh Nguyễn Thái Bình từ bang California - Hoa Kỳ và một thí sinh ở Pháp cũng đăng ký tham gia.</p><div> “Cùng với lĩnh vực CNTT, năm nay, Hội đồng khoa học của Viện khoa học và công nghệ Việt Nam và Hội đồng khoa học - Bộ Y tế tiếp tục giới thiệu những nhà khoa học xuất&nbsp; sắc, có công trình nghiên cứu đem lại nhiều lợi ích cho xã hội trong lĩnh vực khoa học tự nhiên và lĩnh vực y dược. Đó là những bác sĩ tài năng, những nhà khoa học mẫn tuệ, những người đang ngày đêm thầm lặng cống hiến trí tuệ sáng tạo của mình cho xã hội trong công cuộc xây dựng đất nước.” - nhà báo Phạm Huy Hoàn nói.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/14_6e18f.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nhà báo Phạm Huy Hoàn, TBT báo điện tử Dân trí, Trưởng BTC Giải thưởng và ông Phan Hoàng Đức, Phó TGĐ Tập đoàn VNPT nhận lẵng hoa chúc mừng của Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang.</span></div><p> Cũng theo Trưởng Ban tổ chức Phạm Huy Hoàn, đến nay, vị Chủ tịch danh dự đầu tiên của Hội Khuyến học Việt Nam, Đại tướng Võ Nguyên Giáp, đã bước qua tuổi 100 nhưng vẫn luôn dõi theo và động viên từng bước phát triển của Giải thưởng Nhân tài Đất Việt. Đại tướng luôn quan tâm chăm sóc Giải thưởng ngay từ khi Giải thưởng&nbsp; mới ra đời cách đây 7 năm.</p><p> Trước lễ trao giải, Đại tướng Võ Nguyên Giáp đã gửi thư chúc mừng, động viên Ban tổ chức. Trong thư, Đại tướng viết: “Mong rằng, các sản phẩm và các công trình nghiên cứu được trao giải sẽ được tiếp tục hoàn thiện và được ứng dụng rộng rãi trong đời sống, đem lại hiệu quả kinh tế và xã hội thiết thực.</p><p> Sau phần khai mạc, cả hội trường hồi hội chờ đợi phút vinh danh các nhà khoa học và các tác giả, nhóm tác giả đoạt giải.</p><div> <span style=\"FONT-WEIGHT: bold\">* Giải thưởng Khoa học Tự nhiên Việt Nam </span>thuộc về 2 nhà khoa học GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ - Viện Vật lý, Viện Khoa học công nghệ Việt Nam với công trình “Nghiên cứu cấu trúc hạt nhân và các phản ứng hạt nhân”.</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/khtn_d4aae.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><p> Hai nhà khoa học đã tiến hành thành công các nghiên cứu về phản ứng hạt nhân với nơtron, phản ứng quang hạt nhân, quang phân hạch và các phản ứng hạt nhân khác có cơ chế phức tạp trên các máy gia tốc như máy phát nơtron, Microtron và các máy gia tốc thẳng của Việt Nam và Quốc tế. Các nghiên cứu này đã góp phần làm sáng tỏ cấu trúc hạt nhân và cơ chế phản ứng hạt nhân, đồng thời cung cấp nhiều số liệu hạt nhân mới có giá trị cho Kho tàng số liệu hạt nhân.</p><p> GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ đã khai thác hiệu quả hai máy gia tốc đầu tiên của Việt Nam là máy phát nơtron NA-3-C và Microtron MT-17 trong nghiên cứu cơ bản, nghiên cứu ứng dụng và đào tạo nhân lực. Trên cơ sở các thiết bị này, hai nhà khoa học đã tiến hành thành công những nghiên cứu cơ bản thực nghiệm đầu tiên về phản ứng hạt nhân ở Việt Nam; nghiên cứu và phát triển các phương pháp phân tích hạt nhân hiện đại và áp dụng thành công ở Việt Nam.</p><div> Bà Nguyễn Thị Doan, Phó Chủ tịch nước CHXHCNVN và Giáo sư - Viện sỹ Nguyễn Văn Hiệu trao giải thưởng cho 2 nhà khoa học.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/khtn2_e2865.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Phó Chủ tịch nước CHXHCNVN Nguyễn Thị Doan và Giáo sư - Viện sỹ Nguyễn Văn Hiệu trao giải thưởng cho 2 nhà khoa học GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ.</span></div><p> GS.VS Nguyễn Văn Hiệu chia sẻ: “Cách đây không lâu, Chính phủ đã ký quyết định xây dựng nhà máy điện hạt nhân trong điều kiện đất nước còn nhỏ bé, nghèo khó và vì thế việc đào tạo nhân lực là nhiệm vụ số 1 hiện nay. Rất may, Việt Nam có 2 nhà khoa học cực kỳ tâm huyết và nổi tiếng trong cả nước cũng như trên thế giới. Hội đồng khoa học chúng tôi muốn xướng tên 2 nhà khoa học này để Chính phủ huy động cùng phát triển xây dựng nhà máy điện hạt nhân.”</p><p> GS.VS Hiệu nhấn mạnh, mặc dù điều kiện làm việc của 2 nhà khoa học không được quan tâm, làm việc trên những máy móc cũ kỹ được mua từ năm 1992 nhưng 2 ông vẫn xay mê cống hiến hết mình cho lĩnh Khoa học tự nhiên Việt Nam.</p><p> <span style=\"FONT-WEIGHT: bold\">* Giải thưởng Nhân tài Đất Việt trong lĩnh vực Y Dược:</span> 2 giải</p><div> <span style=\"FONT-WEIGHT: bold\">1.</span> Nhóm nghiên cứu của Bệnh viện Hữu nghị Việt - Đức với công trình <span style=\"FONT-STYLE: italic\">“Nghiên cứu triển khai ghép gan, thận, tim lấy từ người cho chết não”</span>.</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y_3dca2.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><div> &nbsp;</div><div> Tại bệnh viện Việt Đức, tháng 4/2011, các ca ghép tạng từ nguồn cho là người bệnh chết não được triển khai liên tục. Với 4 người cho chết não hiến tạng, bệnh viện đã ghép tim cho một trường hợp,&nbsp;2 người được ghép gan, 8 người được ghép thận, 2 người được ghép van tim và tất cả các ca ghép này đều thành công, người bệnh được ghép đã có một cuộc sống tốt hơn với tình trạng sức khỏe ổn định.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y2_cb5a1.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nguyên Tổng Bí Ban chấp hành TW Đảng CSVN Lê Khả Phiêu và ông Vũ Văn Tiền, Chủ tịch Hội đồng quản trị Ngân hàng An Bình trao giải thưởng cho nhóm nghiên cứu của BV Hữu nghị Việt - Đức.</span></div><p> Công trong việc ghép tạng từ người cho chết não không chỉ thể hiện năng lực, trình độ, tay nghề của bác sĩ Việt Nam mà nó còn mang một ý nghĩa nhân văn to lớn, mang một thông điệp gửi đến những con người giàu lòng nhân ái với nghĩa cử cao đẹp đã hiến tạng để cứu sống những người bệnh khác.</p><p> <span style=\"FONT-WEIGHT: bold\">2.</span> Hội đồng ghép tim Bệnh viện Trung ương Huế với công trình nghiên cứu <span style=\"FONT-STYLE: italic\">“Triển khai ghép tim trên người lấy từ người cho chết não”</span>.</p><div> Đề tài được thực hiện dựa trên ca mổ ghép tim thành công lần đầu tiên ở Việt Nam của chính 100% đội ngũ y, bác sĩ của Bệnh viện Trung ương Huế đầu tháng 3/2011. Bệnh nhân được ghép tim thành công là anh Trần Mậu Đức (26 tuổi, ở phường Phú Hội, TP. Huế).</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y3_7768c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Hội đồng ghép tim BV Trung ương Huế nhận Giải thưởng Nhân tài Đất Việt.</span></div><p> Ghép tim từ người cho chết não đến người bị bệnh tim cần được ghép tim phải đảm bảo các yêu cầu: đánh giá chức năng các cơ quan; đánh giá tương hợp miễn dịch và phát hiện nguy cơ tiềm ẩn có thể xảy ra trong và sau khi ghép tim để từ đó có phương thức điều trị thích hợp. Có tới 30 xét nghiệm cận lâm sàng trung và cao cấp tiến hành cho cả người cho tim chết não và người sẽ nhận ghép tim tại hệ thống labo của bệnh viện.</p><p> ---------------------</p><p> <span style=\"FONT-WEIGHT: bold\">* Giải thưởng Nhân tài đất Việt Lĩnh vực Công nghệ thông tin.</span></p><p> <span style=\"FONT-STYLE: italic\">Hệ thống sản phẩm đã ứng dụng thực tế:</span></p><p> <span style=\"FONT-STYLE: italic\">Giải Nhất:</span> Không có.</p><p> <span style=\"FONT-STYLE: italic\">Giải Nhì:</span> Không có</p><p> <span style=\"FONT-STYLE: italic\">Giải Ba:</span> 3 giải, mỗi giải trị giá 30 triệu đồng.</p><div> <span style=\"FONT-WEIGHT: bold\">1.</span> <span style=\"FONT-STYLE: italic\">“Bộ cạc xử lý tín hiệu HDTV”</span> của nhóm HD Việt Nam.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/hdtv_13b10.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nhóm HDTV Việt Nam lên nhận giải.</span></div><p> Đây là bộ cạc xử lý tín hiệu HDTV đầu tiên tại Việt Nam đạt tiêu chuẩn OpenGear. Bộ thiết bị bao gồm 2 sản phẩm là cạc khuếch đại phân chia tín hiệu HD DA và cạc xử lý tín hiệu HD FX1. Nhờ bộ cạc này mà người sử dụng cũng có thể điều chỉnh mức âm thanh hoặc video để tín hiệu của kênh tuân theo mức chuẩn và không phụ thuộc vào chương trình đầu vào.</p><div> <span style=\"FONT-WEIGHT: bold; FONT-STYLE: italic\">2.</span> <span style=\"FONT-STYLE: italic\">“Mã nguồn mở NukeViet”</span> của nhóm tác giả Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC).</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" alt=\"NukeViet nhận giải ba Nhân tài đất Việt 2011\" src=\"/uploads/news/nukeviet-nhantaidatviet2011.jpg\" style=\"margin: 5px; width: 450px; height: 301px;\" /></div></div><p> NukeViet là CMS mã nguồn mở đầu tiên của Việt Nam có quá trình phát triển lâu dài nhất, có lượng người sử dụng đông nhất. Hiện NukeViet cũng là một trong những mã nguồn mở chuyên nghiệp đầu tiên của Việt Nam, cơ quan chủ quản của NukeViet là VINADES.,JSC - đơn vị chịu trách nhiệm phát triển NukeViet và triển khai NukeViet thành các ứng dụng cụ thể cho doanh nghiệp.</p><div> <span style=\"FONT-WEIGHT: bold\">3.</span> <span style=\"FONT-STYLE: italic\">“Hệ thống ngôi nhà thông minh homeON”</span> của nhóm Smart home group.</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16132_82014.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><p> Sản phẩm là kết quả từ những nghiên cứu miệt mài nhằm xây dựng một ngôi nhà thông minh, một cuộc sống xanh với tiêu chí: An toàn, tiện nghi, sang trọng và tiết kiệm năng lượng, hưởng ứng lời kêu gọi tiết kiệm năng lượng của Chính phủ.&nbsp;</p><p> <strong><span style=\"FONT-STYLE: italic\">* Hệ thống sản phẩm có tiềm năng ứng dụng:</span></strong></p><p> <span style=\"FONT-STYLE: italic\">Giải Nhất: </span>Không có.</p><div> <span style=\"FONT-STYLE: italic\">Giải Nhì:</span> trị giá 50 triệu đồng: <span style=\"FONT-STYLE: italic\">“Dịch vụ Thông tin và Tri thức du lịch ứng dụng cộng nghệ ngữ nghĩa - iCompanion”</span> của nhóm tác giả SIG.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/nhi_7eee0.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nhóm tác giả SIG nhận giải Nhì Nhân tài đất Việt 2011 ở hệ thống sản phẩm có tiềm năng ứng dụng.</span></div><p> ICompanion là hệ thống thông tin đầu tiên ứng dụng công nghệ ngữ nghĩa trong lĩnh vực du lịch - với đặc thù khác biệt là cung cấp các dịch vụ tìm kiếm, gợi ý thông tin “thông minh” hơn, hướng người dùng và kết hợp khai thác các tính năng hiện đại của môi trường di động.</p><p> Đại diện nhóm SIG chia sẻ: “Tinh thần sáng tạo và lòng khát khao muốn được tạo ra các sản phẩm mới có khả năng ứng dụng cao trong thực tiễn luôn có trong lòng của những người trẻ Việt Nam. Cảm ơn ban tổ chức và những nhà tài trợ đã giúp chúng tôi có một sân chơi thú vị để khuyến khích và chắp cánh thực hiện ước mơ của mình. Xin cảm ơn trường ĐH Bách Khoa đã tạo ra một môi trường nghiên cứu và sáng tạo, gắn kết 5 thành viên trong nhóm.”</p><p> <span style=\"FONT-STYLE: italic\">Giải Ba:</span> 2 giải, mỗi giải trị giá 30 triệu đồng.</p><div> <span style=\"FONT-WEIGHT: bold\">1. </span><span style=\"FONT-STYLE: italic\">“Bộ điều khiển IPNET”</span> của nhóm IPNET</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16149_ed58d.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nhà báo Phạm Huy Hoàn, Trưởng Ban Tổ chức Giải thưởng NTĐV, Tổng Biên tập báo điện tử Dân trí và ông Tạ Hữu Thanh - Phó TGĐ Jetstar Pacific trao giải cho nhóm IPNET.</span></div><p> Bằng cách sử dụng kiến thức thiên văn học để tính giờ mặt trời lặn và mọc tại vị trí cần chiếu sáng được sáng định bởi kinh độ, vĩ độ cao độ, hàng ngày sản phẩm sẽ tính lại thời gian cần bật/tắt đèn cho phù hợp với giờ mặt trời lặn/mọc.</p><div> <span style=\"FONT-WEIGHT: bold\">2.</span> <span style=\"FONT-STYLE: italic\">“Hệ thống lập kế hoạch xạ trị ung thư quản lý thông tin bệnh nhân trên web - LYNX”</span> của nhóm LYNX.</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/3tiem-nang_32fee.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><p> Đây là loại phần mềm hoàn toàn mới ở Việt Nam, là hệ thống lập kế hoạch và quản lý thông tin của bệnh nhân ung thư qua Internet (LYNX) dựa vào nền tảng Silverlight của Microsoft và kiến thức chuyên ngành Vật lý y học. LYNX giúp ích cho các nhà khoa học, bác sĩ, kỹ sư vật lý, bệnh nhân và mọi thành viên trong việc quản lý và theo dõi hệ thống xạ trị ung thư một cách tổng thể. LYNX có thể được sử dụng thông qua các thiết bị như máy tính cá nhân, máy tính bảng… và các trình duyệt Internet Explorer, Firefox, Chrome…</p><div> Chương trình trao giải đã được truyền hình trực tiếp trên VTV2 - Đài Truyền hình Việt Nam và tường thuật trực&nbsp;tuyến trên báo điện tử Dân trí từ 20h tối 20/11/2011.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/NVH0545_c898e.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/NVH0560_c995c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16199_36a5c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <div align=\"center\"> <table border=\"1\" cellpadding=\"0\" cellspacing=\"0\" width=\"90%\"> <tbody> <tr> <td> <div> <span style=\"FONT-WEIGHT: bold\"><span style=\"FONT-WEIGHT: normal; FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Khởi xướng từ năm 2005, Giải thưởng Nhân tài Đất Việt đã phát hiện và tôn vinh nhiều tài năng trong lĩnh vực CNTT-TT, Khoa học tự nhiên và Y dược, trở thành một sân chơi bổ ích cho những người yêu thích CNTT. Mỗi năm, Giải thưởng ngày càng thu hút số lượng tác giả và sản phẩm tham gia đông đảo và nhận được sự quan tâm sâu sắc của lãnh đạo Đảng, Nhà nước cũng như công chúng.</span></span></div> <div> <span style=\"FONT-WEIGHT: bold\">&nbsp;</span></div> <div> <span style=\"FONT-WEIGHT: bold\"><span style=\"FONT-WEIGHT: normal; FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Đối tượng tham gia Giải thưởng trong lĩnh vực CNTT là những người Việt Nam ở mọi lứa tuổi, đang sinh sống trong cũng như ngoài nước. Năm 2006, Giải thưởng có sự tham gia của thí sinh đến từ 8 nước trên thế giới và 40 tỉnh thành của Việt Nam. Từ năm 2009, Giải thưởng được mở rộng sang lĩnh vực Khoa học tự nhiên, và năm 2010 là lĩnh vực Y dược, vinh danh những nhà khoa học trong các lĩnh vực này.</span>&nbsp;</span></div> <div> <span style=\"FONT-WEIGHT: bold\">&nbsp;</span></div> </td> </tr> </tbody> </table> </div></div>', NULL, '', '', NULL, 2, '', 0, 1, 1, 1), 
(7, '', '', '<div>Có hiệu lực từ ngày 20/1/2015, Thông tư này thay thế cho Thông tư 41/2009/TT-BTTTT (Thông tư 41) ngày 30/12/2009 ban hành Danh mục các sản phẩm phần mềm nguồn mở đáp ứng yêu cầu sử dụng trong cơ quan, tổ chức nhà nước.<br /><br />Sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước trong Thông tư 41/2009/TT-BTTTT vừa được Bộ TT&amp;TT ban hành, là những&nbsp;sản phẩm đã đáp ứng các tiêu chí về tính năng kỹ thuật cũng như tính mở và bền vững, và NukeViet là một trong số đó.</div><p>Cụ thể, theo Thông tư 20, sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước phải đáp các tiêu chí về chức năng, tính năng kỹ thuật bao gồm: phần mềm có các chức năng, tính năng kỹ thuật phù hợp với các yêu cầu nghiệp vụ hoặc các quy định, hướng dẫn tương ứng về ứng dụng CNTT trong các cơ quan, tổ chức nhà nước; phần mềm đáp ứng được yêu cầu tương thích với hệ thống thông tin, cơ sở dữ liệu hiện có của các cơ quan, tổ chức.</p><p>Bên cạnh đó, các sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước còn phải đáp ứng tiêu chí về tính mở và tính bền vững của phần mềm. Cụ thể, phần mềm phải đảm bảo các quyền: tự do sử dụng phần mềm không phải trả phí bản quyền, tự do phân phối lại phần mềm, tự do sửa đổi phần mềm theo nhu cầu sử dụng, tự do phân phối lại phần mềm đã chỉnh sửa (có thể thu phí hoặc miễn phí); phần mềm phải có bản mã nguồn, bản cài đặt được cung cấp miễn phí trên mạng; có điểm ngưỡng thất bại PoF từ 50 điểm trở xuống và điểm mô hình độ chín nguồn mở OSMM từ 60 điểm trở lên.</p><p>Căn cứ những tiêu chuẩn trên, thông tư 20 quy định cụ thể Danh mục 31 sản phẩm thuộc 11 loại phần mềm được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước.&nbsp;NukeViet thuộc danh mục hệ quản trị nội dung nguồn mở. Chi tiết thông tư và danh sách 31 sản phẩm phần mềm nguồn mở được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước có&nbsp;<a href=\"http://vinades.vn/vi/download/van-ban-luat/Thong-tu-20-2014-TT-BTTTT/\" target=\"_blank\">tại đây</a>.</p><p>Thông tư 20/2014/TT-BTTTT quy định rõ: Các cơ quan, tổ chức nhà nước khi có nhu cầu sử dụng vốn nhà nước để đầu tư xây dựng, mua sắm hoặc thuê sử dụng các loại phần mềm có trong Danh mục hoặc các loại phần mềm trên thị trường đã có sản phẩm phần mềm nguồn mở tương ứng thỏa mãn các tiêu chí trên (quy định tại Điều 3 Thông tư 20) thì phải&nbsp;ưu tiên lựa chọn các sản phẩm phần mềm nguồn mở tương ứng, đồng thời phải thể hiện rõ sự ưu tiên này trong các tài liệu&nbsp;như thiết kế sơ bộ, thiết kế thi công, kế hoạch đấu thầu, kế hoạch đầu tư, hồ sơ mời thầu, yêu cầu chào hàng, yêu cầu báo giá hoặc các yêu cầu mua sắm khác.</p><p>Đồng thời,&nbsp;các cơ quan, tổ chức nhà nước phải đảm bảo không đưa ra các yêu cầu, điều kiện, tính năng kỹ thuật có thể dẫn đến việc loại bỏ các sản phẩm phần mềm nguồn mở&nbsp;trong các tài liệu như thiết kế sơ bộ, thiết kế thi công, kế hoạch đấu thầu, kế hoạch đầu tư, hồ sơ mời thầu, yêu cầu chào hàng, yêu cầu báo giá hoặc các yêu cầu mua sắm khác.</p><p>Như vậy, sau thông tư số 08/2010/TT-BGDĐT của Bộ GD&amp;ĐT ban hành ngày 01-03-2010 quy định về sử dụng phần mềm tự do mã nguồn mở trong các cơ sở giáo dục trong đó đưa NukeViet vào danh sách các mã nguồn mở được khuyến khích sử dụng trong giáo dục, thông tư 20/2014/TT-BTTTT đã mở đường cho NukeViet vào sử dụng cho các cơ quan, tổ chức nhà nước. Các đơn vị hỗ trợ triển khai NukeViet cho các cơ quan nhà nước có thể sử dụng quy định này để được ưu tiên triển khai cho các dự án website, cổng thông tin cho các cơ quan, tổ chức nhà nước.<br /><br />Thời gian tới, Công ty cổ phần phát triển nguồn mở Việt Nam (<a href=\"http://vinades.vn/\" target=\"_blank\">VINADES.,JSC</a>) - đơn vị chủ quản của NukeViet - sẽ cùng với Ban Quản Trị NukeViet tiếp tục hỗ trợ các doanh nghiệp đào tạo nguồn nhân lực chính quy phát triển NukeViet nhằm cung cấp dịch vụ ngày một tốt hơn cho chính phủ và các cơ quan nhà nước, từng bước xây dựng và hình thành liên minh các doanh nghiệp phát triển NukeViet, đưa sản phẩm phần mềm nguồn mở Việt không những phục vụ tốt thị trường Việt Nam mà còn từng bước tiến ra thị trường khu vực và các nước đang phát triển khác trên thế giới nhờ vào lợi thế phần mềm nguồn mở đang được chính phủ nhiều nước ưu tiên phát triển.</p>', NULL, '', 'mic.gov.vn', NULL, 2, '', 0, 1, 1, 1), 
(8, '', '', '<div>Trong năm 2016, chúng tôi xác định là đơn vị sát cánh cùng các đơn vị giáo dục- là đơn vị xây dựng nhiều website cho ngành giáo dục nhất trên cả nước.<br  />Với phần mềm mã nguồn mở NukeViet hiện có nhiều lợi thế:<br  />+ Được Bộ giáo dục khuyến khích sử dụng.<br  />+ Được bộ thông tin truyền thông chỉ định sử dụng trong khối cơ quan nhà nước.<br  />+Được cục công nghệ thông tin ghi rõ tên sản phẩm NukeViet nên dùng theo hướng dẫn thực hiện CNTT 2015-2016.<br  />Chúng tôi cần các bạn góp phần xây dựng nền giáo dục nước nhà ngày càng phát triển.</div><div>&nbsp;</div><table align=\"left\" border=\"1\" cellpadding=\"20\" cellspacing=\"0\" class=\"table table-striped table-bordered table-hover\" style=\"width:100%;\" width=\"653\">	<tbody>		<tr>			<td style=\"width: 27.66%;\"><strong>Vị trí tuyển dụng:</strong></td>			<td style=\"width: 72.34%;\">Nhân viên kinh doanh</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Chức vụ:</strong></td>			<td style=\"width: 72.34%;\">Nhân viên</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Ngành nghề:</strong></td>			<td style=\"width: 72.34%;\"><strong>Sản phẩm:</strong><br  />			Cổng thông tin, website cho các phòng, sở giáo dục và đào tạo các trường học.</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Hình thức làm việc:</strong></td>			<td style=\"width: 72.34%;\">Toàn thời gian cố định</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Địa điểm làm việc:</strong></td>			<td style=\"width: 72.34%;\">Văn phòng công ty (Được đi công tác theo hợp đồng đã ký)</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Mức lương:</strong></td>			<td style=\"width: 72.34%;\">&nbsp;Lương cố định + Thưởng vượt doanh số + thưởng theo từng hợp đồng (từ 2-7%).</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Mô tả công việc:</strong></td>			<td style=\"width: 72.34%;\">Chúng tôi có khách hàng mục tiêu và danh sách khách hàng, công việc đòi hỏi ứng viên sử dụng thành thạo vi tính văn phòng, các phần mềm liên quan đến công việc và có laptop để phục vụ công việc.<br  />			- Sales Online, quảng bá ký kết, liên kết, với các đối tác qua INTERNET. Xây dưng mối quan hệ phát triển bền vững với các đối tác.<br  />			- Gọi điện, giới thiệu dịch vụ, sản phẩm của công ty đến đối tác.<br  />			- Xử lý các cuộc gọi của khách hàng liên quan đến, sản phẩm, dịch vụ công ty.<br  />			- Đàm phán, thương thuyết, ký kết hợp đồng với khách hàng đang có nhu cầu thiết kế website , SEO website , PR thương hiệu trên Internet&nbsp;<br  />			- Duy trì và chăm sóc mối quan hệ lâu dài với khách hàng, mở rộng khách hàng tiềm năng nhằm thúc đẩy doanh số bán hàng<br  />			- Hỗ trợ khách hàng khi được yêu cầu</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Số lượng cần tuyển:</strong></td>			<td style=\"width: 72.34%;\">05</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Quyền lợi được hưởng:</strong></td>			<td style=\"width: 72.34%;\">- Được đào tạo kĩ năng bán hàng, được công ty hỗ trợ tham gia khóa học bán hàng chuyên nghiệp.<br  />			- Lương cứng: 3.000.000 VNĐ+ hoa hồng dự án (2-7%/năm/hợp đồng). Lương trả qua ATM, được xét tăng lương 3 tháng một lần dựa trên doanh thu.<br  />			- Bậc lương xét trên năng lực bán hàng.<br  />			- Thưởng theo dự án, các ngày lễ tết.<br  />			- Hưởng các chế độ khác theo quy định của công ty và pháp luật: Bảo hiểm y tế, bảo hiểm xã hội.<br  />			- Cơ hội làm việc và gắn bó lâu dài trong công ty, được thưởng cổ phần nếu doanh thu tốt.</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Số năm kinh nghiệm:</strong></td>			<td style=\"width: 72.34%;\">Trên 6 tháng</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Yêu cầu bằng cấp:</strong></td>			<td style=\"width: 72.34%;\">Cao đẳng, Đại học</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Yêu cầu giới tính:</strong></td>			<td style=\"width: 72.34%;\">Không yêu cầu</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Yêu cầu độ tuổi:</strong></td>			<td style=\"width: 72.34%;\">Không yêu cầu</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Yêu cầu khác:</strong></td>			<td style=\"width: 72.34%;\">- Yêu thích và đam mê Internet Marketing, thích online, thương mại điện tử<br  />			- Giọng nói dễ nghe, không nói ngọng.<br  />			- Có khả năng giao tiếp qua điện thoại.<br  />			- Ngoại hình ưa nhìn là một lợi thế<br  />			- Có tính cẩn thận trong công việc, luôn cố gắng học hỏi.<br  />			- Kỹ năng sales online tốt.<br  />			-Trung thực, năng động, nhiệt tình,siêng năng, nhiệt huyết trong công việc.</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Hồ sơ bao gồm:</strong></td>			<td style=\"width: 72.34%;\"><strong>* Yêu cầu Hồ sơ:</strong><br  />			<strong>Cách thức đăng ký dự tuyển</strong>: Làm Hồ sơ xin việc (file mềm) và gửi về hòm thư <a href=\"mailto:tuyendung@vinades.vn\">tuyendung@vinades.vn</a><br  />			<br  />			<strong>Nội dung hồ sơ xin việc file mềm gồm</strong>:<br  />			<strong>+ Đơn xin việc:</strong>&nbsp;Theo hướng dẫn bên dưới.<br  />			<strong>+ Thông tin ứng viên:</strong>&nbsp;Theo mẫu của VINADES.,JSC <strong><em>(download tại đây:&nbsp;<a href=\"http://vinades.vn/vi/download/Tai-lieu/Ban-khai-so-yeu-ly-lich-kinh-doanh/\">Mẫu lý lịch ứng viên</a>)</em></strong><br  />			<strong>* Hồ sơ xin việc (Bản in thông thường) bao gồm</strong>:<br  />			- Giấy khám sức khoẻ của cơ quan y tế.<br  />			- Bản sao hộ khẩu (có công chứng)<br  />			- Bản sao giấy khai sinh (có công chứng)<br  />			- Bản sao quá trình học tập (bảng điểm tốt nghiệp), các văn -bằng chứng chỉ (có công chứng)<br  />			- Sơ yếu lý lịch có xác nhận của cơ quan công tác trước đó (nếu có) hoặc xác nhận của chính quyền địa phương nơi bạn đăng ký hộ khẩu thường trú.<br  />			- Thư giới thiệu (nếu có)<br  />			- Ảnh 4x6: 4 chiếc (đã bao gồm 1 chiếc gắn trên sơ yếu lý lịch).<br  />			<br  />			<strong>*Hướng dẫn</strong>:<br  />			- Với bản in của hồ sơ ứng tuyển, ứng viên sẽ phải nộp trước cho Ban tuyển dụng hoặc muộn nhất là mang theo khi có lịch phỏng vấn. Bản in sẽ không được trả lại ngay cả khi ứng viên không đạt yêu cầu.<br  />			- Nếu không thể bố trí thời gian phỏng vấn như sắp xếp của -Ban tuyển dụng, thí sinh cần thông báo ngay để được đổi lịch.<br  />			- Nếu có bất cứ thắc mắc gì bạn có thể liên hệ với Ms. Thu qua email: tuyendung@vinades.vn. Có thể gọi điện theo số điện thoại: 01255723353</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Hạn nộp hồ sơ:</strong></td>			<td style=\"width: 72.34%;\">Không hạn chế cho tới khi tuyển đủ.</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Hình thức nộp hồ sơ:</strong></td>			<td style=\"width: 72.34%;\">Qua Email</td>		</tr>		<tr>			<td colspan=\"2\" style=\"width:100.0%;\">			<h3>THÔNG TIN LIÊN HỆ</h3>			</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Điện thoại liên hệ:</strong></td>			<td style=\"width: 72.34%;\">01255723353- Ms. Thu</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Địa chỉ liên hệ:</strong></td>			<td style=\"width: 72.34%;\">Phòng 1706 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.</td>		</tr>		<tr>			<td style=\"width: 27.66%;\"><strong>Email liên hệ:</strong></td><td style=\"width: 72.34%;\">tuyendung@vinades.vn</td></tr></tbody></table>', NULL, '', '', NULL, 2, '', 0, 1, 1, 1), 
(9, '', '', '<p>Nếu bạn yêu thích công nghệ, thích kinh doanh hoặc lập trình web và mong muốn trải nghiệm, học hỏi, thậm chí là đi làm ngay từ khi còn ngồi trên ghế nhà trường, hãy tham gia chương trình thực tập sinh tại công ty VINADES.</p><p>Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC) là đơn vị chịu trách nhiệm chính trong việc phát triển phần mềm NukeViet và có nhiệm vụ hỗ trợ cộng đồng người dùng NukeViet &#91;<u><a href=\"http://vinades.vn/vi/about/history/\" target=\"_blank\">xem thêm giới thiệu về lịch sử hình thành VINADES</a></u>&#93;. Là công ty được thành lập từ cộng đồng phần mềm nguồn mở, hàng năm công ty dành những vị trí đặc biệt cho các bạn sinh viên được học tập, trải nghiệm, làm việc tại công ty.<br  />&nbsp;</p><h2><b>C</b><b>ác vị trí thực tập</b></h2><ul>	<li><strong>Kinh doanh:</strong> Cổng thông tin doanh nghiệp, Cổng thông tin giáo dục Edu Gate…</li>	<li><strong>Kỹ thuật:</strong> Chuyên viên đồ họa, Lập trình viên…</li></ul><h2><b>Quyền lợi của thực tập sinh</b></h2><ul>	<li>Được&nbsp;tiếp xúc với văn hóa doanh nghiệp, trải nghiệm trong môi trường làm việc chuyên nghiệp, năng động.</li>	<li>Được&nbsp;giao tiếp và học hỏi kiến thức từ những SEO, các lập trình viên chính của đội code NukeViet; qua đó&nbsp;nâng cao không chỉ kỹ năng chuyên môn liên quan đến công việc mà còn các kỹ năng mềm trong quá trình làm việc hàng ngày.</li>	<li>Có cơ hội tìm hiểu, phát triển định hướng của bản thân.</li>	<li>Tham gia các chương trình ngoại khóa, các hoạt động nội bộ của công ty.</li>	<li>Cơ&nbsp;hội được học việc để trở thành nhân viên chính thức nếu có kết quả thực tập tốt.</li>	<li>Thực tập không hưởng lương nhưng có thể được trả thù lao cho một số công việc được giao theo đơn hàng.</li></ul><h2><b>Thời gian làm việc</b></h2><ul>	<li>Toàn thời gian cố định hoặc làm online.</li>	<li>Thời gian làm việc là:&nbsp;8:00 – 17:00, Thứ hai – Thứ sáu</li>	<li>Ngày làm việc và thời gian làm việc có thể thay đổi linh hoạt tùy thuộc vào điều kiện của ứng viên và tình hình thực tế.</li></ul><h2><b>Đối tượng và điều kiện ứng tuyển</b></h2><p>Tất cả các bạn sinh viên năm cuối/mới tốt nghiệp các trường CĐ - ĐH đáp ứng được những yêu cầu sau:</p><ul>	<li>Sinh viên khối ngành kinh tế: yêu thích marketing online, mong muốn thực tập trong lĩnh vực kinh doanh phần mềm.</li>	<li>Sinh viên khối ngành kỹ thuật: yêu thích thiết kế, lập trình web.</li></ul><p>Có kỹ năng giao tiếp và tư duy logic tốt, năng động và ham học hỏi.</p><p>Có máy tính xách tay để làm việc.</p><p>Ưu tiên các ứng viên đam mê phần mềm nguồn mở, đặc biệt là các ứng viên đã từng tham gia và có bài viết diễn đàn NukeViet (<a href=\"http://forum.nukeviet.vn/\">forum.nukeviet.vn</a>).</p><h2><b>Cách thức ứng tuyển</b></h2><p>Gửi bản mềm đơn đăng ký ứng tuyển tới:&nbsp;<a href=\"mailto:tuyendung@vinades.vn\">tuyendung@vinades.vn</a>;</p><p>Tiêu đề mail ghi rõ: &#91;Họ tên&#93; –Ứng tuyển thực tập &#91;Bộ phận ứng tuyển&#93;.</p><p>Ví dụ: Lê Văn Nam –&nbsp;Ứng tuyển thực tập sinh bộ phận đồ họa</p><p>Hồ sơ bản cứng cần chuẩn bị (sẽ gửi sau nếu đạt yêu cầu) gồm:</p><ul>	<li>Giấy khám sức khoẻ của cơ quan y tế</li>	<li>Bản sao giấy khai sinh (có công chứng).</li>	<li>Bản sao quá trình học tập (bảng điểm tốt nghiệp), các văn bằng chứng chỉ (có công chứng) nếu đã tốt nghiệp.</li>	<li>Sơ yếu lý lịch có xác nhận của cơ quan công tác trước đó (nếu có) hoặc xác nhận của chính quyền địa phương nơi bạn đăng ký hộ khẩu thường trú.</li>	<li>Chứng minh thư (photo không cần công chứng).</li>	<li>Thư giới thiệu (nếu có)</li>	<li>Ảnh 4x6: 4 chiếc (đã bao gồm 1 chiếc gắn trên sơ yếu lý lịch).</li></ul><p><br  /><strong>Chi tiết vui lòng tham khảo tại:</strong>&nbsp;<a href=\"http://vinades.vn/vi/news/Tuyen-dung/\" target=\"_blank\">http://vinades.vn/vi/news/Tuyen-dung/</a><br  /><br  /><strong>Mọi thắc mắc vui lòng liên hệ:</strong></p><blockquote><p><strong>Công ty cổ phần phát triển nguồn mở Việt Nam.</strong><br  />Trụ sở chính: Phòng 1706 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.<br  /><br  />- Tel: +84-24-85872007 - Fax: +84-24-35500914<br  />- Email:&nbsp;<a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a>&nbsp;- Website:&nbsp;<a href=\"http://www.vinades.vn/\">http://www.vinades.vn</a></p></blockquote>', NULL, '', '', NULL, 2, '', 0, 1, 1, 1), 
(10, '', '', '<p>Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC) là đơn vị chịu trách nhiệm chính trong việc phát triển phần mềm NukeViet và có nhiệm vụ hỗ trợ cộng đồng người dùng NukeViet &#91;<u><a href=\"http://vinades.vn/vi/about/history/\" target=\"_blank\">xem thêm giới thiệu về lịch sử hình thành VINADES</a></u>&#93;.</p><p>Nếu bạn yêu thích phần mềm nguồn mở, triết lý của phần mềm tự do nguồn mở hoặc đơn giản là yêu NukeViet, hãy liên hệ ngay để gia nhập công ty VINADES, cùng chúng tôi phát triển NukeViet – Phần mềm nguồn mở Việt Nam – và tạo ra những sản phẩm web tuyệt vời cho cộng đồng.</p><h2><b>Các vị trí nhận học việc</b></h2><ul>	<li><strong>Kinh doanh:</strong> Cổng thông tin doanh nghiệp, Cổng thông tin giáo dục Edu Gate…</li>	<li><strong>Kỹ thuật:</strong> Chuyên viên đồ họa, Lập trình viên…</li></ul><h2><b>Quyền lợi của học viên</b></h2><ul>	<li>Được hưởng trợ cấp ăn trưa.</li>	<li>Được trợ cấp vé gửi xe.</li>	<li>Được hưởng lương khoán theo từng dự án (nếu có).</li>	<li>Được hỗ trợ học phí tham gia các khóa học nâng cao các kỹ năng (nếu có).</li>	<li>Được&nbsp;tiếp xúc với văn hóa doanh nghiệp, trải nghiệm trong môi trường làm việc chuyên nghiệp, năng động.</li>	<li>Được&nbsp;giao tiếp và học hỏi kiến thức từ những SEO, các lập trình viên chính của đội code NukeViet; qua đó&nbsp;nâng cao không chỉ kỹ năng chuyên môn liên quan đến công việc mà còn các kỹ năng mềm trong quá trình làm việc hàng ngày.</li>	<li>Tham gia các chương trình ngoại khóa, các hoạt động nội bộ của công ty.</li>	<li>Cơ&nbsp;hội ưu tiên (không cần qua thử việc) trở thành nhân viên chính thức nếu có kết quả học việc tốt.</li></ul><h2><b>Thời gian làm việc</b></h2><ul>	<li>Toàn thời gian cố định hoặc làm online.</li>	<li>Thời gian làm việc là:&nbsp;8:00 – 17:00, Thứ hai – Thứ sáu</li>	<li>Ngày làm việc và thời gian làm việc có thể thay đổi linh hoạt tùy thuộc vào điều kiện của ứng viên và tình hình thực tế.</li></ul><h2><b>Đối tượng</b></h2><p>Tất cả các bạn sinh viên năm cuối/mới tốt nghiệp các trường CĐ - ĐH đáp ứng được những yêu cầu sau:</p><ul>	<li>Sinh viên khối ngành kinh tế: yêu thích marketing online, mong muốn thực tập trong lĩnh vực kinh doanh phần mềm.</li>	<li>Sinh viên khối ngành kỹ thuật: yêu thích thiết kế, lập trình web.</li></ul><p>Có kỹ năng giao tiếp và tư duy logic tốt, năng động và ham học hỏi.</p><p>Ưu tiên các ứng viên đam mê phần mềm nguồn mở, đặc biệt là các ứng viên đã từng tham gia và có bài viết diễn đàn NukeViet (<a href=\"http://forum.nukeviet.vn/\">forum.nukeviet.vn</a>)</p><h2><b>Điều kiện</b></h2><p>Có máy tính xách tay để làm việc.</p><p>Ứng viên sẽ được ký hợp đồng học việc (có thời hạn cụ thể). Nếu được nhận vào làm việc chính thức, người lao động phải làm ở công ty ít nhất 2 năm, nếu không làm hoặc nghỉ trước thời hạn sẽ phải hoàn lại tiền đào tạo. Chi phí này được tính là 3.000.000 VND</p><p>Nếu được cử đi học, người lao động phải làm ở công ty ít nhất 2 năm, nếu không làm hoặc nghỉ trước thời hạn sẽ phải hoàn lại tiền học phí.</p><p>Thực hiện theo các quy định khác của công ty...</p><h2><b>Cách thức ứng tuyển</b></h2><p>Gửi bản mềm đơn đăng ký ứng tuyển tới:&nbsp;<a href=\"mailto:tuyendung@vinades.vn\">tuyendung@vinades.vn</a>;</p><p>Tiêu đề mail ghi rõ: &#91;Họ tên&#93; –Ứng tuyển học việc&#91;Bộ phận ứng tuyển&#93;;</p><p>Ví dụ: Lê Văn Nam –&nbsp;Ứng tuyển học việc bộ phận đồ họa</p><p>Hồ sơ bản cứng cần chuẩn bị (sẽ gửi sau nếu đạt yêu cầu) gồm:</p><ul>	<li>Giấy khám sức khoẻ của cơ quan y tế</li>	<li>Bản sao giấy khai sinh (có công chứng).</li>	<li>Bản sao quá trình học tập (bảng điểm tốt nghiệp), các văn bằng chứng chỉ (có công chứng) nếu đã tốt nghiệp.</li>	<li>Sơ yếu lý lịch có xác nhận của cơ quan công tác trước đó (nếu có) hoặc xác nhận của chính quyền địa phương nơi bạn đăng ký hộ khẩu thường trú.</li>	<li>Chứng minh thư (photo không cần công chứng).</li>	<li>Thư giới thiệu (nếu có)</li>	<li>Ảnh 4x6: 4 chiếc (đã bao gồm 1 chiếc gắn trên sơ yếu lý lịch).</li></ul><p><br  /><strong>Chi tiết vui lòng tham khảo tại:</strong>&nbsp;<a href=\"http://vinades.vn/vi/news/Tuyen-dung/\" target=\"_blank\">http://vinades.vn/vi/news/Tuyen-dung/</a><br  /><br  /><strong>Mọi thắc mắc vui lòng liên hệ:</strong></p><blockquote><p><strong>Công ty cổ phần phát triển nguồn mở Việt Nam.</strong><br  />Trụ sở chính: Phòng 1706 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.<br  /><br  />- Tel: +84-24-85872007 - Fax: +84-24-35500914<br  />- Email:&nbsp;<a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a>&nbsp;- Website:&nbsp;<a href=\"http://www.vinades.vn/\">http://www.vinades.vn</a></p></blockquote>', NULL, '', '', NULL, 2, '', 0, 1, 1, 1), 
(11, '', '', '<div class=\"details-content clearfix\" id=\"bodytext\"><strong>Hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016 của Bộ Giáo dục và Đào tạo có gì mới?</strong><br  /><br  />Trong các hướng dẫn thực hiện nhiệm vụ CNTT từ năm 2010 đến nay liên tục chỉ đạo việc đẩy mạnh công tác triển khai sử dụng phần mềm nguồn mở trong nhà trường và các cơ quan quản lý giáo dục. Tuy nhiên Hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016 của Bộ Giáo dục và Đào tạo có nhiều thay đổi mạnh mẽ đáng chú ý, đặc biệt việc chỉ đạo triển khai các phần mềm nguồn mở vào trong các cơ sở quản lý giao dục được rõ ràng và cụ thể hơn rất nhiều.<br  /><br  />Một điểm thay đổi đáng chú ý đối với phần mềm nguồn mở, trong đó đã thay hẳn thuật ngữ &quot;phần mềm tự do mã nguồn mở&quot; hoặc &quot;phần mềm mã nguồn mở&quot; thành &quot;phần mềm nguồn mở&quot;, phản ánh xu thế sử dụng thuật ngữ phần mềm nguồn mở đã phổ biến trong cộng đồng nguồn mở thời gian vài năm trở lại đây.<br  /><br  /><strong>NukeViet - Phần mềm nguồn mở Việt - không chỉ được khuyến khích mà đã được hướng dẫn thực thi</strong><br  /><br  />Từ 5 năm trước, thông tư số 08/2010/TT-BGDĐT của Bộ GD&amp;ĐTquy định về sử dụng phần mềm tự do mã nguồn mở trong các cơ sở giáo dục, NukeViet đã được đưa vào danh sách các mã nguồn mở <strong>được khuyến khích sử dụng trong giáo dục</strong>. Tuy nhiên, việc sử dụng chưa được thực hiện một cách đồng bộ mà chủ yếu làm nhỏ lẻ rải rác tại một số trường, Phòng và Sở GD&amp;ĐT.<br  /><br  />Trong Hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016 của Bộ Giáo dục và Đào tạo lần này, NukeViet&nbsp; không chỉ được khuyến khích mà đã được hướng dẫn thực thi, không những thế NukeViet còn được đưa vào hầu hết các nhiệm vụ chính, cụ thể:<div><div><div>&nbsp;</div>- <strong>Nhiệm vụ số 5</strong> &quot;<strong>Công tác bồi dưỡng ứng dụng CNTT cho giáo viên và cán bộ quản lý giáo dục</strong>&quot;, mục 5.1 &quot;Một số nội dung cần bồi dưỡng&quot; có ghi &quot;<strong>Tập huấn sử dụng phần mềm nguồn mở NukeViet.</strong>&quot;<br  />&nbsp;</div>- <strong>Nhiệm vụ số 10 &quot;Khai thác, sử dụng và dạy học bằng phần mềm nguồn mở</strong>&quot; có ghi: &quot;<strong>Khai thác và áp dụng phần mềm nguồn mở NukeViet trong giáo dục.&quot;</strong><br  />&nbsp;</div>- Phụ lục văn bản, có trong nội dung &quot;Khuyến cáo khi sử dụng các hệ thống CNTT&quot;, hạng mục số 3 ghi rõ &quot;<strong>Không nên làm website mã nguồn đóng&quot; và &quot;Nên làm NukeViet: phần mềm nguồn mở&quot;.</strong><br  />&nbsp;<div>Hiện giờ văn bản này đã được đăng lên website của Bộ GD&amp;ĐT: <a href=\"http://moet.gov.vn/?page=1.10&amp;view=983&amp;opt=brpage\" target=\"_blank\">http://moet.gov.vn/?page=1.10&amp;view=983&amp;opt=brpage</a></div><p><br  />Hoặc có thể tải về tại đây: <a href=\"http://vinades.vn/vi/download/van-ban-luat/Huong-dan-thuc-hien-nhiem-vu-CNTT-nam-hoc-2015-2016/\" target=\"_blank\">http://vinades.vn/vi/download/van-ban-luat/Huong-dan-thuc-hien-nhiem-vu-CNTT-nam-hoc-2015-2016/</a></p><blockquote><p><em>Trên cơ sở hướng dẫn của Bộ GD&amp;ĐT, Công ty cổ phần phát triển nguồn mở Việt Nam và các doanh nghiệp phát triển NukeViet trong cộng đồng NukeViet đang tích cực công tác hỗ trợ cho các phòng GD&amp;ĐT, Sở GD&amp;ĐT triển khai 2 nội dung chính: Hỗ trợ công tác đào tạo tập huấn hướng dẫn sử dụng NukeViet và Hỗ trợ triển khai NukeViet cho các trường, Phòng và Sở GD&amp;ĐT.<br  /><br  />Các Phòng, Sở GD&amp;ĐT có nhu cầu có thể xem thêm thông tin chi tiết tại đây: <a href=\"http://vinades.vn/vi/news/thong-cao-bao-chi/Ho-tro-trien-khai-dao-tao-va-trien-khai-NukeViet-cho-cac-Phong-So-GD-DT-264/\" target=\"_blank\">Hỗ trợ triển khai đào tạo và triển khai NukeViet cho các Phòng, Sở GD&amp;ĐT</a></em></p></blockquote></div>', NULL, '', '', NULL, 2, '', 0, 1, 1, 1), 
(12, '', '', '<div class=\"details-content clearfix\" id=\"bodytext\"><span style=\"font-size:16px;\"><strong>Hỗ trợ công tác đào tạo tập huấn hướng dẫn sử dụng phần mềm nguồn mở NukeViet</strong></span><br  /><br  />Công tác hỗ trợ công tác đào tạo tập huấn hướng dẫn sử dụng phần mềm nguồn mở NukeViet sẽ được thực hiện bởi đội ngũ chuyên gia giàu kinh nghiệm về NukeViet được tuyển chọn từ lực lượng lập trình viên, chuyên viên kỹ thuật hiện đang tham gia phát triển và hỗ trợ về NukeViet từ Ban Quản Trị NukeViet và Công ty cổ phần phát triển nguồn mở Việt Nam và các đối tác thuộc Liên minh phần mềm giáo dục nguồn mở NukeViet.<br  /><br  />Với kinh nghiệm tập huấn đã được tổ chức thành công cho nhiều Phòng giáo dục và đào tạo, các chuyên gia về NukeViet sẽ giúp chuyển giao giáo trình, chương trình, kịch bản đào tạo cho các Phòng, Sở GD&amp;ĐT; hỗ trợ các giáo viên và cán bộ quản lý giáo dục sử dụng trong suốt thời gian sau đào tạo.<br  /><br  />Đặc biệt, đối với các đơn vị sử dụng NukeViet làm website và cổng thông tin đồng bộ theo quy mô cấp Phòng và Sở, cán bộ tập huấn của NukeViet sẽ có nhiều chương trình hỗ trợ khác như chương trình thi đua giữa các website sử dụng NukeViet trong cùng đơn vị cấp Phòng, Sở và trên toàn quốc; Chương trình báo cáo và giám sát và xếp hạng website hàng tháng; Chương trình tập huấn nâng cao trình độ sử dụng NukeViet hàng năm cho giáo viên và cán bộ quản lý giáo dục đang thực hiện công tác quản trị các hệ thống sử dụng nền tảng NukeViet.<br  /><br  /><span style=\"font-size:16px;\"><strong>Hỗ trợ triển khai NukeViet cho các trường, Phòng và Sở GD&amp;ĐT</strong></span><br  /><br  />Nhằm hỗ trợ triển khai NukeViet cho các trường, Phòng và Sở GD&amp;ĐT một cách toàn diện, đồng bộ và tiết kiệm, hiện tại, Liên minh phần mềm nguồn mở giáo dục NukeViet chuẩn bị ra mắt. Liên minh này do Công ty cổ phần phát triển nguồn mở Việt Nam đứng dầu và thực hiện việc điều phối công các hỗ trợ và phối hợp giữa các đơn vị trên toàn quốc. Thành viên của liên minh là các doanh nghiệp cung cấp sản phẩm và dịch vụ phần mềm hỗ trợ cho giáo dục (kể cả những đơn vị chỉ tham gia lập trình và những đơn vị chỉ tham gia khai thác thương mại). Liên minh sẽ cùng nhau làm việc để xây dựng một hệ thống phần mềm thống nhất cho giáo dục, có khả năng liên thông và kết nối với nhau, hoàn toàn dựa trên nền tảng phần mềm nguồn mở. Liên minh cũng hỗ trợ và phân phối phần mềm cho các đơn vị làm phần mềm trong ngành giáo dục với mục tiêu là tiết kiệm tối đa chi phí trong khâu thương mại, mang tới cơ hội cho các đơn vị làm phần mềm giáo dục mà không cần phải lo lắng về việc phân phối phần mềm. Các doanh nghiệp quan tâm đến cơ hội kinh doanh bằng phần mềm nguồn mở, muốn tìm hiểu và tham gia liên minh có thể đăng ký tại đây: <a href=\"http://edu.nukeviet.vn/lienminh-dangky.html\" target=\"_blank\">http://edu.nukeviet.vn/lienminh-dangky.html</a><br  /><br  />Liên minh phần mềm nguồn mở giáo dục NukeViet đang cung cấp giải pháp cổng thông tin chuyên dùng cho phòng và Sở GD&amp;ĐT (NukeViet Edu Gate) cung cấp dưới dạng dịch vụ công nghệ thông tin (theo mô hình của <a href=\"http://vinades.vn/vi/download/van-ban-luat/Quyet-dinh-80-ve-thue-dich-vu-CNTT/\" target=\"_blank\">Quyết định số 80/2014/QĐ-TTg của Thủ tướng Chính phủ</a>) có thể hỗ trợ cho các trường, Phòng và Sở GD&amp;ĐT triển khai NukeViet ngay lập tức.<br  /><br  />Giải pháp cổng thông tin chuyên dùng cho phòng và Sở GD&amp;ĐT (NukeViet Edu Gate) có tích hợp website các trường (liên thông 3 cấp: trường - phòng - sở) cho phép tích hợp hàng ngàn website của các trường cùng nhiều dịch vụ khác trên cùng một hệ thống giúp tiết kiệm chi phí đầu tư, chi phí triển khai và bảo trì hệ thống bởi toàn bộ hệ thống được vận hành bằng một phần mềm duy nhất. Ngoài giải pháp cổng thông tin giáo dục tích hợp, Liên minh phần mềm nguồn mở giáo dục NukeViet cũng đang phát triển một số&nbsp;sản phẩm phần mềm dựa trên phần mềm nguồn mở NukeViet và sẽ sớm ra mắt trong thời gian tới.<div><br  />Hiện nay,&nbsp;NukeViet Edu Gate cũng&nbsp;đã được triển khai rộng rãi và nhận được sự ủng hộ của&nbsp;nhiều Phòng, Sở GD&amp;ĐT trên toàn quốc.&nbsp;Các phòng, sở GD&amp;ĐT quan tâm đến giải pháp NukeViet Edu Gate có thể truy cập&nbsp;<a href=\"http://edu.nukeviet.vn/\" target=\"_blank\">http://edu.nukeviet.vn</a>&nbsp;để tìm hiểu thêm hoặc liên hệ:<br  /><br  /><span style=\"font-size:14px;\"><strong>Liên minh phần mềm nguồn mở giáo dục NukeViet</strong></span><br  />Đại diện: <strong>Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC)</strong><br  /><strong>Địa chỉ</strong>: Phòng 1706 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội<br  /><strong>Email</strong>: contact@vinades.vn, Tel: 024-85872007, <strong>Fax</strong>: 024-35500914,<br  /><strong>Hotline</strong>: 0904762534 (Mr. Hùng), 0936226385 (Ms. Ngọc),&nbsp;<span style=\"color: rgb(38, 38, 38); font-family: arial, sans-serif; font-size: 13px; line-height: 16px;\">0904719186 (Mr. Hậu)</span><br  />Các Phòng GD&amp;ĐT, Sở GD&amp;ĐT có thể đăng ký tìm hiểu, tổ chức hội thảo, tập huấn, triển khai NukeViet trực tiếp tại đây: <a href=\"http://edu.nukeviet.vn/dangky.html\" target=\"_blank\">http://edu.nukeviet.vn/dangky.html</a><br  /><br  /><span style=\"font-size:16px;\"><strong>Tìm hiểu về phương thức chuyển đổi các hệ thống website cổng thông tin sang NukeViet theo mô hình tích hợp liên thông từ trưởng, lên Phòng, Sở GD&amp;ĐT:</strong></span><br  /><br  />Đối với các Phòng, Sở GD&amp;ĐT, trường Nầm non, tiểu học, THCS, THPT... chưa có website, Liên minh phần mềm nguồn mở giáo dục NukeViet sẽ hỗ trợ triển khai NukeViet theo mô hình cổng thông tin liên cấp như quy định tại <a href=\"http://vinades.vn/vi/download/van-ban-luat/Thong-tu-quy-dinh-ve-ve-to-chuc-hoat-dong-su-dung-thu-dien-tu/\" target=\"_blank\">thông tư số <strong>53/2012/TT-BGDĐT</strong> của Bộ GD&amp;ĐT</a> ban hành ngày 20-12-2012 quy định về quy định về về tổ chức hoạt động, sử dụng thư điện tử và cổng thông tin điện tử tại sở giáo dục và đào tạo, phòng giáo dục và đào tạo và các cơ sở GDMN, GDPT và GDTX.<br  /><br  />Trường hợp các đơn vị có website và đang sử dụng NukeViet theo dạng rời rạc thì việc chuyển đổi và tích hợp các website NukeViet rời rạc vào NukeViet Edu Gate của Phòng và Sở có thể thực hiện dễ dàng và giữ nguyên toàn bộ dữ liệu.<br  /><br  />Trường hợp các đơn vị có website và nhưng không sử dụng NukeViet cũng có thể chuyển đổi sang sử dụng NukeViet để hợp nhất vào hệ thống cổng thông tin giáo dục cấp Phòng, Sở. Tuy nhiên mức độ và tỉ lệ dữ liệu được chuyển đổi thành công sẽ phụ thuộc vào tình hình thực tế của từng website.</div></div>', NULL, '', '', NULL, 2, '', 0, 1, 1, 1), 
(13, '', '', '<p dir=\"ltr\">Trải qua hơn 10 năm phát triển, từ một mã nguồn chỉ mang tính cá nhân, NukeViet đã phát triển thành công theo hướng cộng đồng. Năm 2010, NukeViet 3 ra đời đánh dấu một mốc lớn trong quá trình đi lên của NukeViet, phát triển theo hướng chuyên nghiệp với sự hậu thuẫn của Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC). NukeViet 3 đã và được sử dụng rộng rãi trong cộng đồng, từ các cổng thông tin tổ chức, hệ thống giáo dục, cho đến các website cá nhân, thương mại, mang lại các trải nghiệm vượt trội của mã nguồn thương hiệu Việt so với các mã nguồn nổi tiếng khác trên thế giới.<br  /><br  />Năm 2016, NukeViet 4 ra đời được xem là một cuộc cách mạng lớn trong chuỗi sự kiện phát triển NukeViet, cũng như xu thế công nghệ hiện tại. Hệ thống gần như được đổi mới hoàn toàn từ nhân hệ thống đến giao diện, nâng cao đáng kể hiệu suất và trải nghiệm người dùng.<br  /><br  /><span style=\"line-height: 1.6;\"><strong>Dưới đây là một số thay đổi của NukeViet 4.</strong></span><br  /><strong><span style=\"line-height: 1.6;\">Các thay đổi từ nhân hệ thống:</span></strong></p><ul>	<li dir=\"ltr\">	<p dir=\"ltr\"><strong>Các công nghệ mới được áp dụng.</strong></p>	<ul>		<li dir=\"ltr\">		<p dir=\"ltr\">Sử dụng composer để quản lý các thư viện PHP được cài vào hệ thống.</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\">Từng bước áp dụng &nbsp;các tiêu chuẩn viết code PHP theo khuyến nghị của <a href=\"http://www.php-fig.org/psr/\">http://www.php-fig.org/psr/</a></p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\">Sử dụng PDO để thay cho extension MySQL.</p>		</li>	</ul>	</li></ul><ul>	<li dir=\"ltr\">	<p dir=\"ltr\"><strong>Tăng cường khả năng bảo mật</strong></p>	<ul>		<li dir=\"ltr\">		<p dir=\"ltr\">Sau khi các chuyên giả bảo mật của HP gửi đánh giá, chúng tôi đã tối ưu NukeViet 4.0 để hệ thống an toàn hơn.</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\">Mã hóa các mật khẩu lưu trữ trong hệ thống: Các mật khẩu như FTP, SMTP,... đã được mã hóa, bảo mật thông tin người dùng.</p>		</li>	</ul>	</li></ul><ul>	<li dir=\"ltr\">	<p dir=\"ltr\"><strong>Tối ưu SEO:</strong></p>	<ul>		<li dir=\"ltr\">		<p dir=\"ltr\">SEO được xem là một trong những ưu tiên hàng đầu được phát triển trong phiên bản này. NukeViet 4 tập trung tối ưu hóa SEO Onpage mạnh mẽ. Các công cụ hỗ trợ SEO được tập hợp lại qua module “Công cụ SEO”. Các chức năng được thêm mới:</p>		<ul>			<li dir=\"ltr\">			<p dir=\"ltr\">Loại bỏ tên module khỏi URL khi không dùng đa ngôn ngữ</p>			</li>			<li dir=\"ltr\">			<p dir=\"ltr\">Cho phép đổi đường dẫn module</p>			</li>			<li dir=\"ltr\">			<p dir=\"ltr\">Thêm chức năng xác thực Google+ (Bản quyền tác giả)</p>			</li>			<li dir=\"ltr\">			<p dir=\"ltr\">Thêm chức năng ping đến các công cụ tìm kiếm: Submit url mới đến google để việc hiển thị bài viết mới lên kết quả tìm kiếm nhanh chóng hơn.</p>			</li>			<li dir=\"ltr\">			<p dir=\"ltr\">Hỗ trợ Meta OG của facebook</p>			</li>			<li dir=\"ltr\">			<p dir=\"ltr\">Hỗ trợ chèn Meta GEO qua Cấu hình Meta-Tags</p>			</li>		</ul>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\">Cùng với đó, các module cũng được tối ưu hóa bằng các form hỗ trợ khai báo tiêu đề, mô tả (description), từ khóa (keywods) cho từng khu vực, từng trang. &nbsp;</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\">Với sự hỗ trợ tối đa này, người quản trị (admin) có thể tùy biến lại website theo phong cách SEO riêng biệt.</p>		</li>	</ul>	</li>	<li dir=\"ltr\">	<p dir=\"ltr\"><strong>Thay đổi giao diện, sử dụng giao diện tuỳ biến</strong></p>	<ul>		<li dir=\"ltr\">		<p dir=\"ltr\">Giao diện trong NukeViet 4 được làm mới, tương thích với nhiều màn hình hơn.</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\">Sử dụng thư viện bootstrap để việc phát triển giao diện thống nhất và dễ dàng hơn.</p>		</li>	</ul>	</li>	<li dir=\"ltr\">	<p dir=\"ltr\"><strong>Hệ thống nhận thông báo:&nbsp;</strong><span style=\"line-height: 1.6;\">Có thể gọi đây là một tiện ích nhỏ, song nó rất hữu dụng để admin tương tác với hệ thống một cách nhanh chóng. Admin có thể nhận thông báo từ hệ thống (hoặc từ module) khi có sự kiện nào đó.</span></p>	</li></ul><p dir=\"ltr\" style=\"margin-left: 40px;\"><strong>Ví dụ:</strong> Khi có khách gửi liên hệ (qua module contact) đến thì hệ thống xuất hiện biểu tượng thông báo “Có liên hệ mới” ở góc phải, Admin sẽ nhận được ngay lập tức thông báo khi người dùng đang ở Admin control panel (ACP).</p><ul>	<li dir=\"ltr\">	<p dir=\"ltr\"><strong>Thay đổi cơ chế quản lý block:</strong></p>	<ul>		<li dir=\"ltr\">		<p dir=\"ltr\">Nhận thấy việc hiển thị block ở lightbox trong NukeViet 3 dẫn đến một số bất tiện trong quá trình quản lý, NukeViet 4 đã thay thế cách hiển thị này ở dạng cửa sổ popup. Dễ nhận thấy sự thay đổi này khi admin thêm (hoặc sửa) một block nào đó.</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\">“Cấu hình hiển thị block trên các thiết bị” cũng được đưa vào phần cấu hình block, admin có thể tùy chọn cho phép block hiển thị trên các thiết bị nào (tất cả thiết bị, thiết bị di động, máy tính bảng, thiết bị khác).<span style=\"line-height: 1.6;\">&nbsp;</span></p>		</li>	</ul>	</li></ul><ul>	<li dir=\"ltr\">	<p dir=\"ltr\"><strong>Thêm ngôn ngữ tiếng Pháp:</strong> website cài đặt mới có sẵn 3 ngôn ngữ mặc định là Việt, Anh và Pháp.</p>	</li></ul><p dir=\"ltr\"><strong>Các thay đổi của module:</strong></p><ul>	<li dir=\"ltr\">	<p dir=\"ltr\"><strong>Module menu:</strong></p>	<ul>		<li dir=\"ltr\">		<p dir=\"ltr\">Phương án quản lý menu được thay đổi hướng tới việc quản lý menu nhanh chóng, tiện lợi nhất cho admin. Admin có thể nạp nhanh menu theo các tùy chọn mà hệ thống cung cấp.</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\">Mẫu menu cũng được thay đổi, đa dạng và hiển thị tốt với các giao diện hiện đại.</p>		</li>	</ul>	</li>	<li dir=\"ltr\">	<p dir=\"ltr\"><strong>Module contact (Liên hệ):</strong></p>	<ul>		<li dir=\"ltr\">		<p dir=\"ltr\">Bổ sung các trường thông tin về bộ phận (Điện thoại, fax, email, các trường liên hệ khác,...).</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\">Admin có thể trả lời khách nhiều lần, hệ thống lưu lại lịch sử trao đổi đó.</p>		</li>	</ul>	</li>	<li dir=\"ltr\">	<p dir=\"ltr\"><strong>Module users (Tài khoản):</strong></p>	<ul>		<li dir=\"ltr\">		<p dir=\"ltr\">Thay thế OpenID bằng thư viện OAuth - hỗ trợ tích hợp đăng nhập qua tài khoản mạng xã hội</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\">Cho phép đăng nhập 1 lần tài khoản người dùng NukeViet với Alfresco, Zimbra, Moodle, Koha</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\">Thêm chức năng tùy biến trường dữ liệu thành viên</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\">Thêm chức năng phân quyền sử dụng module users</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\">Thêm cấu hình: Số ký tự username, độ phức tạp mật khẩu, tạo mật khảu ngẫu nhiên,....</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\">Cho phép sử dụng tên truy cập, hoặc email để đăng nhập</p>		</li>	</ul>	</li>	<li dir=\"ltr\">	<p dir=\"ltr\"><strong>Module about:</strong></p>	<ul>		<li dir=\"ltr\">		<p dir=\"ltr\">Module about ở NukeViet 3 được đổi tên thành module page</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\">Thêm các cấu hình hỗ trợ SEO: Ảnh minh họa, chú thích ảnh minh họa, mô tả, từ khóa cho bài viết, hiển thị các công cụ tương tác với các mạng xã hội.</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\">Thêm RSS</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\">Cấu hình phương án hiển thị các bài viết trên trang chính</p>		</li>	</ul>	</li>	<li dir=\"ltr\">	<p dir=\"ltr\"><strong>Module news (Tin tức):</strong></p>	<ul>		<li dir=\"ltr\">		<p dir=\"ltr\">Thêm phân quyền cho người quản lý module, đến từng chủ đề</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\">Thay đổi phương án lọc từ khóa bài viết, lọc từ khóa theo các từ khóa đã có trong tags thay vì đọc từ từ điển.</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\">Bổ sung các trạng thái bài viết</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\">Thêm cấu hình mặc định hiển thị ảnh minh họa trên trang xem chi tiết bài viết</p>		</li>		<li dir=\"ltr\">		<p dir=\"ltr\">Thêm các công cụ tương tác với mạng xã &nbsp;hội.</p>		</li>	</ul>	</li></ul><p dir=\"ltr\"><strong>Quản lý Bình luận</strong></p><ul>	<li dir=\"ltr\">	<p dir=\"ltr\">Các bình luận của các module sẽ được tích hợp quản lý tập trung để cấu hình.</p>	</li>	<li dir=\"ltr\">Khi xây dựng mới module, Chỉ cần nhúng 1 đoạn mã vào. Tránh phải việc copy mã code gây khó khăn cho bảo trì.</li></ul>', NULL, '', '', NULL, 2, '', 0, 1, 1, 1), 
(14, '', '', '<strong>Hệ thống:</strong><br  />- Sửa code theo khuyến nghị của codacy: https://www.codacy.com/app/nukeviet/nukeviet/dashboard<br  />- Cải thiện an ninh hệ thống theo đánh giá của các phần mềm bảo mật OWASP ZAP 2.6<br  />- Cải tiến chức năng Rewrite<br  />- Thêm tính năng bật tắt sitemap cho các module<br  />- Thêm link hướng dẫn sử dụng website dẫn tới từng chức năng tại https://wiki.nukeviet.vn/<br  />- Cập nhật trình soạn thảo&nbsp; CKEditor 4.7.1 để hỗ trợ việc copy nội dung từ Word, Excel, Hỗ trợ việc kéo thả ảnh, file từ máy tính vào trình soạn thảo tốt hơn: http://ckeditor.com/blog/CKEditor-4.7-released<br  />- Tích hợp thêm <a href=\\\"https://nukeviet.vn/vi/news/Tin-tuc/nukeviet-4-1-se-ho-tro-redis-de-cache-435.html\\\">Redis để cache</a> cho hệ thống<br  /><br  /><strong>Module Tài khoản:</strong><br  />- Tùy biến các trường hệ thống của module users giúp quản trị có thể cho ẩn/hiện khi đăng ký và đổi tên các trường này.<br  />- Thêm chức năng&nbsp; xác thực hai bước cho từng nhóm thành viên, Cấu hình yêu cầu xác thực hai bước cho từng nhóm thành viên.<br  />- Tích hợp reCAPTCHA<br  /><br  /><strong>Module Tin tức:</strong><br  />- Thêm cấu hình có bật tính năng copy bài viết, để dùng module này đăng cái bài viết có cạc trình bày tương tự nhau.<br  />- Cải thiện tính năng cho bài viết Facebook Instant Articles<br  />- Cảnh báo tránh cùng&nbsp; một lúc nhiều người sửa bài viết.<br  /><br  /><strong>Module banners</strong><br  />- Bỏ phần quản lý khách hàng tại quảng cáo, chuyển sang dùng tài khoản chung của site<br  />- Phần cấu hình khối quảng cáo được viết lại để cấu hình nhóm&nbsp; thành viên được đăng quảng cáo ngoài site, sau đó quản trị duyệt lại quảng cáo để hiển thị ngoài site.<br  />- Thêm cấu hình về thời gian chung áp dụng cho quảng cáo theo khối.<br  />- Sửa lại link quản cáo để tránh các click ảo.<br  />- Sửa hiển thị quản lý quảng cáo để tiện quản lý hơn.<br  /><br  />Và nhiều cập nhật sửa lỗi khác, xem chi tiết tại: https://github.com/nukeviet/nukeviet/blob/develop/CHANGELOG.txt<br  />', NULL, '', 'https://nukeviet.vn/vi/news/Tin-tuc/nukeviet-4-2-co-gi-moi-505.html', NULL, 2, '', 0, 1, 1, 1), 
(15, '', '', '<strong>Hệ thống:</strong><br  />- Thay đổi phần quản lý block để dễ dùng hơn khi module có quá nhiều chức năng.<br  />- Thêm các tham số cấu hình&nbsp; SSL cho&nbsp; SMTP<br  />- Module Upload: Thêm cấu hình có thể chia nhỏ các file khi upload để có thể upload<br  />- Plugin:Thêm vị trí chạy sau khi thực hiện module, cải tiến mỗi Plugin sẽ chạy được ở các vị trí nhất định theo người lập trình quy định.<br  />- Tích hợp thêm thư viện PDF.js<br  />- Thêm tính năng xuất dữ liệu mẫu để khi tiết hành cài đặt có thể dựng luôn site hoàn chỉnh tường tự như cài đặt NukeViet eGovernment<br  /><br  /><strong>Module comment: </strong><br  />- Cho phép cấu hình có sử dụng trình soạn thảo ở phần bình luận hay không.<br  />- Cho phép cấu hình có sử dụng file đính kèm ở phần bình luận hay không.<br  />- Module news: Allow deactive category, allow search for locked posts, Allows attaching files to posts<br  />- Config module display on admin index for authors<br  />&nbsp;<br  /><strong>Module Tài khoản:</strong><br  />- Module users: Allowed to delete and change status multiple account, fix block login, update Openid icon, fix sort groups, fix delete group<br  />- Người điều hành chung của site có thể cấu hình 1 số thông số. (Lúc trước chỉ quản trị tối cao mới cấu hình được)<br  />- Với mỗi tài khoản quản trị, có thể chọn module mặc định sau khi đăng nhập quản trị.<br  /><br  /><strong>Module Tin tức:</strong><br  />-&nbsp; Thay đổi chức năng quản lý chủ đề có thể: Hiển thị trên trang chủ, không hiển thị trên trang chủ hoặc Khóa chủ đề.<br  />-&nbsp; Cho phép đính kèm file vào các bài viết (Không cần thông qua trình soạn thảo)<br  />- Thêm tính năng sắp xếp các bài viết.<br  />- Cho phép cấu hình layout khi xem chi tiết bài viết (Tưong tự module page đã có trước)<br  /><br  /><strong>Module page</strong><br  />-&nbsp; Thêm cấu hình alias lower khi thêm bài viết mới.<br  /><br  />Và nhiều cập nhật sửa lỗi khác, xem chi tiết tại: <a href=\"https://github.com/nukeviet/nukeviet/blob/develop/CHANGELOG.txt\">https://github.com/nukeviet/nukeviet/blob/develop/CHANGELOG.txt</a>', NULL, '', 'https://nukeviet.vn/vi/news/Tin-tuc/nukeviet-4-3-co-gi-moi-540.html', NULL, 2, '', 0, 1, 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_logs`
--

DROP TABLE IF EXISTS `nv4_vi_news_logs`;
CREATE TABLE `nv4_vi_news_logs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `sid` mediumint(9) NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `log_key` varchar(60)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Khóa loại log, tùy vào lập trình',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `note` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `set_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`),
  KEY `log_key` (`log_key`),
  KEY `status` (`status`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_row_histories`
--

DROP TABLE IF EXISTS `nv4_vi_news_row_histories`;
CREATE TABLE `nv4_vi_news_row_histories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `new_id` int(10) unsigned NOT NULL DEFAULT '0',
  `historytime` int(10) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT 'ID người đăng',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sourceid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `publtime` int(10) unsigned NOT NULL DEFAULT '0',
  `exptime` int(10) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `inhome` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `external_link` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `instant_active` tinyint(1) NOT NULL DEFAULT '0',
  `instant_template` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `instant_creatauto` tinyint(1) NOT NULL DEFAULT '0',
  `titlesite` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `bodyhtml` longtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `voicedata` text  COLLATE utf8mb4_unicode_ci COMMENT 'Data giọng đọc json',
  `keywords` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourcetext` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `files` text  COLLATE utf8mb4_unicode_ci,
  `tags` text  COLLATE utf8mb4_unicode_ci,
  `internal_authors` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `layout_func` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `copyright` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_send` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) NOT NULL DEFAULT '0',
  `changed_fields` text  COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Các field thay đổi',
  PRIMARY KEY (`id`),
  KEY `new_id` (`new_id`),
  KEY `historytime` (`historytime`),
  KEY `admin_id` (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci COMMENT='Lịch sử bài viết';


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_rows`
--

DROP TABLE IF EXISTS `nv4_vi_news_rows`;
CREATE TABLE `nv4_vi_news_rows` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(9) NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `weight` int(10) unsigned NOT NULL DEFAULT '0',
  `publtime` int(10) unsigned NOT NULL DEFAULT '0',
  `exptime` int(10) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `external_link` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `instant_active` tinyint(1) NOT NULL DEFAULT '0',
  `instant_template` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `instant_creatauto` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `edittime` (`edittime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`),
  KEY `instant_active` (`instant_active`),
  KEY `instant_creatauto` (`instant_creatauto`)
) ENGINE=MyISAM  AUTO_INCREMENT=16  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_news_rows`
--

INSERT INTO `nv4_vi_news_rows` VALUES
(1, 1, '1,5,7', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', 'nangly.jpg', 'Thành lập VINADES.,JSC', 1, 1, '6', 1, 0, 2, 0, 0, 0, 0, '', 0), 
(2, 7, '1,7', 0, 1, 'Nguyễn Thế Hùng', 7, 1453192444, 1453192444, 1, 12, 1453192444, 0, 2, 'Hãy trở thành nhà cung cấp dịch vụ của NukeViet&#33;', 'hay-tro-thanh-nha-cung-cap-dich-vu-cua-nukeviet', 'Nếu bạn là công ty hosting, là công ty thiết kế web có sử dụng mã nguồn NukeViet, là cơ sở đào tạo NukeViet hay là công ty bất kỳ có kinh doanh dịch vụ liên quan đến NukeViet... hãy cho chúng tôi biết thông tin liên hệ của bạn để NukeViet hỗ trợ bạn trong công việc kinh doanh nhé!', 'hoptac.jpg', '', 1, 1, '6', 1, 0, 13, 0, 0, 0, 0, '', 0), 
(3, 4, '4', 0, 1, 'Phạm Quốc Tiến', 2, 1453192400, 1453192400, 1, 11, 1453192400, 0, 2, 'Tuyển dụng lập trình viên PHP phát triển NukeViet', 'Tuyen-dung-lap-trinh-vien-PHP', 'Bạn đam mê nguồn mở? Bạn đang cần tìm một công việc phù hợp với thế mạnh của bạn về PHP và MySQL? Hãy gia nhập VINADES.,JSC để xây dựng mã nguồn mở hàng đầu cho Việt Nam.', 'tuyendung-kythuat.jpg', 'Tuyển dụng', 1, 1, '6', 1, 0, 0, 0, 0, 0, 0, '', 0), 
(4, 4, '4', 0, 1, 'Phạm Quốc Tiến', 0, 1445391089, 1445394192, 1, 5, 1445391060, 0, 2, 'Tuyển dụng chuyên viên đồ hoạ phát triển NukeViet', 'Tuyen-dung-chuyen-vien-do-hoa', 'Bạn đam mê nguồn mở? Bạn là chuyên gia đồ họa? Chúng tôi sẽ giúp bạn hiện thực hóa ước mơ của mình với một mức lương đảm bảo. Hãy gia nhập VINADES.,JSC để xây dựng mã nguồn mở hàng đầu cho Việt Nam.', 'tuyendung-kythuat.jpg', 'Tuyển dụng', 1, 1, '6', 1, 0, 0, 0, 0, 0, 0, '', 0), 
(5, 4, '4', 0, 1, 'Phạm Quốc Tiến', 0, 1445391090, 1445394193, 1, 6, 1445391060, 0, 2, 'Tuyển dụng lập trình viên front-end (HTML/CSS/JS) phát triển NukeViet', 'Tuyen-dung-lap-trinh-vien-front-end-HTML-CSS-JS', 'Bạn đam mê nguồn mở? Bạn đang cần tìm một công việc phù hợp với thế mạnh của bạn về front-end (HTML/CSS/JS)? Hãy gia nhập VINADES.,JSC để xây dựng mã nguồn mở hàng đầu cho Việt Nam.', 'tuyendung-kythuat.jpg', 'Tuyển dụng', 1, 1, '6', 1, 0, 0, 0, 0, 0, 0, '', 0), 
(6, 1, '1,6', 0, 1, '', 3, 1322685920, 1322686042, 1, 2, 1322685920, 0, 2, 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 'Ma-nguon-mo-NukeViet-gianh-giai-ba-Nhan-tai-dat-Viet-2011', 'Không có giải nhất và giải nhì, sản phẩm Mã nguồn mở NukeViet của VINADES.,JSC là một trong ba sản phẩm đã đoạt giải ba Nhân tài đất Việt 2011 - Lĩnh vực Công nghệ thông tin (Sản phẩm đã ứng dụng rộng rãi).', 'nukeviet-nhantaidatviet2011.jpg', 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 1, 1, '6', 1, 0, 1, 0, 0, 0, 0, '', 0), 
(7, 1, '1', 0, 1, '', 4, 1445309676, 1445309676, 1, 3, 1445309520, 0, 2, 'NukeViet được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước', 'nukeviet-duoc-uu-tien-mua-sam-su-dung-trong-co-quan-to-chuc-nha-nuoc', 'Ngày 5/12/2014, Bộ trưởng Bộ TT&TT Nguyễn Bắc Son đã ký ban hành Thông tư 20/2014/TT-BTTTT (Thông tư 20) quy định về các sản phẩm phần mềm nguồn mở (PMNM) được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước. NukeViet (phiên bản 3.4.02 trở lên) là phần mềm được nằm trong danh sách này.', 'chuc-mung-nukeviet-thong-tu-20-bo-tttt.jpg', 'NukeViet được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước', 1, 1, '4', 1, 0, 2, 0, 0, 0, 0, '', 0), 
(8, 4, '4', 0, 1, 'Vũ Bích Ngọc', 0, 1445391061, 1445394203, 1, 4, 1445391000, 0, 2, 'Công ty VINADES tuyển dụng nhân viên kinh doanh', 'cong-ty-vinades-tuyen-dung-nhan-vien-kinh-doanh', 'Công ty cổ phần phát triển nguồn mở Việt Nam là đơn vị chủ quản của phần mềm mã nguồn mở NukeViet - một mã nguồn được tin dùng trong cơ quan nhà nước, đặc biệt là ngành giáo dục. Chúng tôi cần tuyển 05 nhân viên kinh doanh cho lĩnh vực này.', 'tuyen-dung-nvkd.png', '', 1, 1, '4', 1, 0, 0, 0, 0, 0, 0, '', 0), 
(9, 1, '1,4', 0, 1, 'Trần Thị Thu', 0, 1445391118, 1445394180, 1, 7, 1445391060, 0, 2, 'Chương trình thực tập sinh tại công ty VINADES', 'chuong-trinh-thuc-tap-sinh-tai-cong-ty-vinades', 'Cơ hội để những sinh viên năng động được học tập, trải nghiệm, thử thách sớm với những tình huống thực tế, được làm việc cùng các chuyên gia có nhiều kinh nghiệm của công ty VINADES.', 'thuc-tap-sinh.jpg', '', 1, 1, '4', 1, 0, 0, 0, 0, 0, 0, '', 0), 
(10, 4, '4', 0, 1, 'Trần Thị Thu', 0, 1445391135, 1445394444, 1, 8, 1445391120, 0, 2, 'Học việc tại công ty VINADES', 'hoc-viec-tai-cong-ty-vinades', 'Công ty cổ phần phát triển nguồn mở Việt Nam tạo cơ hội việc làm và học việc miễn phí cho những ứng viên có đam mê thiết kế web, lập trình PHP… được học tập và rèn luyện cùng đội ngũ lập trình viên phát triển NukeViet.', 'hoc-viec-tai-cong-ty-vinades.jpg', '', 1, 1, '4', 1, 0, 0, 0, 0, 0, 0, '', 0), 
(11, 1, '1', 0, 1, '', 0, 1445391182, 1445394133, 1, 9, 1445391120, 0, 2, 'NukeViet được Bộ GD&amp;ĐT đưa vào Hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016', 'nukeviet-duoc-bo-gd-dt-dua-vao-huong-dan-thuc-hien-nhiem-vu-cntt-nam-hoc-2015-2016', 'Trong Hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016 của Bộ Giáo dục và Đào tạo, NukeViet được đưa vào các hạng mục: Tập huấn sử dụng phần mềm nguồn mở cho giáo viên và cán bộ quản lý giáo dục; Khai thác, sử dụng và dạy học; đặc biệt phần &quot;khuyến cáo khi sử dụng các hệ thống CNTT&quot; có chỉ rõ &quot;Không nên làm website mã nguồn đóng&quot; và &quot;Nên làm NukeViet: phần mềm nguồn mở&quot;.', 'nukeviet-cms.jpg', '', 1, 1, '4', 1, 0, 0, 0, 0, 0, 0, '', 0), 
(12, 1, '1,3', 0, 1, '', 0, 1445391217, 1445393997, 1, 10, 1445391180, 0, 2, 'Hỗ trợ tập huấn và triển khai NukeViet cho các Phòng, Sở GD&amp;ĐT', 'ho-tro-tap-huan-va-trien-khai-nukeviet-cho-cac-phong-so-gd-dt', 'Trên cơ sở Hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016 của Bộ Giáo dục và Đào tạo, Công ty cổ phần phát triển nguồn mở Việt Nam và các doanh nghiệp phát triển NukeViet trong cộng đồng NukeViet đang tích cực công tác hỗ trợ cho các phòng GD&ĐT, Sở GD&ĐT triển khai 2 nội dung chính: Hỗ trợ công tác đào tạo tập huấn hướng dẫn sử dụng NukeViet và Hỗ trợ triển khai NukeViet cho các trường, Phòng và Sở GD&ĐT', 'tap-huan-pgd-ha-dong-2015.jpg', 'Tập huấn triển khai NukeViet tại Phòng Giáo dục và Đào tạo Hà Đông - Hà Nội', 1, 1, '4', 1, 0, 1, 0, 0, 0, 0, '', 0), 
(13, 2, '2', 0, 1, 'VINADES', 0, 1453194455, 1453194455, 1, 13, 1453194455, 0, 2, 'NukeViet 4.0 có gì mới?', 'nukeviet-4-0-co-gi-moi', 'NukeViet 4 là phiên bản NukeViet được cộng đồng đánh giá cao, hứa hẹn nhiều điểm vượt trội về công nghệ đến thời điểm hiện tại. NukeViet 4 thay đổi gần như hoàn toàn từ nhân hệ thống đến chức năng, giao diện người dùng. Vậy, có gì mới trong phiên bản này?', 'chuc-mung-nukeviet-thong-tu-20-bo-tttt.jpg', '', 1, 1, '4', 1, 0, 2, 0, 0, 0, 0, '', 0), 
(14, 2, '2', 0, 1, 'VINADES', 0, 1501837620, 1501837620, 1, 14, 1501837620, 0, 2, 'NukeViet 4.2 có gì mới?', 'nukeviet-4-2-co-gi-moi', 'NukeViet 4.2 là phiên bản nâng cấp của phiên bản NukeViet 4.0 tập trung vào việc fix các vấn đề bất cập còn tồn tại của NukeViet 4.0, Thêm các tính năng mới để tăng cường bảo mật của hệ thống cũng như tối ưu trải nghiệm của người dùng.', 'chuc-mung-nukeviet-thong-tu-20-bo-tttt.jpg', '', 1, 1, '4', 1, 1, 2, 0, 0, 0, 0, '', 0), 
(15, 2, '2', 0, 1, 'VINADES', 0, 1510215907, 1510215907, 1, 15, 1510215907, 0, 2, 'NukeViet 4.3 có gì mới?', 'nukeviet-4-3-co-gi-moi', 'NukeViet 4.3 là phiên bản nâng cấp của phiên bản NukeViet 4.2 tập trung vào việc fix các vấn đề bất cập còn tồn tại, tối ưu trải nghiệm của người dùng.', 'chuc-mung-nukeviet-thong-tu-20-bo-tttt.jpg', '', 1, 1, '4', 1, 1, 2, 0, 0, 0, 0, '', 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_sources`
--

DROP TABLE IF EXISTS `nv4_vi_news_sources`;
CREATE TABLE `nv4_vi_news_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `logo` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(10) unsigned NOT NULL,
  `edit_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`sourceid`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_news_sources`
--

INSERT INTO `nv4_vi_news_sources` VALUES
(1, 'Báo Hà Nội Mới', 'http://hanoimoi.com.vn', '', 1, 1274989177, 1274989177), 
(2, 'VINADES.,JSC', 'http://vinades.vn', '', 2, 1274989787, 1274989787), 
(3, 'Báo điện tử Dân Trí', 'http://dantri.com.vn', '', 3, 1322685396, 1322685396), 
(4, 'Bộ Thông tin và Truyền thông', 'http://http://mic.gov.vn', '', 4, 1445309676, 1445309676);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_tags`
--

DROP TABLE IF EXISTS `nv4_vi_news_tags`;
CREATE TABLE `nv4_vi_news_tags` (
  `tid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `numnews` mediumint(9) NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `keywords` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`tid`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=43  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_news_tags`
--

INSERT INTO `nv4_vi_news_tags` VALUES
(1, 0, '', 'nguồn-mở', '', '', 'nguồn mở'), 
(2, 0, '', 'quen-thuộc', '', '', 'quen thuộc'), 
(3, 0, '', 'cộng-đồng', '', '', 'cộng đồng'), 
(4, 0, '', 'việt-nam', '', '', 'việt nam'), 
(5, 0, '', 'hoạt-động', '', '', 'hoạt động'), 
(6, 0, '', 'tin-tức', '', '', 'tin tức'), 
(7, 1, '', 'thương-mại-điện', '', '', 'thương mại điện'), 
(8, 0, '', 'điện-tử', '', '', 'điện tử'), 
(9, 13, '', 'nukeviet', '', '', 'nukeviet'), 
(10, 8, '', 'vinades', '', '', 'vinades'), 
(11, 3, '', 'lập-trình-viên', '', '', 'lập trình viên'), 
(12, 3, '', 'chuyên-viên-đồ-họa', '', '', 'chuyên viên đồ họa'), 
(13, 3, '', 'php', '', '', 'php'), 
(14, 2, '', 'mysql', '', '', 'mysql'), 
(15, 1, '', 'nhân-tài-đất-việt-2011', '', '', 'nhân tài đất việt 2011'), 
(16, 9, '', 'mã-nguồn-mở', '', '', 'mã nguồn mở'), 
(17, 2, '', 'nukeviet4', '', '', 'nukeviet4'), 
(18, 1, '', 'mail', '', '', 'mail'), 
(19, 1, '', 'fpt', '', '', 'fpt'), 
(20, 1, '', 'smtp', '', '', 'smtp'), 
(21, 1, '', 'bootstrap', '', '', 'bootstrap'), 
(22, 1, '', 'block', '', '', 'block'), 
(23, 1, '', 'modules', '', '', 'modules'), 
(24, 2, '', 'banner', '', '', 'banner'), 
(25, 1, '', 'liên-kết', '', '', 'liên kết'), 
(26, 2, '', 'hosting', '', '', 'hosting'), 
(27, 1, '', 'hỗ-trợ', '', '', 'hỗ trợ'), 
(28, 1, '', 'hợp-tác', '', '', 'hợp tác'), 
(29, 1, '', 'tốc-độ', '', '', 'tốc độ'), 
(30, 2, '', 'website', '', '', 'website'), 
(31, 1, '', 'bảo-mật', '', '', 'bảo mật'), 
(32, 4, '', 'giáo-dục', '', '', 'giáo dục'), 
(33, 1, '', 'edu-gate', '', '', 'edu gate'), 
(34, 2, '', 'lập-trình', '', '', 'lập trình'), 
(35, 1, '', 'logo', '', '', 'logo'), 
(36, 1, '', 'code', '', '', 'code'), 
(37, 1, '', 'thực-tập', '', '', 'thực tập'), 
(38, 1, '', 'kinh-doanh', '', '', 'kinh doanh'), 
(39, 1, '', 'nhân-viên', '', '', 'nhân viên'), 
(40, 1, '', 'bộ-gd&đt', '', '', 'Bộ GD&ĐT'), 
(41, 1, '', 'module', '', '', 'module'), 
(42, 1, '', 'php-nuke', '', '', 'php-nuke');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_tags_id`
--

DROP TABLE IF EXISTS `nv4_vi_news_tags_id`;
CREATE TABLE `nv4_vi_news_tags_id` (
  `id` int(11) NOT NULL,
  `tid` mediumint(9) NOT NULL,
  `keyword` varchar(65)  COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `id_tid` (`id`,`tid`),
  KEY `tid` (`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_news_tags_id`
--

INSERT INTO `nv4_vi_news_tags_id` VALUES
(1, 7, 'thương mại điện'), 
(1, 9, 'nukeviet'), 
(1, 41, 'module'), 
(1, 16, 'mã nguồn mở'), 
(1, 42, 'php-nuke'), 
(2, 16, 'mã nguồn mở'), 
(2, 9, 'nukeviet'), 
(2, 17, 'nukeviet4'), 
(2, 10, 'vinades'), 
(2, 24, 'banner'), 
(2, 25, 'liên kết'), 
(2, 26, 'hosting'), 
(2, 27, 'hỗ trợ'), 
(2, 28, 'hợp tác'), 
(3, 10, 'vinades'), 
(3, 9, 'nukeviet'), 
(3, 11, 'lập trình viên'), 
(3, 12, 'chuyên viên đồ họa'), 
(3, 13, 'php'), 
(3, 14, 'mysql'), 
(4, 10, 'vinades'), 
(4, 34, 'lập trình'), 
(4, 35, 'logo'), 
(4, 24, 'banner'), 
(4, 30, 'website'), 
(4, 36, 'code'), 
(4, 13, 'php'), 
(5, 16, 'mã nguồn mở'), 
(5, 10, 'vinades'), 
(5, 34, 'lập trình'), 
(5, 9, 'nukeviet'), 
(6, 15, 'Nhân tài đất Việt 2011'), 
(6, 16, 'mã nguồn mở'), 
(6, 9, 'nukeviet'), 
(7, 16, 'mã nguồn mở'), 
(7, 9, 'nukeviet'), 
(7, 40, 'Bộ GD&ĐT'), 
(7, 32, 'giáo dục'), 
(8, 38, 'kinh doanh'), 
(8, 9, 'nukeviet'), 
(8, 32, 'giáo dục'), 
(8, 39, 'nhân viên'), 
(9, 37, 'thực tập'), 
(9, 10, 'vinades'), 
(9, 12, 'chuyên viên đồ họa'), 
(9, 11, 'lập trình viên'), 
(9, 9, 'nukeviet'), 
(9, 16, 'mã nguồn mở'), 
(10, 16, 'mã nguồn mở'), 
(10, 10, 'vinades'), 
(10, 9, 'nukeviet'), 
(10, 11, 'lập trình viên'), 
(10, 12, 'chuyên viên đồ họa'), 
(11, 9, 'nukeviet'), 
(11, 16, 'mã nguồn mở'), 
(11, 32, 'giáo dục'), 
(12, 9, 'nukeviet'), 
(12, 32, 'giáo dục'), 
(12, 33, 'edu gate'), 
(13, 17, 'nukeviet4'), 
(13, 9, 'nukeviet'), 
(13, 10, 'vinades'), 
(13, 13, 'php'), 
(13, 14, 'mysql'), 
(13, 18, 'mail'), 
(13, 19, 'fpt'), 
(13, 20, 'smtp'), 
(13, 21, 'bootstrap'), 
(13, 22, 'block'), 
(13, 23, 'modules'), 
(13, 16, 'mã nguồn mở');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_tmp`
--

DROP TABLE IF EXISTS `nv4_vi_news_tmp`;
CREATE TABLE `nv4_vi_news_tmp` (
  `id` mediumint(8) unsigned NOT NULL,
  `admin_id` int(11) NOT NULL DEFAULT '0',
  `time_edit` int(11) NOT NULL,
  `time_late` int(11) NOT NULL,
  `ip` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_topics`
--

DROP TABLE IF EXISTS `nv4_vi_news_topics`;
CREATE TABLE `nv4_vi_news_topics` (
  `topicid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` smallint(6) NOT NULL DEFAULT '0',
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topicid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_news_topics`
--

INSERT INTO `nv4_vi_news_topics` VALUES
(1, 'NukeViet 4', 'NukeViet-4', '', 'NukeViet 4', 1, 'NukeViet 4', 1445396011, 1445396011);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_voices`
--

DROP TABLE IF EXISTS `nv4_vi_news_voices`;
CREATE TABLE `nv4_vi_news_voices` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `voice_key` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Khóa dùng trong Api sau này',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(10) unsigned NOT NULL DEFAULT '0',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0: Dừng, 1: Hoạt động',
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`),
  KEY `weight` (`weight`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_page`
--

DROP TABLE IF EXISTS `nv4_vi_page`;
CREATE TABLE `nv4_vi_page` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imagealt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imageposition` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `bodytext` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `layout_func` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` smallint(6) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hot_post` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_page_config`
--

DROP TABLE IF EXISTS `nv4_vi_page_config`;
CREATE TABLE `nv4_vi_page_config` (
  `config_name` varchar(30)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_page_config`
--

INSERT INTO `nv4_vi_page_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '20'), 
('news_first', '0'), 
('related_articles', '5'), 
('copy_page', '0'), 
('alias_lower', '1'), 
('socialbutton', 'facebook,twitter');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_referer_stats`
--

DROP TABLE IF EXISTS `nv4_vi_referer_stats`;
CREATE TABLE `nv4_vi_referer_stats` (
  `host` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `month01` int(11) NOT NULL DEFAULT '0',
  `month02` int(11) NOT NULL DEFAULT '0',
  `month03` int(11) NOT NULL DEFAULT '0',
  `month04` int(11) NOT NULL DEFAULT '0',
  `month05` int(11) NOT NULL DEFAULT '0',
  `month06` int(11) NOT NULL DEFAULT '0',
  `month07` int(11) NOT NULL DEFAULT '0',
  `month08` int(11) NOT NULL DEFAULT '0',
  `month09` int(11) NOT NULL DEFAULT '0',
  `month10` int(11) NOT NULL DEFAULT '0',
  `month11` int(11) NOT NULL DEFAULT '0',
  `month12` int(11) NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `host` (`host`),
  KEY `total` (`total`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_referer_stats`
--

INSERT INTO `nv4_vi_referer_stats` VALUES
('tancuong.ravao.online', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1712835425), 
('dichvucong.bocongan.gov.vn', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1712845763), 
('phongkhongkhongquan.vn', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1713013599), 
('', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1713078564), 
('google.com', 4, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 1713192464);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_searchkeys`
--

DROP TABLE IF EXISTS `nv4_vi_searchkeys`;
CREATE TABLE `nv4_vi_searchkeys` (
  `id` varchar(32)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `skey` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `search_engine` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  KEY `id` (`id`),
  KEY `skey` (`skey`),
  KEY `search_engine` (`search_engine`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_siteterms`
--

DROP TABLE IF EXISTS `nv4_vi_siteterms`;
CREATE TABLE `nv4_vi_siteterms` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imagealt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imageposition` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `bodytext` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `layout_func` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` smallint(6) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hot_post` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_siteterms`
--

INSERT INTO `nv4_vi_siteterms` VALUES
(1, 'Chính sách bảo mật (Quyền riêng tư)', 'privacy', '', '', 0, 'Tài liệu này cung cấp cho bạn (người truy cập và sử dụng website) chính sách liên quan đến bảo mật và quyền riêng tư của bạn', '<strong><a id=\"index\" name=\"index\"></a>Danh mục</strong><br /> <a href=\"#1\">Điều 1: Thu thập thông tin</a><br /> <a href=\"#2\">Điều 2: Lưu trữ &amp; Bảo vệ thông tin</a><br /> <a href=\"#3\">Điều 3: Sử dụng thông tin </a><br /> <a href=\"#4\">Điều 4: Tiếp nhận thông tin từ các đối tác </a><br /> <a href=\"#5\">Điều 5: Chia sẻ thông tin với bên thứ ba</a><br /> <a href=\"#6\">Điều 6: Thay đổi chính sách bảo mật</a>  <hr  /> <h2><a id=\"1\" name=\"1\"></a>Điều 1: Thu thập thông tin</h2>  <h3>1.1. Thu thập tự động:</h3>  <div>Hệ thống này được xây dựng bằng mã nguồn NukeViet. Như mọi website hiện đại khác, chúng tôi sẽ thu thập địa chỉ IP và các thông tin web tiêu chuẩn khác của bạn như: loại trình duyệt, các trang bạn truy cập trong quá trình sử dụng dịch vụ, thông tin về máy tính &amp; thiết bị mạng v.v… cho mục đích phân tích thông tin phục vụ việc bảo mật và giữ an toàn cho hệ thống.</div>  <h3>1.2. Thu thập từ các khai báo của chính bạn:</h3>  <div>Các thông tin do bạn khai báo cho chúng tôi trong quá trình làm việc như: đăng ký tài khoản, liên hệ với chúng tôi... cũng sẽ được chúng tôi lưu trữ phục vụ công việc chăm sóc khách hàng sau này.</div>  <h3>1.3. Thu thập thông tin thông qua việc đặt cookies:</h3>  <p>Như mọi website hiện đại khác, khi bạn truy cập website, chúng tôi (hoặc các công cụ theo dõi hoặc thống kê hoạt động của website do các đối tác cung cấp) sẽ đặt một số File dữ liệu gọi là Cookies lên đĩa cứng hoặc bộ nhớ máy tính của bạn.</p>  <p>Một trong số những Cookies này có thể tồn tại lâu để thuận tiện cho bạn trong quá trình sử dụng, ví dụ như: lưu Email của bạn trong trang đăng nhập để bạn không phải nhập lại v.v…</p>  <h3>1.4. Thu thập và lưu trữ thông tin trong quá khứ:</h3>  <p>Bạn có thể thay đổi thông tin cá nhân của mình bất kỳ lúc nào bằng cách sử dụng chức năng tương ứng. Tuy nhiên chúng tôi sẽ lưu lại những thông tin bị thay đổi để chống các hành vi xóa dấu vết gian lận.</p>  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p>  <h2><a id=\"2\" name=\"2\"></a>Điều 2: Lưu trữ &amp; Bảo vệ thông tin</h2>  <div>Hầu hết các thông tin được thu thập sẽ được lưu trữ tại cơ sở dữ liệu của chúng tôi.<br /> <br /> Chúng tôi bảo vệ dữ liệu cá nhân của các bạn bằng các hình thức như: mật khẩu, tường lửa, mã hóa cùng các hình thức thích hợp khác và chỉ cấp phép việc truy cập và xử lý dữ liệu cho các đối tượng phù hợp, ví dụ chính bạn hoặc các nhân viên có trách nhiệm xử lý thông tin với bạn thông qua các bước xác định danh tính phù hợp.<br /> <br /> Mật khẩu của bạn được lưu trữ và bảo vệ bằng phương pháp mã hoá trong cơ sở dữ liệu của hệ thống, vì thế nó rất an toàn. Tuy nhiên, chúng tôi khuyên bạn không nên dùng lại mật khẩu này trên các website khác. Mật khẩu của bạn là cách duy nhất để bạn đăng nhập vào tài khoản thành viên của mình trong website này, vì thế hãy cất giữ nó cẩn thận. Trong mọi trường hợp bạn không nên cung cấp thông tin mật khẩu cho bất kỳ người nào dù là người của chúng tôi, người của NukeViet hay bất kỳ người thứ ba nào khác trừ khi bạn hiểu rõ các rủi ro khi để lộ mật khẩu. Nếu quên mật khẩu, bạn có thể sử dụng chức năng “<a href=\"/users/lostpass/\">Quên mật khẩu</a>” trên website. Để thực hiện việc này, bạn cần phải cung cấp cho hệ thống biết tên thành viên hoặc địa chỉ Email đang sử dụng của mình trong tài khoản, sau đó hệ thống sẽ tạo ra cho bạn mật khẩu mới và gửi đến cho bạn để bạn vẫn có thể đăng nhập vào tài khoản thành viên của mình.  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p> </div>  <h2><a id=\"3\" name=\"3\"></a>Điều 3: Sử dụng thông tin</h2>  <p>Thông tin thu thập được sẽ được chúng tôi sử dụng để:</p>  <div>- Cung cấp các dịch vụ hỗ trợ &amp; chăm sóc khách hàng.</div>  <div>- Thực hiện giao dịch thanh toán &amp; gửi các thông báo trong quá trình giao dịch.</div>  <div>- Xử lý khiếu nại, thu phí &amp; giải quyết sự cố.</div>  <div>- Ngăn chặn các hành vi có nguy cơ rủi ro, bị cấm hoặc bất hợp pháp và đảm bảo tuân thủ đúng chính sách “Thỏa thuận người dùng”.</div>  <div>- Đo đạc, tùy biến &amp; cải tiến dịch vụ, nội dung và hình thức của website.</div>  <div>- Gửi bạn các thông tin về chương trình Marketing, các thông báo &amp; chương trình khuyến mại.</div>  <div>- So sánh độ chính xác của thông tin cá nhân của bạn trong quá trình kiểm tra với bên thứ ba.</div>  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p>  <h2><a id=\"4\" name=\"4\"></a>Điều 4: Tiếp nhận thông tin từ các đối tác</h2>  <div>Khi sử dụng các công cụ giao dịch và thanh toán thông qua internet, chúng tôi có thể tiếp nhận thêm các thông tin về bạn như địa chỉ username, Email, số tài khoản ngân hàng... Chúng tôi kiểm tra những thông tin này với cơ sở dữ liệu người dùng của mình nhằm xác nhận rằng bạn có phải là khách hàng của chúng tôi hay không nhằm giúp việc thực hiện các dịch vụ cho bạn được thuận lợi.<br /> <br /> Các thông tin tiếp nhận được sẽ được chúng tôi bảo mật như những thông tin mà chúng tôi thu thập được trực tiếp từ bạn.</div>  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p>  <h2><a id=\"5\" name=\"5\"></a>Điều 5: Chia sẻ thông tin với bên thứ ba</h2>  <p>Chúng tôi sẽ không chia sẻ thông tin cá nhân, thông tin tài chính... của bạn cho các bên thứ 3 trừ khi được sự đồng ý của chính bạn hoặc khi chúng tôi buộc phải tuân thủ theo các quy định pháp luật hoặc khi có yêu cầu từ cơ quan công quyền có thẩm quyền.</p>  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p>  <h2><a id=\"6\" name=\"6\"></a>Điều 6: Thay đổi chính sách bảo mật</h2>  <p>Chính sách Bảo mật này có thể thay đổi theo thời gian. Chúng tôi sẽ không giảm quyền của bạn theo Chính sách Bảo mật này mà không có sự đồng ý rõ ràng của bạn. Chúng tôi sẽ đăng bất kỳ thay đổi Chính sách Bảo mật nào trên trang này và, nếu những thay đổi này quan trọng, chúng tôi sẽ cung cấp thông báo nổi bật hơn (bao gồm, đối với một số dịch vụ nhất định, thông báo bằng email về các thay đổi của Chính sách Bảo mật).</p>  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p>  <p style=\"text-align: right;\">Chính sách bảo mật mặc định này được xây dựng cho <a href=\"http://nukeviet.vn\" target=\"_blank\">NukeViet CMS</a>, được tham khảo từ website <a href=\"http://webnhanh.vn/vi/thiet-ke-web/detail/Chinh-sach-bao-mat-Quyen-rieng-tu-Privacy-Policy-2147/\">webnhanh.vn</a></p>', '', 0, '4', '', 1, 1, 1712405092, 1712405092, 1, 0, 0), 
(2, 'Điều khoản và điều kiện sử dụng', 'terms-and-conditions', '', '', 0, 'Đây là các điều khoản và điều kiện áp dụng cho website này. Truy cập và sử dụng website tức là bạn đã đồng ý với các quy định này.', '<div>Cảm ơn bạn đã sử dụng. Xin vui lòng đọc các Điều khoản một cách cẩn thận, và <a href=\"/contact/\">liên hệ</a> với chúng tôi nếu bạn có bất kỳ câu hỏi. Bằng việc truy cập hoặc sử dụng website của chúng tôi, bạn đồng ý bị ràng buộc bởi các <a href=\"/siteterms/terms-and-conditions.html\">Điều khoản và điều kiện</a> sử dụng cũng như <a href=\"/siteterms/privacy.html\">Chính sách bảo mật</a> của chúng tôi. Nếu không đồng ý với các quy định này, bạn vui lòng ngưng sử dụng website.<br /> <br /> <strong><a id=\"index\" name=\"index\"></a>Danh mục</strong><br /> <a href=\"#1\">Điều 1: Điều khoản liên quan đến phần mềm vận hành website</a><br /> <a href=\"#2\">Điều 2: Giới hạn cho việc sử dụng Website và các tài liệu trên website</a><br /> <a href=\"#3\">Điều 3: Sử dụng thương hiệu</a><br /> <a href=\"#4\">Điều 4: Các hành vi bị nghiêm cấm</a><br /> <a href=\"#5\">Điều 5: Các đường liên kết đến các website khác</a><br /> <a href=\"#6\">Điều 6: Từ chối bảo đảm</a><br /> <a href=\"#7\">Điều 7: Luật áp dụng và cơ quan giải quyết tranh chấp</a><br /> <a href=\"#8\">Điều 8: Thay đổi điều khoản và điều kiện sử dụng</a></div>  <hr  /> <h2><a id=\"1\" name=\"1\"></a>Điều khoản liên quan đến phần mềm vận hành website</h2>  <p>- Website của chúng tôi sử dụng hệ thống NukeViet, là giải pháp về website/ cổng thông tin nguồn mở được phát hành theo giấy phép bản quyền phần mềm tự do nguồn mở “<a href=\"http://www.gnu.org/licenses/old-licenses/gpl-2.0.html\" target=\"_blank\">GNU General Public License</a>” (viết tắt là GNU/GPL hay GPL) và có thể tải về miễn phí tại trang web <a href=\"http://www.nukeviet.vn\" target=\"_blank\">www.nukeviet.vn</a>.<br /> - Website này do chúng tôi sở hữu, điều hành và duy trì. NukeViet (hiểu ở đây là “hệ thống NukeViet” (bao gồm nhân hệ thống NukeViet và các sản phẩm phái sinh như NukeViet CMS, NukeViet Portal, <a href=\"http://edu.nukeviet.vn\" target=\"_blank\">NukeViet Edu Gate</a>...), “www.nukeviet.vn”, “tổ chức NukeViet”, “ban điều hành NukeViet”, &quot;Ban Quản Trị NukeViet&quot; và nói chung là những gì liên quan đến NukeViet...) không liên quan gì đến việc chúng tôi điều hành website cũng như quy định bạn được phép làm và không được phép làm gì trên website này.<br /> - Hệ thống NukeViet là bộ mã nguồn được phát triển để xây dựng các website/ cổng thông tin trên mạng. Chúng tôi (chủ sở hữu, điều hành và duy trì website này) không hỗ trợ và khẳng định hay ngụ ý về việc có liên quan đến NukeViet. Để biết thêm nhiều thông tin về NukeViet, hãy ghé thăm website của NukeViet tại địa chỉ: <a href=\"http://nukeviet.vn\" target=\"_blank\">http://nukeviet.vn</a>.</p>  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p>  <h2><a id=\"2\" name=\"2\"></a>Giới hạn cho việc sử dụng Website và các tài liệu trên website</h2>  <p>- Tất cả các quyền liên quan đến tất cả tài liệu và thông tin được hiển thị và/ hoặc được tạo ra sẵn cho Website này (ví dụ như những tài liệu được cung cấp để tải về) được quản lý, sở hữu hoặc được cho phép sử dụng bởi chúng tôi hoặc chủ sở hữu tương ứng với giấy phép tương ứng. Việc sử dụng các tài liệu và thông tin phải được tuân thủ theo giấy phép tương ứng được áp dụng cho chúng.<br /> - Ngoại trừ các tài liệu được cấp phép rõ ràng dưới dạng giấy phép tư liệu mở&nbsp;Creative Commons (gọi là giấy phép CC) cho phép bạn khai thác và chia sẻ theo quy định của giấy phép tư liệu mở, đối với các loại tài liệu không ghi giấy phép rõ ràng thì bạn không được phép sử dụng (bao gồm nhưng không giới hạn việc sao chép, chỉnh sửa toàn bộ hay một phần, đăng tải, phân phối, cấp phép, bán và xuất bản) bất cứ tài liệu nào mà không có sự cho phép trước bằng văn bản của chúng tôi ngoại trừ việc sử dụng cho mục đích cá nhân, nội bộ, phi thương mại.<br /> - Một số tài liệu hoặc thông tin có những điều khoản và điều kiện áp dụng riêng cho chúng không phải là giấy phép tư liệu mở, trong trường hợp như vậy, bạn được yêu cầu phải chấp nhận các điều khoản và điều kiện đó khi truy cập vào các tài liệu và thông tin này.</p>  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p>  <h2><a id=\"3\" name=\"3\"></a>Sử dụng thương hiệu</h2>  <p>- VINADES.,JSC, NukeViet và thương hiệu gắn với NukeViet (ví dụ NukeViet CMS, NukeViet Portal, NukeViet Edu Gate...), logo công ty VINADES thuộc sở hữu của Công ty cổ phần phát triển nguồn mở Việt Nam.<br /> - Những tên sản phẩm, tên dịch vụ khác, logo và/ hoặc những tên công ty được sử dụng trong Website này là những tài sản đã được đăng ký độc quyền và được giữ bản quyền bởi những người sở hữu và/ hoặc người cấp phép tương ứng.</p>  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p>  <h2><a id=\"4\" name=\"4\"></a>Các hành vi bị nghiêm cấm</h2>  <p>Người truy cập website này không được thực hiện những hành vi dưới đây khi sử dụng website:<br /> - Xâm phạm các quyền hợp pháp (bao gồm nhưng không giới hạn đối với các quyền riêng tư và chung) của người khác.<br /> - Gây ra sự thiệt hại hoặc bất lợi cho người khác.<br /> - Làm xáo trộn trật tự công cộng.<br /> - Hành vi liên quan đến tội phạm.<br /> - Tải lên hoặc phát tán thông tin riêng tư của tổ chức, cá nhân khác mà không được sự chấp thuận của họ.<br /> - Sử dụng Website này vào mục đích thương mại mà chưa được sự cho phép của chúng tôi.<br /> - Nói xấu, làm nhục, phỉ báng người khác.<br /> - Tải lên các tập tin chứa virus hoặc các tập tin bị hư mà có thể gây thiệt hại đến sự vận hành của máy tính khác.<br /> - Những hoạt động có khả năng ảnh hưởng đến hoạt động bình thường của website.<br /> - Những hoạt động mà chúng tôi cho là không thích hợp.<br /> - Những hoạt động bất hợp pháp hoặc bị cấm bởi pháp luật hiện hành.</p>  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p>  <h2><a id=\"5\" name=\"5\"></a>Các đường liên kết đến các website khác</h2>  <p>- Các website của các bên thứ ba (không phải các trang do chúng tôi quản lý) được liên kết đến hoặc từ website này (&quot;Các website khác&quot;) được điều hành và duy trì hoàn toàn độc lập bởi các bên thứ ba đó và không nằm trong quyền điều khiển và/hoặc giám sát của chúng tôi. Việc truy cập các website khác phải được tuân thủ theo các điều khoản và điều kiện quy định bởi ban điều hành của website đó.<br /> - Chúng tôi không chịu trách nhiệm cho sự mất mát hoặc thiệt hại do việc truy cập và sử dụng các website bên ngoài, và bạn phải chịu mọi rủi ro khi truy cập các website đó.<br /> - Không có nội dung nào trong Website này thể hiện như một sự đảm bảo của chúng tôi về nội dung của các website khác và các sản phẩm và/ hoặc các dịch vụ xuất hiện và/ hoặc được cung cấp tại các website khác.</p>  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p>  <h2><a id=\"6\" name=\"6\"></a>Từ chối bảo đảm</h2>  <p>NGOẠI TRỪ PHẠM VI BỊ CẤM THEO LUẬT PHÁP HIỆN HÀNH, CHÚNG TÔI SẼ:<br /> - KHÔNG CHỊU TRÁCH NHIỆM HAY BẢO ĐẢM, MỘT CÁCH RÕ RÀNG HAY NGỤ Ý, BAO GỒM SỰ BẢO ĐẢM VỀ TÍNH CHÍNH XÁC, MỨC ĐỘ TIN CẬY, HOÀN THIỆN, PHÙ HỢP CHO MỤC ĐÍCH CỤ THỂ, SỰ KHÔNG XÂM PHẠM QUYỀN CỦA BÊN THỨ 3 VÀ/HOẶC TÍNH AN TOÀN CỦA NỘI DỤNG WEBSITE NÀY, VÀ NHỮNG TUYÊN BỐ, ĐẢM BẢO CÓ LIÊN QUAN.<br /> - KHÔNG CHỊU TRÁCH NHIỆM CHO BẤT KỲ SỰ THIỆT HẠI HAY MẤT MÁT PHÁT SINH TỪ VIỆC TRUY CẬP VÀ SỬ DỤNG WEBSITE HAY VIỆC KHÔNG THỂ SỬ DỤNG WEBSITE.<br /> - CHÚNG TÔI CÓ THỂ THAY ĐỔI VÀ/HOẶC THAY THẾ NỘI DUNG CỦA WEBSITE NÀY, HOẶC TẠM HOÃN HOẶC NGƯNG CUNG CẤP CÁC DỊCH VỤ QUA WEBSITE NÀY VÀO BẤT KỲ THỜI ĐIỂM NÀO MÀ KHÔNG CẦN THÔNG BÁO TRƯỚC. CHÚNG TÔI SẼ KHÔNG CHỊU TRÁCH NHIỆM CHO BẤT CỨ THIỆT HẠI NÀO PHÁT SINH DO SỰ THAY ĐỔI HOẶC THAY THẾ NỘI DUNG CỦA WEBSITE.</p>  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p>  <h2><a id=\"7\" name=\"7\"></a>Luật áp dụng và cơ quan giải quyết tranh chấp</h2>  <p>- Các Điều Khoản và Điều Kiện này được điều chỉnh và giải thích theo luật của Việt Nam trừ khi có điều khoản khác được cung cấp thêm. Tất cả tranh chấp phát sinh liên quan đến website này và các Điều Khoản và Điều Kiện sử dụng này sẽ được giải quyết tại các tòa án ở Việt Nam.<br /> - Nếu một phần nào đó của các Điều Khoản và Điều Kiện bị xem là không có giá trị, vô hiệu, hoặc không áp dụng được vì lý do nào đó, phần đó được xem như là phần riêng biệt và không ảnh hưởng đến tính hiệu lực của phần còn lại.<br /> - Trong trường hợp có sự mâu thuẫn giữa bản Tiếng Anh và bản Tiếng Việt của bản Điều Khoản và Điều Kiện này, bản Tiếng Việt sẽ được ưu tiên áp dụng.</p>  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p>  <h2><a id=\"8\" name=\"8\"></a>Thay đổi điều khoản và điều kiện sử dụng</h2>  <div>Điều khoản và điều kiện sử dụng có thể thay đổi theo thời gian. Chúng tôi bảo lưu quyền thay đổi hoặc sửa đổi bất kỳ điều khoản và điều kiện cũng như các quy định khác, bất cứ lúc nào và theo ý mình. Chúng tôi sẽ có thông báo trên website khi có sự thay đổi. Tiếp tục sử dụng trang web này sau khi đăng các thay đổi tức là bạn đã chấp nhận các thay đổi đó. <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p> </div>', '', 0, '4', '', 2, 1, 1712405092, 1712405092, 1, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_siteterms_config`
--

DROP TABLE IF EXISTS `nv4_vi_siteterms_config`;
CREATE TABLE `nv4_vi_siteterms_config` (
  `config_name` varchar(30)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_siteterms_config`
--

INSERT INTO `nv4_vi_siteterms_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '20'), 
('news_first', '0'), 
('related_articles', '5'), 
('copy_page', '0'), 
('alias_lower', '1'), 
('socialbutton', 'facebook,twitter');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_thong_tin`
--

DROP TABLE IF EXISTS `nv4_vi_thong_tin`;
CREATE TABLE `nv4_vi_thong_tin` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imagealt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imageposition` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `bodytext` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `layout_func` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` smallint(6) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hot_post` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_thong_tin`
--

INSERT INTO `nv4_vi_thong_tin` VALUES
(1, 'Danh sách đại lý, cửa hàng', 'danh-sach-dai-ly-cua-hang', '', '', 0, 'Danh sách đại lý', 'Danh sách đại lý, cửa hàng', 'danh sách', 1, '4', '', 1, 1, 1712537433, 1712912091, 1, 3, 0), 
(2, 'Đăng ký đại lý', 'dang-ky-dai-ly', '', '', 0, 'Đăng ký đại lý', 'Đăng ký đại lý', 'đăng ký', 1, '4', '', 2, 1, 1712912111, 1712912111, 1, 1, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_thong_tin_config`
--

DROP TABLE IF EXISTS `nv4_vi_thong_tin_config`;
CREATE TABLE `nv4_vi_thong_tin_config` (
  `config_name` varchar(30)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_thong_tin_config`
--

INSERT INTO `nv4_vi_thong_tin_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '20'), 
('news_first', '0'), 
('related_articles', '5'), 
('copy_page', '0'), 
('alias_lower', '1'), 
('socialbutton', 'facebook,twitter');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_tin_tuc_1`
--

DROP TABLE IF EXISTS `nv4_vi_tin_tuc_1`;
CREATE TABLE `nv4_vi_tin_tuc_1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(9) NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `weight` int(10) unsigned NOT NULL DEFAULT '0',
  `publtime` int(10) unsigned NOT NULL DEFAULT '0',
  `exptime` int(10) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `external_link` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `instant_active` tinyint(1) NOT NULL DEFAULT '0',
  `instant_template` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `instant_creatauto` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `edittime` (`edittime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`),
  KEY `instant_active` (`instant_active`),
  KEY `instant_creatauto` (`instant_creatauto`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_tin_tuc_1`
--

INSERT INTO `nv4_vi_tin_tuc_1` VALUES
(4, 1, '1,3,5', 0, 1, '', 0, 1712670024, 1712670024, 1, 4, 1712669940, 0, 2, 'Tuyệt chiêu pha trà ngon cực kỳ đơn giản', 'tuyet-chieu-pha-tra-ngon-cuc-ky-don-gian', 'Trà vẫn là thức uống yêu thích của nhiều người nhất là đối với các cụ lớn tuổi. Để có được ly trà ngon, đậm vị còn tùy thuộc và 4 yếu tố: loại trà, ấm pha, nguồn nước và cách pha trà. Vậy phải như thế nào mới có một ấm trà ngon?', 'https://cdn.tgdd.vn/Files/2018/01/16/1059355/tuyet-chieu-pha-tra-ngon-cuc-ky-don-gian2_800x400.jpg', '', 3, 1, '4', 1, 0, 6, 0, 0, 0, 0, '', 0), 
(2, 1, '1,2,3,5,4', 0, 1, '', 0, 1712669747, 1712717793, 1, 2, 1712669700, 0, 2, 'Thưởng thức Trà Sen Sớm để cảm nhận hương vị sớm của Sen', 'thuong-thuc-tra-sen-som-de-cam-nhan-huong-vi-som-cua-sen', 'Sớm mai lấp ló vài giọt nắng. Giữa khoảng không gian mênh mông, làn sương mỏng manh đang tan đi trong mùi sen thơm nức… 5h sáng, mấy chiếc ghe bắt đầu vào việc. Đôi mắt tinh nhanh của người hái sen tìm kiếm những búp sen “hé miệng sáo” đang lấp ló giấu mình sau những tấm lá. Và rồi chính họ cũng thoắt ẩn thoắt hiện trong đầm sen mênh mông. Chỉ biết là trước khi nắng lên thì ghe đã cập', 'https://htxtravandung.vn/uploads/news/tin_hoat_dong/pha-tra-sen-tay-ho-1.jpg', '', 3, 1, '4', 1, 0, 1, 0, 0, 0, 0, '', 0), 
(1, 1, '1,2,3,5,4', 0, 1, '', 0, 1712669713, 1712717807, 1, 1, 1712669640, 0, 2, 'Ý tưởng để kết hợp trà với bánh trung thu của bạn', 'y-tuong-de-ket-hop-tra-voi-banh-trung-thu-cua-ban', 'Trà, bánh trung thu và mặt trăng sáng đã được kết hợp hài hòa từ thời xa xưa. Đó là điều thơ mộng nhất cho các gia đình ngồi quanh bàn trong sân, ăn bánh trung thu và uống trà trong khi thưởng thức vẻ đẹp của mặt trăng tròn. Trong ấn tượng chung, mặt trăng trong ngày trung thu là thanh lịch, theo nghĩa này, hợp nhất là uống trà.', 'https://htxtravandung.vn/uploads/news/tin_hoat_dong/ket-hop-banh-voi-tra-1.jpg', '', 3, 1, '4', 1, 0, 1, 0, 0, 0, 0, '', 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_tin_tuc_2`
--

DROP TABLE IF EXISTS `nv4_vi_tin_tuc_2`;
CREATE TABLE `nv4_vi_tin_tuc_2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(9) NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `weight` int(10) unsigned NOT NULL DEFAULT '0',
  `publtime` int(10) unsigned NOT NULL DEFAULT '0',
  `exptime` int(10) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `external_link` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `instant_active` tinyint(1) NOT NULL DEFAULT '0',
  `instant_template` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `instant_creatauto` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `edittime` (`edittime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`),
  KEY `instant_active` (`instant_active`),
  KEY `instant_creatauto` (`instant_creatauto`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_tin_tuc_2`
--

INSERT INTO `nv4_vi_tin_tuc_2` VALUES
(2, 1, '1,2,3,5,4', 0, 1, '', 0, 1712669747, 1712717793, 1, 2, 1712669700, 0, 2, 'Thưởng thức Trà Sen Sớm để cảm nhận hương vị sớm của Sen', 'thuong-thuc-tra-sen-som-de-cam-nhan-huong-vi-som-cua-sen', 'Sớm mai lấp ló vài giọt nắng. Giữa khoảng không gian mênh mông, làn sương mỏng manh đang tan đi trong mùi sen thơm nức… 5h sáng, mấy chiếc ghe bắt đầu vào việc. Đôi mắt tinh nhanh của người hái sen tìm kiếm những búp sen “hé miệng sáo” đang lấp ló giấu mình sau những tấm lá. Và rồi chính họ cũng thoắt ẩn thoắt hiện trong đầm sen mênh mông. Chỉ biết là trước khi nắng lên thì ghe đã cập', 'https://htxtravandung.vn/uploads/news/tin_hoat_dong/pha-tra-sen-tay-ho-1.jpg', '', 3, 1, '4', 1, 0, 1, 0, 0, 0, 0, '', 0), 
(1, 1, '1,2,3,5,4', 0, 1, '', 0, 1712669713, 1712717807, 1, 1, 1712669640, 0, 2, 'Ý tưởng để kết hợp trà với bánh trung thu của bạn', 'y-tuong-de-ket-hop-tra-voi-banh-trung-thu-cua-ban', 'Trà, bánh trung thu và mặt trăng sáng đã được kết hợp hài hòa từ thời xa xưa. Đó là điều thơ mộng nhất cho các gia đình ngồi quanh bàn trong sân, ăn bánh trung thu và uống trà trong khi thưởng thức vẻ đẹp của mặt trăng tròn. Trong ấn tượng chung, mặt trăng trong ngày trung thu là thanh lịch, theo nghĩa này, hợp nhất là uống trà.', 'https://htxtravandung.vn/uploads/news/tin_hoat_dong/ket-hop-banh-voi-tra-1.jpg', '', 3, 1, '4', 1, 0, 1, 0, 0, 0, 0, '', 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_tin_tuc_3`
--

DROP TABLE IF EXISTS `nv4_vi_tin_tuc_3`;
CREATE TABLE `nv4_vi_tin_tuc_3` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(9) NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `weight` int(10) unsigned NOT NULL DEFAULT '0',
  `publtime` int(10) unsigned NOT NULL DEFAULT '0',
  `exptime` int(10) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `external_link` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `instant_active` tinyint(1) NOT NULL DEFAULT '0',
  `instant_template` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `instant_creatauto` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `edittime` (`edittime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`),
  KEY `instant_active` (`instant_active`),
  KEY `instant_creatauto` (`instant_creatauto`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_tin_tuc_3`
--

INSERT INTO `nv4_vi_tin_tuc_3` VALUES
(3, 3, '3,5', 0, 1, '', 0, 1712669970, 1712669970, 1, 3, 1712669880, 0, 2, 'Hướng dẫn cách pha trà thơm – ngon – giữ nguyên vị trà', 'huong-dan-cach-pha-tra-thom-ngon-giu-nguyen-vi-tra', 'Hầu như ai cũng biết đến cách pha trà cơ bản là hãm lá trà khô trong ấm với nước sôi rồi rót ra chén để thưởng thức. Tuy nhiên để có được một chén trà thơm, ngon, giữ trọn hương vị tự nhiên nhất thì bạn cần phải chú ý đến một số yếu tố ảnh hưởng khác. Vậy làm thế nào để pha trà đúng cách, mời bạn cùng TITA Art tìm hiểu trong bài viết sau đây nhé.', 'https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-dung-cach.jpg', '', 3, 1, '4', 1, 0, 2, 0, 0, 0, 0, '', 0), 
(4, 1, '1,3,5', 0, 1, '', 0, 1712670024, 1712670024, 1, 4, 1712669940, 0, 2, 'Tuyệt chiêu pha trà ngon cực kỳ đơn giản', 'tuyet-chieu-pha-tra-ngon-cuc-ky-don-gian', 'Trà vẫn là thức uống yêu thích của nhiều người nhất là đối với các cụ lớn tuổi. Để có được ly trà ngon, đậm vị còn tùy thuộc và 4 yếu tố: loại trà, ấm pha, nguồn nước và cách pha trà. Vậy phải như thế nào mới có một ấm trà ngon?', 'https://cdn.tgdd.vn/Files/2018/01/16/1059355/tuyet-chieu-pha-tra-ngon-cuc-ky-don-gian2_800x400.jpg', '', 3, 1, '4', 1, 0, 6, 0, 0, 0, 0, '', 0), 
(5, 5, '3,5', 0, 1, '', 0, 1712670077, 1712670077, 1, 5, 1712670000, 0, 2, 'Hai cách ướp trà sen thông dụng nhất', 'hai-cach-uop-tra-sen-thong-dung-nhat', 'Nếu như bạn chưa có điều kiện thưởng thức chén trà sen Hồ Tây nổi tiếng thì có thể tự mình học cách ướp trà sen tại nhà nhé.', 'https://vnn-imgs-a1.vgcloud.vn/info-imgs.vgcloud.vn/2020/06/26/14/hai-cach-uop-tra-sen-thong-dung-nhat.jpg', '', 3, 1, '4', 1, 0, 1, 0, 0, 0, 0, '', 0), 
(2, 1, '1,2,3,5,4', 0, 1, '', 0, 1712669747, 1712717793, 1, 2, 1712669700, 0, 2, 'Thưởng thức Trà Sen Sớm để cảm nhận hương vị sớm của Sen', 'thuong-thuc-tra-sen-som-de-cam-nhan-huong-vi-som-cua-sen', 'Sớm mai lấp ló vài giọt nắng. Giữa khoảng không gian mênh mông, làn sương mỏng manh đang tan đi trong mùi sen thơm nức… 5h sáng, mấy chiếc ghe bắt đầu vào việc. Đôi mắt tinh nhanh của người hái sen tìm kiếm những búp sen “hé miệng sáo” đang lấp ló giấu mình sau những tấm lá. Và rồi chính họ cũng thoắt ẩn thoắt hiện trong đầm sen mênh mông. Chỉ biết là trước khi nắng lên thì ghe đã cập', 'https://htxtravandung.vn/uploads/news/tin_hoat_dong/pha-tra-sen-tay-ho-1.jpg', '', 3, 1, '4', 1, 0, 1, 0, 0, 0, 0, '', 0), 
(1, 1, '1,2,3,5,4', 0, 1, '', 0, 1712669713, 1712717807, 1, 1, 1712669640, 0, 2, 'Ý tưởng để kết hợp trà với bánh trung thu của bạn', 'y-tuong-de-ket-hop-tra-voi-banh-trung-thu-cua-ban', 'Trà, bánh trung thu và mặt trăng sáng đã được kết hợp hài hòa từ thời xa xưa. Đó là điều thơ mộng nhất cho các gia đình ngồi quanh bàn trong sân, ăn bánh trung thu và uống trà trong khi thưởng thức vẻ đẹp của mặt trăng tròn. Trong ấn tượng chung, mặt trăng trong ngày trung thu là thanh lịch, theo nghĩa này, hợp nhất là uống trà.', 'https://htxtravandung.vn/uploads/news/tin_hoat_dong/ket-hop-banh-voi-tra-1.jpg', '', 3, 1, '4', 1, 0, 1, 0, 0, 0, 0, '', 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_tin_tuc_4`
--

DROP TABLE IF EXISTS `nv4_vi_tin_tuc_4`;
CREATE TABLE `nv4_vi_tin_tuc_4` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(9) NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `weight` int(10) unsigned NOT NULL DEFAULT '0',
  `publtime` int(10) unsigned NOT NULL DEFAULT '0',
  `exptime` int(10) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `external_link` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `instant_active` tinyint(1) NOT NULL DEFAULT '0',
  `instant_template` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `instant_creatauto` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `edittime` (`edittime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`),
  KEY `instant_active` (`instant_active`),
  KEY `instant_creatauto` (`instant_creatauto`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_tin_tuc_4`
--

INSERT INTO `nv4_vi_tin_tuc_4` VALUES
(2, 1, '1,2,3,5,4', 0, 1, '', 0, 1712669747, 1712717793, 1, 2, 1712669700, 0, 2, 'Thưởng thức Trà Sen Sớm để cảm nhận hương vị sớm của Sen', 'thuong-thuc-tra-sen-som-de-cam-nhan-huong-vi-som-cua-sen', 'Sớm mai lấp ló vài giọt nắng. Giữa khoảng không gian mênh mông, làn sương mỏng manh đang tan đi trong mùi sen thơm nức… 5h sáng, mấy chiếc ghe bắt đầu vào việc. Đôi mắt tinh nhanh của người hái sen tìm kiếm những búp sen “hé miệng sáo” đang lấp ló giấu mình sau những tấm lá. Và rồi chính họ cũng thoắt ẩn thoắt hiện trong đầm sen mênh mông. Chỉ biết là trước khi nắng lên thì ghe đã cập', 'https://htxtravandung.vn/uploads/news/tin_hoat_dong/pha-tra-sen-tay-ho-1.jpg', '', 3, 1, '4', 1, 0, 1, 0, 0, 0, 0, '', 0), 
(1, 1, '1,2,3,5,4', 0, 1, '', 0, 1712669713, 1712717807, 1, 1, 1712669640, 0, 2, 'Ý tưởng để kết hợp trà với bánh trung thu của bạn', 'y-tuong-de-ket-hop-tra-voi-banh-trung-thu-cua-ban', 'Trà, bánh trung thu và mặt trăng sáng đã được kết hợp hài hòa từ thời xa xưa. Đó là điều thơ mộng nhất cho các gia đình ngồi quanh bàn trong sân, ăn bánh trung thu và uống trà trong khi thưởng thức vẻ đẹp của mặt trăng tròn. Trong ấn tượng chung, mặt trăng trong ngày trung thu là thanh lịch, theo nghĩa này, hợp nhất là uống trà.', 'https://htxtravandung.vn/uploads/news/tin_hoat_dong/ket-hop-banh-voi-tra-1.jpg', '', 3, 1, '4', 1, 0, 1, 0, 0, 0, 0, '', 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_tin_tuc_5`
--

DROP TABLE IF EXISTS `nv4_vi_tin_tuc_5`;
CREATE TABLE `nv4_vi_tin_tuc_5` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(9) NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `weight` int(10) unsigned NOT NULL DEFAULT '0',
  `publtime` int(10) unsigned NOT NULL DEFAULT '0',
  `exptime` int(10) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `external_link` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `instant_active` tinyint(1) NOT NULL DEFAULT '0',
  `instant_template` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `instant_creatauto` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `edittime` (`edittime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`),
  KEY `instant_active` (`instant_active`),
  KEY `instant_creatauto` (`instant_creatauto`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_tin_tuc_5`
--

INSERT INTO `nv4_vi_tin_tuc_5` VALUES
(3, 3, '3,5', 0, 1, '', 0, 1712669970, 1712669970, 1, 3, 1712669880, 0, 2, 'Hướng dẫn cách pha trà thơm – ngon – giữ nguyên vị trà', 'huong-dan-cach-pha-tra-thom-ngon-giu-nguyen-vi-tra', 'Hầu như ai cũng biết đến cách pha trà cơ bản là hãm lá trà khô trong ấm với nước sôi rồi rót ra chén để thưởng thức. Tuy nhiên để có được một chén trà thơm, ngon, giữ trọn hương vị tự nhiên nhất thì bạn cần phải chú ý đến một số yếu tố ảnh hưởng khác. Vậy làm thế nào để pha trà đúng cách, mời bạn cùng TITA Art tìm hiểu trong bài viết sau đây nhé.', 'https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-dung-cach.jpg', '', 3, 1, '4', 1, 0, 2, 0, 0, 0, 0, '', 0), 
(4, 1, '1,3,5', 0, 1, '', 0, 1712670024, 1712670024, 1, 4, 1712669940, 0, 2, 'Tuyệt chiêu pha trà ngon cực kỳ đơn giản', 'tuyet-chieu-pha-tra-ngon-cuc-ky-don-gian', 'Trà vẫn là thức uống yêu thích của nhiều người nhất là đối với các cụ lớn tuổi. Để có được ly trà ngon, đậm vị còn tùy thuộc và 4 yếu tố: loại trà, ấm pha, nguồn nước và cách pha trà. Vậy phải như thế nào mới có một ấm trà ngon?', 'https://cdn.tgdd.vn/Files/2018/01/16/1059355/tuyet-chieu-pha-tra-ngon-cuc-ky-don-gian2_800x400.jpg', '', 3, 1, '4', 1, 0, 6, 0, 0, 0, 0, '', 0), 
(5, 5, '3,5', 0, 1, '', 0, 1712670077, 1712670077, 1, 5, 1712670000, 0, 2, 'Hai cách ướp trà sen thông dụng nhất', 'hai-cach-uop-tra-sen-thong-dung-nhat', 'Nếu như bạn chưa có điều kiện thưởng thức chén trà sen Hồ Tây nổi tiếng thì có thể tự mình học cách ướp trà sen tại nhà nhé.', 'https://vnn-imgs-a1.vgcloud.vn/info-imgs.vgcloud.vn/2020/06/26/14/hai-cach-uop-tra-sen-thong-dung-nhat.jpg', '', 3, 1, '4', 1, 0, 1, 0, 0, 0, 0, '', 0), 
(2, 1, '1,2,3,5,4', 0, 1, '', 0, 1712669747, 1712717793, 1, 2, 1712669700, 0, 2, 'Thưởng thức Trà Sen Sớm để cảm nhận hương vị sớm của Sen', 'thuong-thuc-tra-sen-som-de-cam-nhan-huong-vi-som-cua-sen', 'Sớm mai lấp ló vài giọt nắng. Giữa khoảng không gian mênh mông, làn sương mỏng manh đang tan đi trong mùi sen thơm nức… 5h sáng, mấy chiếc ghe bắt đầu vào việc. Đôi mắt tinh nhanh của người hái sen tìm kiếm những búp sen “hé miệng sáo” đang lấp ló giấu mình sau những tấm lá. Và rồi chính họ cũng thoắt ẩn thoắt hiện trong đầm sen mênh mông. Chỉ biết là trước khi nắng lên thì ghe đã cập', 'https://htxtravandung.vn/uploads/news/tin_hoat_dong/pha-tra-sen-tay-ho-1.jpg', '', 3, 1, '4', 1, 0, 1, 0, 0, 0, 0, '', 0), 
(1, 1, '1,2,3,5,4', 0, 1, '', 0, 1712669713, 1712717807, 1, 1, 1712669640, 0, 2, 'Ý tưởng để kết hợp trà với bánh trung thu của bạn', 'y-tuong-de-ket-hop-tra-voi-banh-trung-thu-cua-ban', 'Trà, bánh trung thu và mặt trăng sáng đã được kết hợp hài hòa từ thời xa xưa. Đó là điều thơ mộng nhất cho các gia đình ngồi quanh bàn trong sân, ăn bánh trung thu và uống trà trong khi thưởng thức vẻ đẹp của mặt trăng tròn. Trong ấn tượng chung, mặt trăng trong ngày trung thu là thanh lịch, theo nghĩa này, hợp nhất là uống trà.', 'https://htxtravandung.vn/uploads/news/tin_hoat_dong/ket-hop-banh-voi-tra-1.jpg', '', 3, 1, '4', 1, 0, 1, 0, 0, 0, 0, '', 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_tin_tuc_admins`
--

DROP TABLE IF EXISTS `nv4_vi_tin_tuc_admins`;
CREATE TABLE `nv4_vi_tin_tuc_admins` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(6) NOT NULL DEFAULT '0',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `add_content` tinyint(4) NOT NULL DEFAULT '0',
  `pub_content` tinyint(4) NOT NULL DEFAULT '0',
  `edit_content` tinyint(4) NOT NULL DEFAULT '0',
  `del_content` tinyint(4) NOT NULL DEFAULT '0',
  `app_content` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`,`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_tin_tuc_author`
--

DROP TABLE IF EXISTS `nv4_vi_tin_tuc_author`;
CREATE TABLE `nv4_vi_tin_tuc_author` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `alias` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `pseudonym` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(10) unsigned NOT NULL DEFAULT '0',
  `active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `numnews` mediumint(9) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid` (`uid`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_tin_tuc_author`
--

INSERT INTO `nv4_vi_tin_tuc_author` VALUES
(1, 1, 'admin', 'admin', '', '', 1712669663, 0, 1, 5);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_tin_tuc_authorlist`
--

DROP TABLE IF EXISTS `nv4_vi_tin_tuc_authorlist`;
CREATE TABLE `nv4_vi_tin_tuc_authorlist` (
  `id` int(11) NOT NULL,
  `aid` mediumint(9) NOT NULL,
  `alias` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `pseudonym` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  UNIQUE KEY `id_aid` (`id`,`aid`),
  KEY `aid` (`aid`),
  KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_tin_tuc_authorlist`
--

INSERT INTO `nv4_vi_tin_tuc_authorlist` VALUES
(1, 1, 'admin', 'admin'), 
(2, 1, 'admin', 'admin'), 
(3, 1, 'admin', 'admin'), 
(4, 1, 'admin', 'admin'), 
(5, 1, 'admin', 'admin');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_tin_tuc_block`
--

DROP TABLE IF EXISTS `nv4_vi_tin_tuc_block`;
CREATE TABLE `nv4_vi_tin_tuc_block` (
  `bid` smallint(5) unsigned NOT NULL,
  `id` int(10) unsigned NOT NULL,
  `weight` int(10) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_tin_tuc_block`
--

INSERT INTO `nv4_vi_tin_tuc_block` VALUES
(1, 1, 5), 
(1, 2, 4), 
(1, 3, 3), 
(1, 4, 2), 
(1, 5, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_tin_tuc_block_cat`
--

DROP TABLE IF EXISTS `nv4_vi_tin_tuc_block_cat`;
CREATE TABLE `nv4_vi_tin_tuc_block_cat` (
  `bid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `numbers` smallint(6) NOT NULL DEFAULT '10',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` smallint(6) NOT NULL DEFAULT '0',
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_tin_tuc_block_cat`
--

INSERT INTO `nv4_vi_tin_tuc_block_cat` VALUES
(1, 1, 4, 'Tin mới', 'tinh-thai-nguyen-dat-nhieu-ket-qua-tich-cuc-sau-02-nam-thuc-hien-de-an-06-cua-chinh-phu', '', '', 1, '', 1712669576, 1712669576), 
(2, 0, 4, 'Tin nổi bật', 'tin-noi-bat', '', '', 2, '', 1712669584, 1712669584);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_tin_tuc_cat`
--

DROP TABLE IF EXISTS `nv4_vi_tin_tuc_cat`;
CREATE TABLE `nv4_vi_tin_tuc_cat` (
  `catid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `titlesite` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `descriptionhtml` text  COLLATE utf8mb4_unicode_ci,
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `viewdescription` tinyint(4) NOT NULL DEFAULT '0',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sort` smallint(6) NOT NULL DEFAULT '0',
  `lev` smallint(6) NOT NULL DEFAULT '0',
  `viewcat` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` smallint(6) NOT NULL DEFAULT '0',
  `subcatid` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `numlinks` tinyint(3) unsigned NOT NULL DEFAULT '3',
  `newday` tinyint(3) unsigned NOT NULL DEFAULT '2',
  `featured` int(11) NOT NULL DEFAULT '0',
  `ad_block_cat` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `admins` text  COLLATE utf8mb4_unicode_ci,
  `add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(10) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` smallint(6) NOT NULL DEFAULT '1',
  PRIMARY KEY (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_tin_tuc_cat`
--

INSERT INTO `nv4_vi_tin_tuc_cat` VALUES
(1, 0, 'Tin nội bộ', '', 'tin-noi-bo', '', '', '', 0, 1, 1, 0, 'viewcat_page_new', 0, '', 3, 2, 0, '', '', '', 1712540004, 1712540004, '6', 1), 
(2, 0, 'Tin hoạt động', '', 'tin-hoat-dong', '', '', '', 0, 2, 2, 0, 'viewcat_page_new', 0, '', 3, 2, 0, '', '', '', 1712540008, 1712540008, '6', 1), 
(3, 0, 'Ngành chè', '', 'nganh-che', '', '', '', 0, 3, 3, 0, 'viewcat_page_new', 0, '', 3, 2, 0, '', '', '', 1712540022, 1712540022, '6', 1), 
(4, 0, 'Tuyển dụng', '', 'tuyen-dung', '', '', '', 0, 5, 5, 0, 'viewcat_page_new', 0, '', 3, 2, 0, '', '', '', 1712540028, 1712540028, '6', 1), 
(5, 0, 'Kiến thức', '', 'kien-thuc', '', '', '', 0, 4, 4, 0, 'viewcat_page_new', 0, '', 3, 2, 0, '', '', '', 1712540269, 1712540269, '6', 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_tin_tuc_config_post`
--

DROP TABLE IF EXISTS `nv4_vi_tin_tuc_config_post`;
CREATE TABLE `nv4_vi_tin_tuc_config_post` (
  `group_id` smallint(6) NOT NULL,
  `addcontent` tinyint(4) NOT NULL,
  `postcontent` tinyint(4) NOT NULL,
  `editcontent` tinyint(4) NOT NULL,
  `delcontent` tinyint(4) NOT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_tin_tuc_config_post`
--

INSERT INTO `nv4_vi_tin_tuc_config_post` VALUES
(4, 0, 0, 0, 0), 
(7, 0, 0, 0, 0), 
(5, 0, 0, 0, 0), 
(10, 0, 0, 0, 0), 
(11, 0, 0, 0, 0), 
(12, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_tin_tuc_detail`
--

DROP TABLE IF EXISTS `nv4_vi_tin_tuc_detail`;
CREATE TABLE `nv4_vi_tin_tuc_detail` (
  `id` int(10) unsigned NOT NULL,
  `titlesite` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `bodyhtml` longtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `voicedata` text  COLLATE utf8mb4_unicode_ci COMMENT 'Data giọng đọc json',
  `keywords` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourcetext` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `files` text  COLLATE utf8mb4_unicode_ci,
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `layout_func` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `copyright` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_send` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_tin_tuc_detail`
--

INSERT INTO `nv4_vi_tin_tuc_detail` VALUES
(1, '', '', 'Trà, bánh trung thu và mặt trăng sáng đã được kết hợp hài hòa từ thời xa xưa. Đó là điều thơ mộng nhất cho các gia đình ngồi quanh bàn trong sân, ăn bánh trung thu và uống trà trong khi thưởng thức vẻ đẹp của mặt trăng tròn. Trong ấn tượng chung, mặt trăng trong ngày trung thu là thanh lịch, theo nghĩa này, hợp nhất là uống trà.<figure><div class=\"image-center\"><img alt=\"Ý tưởng để kết hợp trà với bánh trung thu của bạn\" src=\"https://htxtravandung.vn/uploads/news/tin_hoat_dong/ket-hop-banh-voi-tra-1.jpg\" title=\"Ý tưởng để kết hợp trà với bánh trung thu của bạn\" width=\"460\" /></div></figure><p>Trong đêm Trung thu, sẽ thật nhàm chán nếu chỉ có bánh trung thu. Hương thơm trà dịu dàng trong ánh trăng thanh lịch thêm nên thơ mộng và thú vị. Có cả lịch sử của Tết Trung thu và lịch sử uống trà. Nhưng không có bất kỳ lý do nào để bánh trung thu được phục vụ với trà; nó chỉ đơn giản là tâm trạng tốt. Bây giờ, bên cạnh tâm trạng tốt, nó cũng là cách chăm sóc cho sức khỏe.</p><p>Bánh trung thu luôn là một sản phẩm truyền thống không thể thiếu cho ngày&nbsp;<a aria-label=\"Trung thu (mở trong tab mới)\" href=\"https://htxtravandung.vn/\" rel=\"noreferrer noopener\" target=\"_blank\">Trung thu</a>&nbsp;từ xưa. Nhưng ngày nay, lượng calo cao, chất béo cao và cholesterol cao trong cuộc sống đã áp đảo. Các chuyên gia dinh dưỡng cho rằng ăn quá nhiều bánh trung thu ngọt sẽ làm tăng gánh nặng cho lá lách và dạ dày. Chức năng giúp tiêu hóa và giảm mỡ nặng là chính xác những gì mọi người hiện nay cần. Do đó, uống trà vào Trung thu vừa thanh lịch vừa tốt cho sức khỏe.</p><p><strong><em>Ý tưởng để kết hợp trà với bánh trung thu của bạn</em></strong></p><p><strong>Bánh trung thu ngọt đậm + trà xanh, trà bạc hà / trà đen</strong><br />Khi ăn bánh trung thu ngọt nặng như bánh táo tàu, bánh trung thu đậu và bánh trung thu hạt sen, cách lý tưởng là kết hợp với trà xanh và trà bạc hà. Trà xanh và trà bạc hà tươi mát sẽ cải thiện quá trình chuyển hóa glucose, để ngăn chặn quá nhiều glucose tồn tại trong cơ thể.</p><p>Trà đen cũng là một lựa chọn tốt, bởi vì nó thường có hương vị êm dịu và ngọt ngào sẽ mang lại hương thơm và sự dịu dàng cho bánh trung thu cũng như giúp cho tiêu hóa.<br /><br /><strong>Bánh trung thu có hàm lượng dầu mỡ + trà Phổ Nhĩ, trà Hoa Cúc</strong><br />Bánh trung thu với các loại hạt / thịt / lòng đỏ nhiều dầu mỡ, vì vậy trà có hương vị nặng thích hợp để làm giảm hương vị dầu mỡ. Trà Pu-erh là một kết hợp tốt vì nó là một trợ giúp tốt cho việc giảm béo, trong khi trà hoa cúc là cách tốt nhất với chức năng làm giảm hiệu ứng nhiệt bên trong.</p><p><strong>Bánh trung thu mặn ngọt + Trà Ô Long</strong><br />Đối với hầu hết các loại bánh trung thu mặn ngọt nhẹ, uống&nbsp;<a aria-label=\"trà Ô Long (mở trong tab mới)\" href=\"https://htxtravandung.vn/\" rel=\"noreferrer noopener\" target=\"_blank\">trà Ô Long</a>&nbsp;là một sự lựa chọn tốt. Bởi trà Ô Long với hương vị dịu dàng hài hòa, còn có thể thúc đẩy bài tiết axit dạ dày và giúp hỗ trợ tiêu hóa, hạn chế hấp thu chất béo. Uống trà Ô Long trong đêm thu là sự lựa chọn tinh tế lại ít gây ảnh hưởng đến giấc ngủ.</p>', '', '', '', '', 2, '', 0, 1, 1, 1), 
(2, '', '', 'Sớm mai lấp ló vài giọt nắng. Giữa khoảng không gian mênh mông, làn sương mỏng manh đang tan đi trong mùi sen thơm nức… 5h sáng, mấy chiếc ghe bắt đầu vào việc. Đôi mắt tinh nhanh của người hái sen tìm kiếm những búp sen “hé miệng sáo” đang lấp ló giấu mình sau những tấm lá. Và rồi chính họ cũng thoắt ẩn thoắt hiện trong đầm sen mênh mông. Chỉ biết là trước khi nắng lên thì ghe đã cập bờ đầy ắp búp sen hồng.<figure><img alt=\"Thưởng thức Trà Sen Sớm để cảm nhận hương vị sớm của Sen\" src=\"https://htxtravandung.vn/uploads/news/tin_hoat_dong/pha-tra-sen-tay-ho-1.jpg\" title=\"Thưởng thức Trà Sen Sớm để cảm nhận hương vị sớm của Sen\" width=\"460\" /></figure><p>Sen hồ Tây xưa nay vẫn nổi tiếng dùng để ướp trà bởi mùi hương quyến rũ của nó. Phải hái nhanh, nhẹ nhàng thì búp sen mới không nhàu nát. Hay là ở chỗ, như một nghệ thuật, họ bẻ đúng đoạn ngó non và để sen rơi tự nhiên nhưng chính xác vào mạn ghe. Chèo ghe cũng phải có kỹ thuật thì mới vượt qua những tầng sen dày đặc, đầy bất trắc. “Có ngày bị ngã thuyền mấy lần, tay chân thì bị gai sen đâm khắp” – chị Hà, người có thâm niên làm nghề hái sen tâm sự.</p><p>Sen ướp trà ngoài chuyện cần được hái lúc sáng sớm thì thời tiết thay đổi cũng làm tăng hay giảm chất lượng sen ướp, mưa quá làm sen nhạt hương, bay hết gạo, gió Tây về thì hoa sen nhỏ, ngọn sen dai ảnh hưởng xấu tới chất lượng. Những lúc như thế, thay vì dùng 1.500 – 2.000 hoa ướp cho 1kg trà, thì phải dùng đến gần 3.000 bông.</p><p>Trà sen ngon phải qua nhiều công đoạn ướp sấy cầu kỳ. Một ấm trà sen có thể uống hàng chục tuần trà. Nước trong rồi, hương sen vẫn còn thơm ngan ngát.&nbsp;</p><p>Không cầu kỳ, trà sen sớm thơm hương tự nhiên của đất trời lại có cách ướp độc đáo. Khi hoàng hôn rải nắng vàng lên mặt hồ, người ta chèo&nbsp;thuyền chọn những bông sen chớm nở, lén bỏ vào một dúm trà nhỏ. Sớm hôm sau khi ánh bình minh chưa chạm tới, người ta lại chèo&nbsp;thuyền hái bông sen vừa ướp về. Ấm trà không chỉ có trà ướp trong sen mà còn có cả tua sen và gương sen. Nhiều bạn trẻ thắc mắc khi mua bông về pha không thơm như ngoài quán, cô chủ quán trà tươi cười giải thích: “Bí mật là ở nước pha trà. Ngày xưa các cụ hứng nước từ lá sen còn đọng sương sớm, nay không được như thế thì mình dùng nước mưa để lưu giữ hương thơm”. Để cảm nhận thêm về vị Hương Sen sớm mời thực khách ghé qua Không gian Trà Vân Dũng thưởng thức ạ.</p>', '', '', '', '', 2, '', 0, 1, 1, 1), 
(3, '', '', '<h2 id=\"phng_php_pha_tr\"><strong>1. 5 yếu tố chính ảnh hưởng đến hương vị trà</strong></h2><p>Để có một ấm trà ngon chuẩn vị, người pha trà cần có đủ chuyên môn và tay nghề cao khi pha. Chuyên môn ở đây được đánh giá bởi 5 yếu tố sau:</p><h3 id=\"ftoc-heading-2\"><strong>Nguồn nước</strong></h3><p>Nguồn nước đóng vai trò quyết định đến 70% hương vị trà. Do đó, để đảm bảo pha trà ngon nhất, bạn nên dùng&nbsp;<strong>nước tinh khiết cao</strong>&nbsp;đun sôi như nước giếng, nước suối… Tuyệt đối không dùng các loại nước bị nhiễm tạp chất, chưa qua xử lý hoặc nhiễm phèn, nhiễm mặn có chứa clo để pha trà.</p><figure aria-describedby=\"caption-attachment-12680\" id=\"attachment_12680\"><a href=\"https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-dung-cach.jpg\"><img alt=\"cách pha trà đúng cách\" data-sizes=\"(max-width: 800px) 100vw, 800px\" data-src=\"https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-dung-cach.jpg\" data-srcset=\"https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-dung-cach.jpg 800w, https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-dung-cach-600x400.jpg 600w, https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-dung-cach-768x512.jpg 768w, https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-dung-cach-510x340.jpg 510w\" decoding=\"async\" height=\"533\" sizes=\"(max-width: 800px) 100vw, 800px\" src=\"https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-dung-cach.jpg\" srcset=\"https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-dung-cach.jpg 800w, https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-dung-cach-600x400.jpg 600w, https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-dung-cach-768x512.jpg 768w, https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-dung-cach-510x340.jpg 510w\" width=\"800\" /></a><figcaption id=\"caption-attachment-12680\">Nước pha trà phải là nước tinh khiết. (Sưu tầm)</figcaption></figure><h3 id=\"ftoc-heading-3\"><strong>Nhiệt độ nước</strong></h3><p>Thông thường, mọi người hay cho rằng nên đun sôi nước ở 100°C để pha trà. Tuy nhiên, mỗi loại trà sẽ thích hợp với một mức nhiệt độ riêng.</p><p>Chẳng hạn với trà đen hoặc trà ô long già nên dùng nước vừa sôi để phá vỡ kết cấu lá trà và phát tán hương vị. Nhưng với những dòng trà có hương tinh tế hơn như trà xanh hoặc trà ô long thường thì chỉ nên pha với nước nóng từ 85-95°C.</p><p>Nếu nước pha trà được đun quá nóng sẽ làm trà bị “cháy”, đắng chát hơn và mất đi những hương vị tinh tế. Còn nước quá nguội sẽ làm hương vị trà bị phai nhạt vì các hợp chất có trong lá trà không hòa tan được hoàn toàn.</p><h3 id=\"ftoc-heading-4\"><strong>Lượng trà</strong></h3><p>Khi pha trà dù quá loãng hay quá đặc đều không ngon. Lượng trà quá nhiều sẽ làm vị trà đậm và đắng nhưng lượng trà quá ít thì hương vị không đậm đà không đủ để thưởng thức. Tốt nhất là bạn nên dùng một lượng trà thích hợp để có được ấm trà ngon, trọn vị hơn.</p><p>Thông thường, ấm trà có thể tích 150ml thì nên dùng lượng trà khoảng 7 – 8g. Tuy nhiên định lượng này sẽ có sự thay đổi tùy vào loại trà. Nếu bạn là người mới bắt đầu tập thưởng trà thì hãy pha cho mình một ấm trà gồm 8g trà và 200ml nước. Sau đó, bạn có thể tăng giảm lượng trà tùy ý sao cho phù hợp nhất với khẩu vị của mình.</p><figure aria-describedby=\"caption-attachment-12683\" id=\"attachment_12683\"><a href=\"https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra.jpg\"><img alt=\"hướng dẫn pha trà\" data-sizes=\"(max-width: 800px) 100vw, 800px\" data-src=\"https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra.jpg\" data-srcset=\"https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra.jpg 800w, https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-600x400.jpg 600w, https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-768x512.jpg 768w, https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-510x340.jpg 510w\" decoding=\"async\" height=\"533\" sizes=\"(max-width: 800px) 100vw, 800px\" src=\"https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra.jpg\" srcset=\"https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra.jpg 800w, https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-600x400.jpg 600w, https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-768x512.jpg 768w, https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-510x340.jpg 510w\" width=\"800\" /></a><figcaption id=\"caption-attachment-12683\">Sử dụng lượng trà vừa đủ tùy theo phân loại trà.</figcaption></figure><h3 id=\"ftoc-heading-5\"><strong>Thời gian hãm</strong></h3><p>Thời gian hãm trà quá dài sẽ làm vị trà đắng chát và có mùi nẫu. Tốt nhất là nên hãm trà trong một khoảng thời gian chính xác mới có thể tạo ra ấm trà ngon.</p><p>Nhiều người thường nghĩ rằng nên “ngâm” trà càng lâu càng tốt nhưng đây là điều sai lầm. Thời gian hãm trà sẽ được tính bằng giây và có sự khác biệt tùy vào mỗi loại trà. Với trà ô long, trà xanh hoặc bạch trà cần được hãm lâu hơn và ngược lại, trà đen và hồng trà sẽ hãm nhanh hơn.</p><h3 id=\"ftoc-heading-6\"><strong>Chọn&nbsp;<a href=\"https://www.tita.art/bo-am-chen/#pha_tra\" rel=\"noopener\" target=\"_blank\">bộ ấm pha trà</a>&nbsp;phù hợp</strong></h3><p>Khi pha các loại trà xanh, trà ô long, bạn có thể dùng ấm sứ, ấm gốm hoặc ấm tử sa chu nê để trà dậy hương hơn. Các loại trà hoa thích hợp pha bằng ấm thủy tinh trong suốt để phô diễn được vẻ đẹp của màu nước và hình dáng những bông hoa bung nở.</p><p>Với người đang làm quen với nghệ thuật pha trà thì nên chọn một chiếc ấm làm bằng sứ có độ kết tinh cao hoặc thủy tinh. Loại ấm này có thể dùng một ấm pha được các loại trà khác nhau mà không sợ bị lẫn mùi như ấm tử sa, dễ sử dụng và bảo quản.</p><figure aria-describedby=\"caption-attachment-12681\" id=\"attachment_12681\"><a href=\"https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-ngon.jpg\"><img alt=\"cách pha trà ngon\" data-sizes=\"(max-width: 800px) 100vw, 800px\" data-src=\"https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-ngon.jpg\" data-srcset=\"https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-ngon.jpg 800w, https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-ngon-600x400.jpg 600w, https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-ngon-768x512.jpg 768w, https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-ngon-510x340.jpg 510w\" decoding=\"async\" height=\"533\" sizes=\"(max-width: 800px) 100vw, 800px\" src=\"https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-ngon.jpg\" srcset=\"https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-ngon.jpg 800w, https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-ngon-600x400.jpg 600w, https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-ngon-768x512.jpg 768w, https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-ngon-510x340.jpg 510w\" width=\"800\" /></a><figcaption id=\"caption-attachment-12681\">Chọn ấm pha trà bằng sứ để có vị ngon hơn.</figcaption></figure><blockquote><p>Ngoài các yếu tố trên thì&nbsp;<strong><a href=\"https://www.tita.art/kien-thuc-tra/cach-bao-quan-tra/#b%E1%BA%A3o_qu%E1%BA%A3n_tr%C3%A0\">cách bảo quản trà</a></strong>&nbsp;cũng ảnh hưởng đến chất lượng trà khi pha.</p></blockquote><h2 id=\"k_thut_pha_tr\"><strong>2. Hướng dẫn pha trà ngon với 7 bước</strong></h2><ul>	<li aria-level=\"1\"><strong>Bước 1: Đun nước</strong></li></ul><p>Đầu tiên, bạn sử dụng nước lọc tinh khiết để đun nước pha trà. Tùy vào loại trà để điều chỉnh nhiệt độ thích hợp nhất, có một số loại cần nhiệt độ nước từ 85-95 độ C, có một số thì cần dùng nước sôi 100 độ C.</p><figure aria-describedby=\"caption-attachment-13341\" id=\"attachment_13341\"><a href=\"https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-ngon-1.jpg\"><img alt=\"hướng dẫn cách pha trà ngon\" data-sizes=\"(max-width: 800px) 100vw, 800px\" data-src=\"https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-ngon-1.jpg\" data-srcset=\"https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-ngon-1.jpg 800w, https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-ngon-1-600x400.jpg 600w, https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-ngon-1-768x512.jpg 768w, https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-ngon-1-510x340.jpg 510w\" decoding=\"async\" height=\"533\" sizes=\"(max-width: 800px) 100vw, 800px\" src=\"https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-ngon-1.jpg\" srcset=\"https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-ngon-1.jpg 800w, https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-ngon-1-600x400.jpg 600w, https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-ngon-1-768x512.jpg 768w, https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-ngon-1-510x340.jpg 510w\" width=\"800\" /></a><figcaption id=\"caption-attachment-13341\">Đun nước pha trà đến nhiệt độ thích hợp.</figcaption></figure><ul>	<li aria-level=\"1\"><strong>Bước 2: Làm nóng ấm chén</strong></li></ul><p>Khi nước đã sôi, bạn rót nước vào ấm trà và đậy nắp lại để tăng nhiệt độ ấm. Nếu thấy ấm nóng đều thì rót hết nước ra chuyên trà và các ly sau đó đó đổ nước này đi.</p><ul>	<li aria-level=\"1\"><strong>Bước 3: Đong trà</strong></li></ul><p>Trong&nbsp;<strong>cách pha trà</strong>&nbsp;ngon thì đây là một bước khá quan trọng. Tùy vào loại trà sử dụng mà bạn đong một lượng trà phù hợp, thường là ⅕ đến ½ ấm.</p><figure aria-describedby=\"caption-attachment-13342\" id=\"attachment_13342\"><a href=\"https://www.tita.art/wp-content/uploads/2023/06/pha-tra-1.jpg\"><img alt=\"pha trà ngon\" data-sizes=\"(max-width: 800px) 100vw, 800px\" data-src=\"https://www.tita.art/wp-content/uploads/2023/06/pha-tra-1.jpg\" data-srcset=\"https://www.tita.art/wp-content/uploads/2023/06/pha-tra-1.jpg 800w, https://www.tita.art/wp-content/uploads/2023/06/pha-tra-1-435x400.jpg 435w, https://www.tita.art/wp-content/uploads/2023/06/pha-tra-1-768x707.jpg 768w, https://www.tita.art/wp-content/uploads/2023/06/pha-tra-1-510x469.jpg 510w\" decoding=\"async\" height=\"736\" sizes=\"(max-width: 800px) 100vw, 800px\" src=\"https://www.tita.art/wp-content/uploads/2023/06/pha-tra-1.jpg\" srcset=\"https://www.tita.art/wp-content/uploads/2023/06/pha-tra-1.jpg 800w, https://www.tita.art/wp-content/uploads/2023/06/pha-tra-1-435x400.jpg 435w, https://www.tita.art/wp-content/uploads/2023/06/pha-tra-1-768x707.jpg 768w, https://www.tita.art/wp-content/uploads/2023/06/pha-tra-1-510x469.jpg 510w\" width=\"800\" /></a><figcaption id=\"caption-attachment-13342\">Đong lượng trà phù hợp.</figcaption></figure><ul>	<li aria-level=\"1\"><strong>Bước 4: Đánh thức trà</strong></li></ul><p>Tiếp theo bạn đổ nước nóng vào ngập trà, rồi nhanh chóng đổ đi. Bước này có tác dụng đánh thức trà, làm các lá trà ngấm nước nở ra và bật hương vị đặc trưng.</p><figure aria-describedby=\"caption-attachment-12682\" id=\"attachment_12682\"><a href=\"https://www.tita.art/wp-content/uploads/2023/06/huong-dan-cach-pha-tra.jpg\"><img alt=\"hướng dẫn cách pha trà\" data-sizes=\"(max-width: 800px) 100vw, 800px\" data-src=\"https://www.tita.art/wp-content/uploads/2023/06/huong-dan-cach-pha-tra.jpg\" data-srcset=\"https://www.tita.art/wp-content/uploads/2023/06/huong-dan-cach-pha-tra.jpg 800w, https://www.tita.art/wp-content/uploads/2023/06/huong-dan-cach-pha-tra-600x400.jpg 600w, https://www.tita.art/wp-content/uploads/2023/06/huong-dan-cach-pha-tra-768x512.jpg 768w, https://www.tita.art/wp-content/uploads/2023/06/huong-dan-cach-pha-tra-510x340.jpg 510w\" decoding=\"async\" height=\"533\" sizes=\"(max-width: 800px) 100vw, 800px\" src=\"https://www.tita.art/wp-content/uploads/2023/06/huong-dan-cach-pha-tra.jpg\" srcset=\"https://www.tita.art/wp-content/uploads/2023/06/huong-dan-cach-pha-tra.jpg 800w, https://www.tita.art/wp-content/uploads/2023/06/huong-dan-cach-pha-tra-600x400.jpg 600w, https://www.tita.art/wp-content/uploads/2023/06/huong-dan-cach-pha-tra-768x512.jpg 768w, https://www.tita.art/wp-content/uploads/2023/06/huong-dan-cach-pha-tra-510x340.jpg 510w\" width=\"800\" /></a><figcaption id=\"caption-attachment-12682\">Rót nước nóng vào ấm để đánh thức trà.</figcaption></figure><ul>	<li aria-level=\"1\"><strong>Bước 5: Hãm trà</strong></li></ul><p>Tiếp tục đổ đầy nước nóng vào ấm, đậy nắp lại để hãm trà trong khoảng 10 – 40 giây tùy theo từng loại trà. Đây là bước quan trọng nhất để có được một ấm trà ngon nên bạn cần phải đảm bảo nhiệt độ nước và thời gian hãm phù hợp với loại trà được sử dụng.</p><figure aria-describedby=\"caption-attachment-13339\" id=\"attachment_13339\"><a href=\"https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-co-ban.jpg\"><img alt=\"cách pha trà cơ bản\" data-sizes=\"(max-width: 800px) 100vw, 800px\" data-src=\"https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-co-ban.jpg\" data-srcset=\"https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-co-ban.jpg 800w, https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-co-ban-364x400.jpg 364w, https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-co-ban-729x800.jpg 729w, https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-co-ban-768x843.jpg 768w, https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-co-ban-510x560.jpg 510w\" decoding=\"async\" height=\"878\" sizes=\"(max-width: 800px) 100vw, 800px\" src=\"https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-co-ban.jpg\" srcset=\"https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-co-ban.jpg 800w, https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-co-ban-364x400.jpg 364w, https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-co-ban-729x800.jpg 729w, https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-co-ban-768x843.jpg 768w, https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-co-ban-510x560.jpg 510w\" width=\"800\" /></a><figcaption id=\"caption-attachment-13339\">Đổ một lượng nước vừa đủ để hãm trà.</figcaption></figure><ul>	<li aria-level=\"1\"><strong>Bước 6: Rót trà</strong></li></ul><p>Sau thời gian hãm trà, bạn rót hết nước trong ấm vào chuyên trà. Sau đó mới tiếp tục rót nước trà từ chuyên sang các chén. Tác dụng của chuyên trà giúp người uống có thể thẩm được hương vị đều nhau sau mỗi tuần trà. Từ đó đảm bảo được hương vị thơm ngon của nước trà qua từng tuần trà.</p><figure aria-describedby=\"caption-attachment-12685\" id=\"attachment_12685\"><a href=\"https://www.tita.art/wp-content/uploads/2023/06/ky-thuat-pha-tra.jpg\"><img alt=\"kỹ thuật pha trà\" data-sizes=\"(max-width: 800px) 100vw, 800px\" data-src=\"https://www.tita.art/wp-content/uploads/2023/06/ky-thuat-pha-tra.jpg\" data-srcset=\"https://www.tita.art/wp-content/uploads/2023/06/ky-thuat-pha-tra.jpg 800w, https://www.tita.art/wp-content/uploads/2023/06/ky-thuat-pha-tra-600x400.jpg 600w, https://www.tita.art/wp-content/uploads/2023/06/ky-thuat-pha-tra-768x512.jpg 768w, https://www.tita.art/wp-content/uploads/2023/06/ky-thuat-pha-tra-510x340.jpg 510w\" decoding=\"async\" height=\"533\" sizes=\"(max-width: 800px) 100vw, 800px\" src=\"https://www.tita.art/wp-content/uploads/2023/06/ky-thuat-pha-tra.jpg\" srcset=\"https://www.tita.art/wp-content/uploads/2023/06/ky-thuat-pha-tra.jpg 800w, https://www.tita.art/wp-content/uploads/2023/06/ky-thuat-pha-tra-600x400.jpg 600w, https://www.tita.art/wp-content/uploads/2023/06/ky-thuat-pha-tra-768x512.jpg 768w, https://www.tita.art/wp-content/uploads/2023/06/ky-thuat-pha-tra-510x340.jpg 510w\" width=\"800\" /></a><figcaption id=\"caption-attachment-12685\">Rót trà từ chuyên trà sang chén trà để thưởng thức.</figcaption></figure><figure aria-describedby=\"caption-attachment-13340\" id=\"attachment_13340\"><a href=\"https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-dung-cach.jpg\"><img alt=\"hướng dẫn pha trà đúng cách\" data-sizes=\"(max-width: 800px) 100vw, 800px\" data-src=\"https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-dung-cach.jpg\" data-srcset=\"https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-dung-cach.jpg 800w, https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-dung-cach-600x400.jpg 600w, https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-dung-cach-768x512.jpg 768w, https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-dung-cach-510x340.jpg 510w\" decoding=\"async\" height=\"533\" sizes=\"(max-width: 800px) 100vw, 800px\" src=\"https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-dung-cach.jpg\" srcset=\"https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-dung-cach.jpg 800w, https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-dung-cach-600x400.jpg 600w, https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-dung-cach-768x512.jpg 768w, https://www.tita.art/wp-content/uploads/2023/06/huong-dan-pha-tra-dung-cach-510x340.jpg 510w\" width=\"800\" /></a><figcaption id=\"caption-attachment-13340\">Thành phẩm nước trà màu đẹp, đúng vị.</figcaption></figure><ul>	<li aria-level=\"1\"><strong>Bước 7: Hãm trà lần tiếp theo</strong></li></ul><p>Với những lần hãm trà tiếp theo, bạn thực hiện lặp lại các bước 5 và 6 nêu trên. Một lưu ý là lần hãm sau sẽ có thời gian lâu hơn so với lần hãm trước. Hoặc nếu nước trà đầu bạn pha quá nhạt hoặc quá đậm thì hãy điều chỉnh thời gian phù hợp ở lần hãm tiếp theo. Nếu dùng trà ngon và&nbsp;<strong>cách pha trà</strong>&nbsp;đúng thì bạn có thể lặp lại 5 – 8 lần hãm trà mà vẫn thưởng thức được chén trà giữ được hương vị.</p><p>Bạn có thể tham khảo&nbsp;<strong>cách pha Trà phổ nhĩ</strong>&nbsp;sau:</p><p><iframe allowfullscreen=\"allowfullscreen\" data-src=\"https://www.youtube.com/embed/eDgIcLbP3lw\" frameborder=\"0\" height=\"490\" sandbox=\"\" src=\"data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==\" title=\"Hướng dẫn pha trà Phổ Nhĩ cơ bản\" width=\"800\"></iframe></p><h2 id=\"cch_pha_tr_ngon\"><strong>3. Mẹo pha trà ngon đúng chuẩn</strong></h2><p>Để có một ấm trà thơm ngon cùng các bạn hữu uống trà, người pha trà cần chú ý đến các bước trong quy trình pha trà. Ngoài những bước cơ bản thì còn có một số mẹo được TITA Art đúc kết như sau.</p><ul>	<li aria-level=\"1\">Nếu trà có dạng sợi mỏng xốp thì bạn nên dùng nước pha trà có nhiệt độ thấp và dùng nước nóng ở nhiệt độ cao hơn với các loại trà có sợi lớn hơn.</li>	<li aria-level=\"1\">Nếu bạn thích dùng trà có hương vị đậm thì hãy tăng lượng trà thay vì dùng nước nóng hơn hoặc kéo dài thời gian hãm trà lâu hơn.</li>	<li aria-level=\"1\">Bạn nên sử dụng cảm nhận cá nhân để gia giảm lượng trà, nhiệt độ nước hay thời gian hãm phù hợp. Tuy nhiên, dù là cảm nhận cá nhân nhưng vẫn dựa trên công thức pha thì mới có được vị trà chuẩn nhất.</li></ul><p>Trên đây là một số chia sẻ của TITA Art về&nbsp;<strong>cách pha trà</strong>&nbsp;ngon, đậm hương, trọn vị. Mong rằng sau bài viết này, bạn sẽ có thêm nhiều kiến thức thú vị để pha được ấm trà thơm ngon cho mình.</p>', '', '', '', '', 2, '', 0, 1, 1, 1), 
(4, '', '', '<h3 id=\"hmenuid1\">Nước pha trà</h3><p>Để pha trà ngon tốt nhất bạn nên sử dụng<strong>&nbsp;nước mưa</strong>, tuy nhiên nước mưa hiện nay không còn được sạch trong thời đại công nghiệp, do đó bạn có thể sử dụng&nbsp;<strong>nước giếng đào&nbsp;</strong>thay thế. Ở các thành phố, không có nước giếng nên sử dụng nước tinh khiết đóng chai.</p><p>Nếu cẩn trọng hơn bạn có thể lọc nước qua trước khi đun nóng.</p><div class=\"image-center\"><img alt=\"Tuyệt chiêu pha trà ngon cực kỳ đơn giản\" data-original=\"https://cdn.tgdd.vn/Files/2018/01/16/1059355/tuyet-chieu-pha-tra-ngon-cuc-ky-don-gian2_800x400.jpg\" height=\"140\" src=\"https://cdn.tgdd.vn/Files/2018/01/16/1059355/tuyet-chieu-pha-tra-ngon-cuc-ky-don-gian2_800x400.jpg\" title=\"Tuyệt chiêu pha trà ngon cực kỳ đơn giản\" width=\"360\" /></div><h3 id=\"hmenuid2\">Chọn mua trà - ấm pha trà</h3><p>Trà: Trà ngon nhất thường được các cụ hay gọi là trà một tôm – tức là<strong>&nbsp;trà được chế biến từ phần nõn non nhất của cây trà</strong>. Nõn trà&nbsp;<strong>được hái và chế biến vào mùa đông</strong>&nbsp;sẽ cho chất lượng tốt nhất.</p><p>Ấm pha trà: Với ấm pha trà bạn nên sử dụng loạ<strong>i ấm đất, không chì, ấm bát tràng</strong>, loại ấm này sẽ giúp giữ nhiệt tốt nhất giúp trà khi pha đậm vị hơn.</p><div class=\"image-center\"><img alt=\"Tuyệt chiêu pha trà ngon cực kỳ đơn giản\" data-original=\"https://cdn.tgdd.vn/Files/2018/01/16/1059355/tuyet-chieu-pha-tra-ngon-cuc-ky-don-gian3_800x400.jpg\" data-src=\"https://cdn.tgdd.vn/Files/2018/01/16/1059355/tuyet-chieu-pha-tra-ngon-cuc-ky-don-gian3_800x400.jpg\" data-was-processed=\"true\" height=\"140\" src=\"https://cdn.tgdd.vn/Files/2018/01/16/1059355/tuyet-chieu-pha-tra-ngon-cuc-ky-don-gian3_800x400.jpg\" title=\"Tuyệt chiêu pha trà ngon cực kỳ đơn giản\" width=\"360\" /></div><h3 id=\"hmenuid3\">Cách pha trà</h3><p>Thông thường nhiều bạn chỉ trực tiếp đổ nước vào trà, mà không ủ trà. Như vậy lớp bụi còn sót lại trên trà khô sẽ làm hương vị nước trà giảm đi rất nhiều.</p><p>Do đó tốt nhất bạn nên cho một chút&nbsp;<strong>nước sôi tráng ấm</strong>, sau đó cho trà vào ấm, tiếp tục&nbsp;<strong>cho chút nước sôi vào trà 30 giây để ủ trà</strong>, sau khi bỏ lớp nước này, bạn pha trà như thông thường.</p><p>Nếu không có nước sôi để pha trà, mà&nbsp;<strong>dùng nước ấm, bạn nên thêm vào nước chút&nbsp;<a href=\"https://www.bachhoaxanh.com/duong\" rel=\"nofollow\" title=\"đường\">đường</a></strong>, khuấy tan và cho nước vào trà. Như vậy sau 3 phút bạn sẽ có ấm trà ngon.</p><div class=\"image-center\"><img alt=\"Tuyệt chiêu pha trà ngon cực kỳ đơn giản\" data-original=\"https://cdn.tgdd.vn/Files/2018/01/16/1059355/tuyet-chieu-pha-tra-ngon-cuc-ky-don-gian4_800x400.jpg\" data-src=\"https://cdn.tgdd.vn/Files/2018/01/16/1059355/tuyet-chieu-pha-tra-ngon-cuc-ky-don-gian4_800x400.jpg\" data-was-processed=\"true\" height=\"140\" src=\"https://cdn.tgdd.vn/Files/2018/01/16/1059355/tuyet-chieu-pha-tra-ngon-cuc-ky-don-gian4_800x400.jpg\" title=\"Tuyệt chiêu pha trà ngon cực kỳ đơn giản\" width=\"360\" /></div><h3 id=\"hmenuid4\">Bảo quản và xử lý khi trà bị mốc</h3><p>Bảo quản trà: Khi bảo quản, để tránh tình trạng trà bị ẩm mốc, bạn nên&nbsp;<strong>lấy một cục vôi sống dùng vải bọc lại sau đó dùng giấy gói</strong>,<strong>&nbsp;đặt vào dưới đáy hũ&nbsp;</strong>đựng trà, tiếp tục<strong>&nbsp;đặt một lớp giấy lên trên vôi</strong>&nbsp;trước khi cho trà vào hũ.</p><p>Trà mốc: Nếu trà của bạn bị ẩm có dấu hiệu mốc, bạn loại bỏ phần mốc của trà, sau đó&nbsp;<strong>đem hấp cách thủy 3 phút, cuối cùng đặt trà lên chảo sấy khô với lửa nhỏ</strong>. Như vậy bạn có thể tiếp tục bảo quản trà. Nếu muốn lưu giữ lâu ngày bạn nên đặt gói trà vào tủ lạnh để đảm bảo hương vị.</p><div class=\"image-center\"><img alt=\"Tuyệt chiêu pha trà ngon cực kỳ đơn giản\" data-original=\"https://cdn.tgdd.vn/Files/2018/01/16/1059355/tuyet-chieu-pha-tra-ngon-cuc-ky-don-gian1_800x400.jpg\" data-src=\"https://cdn.tgdd.vn/Files/2018/01/16/1059355/tuyet-chieu-pha-tra-ngon-cuc-ky-don-gian1_800x400.jpg\" data-was-processed=\"true\" height=\"140\" src=\"https://cdn.tgdd.vn/Files/2018/01/16/1059355/tuyet-chieu-pha-tra-ngon-cuc-ky-don-gian1_800x400.jpg\" title=\"Tuyệt chiêu pha trà ngon cực kỳ đơn giản\" width=\"360\" /></div>&nbsp;', '', '', '', '', 2, '', 0, 1, 1, 1), 
(5, '', '', '<p>Trà sen muốn có hương vị tốt nhất thì việc đầu tiên cần quan tâm là chọn trà và chọn hoa sen.&nbsp;</p><p>Theo kinh nghiệm của các nghệ nhân ướp trà Hồ Tây, loại sen Hồ Tây (còn gọi là sen trăm cánh) là lựa chọn thích hợp nhất để ướp trà. Tuy nhiên, nếu như bạn ở nơi khác thì có thể sử dụng các loại sen phổ biến gần nhà.</p><p>Sen dùng ướp trà phải là những bông sen được cắt vào sáng sớm tinh mơ khi mà búp hoa vừa chớm nở. Lúc này, gạo sen sẽ giữ được trọn vẹn mùi hương cũng như là những tinh túy trong hoa sen.</p><p>Loại trà xanh thường được dùng để ướp sen là trà móc câu hoặc trà cổ thụ. Vì những loại trà này thường có cánh lá rộng giúp cho trà thấm hương sen tốt hơn.</p><p>Trà sen ướp xổi</p><p>Cách ướp trà sen này tương đối đơn giản. Bạn thực hiện ướp trà vào bông sen ngay sau khi mua hoa về để đảm bản hương hoa còn đượm nhất.</p><p>Bạn nhẹ nhàng vén các cánh hoa, để lộ ngụy, sau đó cho trà vào (khoảng từ 15-20 gram mỗi bông), sau đó xếp lại cánh hoa, dùng lá gói trọn bông hoa cho kín, chú ý không gói chặt tay quá.</p><p>Sau đó, bạn cắm hoa vào bình hoặc chậu để qua 1 đêm và lấy ra dùng.</p><table>	<tbody>		<tr>			<td>			<img alt=\"Hai cách ướp trà sen thông dụng nhất\" data-lg-id=\"cba3f55d-8bb3-4d54-b993-08843b74a952\" data-thumb-src=\"https://vnn-imgs-a1.vgcloud.vn/info-imgs.vgcloud.vn/2020/06/26/14/hai-cach-uop-tra-sen-thong-dung-nhat.jpg\" src=\"https://vnn-imgs-a1.vgcloud.vn/info-imgs.vgcloud.vn/2020/06/26/14/hai-cach-uop-tra-sen-thong-dung-nhat.jpg\" />			</td>		</tr>		<tr>			<td>&nbsp;</td>		</tr>	</tbody></table><p>Để bảo quản trà sen này, bạn có thể đưa&nbsp;các bông trà sen vào ngăn đá tủ lạnh (tránh để gần các loại thực phẩm khác) rồi dùng trong cả tháng.&nbsp;&nbsp;</p><p>Trà sen ướp kỹ sao khô</p><p>Đây là cách ướp trà sen cầu kỳ hơn, nhưng thành quả thu lại là những chén trà sen thoảng hương thanh tao và có thể sử dụng cả năm.</p><p>Cách ướp trà sen này sử dụng gạo của hoa sen để ướp trà vì gạo sen là phần lưu hương thơm đượm nhất.</p><p>Các bạn cần tỉ mẩn tách gạo ra khỏi từng bông sen. Sau khi tách xong, bạn sàng lọc để loại bỏ những phần lẫn tạp vào gạo sen.</p><table>	<tbody>		<tr>			<td>			<img alt=\"Hai cách ướp trà sen thông dụng nhất\" data-adbro-processed=\"true\" data-lg-id=\"b861cbfe-bb76-4c7d-892a-921b2e29d5b9\" data-thumb-src=\"https://vnn-imgs-a1.vgcloud.vn/info-imgs.vgcloud.vn/2020/06/26/14/hai-cach-uop-tra-sen-thong-dung-nhat-1.jpg\" src=\"https://vnn-imgs-a1.vgcloud.vn/info-imgs.vgcloud.vn/2020/06/26/14/hai-cach-uop-tra-sen-thong-dung-nhat-1.jpg\" /><br />			<a data-track=\"true\" href=\"https://www.fristi.vn/trangchu?utm_source=SponsoredMom&amp;utm_medium=Mom-Adbro&amp;utm_campaign=FristiPromotion2024\" target=\"_blank\">			<video autoplay=\"\" id=\"adbro-video\" muted=\"\" playsinline=\"\" poster=\"https://cdn.adbro.me/inimage/fristi/2403/1/images/fristi-poster.jpg?v=2\" width=\"100%\">&nbsp;</video>			</a><a data-track=\"true\" href=\"https://www.fristi.vn/trangchu?utm_source=SponsoredMom&amp;utm_medium=Mom-Adbro&amp;utm_campaign=FristiPromotion2024\" target=\"_blank\">Ads (0:00)</a>			<ul>				<li data-block-reason=\"4\" data-trans-vn=\"Che nội dung\">&nbsp;</li>				<li data-block-reason=\"2\" data-trans-vn=\"Không quan tâm\">&nbsp;</li>				<li data-block-reason=\"3\" data-trans-vn=\"Không phù hợp\">&nbsp;</li>				<li data-block-reason=\"1\" data-trans-vn=\"Thấy quá nhiều\">&nbsp;</li>			</ul>						</td>		</tr>		<tr>			<td>&nbsp;</td>		</tr>	</tbody></table><p>Dùng một cái thúng phẳng đáy, lót lá sen vào, rãi đều xen kẽ một lớp trà đến một lớp gạo sen,&nbsp;phủ lớp lá sen lên trên rồi đem đi ủ qua đêm.&nbsp;</p><p>Hôm sau bạn&nbsp;đem sao chỗ trà sen vừa ướp. Sau đó sàng bỏ gạo sen cũ, lấy trà đi ướp với gạo sen mới. Cứ như vậy, ướp rồi sao, rồi ướp mới&nbsp;&nbsp;5 - 7 lần để trà thấm hương sen.</p>', '', '', '', '', 2, '', 0, 1, 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_tin_tuc_logs`
--

DROP TABLE IF EXISTS `nv4_vi_tin_tuc_logs`;
CREATE TABLE `nv4_vi_tin_tuc_logs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `sid` mediumint(9) NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `log_key` varchar(60)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Khóa loại log, tùy vào lập trình',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `note` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `set_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`),
  KEY `log_key` (`log_key`),
  KEY `status` (`status`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_tin_tuc_logs`
--

INSERT INTO `nv4_vi_tin_tuc_logs` VALUES
(1, 1, 1, 'change_status', 1, '', 1712669713), 
(2, 2, 1, 'change_status', 1, '', 1712669747), 
(3, 3, 1, 'change_status', 1, '', 1712669970), 
(4, 4, 1, 'change_status', 1, '', 1712670024), 
(5, 5, 1, 'change_status', 1, '', 1712670077), 
(6, 2, 1, 'change_status', 1, '', 1712717793), 
(7, 1, 1, 'change_status', 1, '', 1712717807);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_tin_tuc_row_histories`
--

DROP TABLE IF EXISTS `nv4_vi_tin_tuc_row_histories`;
CREATE TABLE `nv4_vi_tin_tuc_row_histories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `new_id` int(10) unsigned NOT NULL DEFAULT '0',
  `historytime` int(10) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT 'ID người đăng',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sourceid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `publtime` int(10) unsigned NOT NULL DEFAULT '0',
  `exptime` int(10) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `inhome` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `external_link` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `instant_active` tinyint(1) NOT NULL DEFAULT '0',
  `instant_template` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `instant_creatauto` tinyint(1) NOT NULL DEFAULT '0',
  `titlesite` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `bodyhtml` longtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `voicedata` text  COLLATE utf8mb4_unicode_ci COMMENT 'Data giọng đọc json',
  `keywords` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourcetext` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `files` text  COLLATE utf8mb4_unicode_ci,
  `tags` text  COLLATE utf8mb4_unicode_ci,
  `internal_authors` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `layout_func` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `copyright` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_send` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) NOT NULL DEFAULT '0',
  `changed_fields` text  COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Các field thay đổi',
  PRIMARY KEY (`id`),
  KEY `new_id` (`new_id`),
  KEY `historytime` (`historytime`),
  KEY `admin_id` (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci COMMENT='Lịch sử bài viết';


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_tin_tuc_rows`
--

DROP TABLE IF EXISTS `nv4_vi_tin_tuc_rows`;
CREATE TABLE `nv4_vi_tin_tuc_rows` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(9) NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `weight` int(10) unsigned NOT NULL DEFAULT '0',
  `publtime` int(10) unsigned NOT NULL DEFAULT '0',
  `exptime` int(10) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `external_link` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `instant_active` tinyint(1) NOT NULL DEFAULT '0',
  `instant_template` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `instant_creatauto` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `edittime` (`edittime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`),
  KEY `instant_active` (`instant_active`),
  KEY `instant_creatauto` (`instant_creatauto`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_tin_tuc_rows`
--

INSERT INTO `nv4_vi_tin_tuc_rows` VALUES
(1, 1, '1,2,3,5,4', 0, 1, '', 0, 1712669713, 1712717807, 1, 1, 1712669640, 0, 2, 'Ý tưởng để kết hợp trà với bánh trung thu của bạn', 'y-tuong-de-ket-hop-tra-voi-banh-trung-thu-cua-ban', 'Trà, bánh trung thu và mặt trăng sáng đã được kết hợp hài hòa từ thời xa xưa. Đó là điều thơ mộng nhất cho các gia đình ngồi quanh bàn trong sân, ăn bánh trung thu và uống trà trong khi thưởng thức vẻ đẹp của mặt trăng tròn. Trong ấn tượng chung, mặt trăng trong ngày trung thu là thanh lịch, theo nghĩa này, hợp nhất là uống trà.', 'https://htxtravandung.vn/uploads/news/tin_hoat_dong/ket-hop-banh-voi-tra-1.jpg', '', 3, 1, '4', 1, 0, 1, 0, 0, 0, 0, '', 0), 
(2, 1, '1,2,3,5,4', 0, 1, '', 0, 1712669747, 1712717793, 1, 2, 1712669700, 0, 2, 'Thưởng thức Trà Sen Sớm để cảm nhận hương vị sớm của Sen', 'thuong-thuc-tra-sen-som-de-cam-nhan-huong-vi-som-cua-sen', 'Sớm mai lấp ló vài giọt nắng. Giữa khoảng không gian mênh mông, làn sương mỏng manh đang tan đi trong mùi sen thơm nức… 5h sáng, mấy chiếc ghe bắt đầu vào việc. Đôi mắt tinh nhanh của người hái sen tìm kiếm những búp sen “hé miệng sáo” đang lấp ló giấu mình sau những tấm lá. Và rồi chính họ cũng thoắt ẩn thoắt hiện trong đầm sen mênh mông. Chỉ biết là trước khi nắng lên thì ghe đã cập', 'https://htxtravandung.vn/uploads/news/tin_hoat_dong/pha-tra-sen-tay-ho-1.jpg', '', 3, 1, '4', 1, 0, 1, 0, 0, 0, 0, '', 0), 
(3, 3, '3,5', 0, 1, '', 0, 1712669970, 1712669970, 1, 3, 1712669880, 0, 2, 'Hướng dẫn cách pha trà thơm – ngon – giữ nguyên vị trà', 'huong-dan-cach-pha-tra-thom-ngon-giu-nguyen-vi-tra', 'Hầu như ai cũng biết đến cách pha trà cơ bản là hãm lá trà khô trong ấm với nước sôi rồi rót ra chén để thưởng thức. Tuy nhiên để có được một chén trà thơm, ngon, giữ trọn hương vị tự nhiên nhất thì bạn cần phải chú ý đến một số yếu tố ảnh hưởng khác. Vậy làm thế nào để pha trà đúng cách, mời bạn cùng TITA Art tìm hiểu trong bài viết sau đây nhé.', 'https://www.tita.art/wp-content/uploads/2023/06/cach-pha-tra-dung-cach.jpg', '', 3, 1, '4', 1, 0, 2, 0, 0, 0, 0, '', 0), 
(4, 1, '1,3,5', 0, 1, '', 0, 1712670024, 1712670024, 1, 4, 1712669940, 0, 2, 'Tuyệt chiêu pha trà ngon cực kỳ đơn giản', 'tuyet-chieu-pha-tra-ngon-cuc-ky-don-gian', 'Trà vẫn là thức uống yêu thích của nhiều người nhất là đối với các cụ lớn tuổi. Để có được ly trà ngon, đậm vị còn tùy thuộc và 4 yếu tố: loại trà, ấm pha, nguồn nước và cách pha trà. Vậy phải như thế nào mới có một ấm trà ngon?', 'https://cdn.tgdd.vn/Files/2018/01/16/1059355/tuyet-chieu-pha-tra-ngon-cuc-ky-don-gian2_800x400.jpg', '', 3, 1, '4', 1, 0, 6, 0, 0, 0, 0, '', 0), 
(5, 5, '3,5', 0, 1, '', 0, 1712670077, 1712670077, 1, 5, 1712670000, 0, 2, 'Hai cách ướp trà sen thông dụng nhất', 'hai-cach-uop-tra-sen-thong-dung-nhat', 'Nếu như bạn chưa có điều kiện thưởng thức chén trà sen Hồ Tây nổi tiếng thì có thể tự mình học cách ướp trà sen tại nhà nhé.', 'https://vnn-imgs-a1.vgcloud.vn/info-imgs.vgcloud.vn/2020/06/26/14/hai-cach-uop-tra-sen-thong-dung-nhat.jpg', '', 3, 1, '4', 1, 0, 1, 0, 0, 0, 0, '', 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_tin_tuc_sources`
--

DROP TABLE IF EXISTS `nv4_vi_tin_tuc_sources`;
CREATE TABLE `nv4_vi_tin_tuc_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `logo` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(10) unsigned NOT NULL,
  `edit_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`sourceid`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_tin_tuc_tags`
--

DROP TABLE IF EXISTS `nv4_vi_tin_tuc_tags`;
CREATE TABLE `nv4_vi_tin_tuc_tags` (
  `tid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `numnews` mediumint(9) NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `keywords` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`tid`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_tin_tuc_tags_id`
--

DROP TABLE IF EXISTS `nv4_vi_tin_tuc_tags_id`;
CREATE TABLE `nv4_vi_tin_tuc_tags_id` (
  `id` int(11) NOT NULL,
  `tid` mediumint(9) NOT NULL,
  `keyword` varchar(65)  COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `id_tid` (`id`,`tid`),
  KEY `tid` (`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_tin_tuc_tmp`
--

DROP TABLE IF EXISTS `nv4_vi_tin_tuc_tmp`;
CREATE TABLE `nv4_vi_tin_tuc_tmp` (
  `id` mediumint(8) unsigned NOT NULL,
  `admin_id` int(11) NOT NULL DEFAULT '0',
  `time_edit` int(11) NOT NULL,
  `time_late` int(11) NOT NULL,
  `ip` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_tin_tuc_topics`
--

DROP TABLE IF EXISTS `nv4_vi_tin_tuc_topics`;
CREATE TABLE `nv4_vi_tin_tuc_topics` (
  `topicid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` smallint(6) NOT NULL DEFAULT '0',
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topicid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_tin_tuc_voices`
--

DROP TABLE IF EXISTS `nv4_vi_tin_tuc_voices`;
CREATE TABLE `nv4_vi_tin_tuc_voices` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `voice_key` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Khóa dùng trong Api sau này',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(10) unsigned NOT NULL DEFAULT '0',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0: Dừng, 1: Hoạt động',
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`),
  KEY `weight` (`weight`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_voting`
--

DROP TABLE IF EXISTS `nv4_vi_voting`;
CREATE TABLE `nv4_vi_voting` (
  `vid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `acceptcm` int(11) NOT NULL DEFAULT '1',
  `active_captcha` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `publ_time` int(10) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(10) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `vote_one` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0 cho phép vote nhiều lần 1 cho phép vote 1 lần',
  PRIMARY KEY (`vid`),
  UNIQUE KEY `question` (`question`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_voting`
--

INSERT INTO `nv4_vi_voting` VALUES
(2, 'Bạn biết gì về NukeViet 4?', '', 1, 0, 1, '6', 1712405092, 0, 1, 0), 
(3, 'Lợi ích của phần mềm nguồn mở là gì?', '', 1, 0, 1, '6', 1712405092, 0, 1, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_voting_rows`
--

DROP TABLE IF EXISTS `nv4_vi_voting_rows`;
CREATE TABLE `nv4_vi_voting_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `vid` smallint(5) unsigned NOT NULL,
  `title` varchar(245)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `url` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `hitstotal` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vid` (`vid`,`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=14  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nv4_vi_voting_rows`
--

INSERT INTO `nv4_vi_voting_rows` VALUES
(5, 2, 'Một bộ sourcecode cho web hoàn toàn mới.', '', 0), 
(6, 2, 'Mã nguồn mở, sử dụng miễn phí.', '', 0), 
(7, 2, 'Sử dụng HTML5, CSS3 và hỗ trợ Ajax', '', 0), 
(8, 2, 'Tất cả các ý kiến trên', '', 0), 
(9, 3, 'Liên tục được cải tiến, sửa đổi bởi cả thế giới.', '', 0), 
(10, 3, 'Được sử dụng miễn phí không mất tiền.', '', 0), 
(11, 3, 'Được tự do khám phá, sửa đổi theo ý thích.', '', 0), 
(12, 3, 'Phù hợp để học tập, nghiên cứu vì được tự do sửa đổi theo ý thích.', '', 0), 
(13, 3, 'Tất cả các ý kiến trên', '', 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_voting_voted`
--

DROP TABLE IF EXISTS `nv4_vi_voting_voted`;
CREATE TABLE `nv4_vi_voting_voted` (
  `vid` smallint(5) unsigned NOT NULL,
  `voted` text  COLLATE utf8mb4_unicode_ci,
  UNIQUE KEY `vid` (`vid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;