<!-- BEGIN: main -->
<script type="text/javascript" src="{NV_STATIC_URL}themes/default/images/{MODULE_FILE}/jquery.ez-plus.js"></script>
<div class="product-detail <!-- BEGIN: popupid -->prodetail-popup<!-- END: popupid -->" itemtype="http://schema.org/Product" itemscope>
    <span class="d-none hidden hide" itemprop="mpn" content="{PRODUCT_CODE}"></span>
    <span class="d-none hidden hide" itemprop="sku" content="{PRODUCT_CODE}"></span>
    <div class="d-none hidden hide" itemprop="brand" itemtype="http://schema.org/Thing" itemscope>
        <span itemprop="name">N/A</span>
    </div>
    <!-- BEGIN: allowed_rating_snippets -->
    <div class="d-none hidden hide" itemprop="aggregateRating" itemtype="http://schema.org/AggregateRating" itemscope>
        <span itemprop="reviewCount">{RATE_TOTAL}</span>
        <span itemprop="ratingValue">{RATE_VALUE}</span>
    </div>
    <!-- END: allowed_rating_snippets -->
    <div class="d-none hidden hide" itemprop="offers" itemtype="http://schema.org/Offer" itemscope>
        <!-- BEGIN: price1 -->
        <span itemprop="price">{PRICE.sale}</span>
        <span itemprop="priceCurrency">{PRICE.unit}</span>
        <!-- END: price1 -->
        <a itemprop="url" href="{PRO_FULL_LINK}"></a>
        <span itemprop="priceValidUntil">{PRICEVALIDUNTIL}</span>
        <span itemprop="availability">{AVAILABILITY}</span>
    </div>
    <div class="panel panel-default panel-product-info">
        <div class="panel-body">
            <div class="row">
                <div class="col-xs-24 col-sm-10 col-md-10 text-center">
                    <!-- BEGIN: oneimage -->
                    <div class="product-one-image mb-2">
                        <img itemprop="image" src="{IMAGE.file}" alt="{DATA.homeimgalt}" id="product-image-one-view">
                    </div>
                    <script type="text/javascript">
                    $(document).ready(function() {
                        $('#product-image-one-view').ezPlus({
                            scrollZoom: true,
                            containLensZoom: true
                        });
                    });
                    </script>
                    <!-- END: oneimage -->
                    <!-- BEGIN: image -->
                    <div class="product-image-gallery mb-2">
                        <div class="gallery-view">
                            <div class="gallery-view-inner owl-carousel" id="product-image-gallery-view">
                                <!-- BEGIN: loop -->
                                <div class="item" data-item="{IMAGE_STT}">
                                    <div class="item-inner">
                                        <img itemprop="image" src="{IMAGE.file}" alt="{DATA.homeimgalt}" data-zoom-image="{IMAGE.file}">
                                    </div>
                                </div>
                                <!-- END: loop -->
                            </div>
                        </div>
                        <div class="gallery-nav owl-carousel" id="product-image-gallery-nav">
                            <!-- BEGIN: loop1 -->
                            <div class="item<!-- BEGIN: active --> active<!-- END: active -->" data-item="{IMAGE_STT}">
                                <div class="item-inner">
                                    <a href="#" class="item-click-change" data-offset="{IMAGE_STT}"><img src="{IMAGE.thumb}" alt="{DATA.homeimgalt} thumb"></a>
                                </div>
                            </div>
                            <!-- END: loop1 -->
                        </div>
                    </div>
                    <link rel="stylesheet" href="{NV_STATIC_URL}themes/default/images/{MODULE_FILE}/OwlCarousel2/assets/owl.carousel.min.css">
                    <script type="text/javascript" src="{NV_STATIC_URL}themes/default/images/{MODULE_FILE}/OwlCarousel2/owl.carousel.min.js"></script>
                    <script type="text/javascript">
                    $(document).ready(function() {
                        // Slide ảnh sản phẩm
                        var owlView = $('#product-image-gallery-view');
                        var owlNav = $('#product-image-gallery-nav');
                        owlView.owlCarousel({
                            items: 1,
                            nav: true,
                            navText: ['<span><i class="fa fa-angle-left" aria-hidden="true"></i></span>', '<span><i class="fa fa-angle-right" aria-hidden="true"></i></span>'],
                            dots: false,
                            lazyLoad: true,
                            autoplay: false,
                            margin: 5
                        });
                        owlNav.owlCarousel({
                            nav: false,
                            dots: false,
                            autoplay: false,
                            items: 5,
                            margin: 5
                        });
                        owlView.on('changed.owl.carousel', function(e) {
                            $('.item', owlNav).removeClass('active');
                            $('[data-item="' + e.item.index + '"]', owlNav).addClass('active');
                            $('[data-item="' + e.item.index + '"]', owlView).find('img').ezPlus({
                                zIndex: 9,
                                zoomContainerAppendTo: owlView,
                                scrollZoom: true,
                                containLensZoom: true
                            });
                        });
                        $('.item-click-change', owlNav).on('click', function(e) {
                            e.preventDefault();
                            owlView.trigger('to.owl.carousel', [$(this).data('offset'), 300]);
                        });
                        // Zoom ảnh đầu tiên
                        $('[data-item="0"]', owlView).find('img').ezPlus({
                            zIndex: 9,
                            zoomContainerAppendTo: owlView,
                            scrollZoom: true,
                            containLensZoom: true
                        });
                    });
                    </script>
                    <!-- END: image -->
                    <!-- BEGIN: adminlink -->
                    <div class="admin-links margin-bottom mb-2">{ADMINLINK}</div>
                    <!-- END: adminlink -->
                    <!-- BEGIN: social_icon -->
                    <div class="panel panel-default socialicon-wrap">
                        <div class="panel-body">
                            <div class="socialicon">
                                <div class="fb-like" data-href="{SELFURL}" data-layout="button_count" data-action="like" data-show-faces="false" data-share="true">&nbsp;</div>
                                <a href="http://twitter.com/share" class="twitter-share-button">Tweet</a>
                            </div>
                        </div>
                    </div>
                    <!-- END: social_icon -->
                </div>
                <div class="col-xs-24 col-sm-14 col-md-14">
                    <ul class="product-info">
                        <li class="info-title"><h1 itemprop="name">{TITLE}</h1></li>
                        <li class="info-meta text-muted">{DATE_UP} - {NUM_VIEW} {LANG.detail_num_view}</li>
                        <!-- BEGIN: product_code -->
                        <li class="info-code">{LANG.product_code}: <strong>{PRODUCT_CODE}</strong></li>
                        <!-- END: product_code -->
                        <!-- BEGIN: price -->
                        <li class="info-price">
                            <!-- BEGIN: discounts -->
                            <span class="money">{PRICE.sale_format} {PRICE.unit}</span> <span class="discounts_money">{PRICE.price_format} {PRICE.unit}</span> <span class="money">{product_discounts} {money_unit}</span>
                            <!-- END: discounts -->
                            <!-- BEGIN: no_discounts -->
                            <span class="money">{PRICE.price_format} {PRICE.unit}</span>
                            <!-- END: no_discounts -->
                        </li>
                        <!-- END: price -->
                        <!-- BEGIN: product_weight -->
                        <li class="info-weight">{LANG.weights}: <strong>{PRODUCT_WEIGHT}</strong>&nbsp<span>{WEIGHT_UNIT}</span></li>
                        <!-- END: product_weight -->
                        <!-- BEGIN: contact -->
                        <li class="info-priceno">{LANG.detail_pro_price}: <span class="money">{LANG.price_contact}</span></li>
                        <!-- END: contact -->
                        <!-- BEGIN: group_detail -->
                        <li class="info-groups">
                            <!-- BEGIN: loop --> <!-- BEGIN: maintitle -->
                            <div class="pull-left">
                                <strong>{MAINTITLE}:</strong>&nbsp;
                            </div> <!-- END: maintitle --> <!-- BEGIN: subtitle -->
                            <ul class="pull-left list-inline" style="padding: 0 10px 0">
                                <!-- BEGIN: loop -->
                                <li>{SUBTITLE.title}</li>
                                <!-- END: loop -->
                            </ul>
                            <div class="clear"></div> <!-- END: subtitle --> <!-- END: loop -->
                        </li>
                        <!-- END: group_detail -->
                        <!-- BEGIN: custom_data -->
                        <div class="info-customs">{CUSTOM_DATA}</div>
                        <!-- END: custom_data -->
                        <!-- BEGIN: hometext -->
                        <li class="info-hometext">
                            <p class="text-justify" itemprop="description">{hometext}</p>
                        </li>
                        <!-- END: hometext -->
                        <!-- BEGIN: promotional -->
                        <li class="info-promotion"><strong>{LANG.detail_promotional}:</strong> {promotional}</li>
                        <!-- END: promotional -->
                        <!-- BEGIN: warranty -->
                        <li class="info-warranty"><strong>{LANG.detail_warranty}:</strong> {warranty}</li>
                        <!-- END: warranty -->
                    </ul>
                    <hr />
                    <!-- BEGIN: gift -->
                    <div class="alert alert-info pro-gift">
                        <div class="pull-left">
                            <em class="fa fa-gift fa-3x">&nbsp;</em>
                        </div>
                        <div class="pull-left">
                            <h4>{gift_content}</h4>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <!-- END: gift -->

                    <div class="alert alert-info alert-detail">
                        <div>
                            <h4>Ưu đãi cho bạn</h4>
                        </div>
                        <ul>
                            <li>Giảm giá khi mua số lượng lớn</li>
                            <li>Giảm giá cho cơ quan, doanh nghiệp</li>
                            <li>Tuyển CTV, Đại lý trên cả nước</li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <!-- BEGIN: group -->
                    <div class="well pro-group-lists">
                        <div class="filter_product">
                            <!-- BEGIN: items -->
                            <div class="row">
                                <!-- BEGIN: header -->
                                <div class="col-xs-8 col-sm-5" style="margin-top: 4px">{HEADER}</div>
                                <!-- END: header -->
                                <div class="col-xs-16 col-sm-19 itemsgroup" data-groupid="{GROUPID}" data-header="{HEADER}">
                                    <!-- BEGIN: loop -->
                                    <label class="label_group <!-- BEGIN: active -->active<!-- END: active -->"> <input type="radio" class="groupid" onclick="check_quantity( $(this) )" name="groupid[{GROUPID}]" value="{GROUP.groupid}"
                                    <!-- BEGIN: checked -->checked="checked" <!-- END: checked -->>{GROUP.title}
                                    </label>
                                    <!-- END: loop -->
                                </div>
                            </div>
                            <!-- END: items -->
                        </div>
                        <span id="group_error">&nbsp;</span>
                    </div>
                    <!-- END: group -->
                    <div class="row">
                        <!-- BEGIN: order_number -->
                        <div class="well order-number pull-left">
                            <div class="row">
                                <!--<div class="col-xs-8 col-sm-5">{LANG.detail_pro_number}</div>-->
                                <div class="col-xs-16 col-sm-19 col-md-24">
                                    <input type="number" name="num" value="1" min="1" id="pnum" class="pull-left form-control" style="width: 70px; margin-right: 5px">
                                    <!-- BEGIN: product_number -->
                                    <span class="help-block pull-left" id="product_number"> {pro_unit} </span>
                                    <!-- END: product_number -->
                                </div>
                            </div>
                        </div>
                        <!-- END: order_number -->
                        &nbsp;
                        <!-- BEGIN: order -->
                        <button class="btn btn-danger btn-order btn-order-cart btn-lg" data-id="{proid}" onclick="cartorder_detail(this, {POPUP}, 0); return !1;">
                            <i class="fa fa-shopping-cart fa-lg"></i> {LANG.add_cart}
                        </button>
                        <button class="btn btn-success btn-order btn-order-buy btn-lg" data-id="{proid}" onclick="cartorder_detail(this, {POPUP}, 1); return !1;">
                            <i class="fa fa-paper-plane-o fa-lg"></i> {LANG.buy_now}
                        </button>
                        <!-- END: order -->
                        <!-- BEGIN: product_empty -->
                        <button class="btn btn-danger disabled">{LANG.product_empty}</button>
                        <!-- END: product_empty -->
                    </div>
                    <div class="clearfix"></div>
                    <!-- BEGIN: typepeice -->
                    <table class="table table-striped table-bordered table-hover type-peice">
                        <thead>
                            <tr>
                                <th class="text-right">{LANG.detail_pro_number}</th>
                                <th class="text-left">{LANG.cart_price} ({money_unit})</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- BEGIN: items -->
                            <tr>
                                <td class="text-right">{ITEMS.number_from} -> {ITEMS.number_to}</td>
                                <td class="text-left">{ITEMS.price}</td>
                            </tr>
                            <!-- END: items -->
                        </tbody>
                    </table>
                    <!-- END: typepeice -->
                    <div class="text-center">
                    </div>
                    <br>
                    <div class="text-center">
                        <a href="tel:0336050020" class="btn bg-main no-borderr btn-padding"><i class="fa fa-phone"></i> HOTLINE: 0336.050.020</a>
                        <a href="https://www.messenger.com/t/tancuonghoangdat" class="btn btn-primary no-borderr btn-padding"><i class="fa fa-facebook"></i> CHAT FACEBOOK</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- BEGIN: product_detail -->
    <!-- BEGIN: tabs -->
    <div role="tabpanel" class="tabs">
        <ul class="nav nav-tabs" role="tablist">
            <!-- BEGIN: tabs_title -->
            <li role="presentation"
                <!-- BEGIN: active -->class="active"<!-- END: active -->> <a href="#{TABS_KEY}-{TABS_ID}" aria-controls="{TABS_KEY}-{TABS_ID}" role="tab" data-toggle="tab"> <!-- BEGIN: icon --> <img src="{TABS_ICON}" /> <!-- END: icon -->  <span>{TABS_TITLE}</span>
            </a>
            </li>
            <!-- END: tabs_title -->
        </ul>
        <div class="tab-content">
            <!-- BEGIN: tabs_content -->
            <div role="tabpanel" class="tab-pane fade <!-- BEGIN: active -->active in<!-- END: active -->" id="{TABS_KEY}-{TABS_ID}">{TABS_CONTENT}</div>
            <!-- END: tabs_content -->
        </div>
    </div>
    <!-- END: tabs -->
    <!-- BEGIN: keywords -->
    <div class="panel panel-default panel-product-keywords">
        <div class="panel-body">
            <div class="keywords">
                <em class="fa fa-tags">&nbsp;</em><strong>{LANG.keywords}: </strong>
                <!-- BEGIN: loop -->
                <a title="{KEYWORD}" href="{LINK_KEYWORDS}" rel="dofollow"><em>{KEYWORD}</em></a>{SLASH}
                <!-- END: loop -->
            </div>
        </div>
    </div>
    <!-- END: keywords -->
    <!-- BEGIN: other -->
    <div class="panel panel-default panel-product-others">
        <div class="panel-heading"><h3 class="cat-title"><a href="#"><img src="{NV_STATIC_URL}themes/default/images/la-che-thai-nguyen.png" /> {LANG.detail_others}</a></h3></div>
        <div class="panel-body">{OTHER}</div>
    </div>
    <!-- END: other -->
    <!-- BEGIN: other_view -->
    <div class="panel panel-default panel-product-viewed">
        <div class="panel-heading"><h3 class="cat-title"><a href="#"><img src="{NV_STATIC_URL}themes/default/images/la-che-thai-nguyen.png" /> {LANG.detail_others_view}</a></h3></div>
        <div class="panel-body">{OTHER_VIEW}</div>
    </div>
    <!-- END: other_view -->
    <!-- END: product_detail -->
</div>
<div class="modal fade" id="idmodals" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                &nbsp;
            </div>
            <div class="modal-body">
                <p class="text-center">
                    <em class="fa fa-spinner fa-spin fa-3x">&nbsp;</em>
                </p>
            </div>
        </div>
    </div>
</div>
<!-- BEGIN: allowed_print_js -->
<script type="text/javascript" data-show="after">
    $(function() {
        $('#click_print').click(function(event) {
            var href = $(this).attr("href");
            event.preventDefault();
            nv_open_browse(href, '', 640, 500, 'resizable=no,scrollbars=yes,toolbar=no,location=no,status=no');
            return false;
        });
    });
</script>
<!-- END: allowed_print_js -->
<!-- BEGIN: imagemodal -->
<script type="text/javascript" data-show="after">
    $('.open_modal').click(function(e){
        e.preventDefault();
         $('#idmodals .modal-body').html( '<img src="' + $(this).data('src') + '" alt="" class="img-responsive" />' );
         $('#idmodals').modal('show');
    });
</script>
<!-- END: imagemodal -->
<!-- BEGIN: order_number_limit -->
<script type="text/javascript" data-show="after">
    $('#pnum').attr( 'max', '{PRODUCT_NUMBER}' );
    $('#pnum').change(function(){
        if( intval($(this).val()) > intval($(this).attr('max')) ){
            alert('{LANG.detail_error_number} ' + $(this).attr('max') );
            $(this).val( $(this).attr('max') );
        }
    });
</script>
<!-- END: order_number_limit -->
<script type="text/javascript">
var detail_error_group = '{LANG.detail_error_group}';
function check_quantity(_this) {
    $('input[name="'+_this.attr('name')+'"]').parent().css('border-color', '#ccc');
    if (_this.is(':checked')) {
        _this.parent().css('border-color', 'blue');
    }
    $('#group_error').css( 'display', 'none' );
    <!-- BEGIN: check_price -->
    check_price( '{proid}', '{pro_unit}' );
    <!-- END: check_price -->
    resize_popup();
}
$(document).ready(function() {
    // Chọn ngay nhóm sản phẩm đầu tiên nếu có 1 nhóm mỗi loại
    var itemsgroup = $('.itemsgroup');
    itemsgroup.each(function() {
        var item = $(this);
        var radio = $('[type="radio"]', item);
        if (radio.length == 1) {
            radio.trigger('click');
        }
    });
});
</script>
<!-- BEGIN: popup -->
<script type="text/javascript">
$(window).on('load', function() {
    setTimeout(function() {
        resize_popup();
    }, 300);
});
</script>
<!-- END: popup -->
<!-- END: main -->
